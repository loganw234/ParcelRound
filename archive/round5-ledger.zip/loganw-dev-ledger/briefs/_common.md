# What every brief shares

This section goes at the top of every brief. The lead fills in `<P>` and the
base SHA when it dispatches.

---

You are parcel **<P>** in `loganw.dev`, Logan W.'s personal site. You work in
a git worktree of `C:\Users\logan\source\repos\loganw.dev` that the harness
made for you.

**Check your base first.** It is main at or after `<base SHA>`; the dispatch
message gives the exact commit.

1. Run `git log --oneline -1`.
2. If that isn't the base commit, run `git merge --ff-only <base SHA>` and
   check again.
3. If the merge fails, write to `urgent/` and stop.

The harness creates a worktree from the session's HEAD, which may not be
main.

**The site's one promise:**

> **No figure appears on a page unless it was read from a source (a
> repository at a pinned commit, the GitHub snapshot, or this site's own
> ledger), or is marked as someone's word ("stated"), with who and when.**

That works in five parts (all since P0.1; verifier-P0 broke the first
version with a plain string and with `dataclasses.replace`):

- every figure passes through `@fact` (`site/facts.py`);
- `render.fig()` prints a figure only if it is exactly what its fact returned,
  and marks it with that fact's id (`data-f`). In SVG text, use
  `render.mark()`; in a text twin, use `render.plain()`, which writes
  `text [fact N]`;
- the `numbers` stage refuses any numeral on a page outside a mark, any
  number word it lists ("seven", "twenty"), and any mark whose text isn't its
  own fact's. It reads alt and title text, and the strings in stylesheets
  too. A name with a numeral in it that is not a figure, such as "Mercenaries
  2", is allowed only through `site/data/numeral_names.json`, which is the
  lead's: ask in `urgent/`. The name must also appear in some fact's text;
- `public/facts.json` lists every figure;
- `python site/build.py --verify-facts` reads each one again: at its pin,
  from the committed snapshot (a snapshot figure is only as good as that
  file, and its label dates it), or from this site's own ledger in the
  checkout.

Every sentence on your pages that states a fact about a project has to be one
of three things:

- **a quotation** read at its pin, through `facts.prose` (or, for this
  site's own history, from its ledger through `facts.own_prose`). Its
  pattern must match exactly once, or it is refused; `last=True` asks for
  the last match.
- **a paraphrase**, through `facts.prose(..., display=...)`. The page prints
  the source's own words beside it, and the build refuses a display with a
  numeral those words don't have. Whether it keeps their meaning is checked
  by no gate, so keep it close.
- **stated**: someone's word, through `facts.stated(text, who, when)`. Both
  are required. A statement about a repository takes
  `holds_at={name: commit}`, and it refuses the build when that pin moves.
  Words you draft for Logan take `draft=True`; the label says so until Logan
  approves them.

Connective prose that states no fact is fine. **If you can't find where a
fact comes from, leave it out.**

## Start here

1. `CLAUDE.md`, all of it. These are the traps that have already cost time.
2. `README.md`, and `docs/SPEC.md`: the spec, Logan's decisions, and the
   definitions. Then `docs/ROUND1.md`, all of it, then your section.
3. The code you'll build on:
   - `site/pages/__init__.py`: the page contract (sections, extra files,
     `controls()`);
   - `site/pages/home.py`: how a page is written;
   - `site/facts.py`: the facts, the pins, and the ledger parser;
   - `site/render.py`: the page shell, and how a figure prints.
4. HonestFramework's METHOD.md §3, read at the site's pin:
   `git -C C:/Users/logan/source/repos/HonestFramework show 65447fd:METHOD.md`.
   **A gate you haven't watched fail is not a gate.**

## The ledger

It lives at `C:\Users\logan\source\repos\loganw-dev-ledger\`, and its
`README.md` has the rules. Your file is `<P>.md`.

- **Read every file there** at three moments: before you start; before you
  design anything that touches a file this brief calls shared or forbidden;
  and before you write your report.
- **Before anything else, create your file `<P>.md` with a timestamped
  entry, and arm a watch on `urgent/`,** inline, with the loop in the README.
  Re-arm it when it expires, and do a full read each time. In wave 1 one
  parcel was 45 minutes in with neither, and the lead had to ask.
- **Questions for the lead go in `urgent/`.** Everything else goes in your
  own file.
- **Timestamps come from `date`.** Never type one.
- **If you spawn a subagent,** say so in your file when you dispatch it, and
  don't finish while it's running.
- **If a pause is announced,** write down exactly where you are.

## Your scratch directory

Use
`C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-loganw-dev\346a5f1b-6920-410b-b630-a756bb781e84\scratchpad\<P>\`
for anything outside your worktree. Work nowhere else. No secret lives in any
directory you are given.

## Building and testing, verbatim

    export LOGANW_REPOS=C:/Users/logan/source/repos   # the pinned clones (a worktree's parent is not that directory)
    export LOGANW_FETCH=1                             # once: fetches the organisation's four pins into this worktree's .cache/
    python site/build.py                              # writes public/; commit public/ with your change
    bash verify/run.sh --require-all                  # the gate, every stage (--list prints them); read the log, not the exit code
    python site/build.py --control                    # every planted fault, including your page's controls()

`--require-all` refuses `--only` and `--skip`, and `--resume` refuses a dirty
tree. Use `--only` while you work, then run the whole gate before you report.
The `privacy` stage uses Logan's `gh` login to list private repository names.
If it can't here, it skips by name, and under `--require-all` that is a
failure. Report it; don't work around it.

- **Read other repositories only at their pins**, with `git show <sha>:<path>`
  through `facts.pin(...)`.
- **Never read or touch a working tree.** Another session is running a round
  in `cft-fp256`.
- **Never fetch into Logan's clones.**
- **Never pipe a long command through `| head`.** Write to a file, then read
  the file.

## Seams: yours to use, not to edit

| file | owner |
|---|---|
| `site/facts.py` | the lead |
| `site/render.py` | the lead |
| `site/build.py`, `verify/run.sh` | the lead |
| `site/pages/__init__.py` (the page contract) | the lead |
| `site/style.css` | the lead |
| `pins.json` | the lead |
| `sources/` | the lead |
| `site/pages/home.py` | the lead |
| `site/mapgen.py`, `site/data/relations.json` | P2, and only P2 |
| `docs/*`, `README.md`, `CLAUDE.md` | the lead: they state the site's claims, in one voice |

- **Adding a page, a stylesheet or a fact edits no shared file.** Pages and
  stylesheets are found by glob, and a fact goes in your own module with
  `@fact`.
- **If you need a seam changed, or a pin added, ask in `urgent/`.** Don't
  edit it.
- **A boundary you have to cross is expected and fine**, as long as you say
  so and say why. Crossing one silently is not.

## Working rules this repository learned the hard way

- **Count commits, not trailer lines.** Merc2Reborn has 20 agent commits but
  21 trailer lines.
- **A count over a fork's history counts its parent's commits.** A fork gets
  a dash, and the reason.
- **Links must be relative, and pages flat.** Every page is published beside
  `index.html`. Link to a page only if it is built (`ctx["built"]`); the links
  check refuses a link to an unpublished page.
- **A quantifier, a unit and a domain are claims too.** "Every", "all", "the
  only" and "per" each need their source to say so.
- **A date names its calendar.** Git dates are the author's own day; the
  API's are UTC. `Pin.local()` converts an API time to the pinned commit's
  author's calendar, which is how "last verified" is dated.
- **Every element and attribute on a page is on an allowlist**
  (`build.ALLOWED`), and every page carries a Content-Security-Policy. An
  element you need that isn't on the list is a seam change: ask in `urgent/`.
- **No published file holds an email address,** except the site's contact,
  `logan@loganw.dev`. That includes facts.json's arguments. Identify a
  commit's author by GitHub login, or by a hash of the address.
- **The site's own history is read from its own ledger,**
  `docs/VALIDATION.md`, through `facts.own_prose()` (a pattern that matches
  once; it has no `last=`) and `facts.own_entry()` (an entry by its
  heading's whole text, the words after `## `). A commit of the site's own, cited as a fix, goes through
  `facts.own_commit()`, which refuses one that main doesn't hold. The ledger
  is the lead's: never edit it. If a page needs an entry that isn't there,
  ask in `urgent/`.
- **Pages are held to a subset of HTML that a browser reads the same way**
  (`build.PARENTS`). local-only names each refusal.
  - Nesting is strict, and each element stands only where HTML allows it:
    a table row inside `thead` or `tbody`, a cell inside a row.
  - Text goes only where a browser draws it. No self-closed HTML element,
    and no comment.
  - A stylesheet may hold only the strings `build.CSS_STRINGS` lists. For
    another, ask in `urgent/`.
  - An image is a PNG. No published file may hold a character a browser
    draws as nothing, such as a soft hyphen or a zero-width space.
- **Logan's pronouns haven't been stated.** Write "Logan", never "he" or
  "she", on a page, in a comment, and in the ledger. The same goes for
  every other person the site names.
- **Every sentence a page states needs its source.** A sentence with no
  figure in it is still a claim. In wave 1 this was the most common defect a
  verifier found: a sentence that no fact, `prose()` quote or `stated()` line
  backed.
- **A stylesheet may not hide what it styles.** The numbers stage refuses
  `display:none`, zero opacity or size, transparent text, clipping and the
  like, unless `site/data/css_hides.json` names the selector. That file is
  the lead's. If a layout needs one view hidden for another, ask in
  `urgent/`, giving each selector, the declaration it needs (such as
  `display:none`), and why. An entry allows only the declaration it names.

## Negative controls, and what READY means

- **Your page's controls go in `controls()`**, returning
  `[(name, caught, how)]`. `caught` is True only when your check said no.
- **Build each control, run it, and watch it fail.** Report both results.
  A control that is described but never run is worth nothing.
- **A control is named by the property that makes it bite.** Pick a plant
  your check can see; a plant in a region the check never reads proves
  nothing.
- **A control exercises every branch of the property it names.** In wave 1,
  a credits-grouping control never exercised case-folding, and a one-token
  change to that branch passed it while breaking the page.
- **A control plants in a copy, never in `public/` itself.**
- **READY means** every property your pages claim is held by a gate you have
  watched fail, or is stated as a limit on the page that makes the claim.

## Do not

- push, merge, rebase onto anything but the base, or commit to main;
- weaken a check to make something pass;
- "fix" anything outside your scope. Report it instead.

## Report

- **What you changed**, file by file.
- **The gate's output:** the actual lines.
- **Your controls**, with their output, watched failing.
- **Anything this brief got wrong.**
- **Every boundary you crossed**, and why.
- **Every subagent you spawned**, and its result.
- **A side-notes list:** anything outside your scope you noticed.

If you hit something that makes the approach unworkable, stop and report it,
rather than inventing a different design.
