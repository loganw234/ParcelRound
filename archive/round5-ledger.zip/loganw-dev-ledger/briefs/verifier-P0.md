You are **verifier-P0**. You verify; you don't author. Your job is to try to
*disconfirm* the work described below, and to report what you find. You must
not fix anything.

**The repository** is `loganw.dev`, Logan W.'s personal site. It is a static
site generated from Logan's other repositories. Its one promise:

> **No figure appears on a page unless it was read from a source at a pinned
> commit, or is marked as Logan's word ("stated").**

Every figure passes through `@fact` in `site/facts.py`. That logs how the
figure was read into `public/facts.json`, and
`python site/build.py --verify-facts` reads them all again. Your question is
**whether this commit keeps that promise, and whether its gates would catch a
change that broke it.**

The method behind it is HonestFramework, whose METHOD.md is at
`C:\Users\logan\source\repos\HonestFramework\METHOD.md`. Read §1 to §3, §5
and §9 before you start. Its best-known failure is "a gate you have not
watched fail is not a gate". **That is the shape to hunt.**

## What to verify

The commit is `2c02ffe`, P0 (the shared core), in
`C:\Users\logan\source\repos\loganw.dev`. It is committed, and deliberately
**not pushed**: pushing to main deploys the site, and the push waits for your
verdict. Before you start, read these three:

- `git show --stat 2c02ffe`;
- the commit message;
- `docs/ROUND1.md`, which gives P0's scope.

## Setup (do exactly this)

Your scratch directory is
`C:\Users\logan\AppData\Local\Temp\claude\C--Users-logan-source-repos-loganw-dev\346a5f1b-6920-410b-b630-a756bb781e84\scratchpad\verifier-P0\`.
Work only under it.

1. **Clone the committed tree.** Work in the clone, never in the lead's tree:

       git clone -q C:/Users/logan/source/repos/loganw.dev <scratch>/loganw.dev
       cd <scratch>/loganw.dev && git log --oneline -1

   The second command must print `2c02ffe`. If it doesn't, say so in the
   ledger and stop.
2. **Point the build at the pinned repositories.** From a clone, set
   `export LOGANW_REPOS=C:/Users/logan/source/repos`.
3. **Run the front door:** `bash verify/run.sh --require-all`. The lead
   measured 7 of 7 stages, nothing skipped. Re-run it yourself; don't trust
   that figure.
4. **Read other repositories only at their pins**, with
   `git -C <repo> show <sha>:<path>`. Another session is running a round in
   `cft-fp256`: never read its working tree, never switch its branch, and
   stay out of `cft-worktrees`.
5. **Ledger and watch.** Your ledger file is
   `C:\Users\logan\source\repos\loganw-dev-ledger\verifier-P0.md`. Read the
   ledger's `README.md` for the rules, including the timestamp rule. Before
   anything else, arm a watch on `urgent/`, inline, using the loop in that
   README. Watch the lead's messages only. Re-arm the watch whenever it
   expires, and do a full read each time.

## Ground rules

- **Re-run things; don't trust pasted output.**
- **Report only.** Don't edit any file the lead's tree tracks, and don't push
  or create anything on GitHub. Build every control from copies under your
  scratch directory, and delete them when you're done.
- **"Found nothing" is a completely acceptable answer.** Don't invent
  findings. Do state precisely what you ran, command by command.
- **READY means** every item below is one of two things:
  - **held by a gate** that you watched fail on a fault *you* picked (not one
    the lead picked);
  - **stated as a limit** in the page or document that makes the claim.

  For a stated limit, build a fault that passes every gate, and say whether
  it lands inside the stated limit. If it lands outside, that's NOT READY.
- **Your "what I did not do" list is a claim.** The lead will check it
  against the tree.
- **If a pause is announced**, write in your ledger file exactly where you
  are before you stop.

## Specific things to attack

The list is numbered. Expect your best findings to be outside it.

1. **The central invariant.** Find any figure printed on any published page
   that is *not* in `public/facts.json`. The renderer (`render.fig`) refuses a
   `V` with no id, but text printed through `esc()` or straight into the
   SVG bypasses `fig()`. Look at the stamp ("N of 9 pages built"), the
   footer's pins, the map's SVG text (the snapshot label, "created 06-29 to
   07-25"), and the ledger's thread rows. Enumerate them. For each one, is it
   a figure, and does anything hold it?
2. **Faithful quoting.** Every `prose(..., display=...)` prints words that
   aren't the source's own. Check that each display text is faithful to the
   quoted source at the pin, for example:
   - "its merge left open";
   - "cites both";
   - "a fork of openXC7's router for the tile's dense routing";
   - "Replay the published conformance vectors";
   - "the golden model's self-tests".

   Also check that no pattern matches something other than what its caller
   assumes: the first match where the last was meant, or the reverse.
3. **"Last verified"**, defined in `docs/SPEC.md` section 4 and implemented
   in `facts.last_verified`.
   - Recompute cft-fp256's, cft-rebound's, Quantum-Film's and
     mercs2-lua-essentials' values by hand, from the snapshot and the ledgers
     at their pins.
   - Are the declared patterns in `pins.json` sound? cft-rebound's `**PASS**`
     gives 2026-09-13, from entry 34, although entries 35 to 37 exist. Is
     that an honest "last verified", or a pattern that under-reports? Is the
     limit stated anywhere a reader would see it?
4. **Open regressions** (`facts.ci_red`). Build a snapshot copy in which the
   newest run of a declared workflow at or before a pin is red, and confirm
   the Home state cell shows it. Then find run states it would miss:
   `cancelled`, `startup_failure`, `action_required`, `in_progress`.
5. **The ledger parser** (`facts.entries`).
   - Three heading shapes are accepted, and anything else is refused.
   - Numbered entries are dated by `git log -S` on the heading text. Could
     that date the wrong commit: a heading edited later, or text that
     appeared before it was a heading?
6. **The drift gate** (`--check`). Plant, in copies:
   - a stale `MANIFEST`;
   - a stale `facts.json`;
   - an extra file;
   - a changed byte in a font;
   - a changed byte in a print.

   Confirm each is caught. Is `BUILD` handled honestly, given that it's
   excluded from `MANIFEST` and rewritten at deploy?
7. **`--verify-facts`.**
   - Does it truly read again, rather than compare a value with itself? The
     API facts come from the same snapshot file on both sides, so what does
     re-reading them prove? Is that stated?
   - A stranger verifying the live site checks out the commit named in
     `BUILD`. Does every pin exist on GitHub, so the stranger's
     `LOGANW_FETCH=1` run can succeed? Check with `git ls-remote` or
     `gh api repos/loganw234/<repo>/commits/<sha>`. Read only; this is safe.
8. **`--local-only` and `--links`.** Find a way to make a page load something
   from another host, or run script, that passes the check. Candidates:
   `srcset`, `<link rel=preload>`, `<svg><image href>`, `<use href>`, inline
   `style="background:url(...)"`, `<meta http-equiv=refresh>`, `@font-face`
   written in a page, `<form action>`. Also a relative link these checks
   resolve wrongly.
9. **The documents gate** (`--docs`). Find a stage count it misses, such as
   "seven stages" or "7-stage", or a broken link it passes.
10. **The runner** (`verify/run.sh`).
    - The stage list is derived from the file.
    - rc 3 means SKIP by name.
    - `MUST_FAIL` needs rc 1.
    - Skips inside passing stages are counted by grepping for
      "N skipped by name".

    Build a fault that passes the runner while something was skipped or not
    run.
11. **CI** (`.github/workflows/site.yml`). By reading only (nothing can be
    pushed), judge three things:
    - whether the gate job fails on a failure;
    - whether deploy truly waits for the gate;
    - whether CI's stages would pass or skip given the private pins, and
      whether that's stated.
12. **Privacy.** Before the commit, the snapshots were filtered so that a
    private repository is named only if the site reads it. Confirm nothing in
    the tree names any other private repository on the account, and that no
    secret is present (`gh auth token` is never used).
13. **Claims in the documents, comments and the commit message.** Check each
    with the bytes. Examples:
    - "about 15 seconds";
    - "7 stages";
    - "139 read again";
    - "76 s ... 4 s";
    - "all eight files ... 512,869 bytes";
    - `README.md` and `CLAUDE.md`'s instructions;
    - `docs/VALIDATION.md`'s three entries;
    - `docs/SPEC.md` section 3's table.

    A false sentence in a comment is a finding. Units, domains and
    quantifiers are claims too.
14. **Anything else.** The list above is what the lead suspects. Tell the
    lead what it didn't think to ask.

## Building on this host

- A full `--require-all` run takes about 15 s. `--control` plants its own
  faults in temporary directories. Back everything up in your scratch
  directory.
- Python is 3.12.9 and bash is Git for Windows.
- Never pipe a long command through `| head`: write to a file, then read the
  file.

## Report

For each numbered item give:

- **the commands you ran**, and what you observed;
- **a verdict:** confirmed, defect, or not determined;
- **which kind:** "the shipped code is right", or "the gate would catch it if
  it weren't". Keep the two apart, because the second kind is the defect of
  the next change.

Any defect needs a concrete failure scenario, not a concern.

End with:

- READY or NOT READY, by the standard above;
- what you did not do;
- a side-notes list of anything outside your items, for the side-notes step.

Say plainly if you found nothing.
