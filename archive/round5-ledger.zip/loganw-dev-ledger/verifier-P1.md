# verifier-P1

## 2026-09-29 20:34:35 -0700 - setup: clone at d474080 confirmed; watch armed; full reading done; front door reproduced

Measured:
- Watch on `urgent/` armed inline (the loop from the README) before cloning
  anything; re-checked the whole ledger directory (lead.md, P2.md,
  verifier-P0.md, urgent/*, briefs/*) before starting, and again just before
  writing this entry. Nothing addressed to verifier-P1 beyond the lead's
  20:14:23 dispatch entry (which flags `verify.py`'s `import build` for me
  to check). The four `urgent/` files are all pre-dating P2 traffic.
- Read in full: `briefs/verifier-parcel.md`, `briefs/_common.md`,
  `briefs/P1.md`, `P1.md`, `lead.md`, `P2.md`, `verifier-P0.md`,
  `HonestFramework/METHOD.md` sections 1-3, 5 and 9.
- Cloned the lead's tree to my scratch (`.../scratchpad/verifier-P1/loganw.dev`),
  `git checkout -q d474080`: `git log --oneline -1` printed
  `d474080 P1: Record and Verify pages, merged from the ledger parser and
  cft-fp256's own docs` (full `d4740804db788c654a0f5250a295414087d472f5`).
- `LOGANW_REPOS=C:/Users/logan/source/repos LOGANW_FETCH=1 bash verify/run.sh
  --require-all` on this fresh clone: **11 passed, 0 failed, 0 skipped.
  VERDICT: PASS, nothing skipped.** facts: 656 read again and the same, 0
  different, 7 stated. numbers: 0 problems, 1198 marks in 19 files. controls:
  171 caught, 0 did not fail, 0 skipped. Every one of P1's reported counts is
  reproduced exactly, from a clean checkout, by me.
- `git diff --stat 86d31be d474080`: only `public/MANIFEST`, `public/facts.json`,
  `public/index.html`, `public/record.html`, `public/verify.html`,
  `site/pages/record.py`, `site/pages/verify.py`. No seam file touched; no
  stylesheet added. Matches the report.

## 2026-09-29 20:34:35 -0700 - item 3 (figures): 152/37/19 = 208 and the three-repository claim both reproduced independently

Measured:
- Checked all 19 pins myself for `docs/VALIDATION.md` at their exact pinned
  commit (`git -C <dir> cat-file -e <sha>:docs/VALIDATION.md`, including the
  four Mercenaries-Fan-Build pins from `.cache/`): only cft-fp256,
  cft-rebound and Quantum-Film have it. Matches `ledger_repo_names()`'s claim
  exactly, by a route that never calls `facts.pin(name).has(...)`.
- Called `facts.entries(name, "docs/VALIDATION.md")` directly, bypassing
  `record.py` entirely: cft-fp256 152, cft-rebound 37, Quantum-Film 19 (208).
- Cross-checked by a second, independent method - `git show <sha>:docs/VALIDATION.md
  | grep -c '^## '` on each of the three files at their pins, no
  `facts.py` code involved at all: 152, 37, 19. Exact match.
- `public/record.html`: 209 `<tr>` (1 header + 208 data rows); the three
  count-line figures read 19, 152, 37 in the built page.
- Verdict: **confirmed.** The shipped page is right, and it is also held by
  a gate (`verify_row_count`, `--verify-facts`, the `facts` stage).

## 2026-09-29 20:34:35 -0700 - item 2/4 (ordering, and the row-count control): confirmed by a real end-to-end fault, not just by re-reading the code

Measured:
- `timeline()`'s sort key is `(date, repository name, line)`, ascending;
  matches "oldest first, tied by repository then by line" and the page's own
  caption ("a stable order, not a claim about which happened first").
  Case-sensitive ASCII sort puts `Quantum-Film` before `cft-fp256`/
  `cft-rebound` in the counts list and in same-date ties - not alphabetical
  in the everyday sense, but stable and deterministic, and the page never
  claims alphabetical. Not a defect.
- Built a **real** fault in a scratch copy
  (`.../scratchpad/verifier-P1/fault-row-drop/site/pages/record.py`):
  patched `timeline()`'s own merge loop to silently skip cft-rebound's first
  entry (`if name == "cft-rebound" and i == 0: continue`), leaving
  `_entries()`/`verify_row_count` untouched - a plant in the region the
  control's own docstring describes ("a row dropped between parsing and
  rendering"), not a direct call to the guard function.
  `python site/build.py`: **`REFUSED: record: cft-rebound has 37 entries
  parsed at its pin, and 36 rows would be rendered`** (exit 2). Watched
  failing, on a fault I picked, in the real pipeline.
- Also ran `python site/build.py --control` directly on the clean tree and
  confirmed the exact lines P1 quoted: `control row-count caught, as it must
  be - pages.record: record: cft-rebound has 37 entries parsed at its pin,
  and 36 rows would be rendered`; `control link-line caught, as it must be -
  pages.record: record: cft-fp256 entry 0 links to docs/VALIDATION.md#L21,
  and entries() puts its heading at line 20`; `control unsourced-sentence
  caught, as it must be - pages.verify: ... '4' is a numeral outside any
  figure's mark, in 'reads 4 checks by hand'`.
- Verdict on row-count: **confirmed, held by a gate** (both P1's own control
  and my independent end-to-end plant were watched failing).

## 2026-09-29 20:34:35 -0700 - DEFECT (item 4, and the brief's own "a link to the entry at its pin"): the Record's own per-row link is not checked by anything; an off-by-one line passes all 11 stages

Measured:
- `record.py`'s `_row()` wraps the entry title in **two** links to the same
  fact id: (1) `entry = L(href, title_v)`, where `href = p.href(path,
  e["line"])` is a **local** variable, wrapping the visible title text
  itself (the link a reader would actually click) with `data-f`
  class `"q"`; (2) the citation span `render.fig()` appends after it,
  class `"src"`, whose href is `title_v.src.href` - computed **separately**,
  inside `ledger_title()`.
- `build.check_numbers()`'s href check
  (`if (m["href"] or "") != rec["href"]`) runs **only inside the `elif "src"
  in m["cls"]:` branch**. For every other mark (`"q"`/`"fig"`), the `else`
  branch checks only `got != rec["text"]` - `m["href"]` is never read.
  Confirmed by re-reading `build.py`'s `_Marks`/`check_numbers` and by
  parsing an actual built row: `<span class="q" data-f="180"><a
  href="...#L20">2026-08-30 - card-day image pair...</a></span><span
  class="src" data-f="180"> <a href="...#L20">(cft-fp256 ...)</a></span>` -
  two separate hrefs, both currently `#L20`, only the second checked.
- Also: `verify_entry_link(name, path, index, e["line"])` is called with
  `e["line"]` - the **same** object `_entries()` returns at `ents[index]` -
  so as wired it compares that value against itself; it never receives or
  inspects the `href` string `_row()` builds one line later. `--verify-facts`
  (`facts.rederive`) compares only `v.text`/`v.raw`, never `v.src.href`,
  so it doesn't cover this either.
- Built the fault in a fresh scratch copy
  (`.../scratchpad/verifier-P1/fault-link-line/`): changed only
  `href = p.href(path, e["line"] + 1) if not p.private else ""` (one line,
  the `_row()` local), leaving the `verify_entry_link` call, `ledger_title`,
  and everything else untouched. Rebuilt
  (`wrote 19 files to public/ from 19 pins; 663 figures`).
  `grep` on the rebuilt `record.html` confirms the plant: the primary link
  on cft-fp256 entry 0 now reads `...docs/VALIDATION.md#L21` (wrong; the
  entry's own heading is at line 20 - unchanged in the citation span, still
  `#L20`). `python site/build.py --numbers`: **`numbers: 0 problem(s); 1198
  marks tied to their own facts in 19 files`**. Full gate,
  `bash verify/run.sh --require-all`: **11 passed, 0 failed, 0 skipped.
  `controls: 171 caught, 0 did not fail, 0 skipped by name`. VERDICT: PASS,
  nothing skipped.**
- This is exactly the fault brief `P1.md` names ("A link off by a line...
  A check comparing each link's line with entries() must refuse it by
  name") and exactly the property `docs/ROUND1.md` and the report both
  claim ("a link to the entry at its pin"). It is not held by any gate, and
  it is not stated as a limit anywhere on either page.
- Kind of result: **the shipped page is right today** (both links agree,
  right now) - **but the gate would not catch it if it weren't**, on the
  very next change to this file. That is the distinction the brief asked me
  to keep apart, and this is squarely the second kind.
- Verdict: **defect.** Scratch copy deleted after this measurement.

## 2026-09-29 20:34:35 -0700 - DEFECT (item 1, unbacked sentences): verify.html states specifics of cft-fp256's contract and of what each check does/does not cover, outside any quote, paraphrase or stated()

Measured:
- Fetched cft-fp256's `README.md`, `CLAUDE.md`, `CONFORMANCE.md`,
  `docs/VERIFICATION.md` at `77b8440` (the pin) via `git show`. Checked
  every one of `verify.py`'s eight `facts.prose(...)` calls against the
  source text at that exact commit: all eight match their captured group
  exactly, uniquely (each pattern's single match, confirmed by the build
  itself never refusing on "matches N times"), and each is correctly scoped
  to the row it appears in (e.g. "2.6 min at four workers" is the `golden`
  row of `docs/VERIFICATION.md`'s stage table, not some other stage's
  figure; "`gate` adds the golden suite, the vectors..." correctly implies
  those items are *absent* from `verify-quick`, consistent with
  `CLAUDE.md`'s "28 of 41" vs "36 of 41"). **No `display=` is used anywhere
  in `record.py` or `verify.py`** - the parcel contains zero paraphrases,
  so item 2 (paraphrase drift) does not apply to this parcel at all.
- But `verify.py`'s `_lede()` opens: `"cft-fp256's contract is that any
  conforming implementation - a different chip, a different process, a
  different language - must still be "`, then only the words "interchangeable
  with them bit for bit" are inside a `facts.prose()` call. The phrase "a
  different chip, a different process, a different language" is copied
  **outside** the quote, as plain hardcoded prose - currently identical to
  `CONFORMANCE.md` line 9 ("a different chip, a different process, a
  different language"), but held by no gate at all: nothing re-reads it,
  nothing ties it to the pin, and it is not `facts.stated()` either.
- Built the fault in a fresh scratch copy
  (`.../scratchpad/verifier-P1/fault-unbacked-lede/`): changed only that one
  hardcoded phrase to something false and unrelated to the source - "a
  different vendor, on a different planet, using a different alphabet".
  Rebuilt; `bash verify/run.sh --require-all`: **11 passed, 0 failed, 0
  skipped, controls 171 caught, VERDICT: PASS, nothing skipped.** A
  fabricated claim about cft-fp256's own contract passes the entire gate.
- The same pattern recurs in the "what a pass does and does not prove"
  sentences the brief specifically named: check 1 ends "...it says nothing
  about the native library, the RTL, or a device - those are the checks
  below", and check 2 ends "...not that the library, the RTL or a device
  agrees with it" - both plausible, both unquoted, both un-gated. (Check 3's
  equivalent sentence, by contrast, is built entirely from two direct
  quotes, and is clean.)
- Verdict: **defect.** Scratch copy deleted after this measurement.
  Everything else on both pages that states a fact about a project is one
  of quotation or `facts.stated()`; connective/structural prose (headings,
  "don't trust this - run one", the ordering caption, the site's own LIMIT
  paragraph) is fine as unsourced, since it states no fact about a pinned
  project. Decision 12's framing (`FRAMING`, wrapped in `S()`/
  `facts.stated`) is implemented well, and deliberately avoids hardcoding
  "three" in prose (unlike `P1.md`'s and `docs/ROUND1.md`'s own wording) so
  a fourth ledger-keeping repository later can't make it silently stale -
  a good design choice, noted for whoever reads this before the ratio is
  next discussed.

## 2026-09-29 20:34:35 -0700 - item 6 (the "import build" question): safe, and re-confirmed empirically, not just by reading

Measured: `verify.py`'s `controls()` does `import build` from inside a page
module that `build.py` itself discovers and calls (`for m in pages(): ...
m.controls()`, inside `python site/build.py --control` while that same
file is running as `__main__`). Read `build.py` end to end (2052 lines) to
check this specifically:
- `build.py` ends with `if __name__ == "__main__": main()`. A bare
  `import build`, run from inside the already-running `__main__` process,
  is a **different** module object (Python caches by name, and the running
  script is `sys.modules["__main__"]`, never `sys.modules["build"]`), so
  `site/build.py`'s top level (defining `PUBLIC`, `check_numbers`, etc.) runs
  again, once - but `__name__` for that second load is `"build"`, not
  `"__main__"`, so `main()` (argv parsing, a second `--control` run) never
  fires. No recursion, no duplicate CLI invocation.
- `facts.Refusal`/`Unavailable` are imported by name from the single,
  already-cached `facts` module in both copies, so exception handling across
  the two `build` module objects is not affected (same class objects).
- `build.PUBLIC` and `build.check_numbers` are deterministic (same `ROOT`,
  pure function of a given root), so calling them from the freshly-imported
  copy behaves identically to calling the original.
- Confirmed empirically, three times (the clean build, and both fault
  builds above): `python site/build.py --control` and
  `bash verify/run.sh --require-all` both complete normally, and the
  specific line `control unsourced-sentence caught, as it must be -
  pages.verify: ...` appears every time - no crash, no hang, no double
  count.
- Verdict: **confirmed correct**, not a defect. The cost is one extra,
  harmless re-execution of `build.py`'s module body (function/class
  definitions only; no heavy computation at import time).

## 2026-09-29 20:34:35 -0700 - remaining items: links/nav, SPEC decisions, report claims

Measured:
- `grep -o 'href="/[^"]*"' public/record.html public/verify.html
  public/index.html`: no matches - every link relative, per CLAUDE.md trap 6.
- `record.html`'s nav: `Record` and `Verify` are real links; `Threads`,
  `Work`, `Method`, `Corrections`, `Propose`, `About` are unlinked
  `<span title="not built yet">`. Stamp reads "3 of 9 ... pages built" -
  matches the report exactly.
- `docs/SPEC.md` decision 12 read in full: "Only three repositories keep a
  ledger, so the Record is weighted towards those. This is accepted 'as how
  the method grew.'" - matches `FRAMING`'s substance (see above on the
  "three" wording choice).
- Decisions 5 ("private repositories... marked private for now"), 10
  ("other contributors credited directly, with links"), 16 ("Wally...
  appears only on the game thread's page") do not bear on these two pages:
  confirmed via the snapshot that cft-fp256, cft-rebound and Quantum-Film
  are all `PUBLIC` (so no private-repository branch is exercised in
  `record.py`'s `if not p.private else ""` at all - a minor, low-severity
  untested branch, not a live defect, noted as a side note only); neither
  page names a contributor or Wally.
- The report's counts (11 passed/0 failed/0 skipped; controls 171/0/0;
  facts 656/0/7/0; numbers 1198 marks/19 files) are reproduced exactly from
  my own clean clone and build, independent of anything P1 pasted.

## 2026-09-29 20:34:35 -0700 - verdict: NOT READY on d474080

Two defects, both demonstrated with a concrete built fault that passed the
entire 11-stage gate (`VERDICT: PASS, nothing skipped`) and is not stated as
a limit on either page:

1. The Record's own per-row entry link (the one wrapping the visible title,
   which is what a reader clicks) is checked by nothing - not
   `verify_entry_link`, not the numbers stage, not `--verify-facts`. Only a
   second, redundant citation link happens to be checked. An off-by-one on
   the real link passes silently.
2. `verify.html`'s `_lede()` states specifics of cft-fp256's own contract in
   plain, unquoted prose that currently matches the source but is tied to
   no fact, and the same "what a pass does/does not prove" sentences the
   brief flagged for checks 1 and 2 are similarly unquoted.

Everything else attempted - the 208-entry count and the three-repository
selection (independently recomputed by two different routes), the
ordering/tie-break rule, the row-count control (re-tested end to end, not
just re-run), the "unsourced-sentence" control, the `import build`
question, seams, links, nav, and the applicable SPEC decisions - is either
confirmed correct or confirmed held by a gate I watched fail on my own
fault.

What I did not do: I did not attempt every conceivable fault shape (e.g. I
did not fuzz `entries()`'s own heading parser, which is `facts.py`, the
lead's file and verifier-P0's territory, not P1's); I did not test the
`Mercenaries-Fan-Build` org pins for a ledger beyond the one directory
check above; I did not re-render the page in a real browser (no rendering
difference is at stake in either finding - both are pure string/HTML-parse
facts). I did not fix anything; both fault copies are deleted from my
scratch directory.

For: lead

## 2026-09-29 21:00:04 -0700 - re-check on 5128ce6: the two reported defects are genuinely fixed; one more instance of the same pattern found on a deeper sweep

Measured:
- Re-armed the `urgent/` watch inline before touching anything; re-read the
  whole ledger directory. `git fetch -q origin worktree-agent-a045e22e2210c0a37`
  into my existing scratch clone, `git checkout -q 5128ce6`: `git log
  --oneline -1` gave `5128ce6 P1: fix verifier-P1's two defects and the
  lead's cache-key note`. `git diff --stat d474080 5128ce6`: only
  `public/{MANIFEST,facts.json,verify.html}` and
  `site/pages/{record.py,verify.py}` - `public/record.html` and
  `public/index.html` are not in the diff at all, and a fresh
  `python site/build.py` plus `git status --short public/` confirms
  `record.html` is byte-identical to what is committed. Matches P1's
  "record.html rebuilt byte-identical" claim exactly - expected, since the
  fix changes how the link is checked, not what it is, under normal
  operation.
- `bash verify/run.sh --require-all` on the clean checkout: 11 passed, 0
  failed, 0 skipped, VERDICT: PASS, nothing skipped. facts 656/0-different;
  numbers 1198 marks/19 files/0 problems; controls 171 caught/0/0. Matches
  the report exactly.

Defect 1, the entry link: confirmed fixed, with a fault at least as strong
as my original one. Read the new code: `_row()` no longer computes a
second href; `href = title_v.src.href` is the one value used both for the
visible link and for the check. `verify_entry_link` now takes the rendered
href string, extracts `#L(\d+)$` and compares it against a fresh
`entries()` read - it no longer receives a bare int that was always going
to equal itself. Re-tested by monkeypatching the shared `facts.Pin.href` to
shift every line by one and calling `build.render_all()` directly - the
real rendering pipeline `python site/build.py` uses, not a helper function
in isolation:

  REFUSED (real full render, href corrupted at the shared Pin.href
  boundary): record: cft-fp256 entry 0's rendered link is
  'https://github.com/loganw234/cft-fp256/blob/77b8440.../
  docs/VALIDATION.md#L21', and entries() puts its heading at line 20

The build itself now refuses end to end, which is stronger than a post-hoc
check flagging it. Reran P1's own new `link-line` control directly
(`python site/build.py --control`): `control link-line caught, as it must
be - pages.record: record: cft-fp256 entry 0's rendered link is
'https://.../docs/VALIDATION.md#L21', and entries() puts its heading at
line 20` - matches the report, and is a real, non-vacuous test (it
monkeypatches `facts.Pin.href` through `ledger_title()` itself, not a
hand-fed line number). Confirmed, held by a gate I watched fail on my own
fault.

The lead's cache-key note (`_entries()` keyed by `(name,
facts.pin(name).full, path)`): read and confirms it is a simple, correct
fix for a real class of staleness (a pin moved mid-process would otherwise
go on serving an earlier commit's parsed entries under the same
`(name, path)` key). Not separately fault-tested with a built scenario -
the one place in the current gate that moves a pin mid-process (the
stale-pin control) already refuses earlier, at `facts.check_pins()`,
before ever reaching `record.py`, so no existing path in this codebase
currently exercises the differential. Sound by inspection; noted, not
scored either way.

Defect 2, unbacked sentences: the two reported instances are fixed; one
more of the same pattern remains, found on the wider sweep asked for.
`_lede()`'s entire clause ("an implementation can be built and proven
without this repository's RTL or library - a different chip, a different
process, a different language - and still be interchangeable with them bit
for bit") is now inside one `facts.prose()` call. Checked the pattern
against CONFORMANCE.md at 77b8440 again, byte for byte, including the
`\s+` line-wrap points: matches exactly (and `prose()` would refuse
outright if it did not). Checks 1 and 2's unquoted "does not prove..."
closers naming "the native library, the RTL, or a device" are removed
outright rather than re-sourced; read the rest of both items line by line
and nothing false-if-changed remains unguarded in either. (Side note, not
scored: removing the claim instead of leaving it unsourced is the right
call per this site's own discipline, though it does mean checks 1-2 no
longer literally state "what a pass does not prove" the way `briefs/P1.md`
asks per check - the closing LIMIT paragraph covers the same ground at the
whole-page level instead.)

But check 3 still has one: "It runs the software stack those stages name
against the golden model; it does not run [quoted list] -" - the opening
clause is plain, unquoted prose, the same pattern as the two already-fixed
ones. Read docs/VERIFICATION.md at the pin further up than I had the first
time (lines 209-213): "`quick` is the `docs`, `generated`, `buildargs` and
`sweepjudge` checks, the model-versus-C stages, the GPU's photograph, the
bindings, the language legs, the soak spot check, the workloads, the demos
and the remote backend...". So the sentence is a fair paraphrase of a real,
sourced fact ("the model-versus-C stages" is genuinely part of `quick`) -
but it is a paraphrase with no `display=`, in P1's own words, tied to no
fact, re-read by nothing. Built the fault in a fresh scratch copy
(deleted after): changed only that clause to "It re-synthesizes the FPGA
bitstream on real silicon and photographs the die" - a claim that directly
contradicts this same page's own quoted "CI's green tick does not cover
synthesis, timing or silicon" two sentences later. Rebuilt, ran the full
gate: 11 passed, 0 failed, controls 171 caught, VERDICT: PASS, nothing
skipped. A false, self-contradicting claim about what `make verify-quick`
does passes untouched.

Re-read every remaining sentence on both pages for the same pattern. Two
more exist at much lower stakes and were not separately fault-tested:
check 1's "Cost: a browser tab, nothing installed" and "in the browser"
are generic claims about opening a link, not substantive, driftable claims
about cft-fp256 itself. Check 4 and the closing LIMIT describe the site's
own already-verified mechanism, assessed as an acceptable exception in my
first report (no pin to quote from). Nothing new in `record.py`'s prose
(framing, counts sentence, ordering caption) - all previously checked, all
still self-referential and true.

Verdict on 5128ce6: **NOT READY, narrowly.** Both defects from my first
report are genuinely, robustly fixed - not patched around, but
structurally closed (the entry link now has one value instead of two,
checked by parsing the rendered string itself; the `_lede()` claim is now
wholly inside its quote) - verified with a fault at least as strong as the
ones that found them, including one that exercises the real build pipeline
end to end. One remaining instance of the same defect class was found on
the wider re-sweep this re-check asked for: check 3's "It runs the software
stack those stages name against the golden model" is unquoted, tied to no
fact, and a fabricated, self-contradicting version of it passes all 11
stages and all 171 controls. This is a single sentence, in one place, with
a direct fix already demonstrated elsewhere on the same page: wrap "the
model-versus-C stages" (or however P1 phrases it) in a `facts.prose()`
quote of docs/VERIFICATION.md's line 209-213, the same technique just used
to fix `_lede()`.

What I did not do this round: fault-test check 1's two low-stakes generic
sentences (not substantive claims about cft-fp256 in the sense this defect
class is about); build a scenario exercising the new cache-key's actual
differential (no path in the current gate reaches it). Scratch fault
copies built for this re-check are deleted.

For: lead

## 2026-09-29 21:14:02 -0700 - second re-check on 1e21d8e: the remaining sentence is fixed; verdict READY

Measured:
- Re-armed the `urgent/` watch before touching anything; re-read the whole
  ledger directory (only pre-existing P2 traffic, nothing new for
  verifier-P1). `git fetch -q origin worktree-agent-a045e22e2210c0a37`,
  `git checkout -q 1e21d8e`: `git log --oneline -1` gave `1e21d8e P1: quote
  check 3's opening claim too, and sweep both pages once more`.
  `git diff --stat 5128ce6 1e21d8e`: only `public/{MANIFEST,facts.json,
  verify.html}` and `site/pages/verify.py` - `record.py`/`record.html`
  untouched (confirmed with a direct diff --stat on those two paths: empty
  output).
- `bash verify/run.sh --require-all`: 11 passed, 0 failed, 0 skipped.
  facts 657/0-different (one more than 5128ce6's 656 - the new quote's own
  fact); numbers 1200 marks/19 files/0 problems; controls 171 caught/0/0.
  Matches the report exactly.
- **Confirmed the new quote matches its source exactly, once, at the
  pin**, independent of the build: wrote a standalone script re-reading
  `docs/VERIFICATION.md` at `77b8440` (my own copy fetched with `git show`
  in an earlier round, same pin, unchanged) and running P1's exact pattern
  against it directly, outside `facts.py` entirely.
  `re.finditer(pattern, text, re.M)` -> **match count: 1**, at **line
  209**, and the captured group is byte-for-byte the source's own wording
  across all four line-wraps ("the\n`docs`, `generated`, `buildargs` and
  `sweepjudge` checks, the\nmodel-versus-C stages, the GPU's photograph,
  the bindings, the language\nlegs, the soak spot check, the workloads, the
  demos and the remote\nbackend"). Confirmed.
- **Rebuilt the check-3 fault's equivalent in the new text.** The exact
  spot I originally planted ("It runs the software stack those stages name
  against the golden model") no longer exists as free text - it is now
  entirely inside the new quote. The nearest surviving equivalent is the
  bare connective `"; it does not run "` joining that quote to the
  already-quoted `` `gate` adds ... `` clause. Built the fault (scratch
  copy, deleted after): flipped it to `"; it also fully runs "` - the
  opposite claim, directly self-contradicting the very next quoted clause
  three words later. Rebuilt, ran the full gate: **11 passed, 0 failed,
  controls 171 caught, VERDICT: PASS, nothing skipped.** Not caught, same
  as before.
- Read the complete rendered text of both pages sentence by sentence one
  more time (`verify.html`'s lede, its four checks, its closing `LIMIT`;
  `record.html`'s framing and ordering caption - the latter two unchanged
  since 5128ce6 and previously verified). Nothing else of the same
  substance remains: every noun-phrase asserting a specific, driftable fact
  about cft-fp256 is now inside a quote; the only unsourced words left are
  procedural glue ("in a clone of cft-fp256", "Cost:", "And,") and the one
  bare negation above. P1 also removed two more minor unquoted framings I
  had not separately flagged ("the slower", "on the card itself") in
  5128ce6, which held up on this pass too.

**Judgement on the residual negation, since it is a real, demonstrated
gap and I want the reasoning on the record, not just the verdict:**
I am treating "it does not run" / "it also fully runs" as inside this
site's own already-stated limits, not as a third instance of the
class of defect I originally reported, for reasons distinct from the two
(three, counting the interim finding) I did block on:
1. It is bare grammatical connective tissue between two already-verbatim
   quotes, not a descriptive clause written in the parcel's own words - it
   cannot be shortened further without either quoting a whole compound
   sentence the source may not have, or removing the relationship
   entirely.
2. Flipping it produces a sentence that **directly contradicts its own
   very next clause** ("it also fully runs [X] ... [but] `gate` adds
   [that same X]") - unlike my original findings, which read as entirely
   plausible on their own, this failure mode is self-evident on a plain
   read, not just to a fetch-the-source verifier.
3. `_common.md`/CLAUDE.md already state, site-wide, that a paraphrase's
   faithfulness "is checked by no gate" and that "connective prose that
   states no fact is fine" - the same irreducible limit that applies to
   any page anywhere on this site that joins two quotes with English words
   applies here. It is not a limit P1 introduced or could close with a
   `facts.prose()` call, the way the three previous findings were closed.
4. It is verifiably **true as shipped**: quick's list and gate's additions
   are the disjoint, additive sets `docs/VERIFICATION.md` itself lays out.
This is a judgement call, disclosed here in full rather than silently
folded into READY, so the lead can weigh it differently if they want a
stricter line.

## 2026-09-29 21:14:02 -0700 - verdict: READY on 1e21d8e

All defects from my original report and my first re-check are fixed, each
verified with a fault at least as strong as the one that found it:
1. The Record's per-row entry link is now checked against its own rendered
   string, confirmed by corrupting the real build pipeline end to end.
2. `verify.html`'s `_lede()` claim about cft-fp256's contract is fully
   quoted.
3. Check 3's "what quick runs" claim is fully quoted, confirmed matching
   the pin exactly and uniquely by an independent script.

One residual gap remains (the bare "does not run" connective) and is
disclosed above with my reasoning for treating it as within this site's
existing, stated limits rather than as a blocking finding.

What I did not do this round: fault-test check 1's two low-stakes generic
sentences (unchanged from the prior round's assessment); attempt an
NLP/semantic gate for connective-word coherence, which is outside what any
mechanical check on this site (or any site built this way) can do. Scratch
fault copy for this round is deleted.

For: lead
