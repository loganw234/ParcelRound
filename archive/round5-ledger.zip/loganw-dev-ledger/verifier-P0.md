# verifier-P0

## 2026-09-29 15:20:22 -0700 - setup reproduced: clone prints 2c02ffe; front door 7 of 7, nothing skipped

Measured:
- `git clone -q` of the lead's tree into my scratch; `git log --oneline -1` printed 2c02ffe (full 2c02ffe0eb3a1c1d901685a2c8df56f868c819e5, a root commit).
- With `LOGANW_REPOS=C:/Users/logan/source/repos`, `bash verify/run.sh --require-all` in the clone: passed 7, failed 0, skipped 0; `VERDICT: PASS, nothing skipped`; 15.9 s wall. facts: 139 read again and the same, 5 stated. All 7 controls printed "caught".
- Watch on `urgent/` armed (lead-* files only) before starting.
Believed: nothing further yet.
For: lead

## 2026-09-29 15:27:48 -0700 - three findings on shared code that wave-1 briefs may lean on

Measured (copies under my scratch; each rebuilt with `python site/build.py`, then `bash verify/run.sh --require-all`):
- A figure printed through a plain string passes every gate. In a copy of home.py I added `"; %d ledger entries" % len(facts.entries(...)[1])` and a typed "; 3397 tests" to the cft-fp256 row. The page printed "152 ledger entries; 3397 tests"; facts.json still held 144 figures; run: 7 passed, `VERDICT: PASS, nothing skipped`. The page already prints one such figure today: the stamp's "1 of 9 pages built" (render.stamp, through esc).
- A `display=` text is never checked against its quote. In a copy I set atlas-film's display to "merged into main on 2026-09-27" (the source says whether it merges is open). It printed as a sourced figure linked to CASE-STUDY-4.md:388; `--verify-facts` said 139 read again and the same; run: 7 passed, PASS.
- `gh run list` (read only): atlas-optical's own `tests` workflow passed on the pinned commit dbccafe (2026-09-05T13:52:52Z), and atlas-darkroom's passed on c1b9b6e, an ancestor of its pin (2026-09-05T15:34:29Z). Home shows a dash for both, and its caption says "a dash means none is recorded".
Believed: no document states the first two as limits (grep of README, CLAUDE.md, docs/, site/*.py found none; CLAUDE.md says a prose figure "shows that the page quotes its source faithfully").
For: lead (and anyone briefing a parcel that adds facts)

## 2026-09-29 15:45:38 -0700 - gate findings (runner, CI, local-only, docs) and push prerequisites

Measured (copies under my scratch):
- CI simulation (`LOGANW_REPOS` = empty dir, `LOGANW_FETCH=1 bash verify/run.sh`): all 11 public pins fetched from GitHub; `build` SKIP and `controls` SKIP (atlas-darkroom private); facts 118 read again, 21 skipped; PASS, rc 0, 62 s. So CI runs none of the 7 controls; site.yml and run.sh comments name only `build` and private figures as skipped.
- Same CI mode with public/index.html deleted: links and local-only pass with 0 problems (no HTML to read), runner-control crashes with FileNotFoundError and is scored "failed, as it must" (rc 1 from a Python traceback), VERDICT PASS, rc 0.
- `--resume --require-all` after a second, different edit to a dirty tree (stale ABI; direct `--check` rc 1): all 7 reused, "VERDICT: PASS, nothing skipped". `--only docs --require-all`: "PASS, nothing skipped". A stage printing "2 skipped by name" under `--require-all`: PASS, rc 0.
- `--local-only` + `--links` both pass 19 HTML forms (srcset, svg image/use href, style attr url(), <style> @font-face/@import, <base href>, meta refresh, form action, poster, input image, ping, javascript: href, on* handlers, iframe srcdoc) and 3 CSS forms (URL(, @IMPORT, image-set string). Through the renderer (srcset + <style>@import to Google Fonts), full `--require-all`: PASS.
- `--links` passes `style.css/` (GitHub Pages: 404 for `index.html/`), and never reads CSS url().
- `--docs` misses CLAUDE.md's only stage count (inside a code fence), "seven stages", "8-stage", a hard-wrapped "8
stages", links with a title, reference links, raw <a href>, missing anchors.
- `gh api`: atlas-darkroom's pin 6a33735 is not on GitHub (422); GitHub main is c1b9b6e, an ancestor. `loganw234/loganw.dev` does not exist on GitHub (404); the lead's repo has no remote; loganw.dev resolves to 15.197.148.33 / 3.33.130.190, not GitHub Pages.
Believed: pushing needs the repo created, a remote, and Pages set to the Actions source before deploy-pages can succeed.
For: lead

## 2026-09-29 15:50:08 -0700 - a fourth path past fig(): dataclasses.replace keeps the id; bears on the planned --numbers check

Measured (copy, rebuilt, `--require-all`): in home.py, `agent = dataclasses.replace(agent, text="1079/1079")` for cft-fp256. fig() accepted it (it tests only that `v.id` is nonzero). The page printed `<span class="fig">1079/1079</span>` with the real source label "(cft-fp256 77b8440 git log)"; facts.json holds only "1030/1079" and contains "1079/1079" nowhere; run: 7 passed, PASS, and verify-facts "139 read again and the same".
Believed: the --numbers design in lead.md 15:44:45 ("refuses any fact-classed span whose text is not some logged fact's text") would catch this plant, but not a replace to another fact's logged text (e.g. "1006/1157", atlas-darkroom's). A check that ties each printed span to its own id (fig() comparing v.text/v.raw with LOG[v.id-1]) would.
For: lead (p0.1 fixes)

## 2026-09-29 15:50:44 -0700 - correction to 2026-09-29 15:45:38: 18 HTML forms pass both checks, not 19

Measured: recounting the plant table, 18 of the planted HTML forms passed both `--local-only` and `--links`. Of those, `<svg><use href>` to another origin passes the checks, but browsers are believed to block cross-origin <use>, so count 17 that act. The CSS count (3) stands.
For: lead

## 2026-09-29 15:52:25 -0700 - verdict on 2c02ffe: NOT READY; full report delivered to the lead

Measured, beyond the entries above:
- Held by a gate I watched fail on my own faults: `--check` (11 plants: stale MANIFEST, facts.json text and detail-only edits, two extra files, a font byte, a print byte, BUILD rewritten and deleted, CRLF, a trailing newline); `--verify-facts` for pinned facts (cft-fp256 re-pinned to its parent: 3 MISMATCH, rc 1); `entries()` refusal; runner-control against my own links sabotage.
- Not held and not stated (beyond earlier entries): open regressions drop cancelled/startup_failure/action_required/neutral/stale runs, contrary to SPEC section 4, and "red since" prints the newest red run (four failures 09-25..09-29 read "red since 2026-09-29"); snapshot-sourced figures (38 of 139) are compared with the same committed snapshot, and a tampered snapshot passes 7/7; numbered ledger entries are dated at a later retitle, or before they were headings (synthetic repo, real parser); cft-rebound's "last verified" misses entry 36 (2026-09-14, `hw/verify-image.sh` 8 of 8 PASS).
- SPEC section 3: "Headless Rebase, Rebase" is one account ([a GitHub noreply address]); the Mercenaries-Fan-Build org lists 12 repositories, not four.
Believed: CI conclusions come from a local simulation on this Windows host, not ubuntu-24.04.
For: lead

## 2026-09-29 17:01:01 -0700 - re-check setup: my clone at bc2ffbc; front door 10 of 10, nothing skipped

Measured:
- `git fetch origin p0.1` in my scratch clone; checked out 45b8d01, then bc2ffbc when the tip moved (`git rev-parse HEAD` = bc2ffbc1bf08d5912a5af34443f668df45809209). Tree clean.
- 45b8d01, `LOGANW_FETCH=1 bash verify/run.sh --require-all` (first run fetched the four organisation pins into my clone's .cache): 10 passed, nothing skipped, 199 s wall; controls 67 caught.
- bc2ffbc, `bash verify/run.sh --require-all`: 10 passed, 0 skipped, `VERDICT: PASS, nothing skipped`, 63 s wall. build 16 s; facts 172 read again, 6 stated, 0 skipped; numbers 270 marks; privacy 0 problems, 2 unread private repositories looked for in 48 files; controls 69 caught, 0 skipped.
Believed: nothing yet.
For: lead

## 2026-09-29 17:15:17 -0700 - bc2ffbc: five ways past the new gates, each passing 10 of 10

Measured (copies under my scratch, rebuilt with `python site/build.py`, then `bash verify/run.sh --require-all`; browser checks in the Claude browser pane against a 127.0.0.1 server of the copy):
- Duplicate attributes. The checks read `dict(attrs)`, which keeps the last value; a browser keeps the first. render.page emitting `content="default-src * data:" content="<CSP>"` on the policy meta, plus `<img src="https://evil.invalid/pixel.png" src="assets/pauli-print.png" alt="3397 prints" alt="">`: 10 passed, PASS. In the browser the page ran under `default-src * data:`; a probe image to evil.invalid raised no CSP violation, and the fetch went out (net::ERR_NAME_NOT_RESOLVED). The same probe on a copy with the real policy raised `img-src` and was blocked. The broken image showed its first alt, "3397 prints".
- CSS `quotes`: `.stamp::after{content:open-quote}.stamp{quotes:" | 3397 tests" ""}` in site/styles/: 10 passed; the screenshot shows the stamp ending "| 3397 tests". `list-style-type:"3397 "` and `@counter-style` symbols pass the checks too (not rendered by me).
- A display adding a number word its source lacks, "its merge left open for twelve days": 10 passed (check_display reads digits only; numbers reads words only outside marks).
- `NUMERAL_NAMES = ["4096 tests"]` plus a loose "after 4096 tests": 10 passed, reported only as "1 numerals allowed as part of a name". (My first try used "3397 tests", which the CSS control happens to plant; that control then failed, by collision.)
- `ASSETS` takes any published path: `("remote.htm", "cft-fp256", "bindings/wasm/remote.html")`, linked from Home: 10 passed (local-only and numbers read only .html/.css/.txt). The browser served it as text/html, with no policy, and fetched its script and its module import.
- CLAUDE.md trap 9 is false at bc2ffbc: nothing constructs a Pin for the organisation keys, so no fetch is needed; my run without LOGANW_FETCH built with nothing skipped, and no .cache exists.
For: lead

## 2026-09-29 17:38:53 -0700 - bc2ffbc: the rest of the re-check (gates watched failing, gaps, false sentences)

Measured, all on bc2ffbc copies:
- Watched failing on my own faults: red-run control (RED without startup_failure); ledger control (fence skip removed); pin checks (moved pin; snapshot sha null); runner (`--require-all --only`, `--resume` dirty, invalid-UTF-8 index.html gives "did not run as a check"); drift and manifest (font byte, extra file, unlisted edit); prose (a 5-match pattern refused); CSS loads (8 forms refused); fig() (num or raw changed). CI simulation (`CI=true`, empty LOGANW_REPOS, LOGANW_FETCH=1): facts 153 read again, 19 skipped; controls 67 caught, 2 skipped; PASS; under --require-all, FAIL.
- No gate on the "newest" rule: `last_verified` sabotaged to take the oldest passing run (min for max), rebuilt: atlas-engine 2026-08-23, cft-fp256 2026-08-29, mercs2-lua-essentials 2026-07-16, atlas-darkroom 2026-07-28; 10 passed, PASS. My independent recomputation of every cell matches the shipped page.
- Pins are the snapshot's word: atlas-darkroom re-pinned to the local-only 6a33735 with the snapshot's pin record hand-edited, rebuilt: 10 passed, PASS; the footer prints 6a33735.
- Privacy: 101 blobs on main and p0.1 hold neither unread name (ASCII or UTF-16): clean. But the stage's own search misses a made-up name in a UTF-16 file (skipped for its NUL bytes) and one that survives only in an earlier commit (still reachable, so pushed).
- Parser: a fence left open (or 4 backticks closed by 3) drops every later heading with no refusal (1 of 3 read); real ledgers still 152, 37, 19.
- Docs: "Stages: 10.", "The stage count is 10.", "a dozen stages", "ten separate, independent stages", "10 (ten) stages", "thirty stages" pass `--docs`; VALIDATION.md links are never checked; a raw `<img src>` to a missing file passes.
- ASSETS dest "../site/data/x.json" writes outside public/; --check calls it published, --manifest passes.
- False sentences: CLAUDE.md traps 9 and 13; "refuses any numeral" (README, CLAUDE.md, facts.py "every figure a page prints in digits"); MANIFEST header "hash what the build read besides the pins" (relations.json and code are not); VALIDATION "(entries 36 and 37)" (no declared form matches in 37).
Believed: f0a42ab on p0.2 answers my 17:15 entry; I have not reviewed it.
For: lead

## 2026-09-29 17:57:09 -0700 - re-check of p0.2 at 3743c52: setup reproduced

Measured:
- My clone's origin is still the lead's local repository (not GitHub). `git fetch origin p0.2`; checked out 3743c52 (3743c527822a9d5a8349ecb9bafc41830aa90911). Tree clean.
- `bash verify/run.sh --require-all`: 11 passed, 0 skipped, `VERDICT: PASS, nothing skipped`, 38 s wall. facts 172 read again, 6 stated; numbers 270 marks, no names allowed; privacy 67 files and 130 blobs in history; github 19 pins asked; controls 109 caught.
Believed: nothing yet.
For: lead

## 2026-09-29 18:05:04 -0700 - verdict on p0.2 at 3743c52: NOT READY, on four small gaps; everything else held

Measured (copies under my scratch; each rebuilt and run through `bash verify/run.sh --require-all` unless said):
- Held by gates I watched fail on my own faults: "newest" (ledger-oldest and ci-oldest sabotages, each named by the newest controls); manifest (an untracked stylesheet built into public/: a fresh checkout's `--manifest` fails, naming it); github (atlas-darkroom at local-only 6a33735 with a vouching snapshot: github FAIL, naming it); local-only (repeated href, data-f and class; a fifth meta; .svg, .xml, extensionless and fake .png files: all refused); docs (broken link in VALIDATION.md, raw img to a missing file, misspelt anchor: all refused). CI simulation matches the comments: build, privacy, github skipped; facts 153 read again, 19 skipped; controls 106 caught, 3 skipped.
- Inside stated limits: display "hundreds of days" and "since Sep27"; stage counts four words away, "11 steps", "thirty stages".
- Not held, and not stated:
  1. "Last verified" ancestry: with `p.is_ancestor(...)` removed from the CI filter, no figure changed at these pins and all 11 stages passed. No control plants a newer pass on a non-ancestor commit.
  2. Parser: a heading underlined with a single dash renders as h2 (markdown-it-py, CommonMark mode) and is dropped with no refusal (2 of 3 read); the docstring says a dash-underlined heading is refused (the code needs 2 or more dashes). Real ledgers unaffected: entries equal CommonMark h2 counts, 152, 37, 19.
  3. Privacy: with a made-up name, the stage's own functions miss it when it is only a file path, only in an annotated tag message, or only in a compressed PNG text chunk. Its docstring says it reads everything a push would publish. The real content is clean in all three places (73 paths, 0 tags, no PNG text chunks).
  4. The footer's new sentence, "Every figure above this footer names where it was read": 4 map marks have no source label anywhere on the page (snapshot date, two "private", "refesl.live").
- Claims checked true: the binary-sites run at its pin printed "ok" for all four sites; all four action majors exist and are the newest; checkout v5 and setup-python v6 are where Node 24 begins; public/ has no dotfiles; 109 controls.
For: lead

## 2026-09-29 18:23:52 -0700 - p0.2 at 00c847e: the four gaps are closed; three small claim gaps remain (NOT READY by the standard)

Measured (copies under my scratch; `--control`, or a rebuild plus `--require-all`):
- Front door on 00c847e: 11 passed, nothing skipped, 38 s; controls 123 caught. CI simulation: build, privacy, github skipped; facts 153 read again, 19 skipped; controls 120 caught, 3 skipped; the three CommonMark cross-checks ran (152, 37, 19).
- Closed, each watched failing on my own sabotage: ancestry removed from last_verified (named: "last verified 2099-01-01"); ancestry removed from ci_red (named: "open tests red on 2099-01-01"); single-dash rule narrowed back to 2 dashes (named); PNG text reading removed (named); the map's source list removed, rebuilt (numbers FAIL, naming fact 48); cft-rebound entry 37 dropped by the parser (cross-check named "36 entries read, and CommonMark renders 37"). Privacy now finds a name as a folder, in a tag message, in zTXt and in compressed iTXt. The footer sentence is true for the page as built (6 drawn marks labelled in the list, 124 beside their labels, 0 neither).
- Still open, each small:
  1. The same fact printed twice above the footer, the second copy with no label beside it and outside the map: 11 passed, PASS. The gate checks "somewhere on the page"; the footer says "beside it, or ... in the list under the map".
  2. ledger_headings' docstring says every other level-2 shape is refused. Not so for a quote inside a list item or a list item inside a quote (dropped), or a heading inside a multi-line HTML comment (read, though not rendered). The cross-check catches all three on a real ledger, so it is a false sentence, not an open gate.
  3. Privacy does not read commit author, committer or tagger fields, and neither list in its docstring mentions them. The real history is clean (2 identities).
- Checked true: decision 24 matches the lead's ledger quote; markdown-it-py 3.0.0 needs only mdurl, and mdurl 0.1.2 is the newest; the README's install line; the new VALIDATION entry.
For: lead

## 2026-09-29 18:24:21 -0700 - addendum to 18:22 item 2: one shape the cross-check does not see

Measured: `<div><h2>2026-01-02 - b</h2></div>` between two headings: the parser reads 2, and markdown-it-py's CommonMark token count is also 2 (an HTML block, not a heading token). So both miss it, though GitHub renders raw HTML, so a reader would see a heading. The docstring says an HTML <h2> block is refused; only a line starting with <h2 is. Unlikely in a ledger.
For: lead

## 2026-09-29 18:35:30 -0700 - p0.2 at e6ce3d3: the three overclaims are closed; one gap remains (a stylesheet can hide the labels)

Measured (copies under my scratch):
- Front door: 11 passed, nothing skipped, 39 s; controls 131 caught. CI simulation: build, privacy, github skipped; facts 153 again, 19 skipped; controls 128 caught, 3 skipped; the three line-and-title cross-checks ran.
- Closed, each watched failing on my own sabotage: the beside rule weakened back to "anywhere on the page" (named); commit identities removed from the privacy search (named); the parser recording each heading one line off, counts unchanged (all three cross-checks named it). My own plants: a second unlabelled copy, and a copy followed by another fact's label, both refused; a name only in an author name, and only in a tagger name, both found. My nine heading shapes: eight agree with CommonMark or are refused.
- Hashes: verify/requirements.txt pins exactly PyPI's published wheel sha256 for markdown-it-py 3.0.0 and mdurl 0.1.2 (JSON API).
- Still open: `.src{display:none}` in a new site/styles/ file, rebuilt: 11 passed, PASS. In the browser pane 49 of 124 labels were hidden (the table-cell ones stay visible only because `td .src{display:block}` is more specific). The footer says each figure names its source beside it; no document says the gates read the HTML and not what a stylesheet shows.
- Side note: a heading inside a `<pre>` block that spans a blank line is read by the parser but not rendered by CommonMark (the docstring's "up to the next blank line" is not true of pre, script, style or textarea). The cross-check would name it on a real ledger, as the docstring says.
For: lead

## 2026-09-29 18:45:01 -0700 - p0.2 at 1c1779b: the side note is closed; the CSS gap is narrowed but one claim still outruns its check

Measured (copies under my scratch):
- Front door on 1c1779b: 11 passed, nothing skipped, 39 s; controls 135 caught.
- Watched failing on my own sabotage: the hiding check no longer called (all three hiding controls named it); the type-1 raw blocks no longer started (the <pre> control named it). hiding_problems refuses display:none, color:transparent, opacity:0%, transform:scale(0) and clip-path.
- Parser: 7 of my 8 HTML-block shapes agree with markdown-it-py (script and textarea across a blank line, a type-1 block ended by another type-1 end tag, <?...?>, <!ENTITY...>, CDATA, a one-line <pre>). The eighth, an empty comment `<!-->`, is complete in CommonMark but the parser keeps it open until the next -->, silently dropping the heading between. The line-and-title cross-check would name that on a real ledger; wording point only.
- Not held: the README says "transparent text" is refused. `.src{color:rgba(0,0,0,0)}` in one new site/styles/ file, rebuilt: 11 passed, PASS. In the browser pane all 124 labels computed to rgba(0, 0, 0, 0); the screenshot shows the stamp's and the biography's labels gone. `color:#0000` passes too. Two more claimed categories pass in other spellings: zero size as `font-size:calc(0px)`, and zero scale as the `scale:0` property.
- Inside the stated limit ("Hiding by other means would still pass"): near-zero opacity or size, off-screen positioning, colour like the background, a mask.
For: lead

## 2026-09-29 18:54:28 -0700 - p0.2 at 1b87925: side note closed; the value reading is much stronger, but six spellings in claimed categories still pass

Measured (copies under my scratch):
- Front door: 11 passed, nothing skipped, 39 s; controls 142 caught.
- Closed: `<!-->` and `<!--->` now agree with CommonMark (3 and 3), and an open `<!-- x` still does. Custom-property following, sabotaged to ignore definitions: the new control named it. Refused in my tests: rgba(0,0,0,0), #0000, rgb(0 0 0 / 0%), legacy rgb with four args, a chained custom property, `scale:0 1`, `font:0/1 serif`.
- Still open. The README claims "a colour with zero alpha, in any notation, ... also through a custom property" and "a zero opacity ... in any property that sets one" are refused. These pass hiding_problems:
  1. `:root{--hide:transparent}.src{color:var(--hide, rgb(1 2 3))}` (a fallback with parentheses stops var() being parsed);
  2. `@property --hide{syntax:"<color>";inherits:true;initial-value:transparent}.src{color:var(--hide)}` (@ rules are skipped, and no rule defines --hide);
  3. `rgb(0 0 0 / calc(0))` (alpha computed);
  4. `rgb(0 0 0 / -1)` and `opacity:-1` (both clamp to zero);
  5. `-webkit-clip-path:inset(50%)` (an alias of clip-path).
  Numbers 1 and 2 each rebuilt and run through `--require-all`: 11 passed, PASS; in the browser pane all 124 labels computed to rgba(0, 0, 0, 0).
- Side note: css_hides.json exempts a selector from every hiding form, not only the one its reason gives (fill:none).
For: lead

## 2026-09-29 19:02:33 -0700 - p0.2 at 72f8525: last round's six and the allowlist scoping are closed; a nested at-rule still carries a listed declaration past the check

Measured (copies under my scratch):
- Front door: 11 passed, nothing skipped, 39 s; controls 149 caught.
- Closed: all six spellings from 1b87925 are refused, and so is `display:var(--d)` with `--d:none`. `.map .edge{display:none}` is refused; with the per-declaration allowlist sabotaged back to whole-selector exemption, its control named it.
- Still open: hiding_problems skips any block whose selector starts with @. The README says the numbers stage refuses exactly its listed declarations, `display:none` among them. `.src{@media all{display:none}}` (CSS nesting: bare declarations in a nested conditional rule apply to the parent) and `@scope (.src){display:none}` each pass the check; each rebuilt and run through `--require-all`: 11 passed, PASS. In the browser pane (Chrome 152) each hid 49 of 124 labels (the table-cell ones survive through `td .src{display:block}`). `.src{@supports (display:block){display:none}}` passes the check too (not rendered).
For: lead

## 2026-09-29 19:14:55 -0700 - p0.2 at d1b34d1: nested and at-rule blocks closed; a quote inside an unquoted url() still carries a listed declaration past the scanner

Measured (copies under my scratch; the run was interrupted once by a connection drop, and resumed from the same copy):
- Front door: 11 passed, nothing skipped, 41 s; controls 157 caught.
- Closed: my three forms from 72f8525 and the lead's sibling are refused. With blocks under an @ prelude skipped again, the three at-rule controls named it.
- Watched failing on my own fault: the block-count control. With `.planted{background:url(assets/pauli-print.png')}.src{display:none}` published, it said "the stylesheet's 90 blocks, each read: 88".
- Still open: the scanner treats a quote as a string wherever it appears. In CSS a quote inside an unquoted `url(...)` makes a bad URL that ends at the `)`. The site/styles plant `.src{background:url(assets/pauli-print.png');display:none}` followed by a line holding only `}` keeps the block count even. hiding_problems passes it (it reads one declaration, `background`), --links resolves the URL, local-only finds nothing, and the block-count control says 89 of 89. Rebuilt and run through `--require-all`: 11 passed, PASS. In Chrome 152 the parsed rules include `.src { display: none; }` and 49 of 124 labels are hidden.
For: lead

## 2026-09-29 19:23:36 -0700 - p0.2 at b40598b: the url() gap is closed; a form feed inside a string still parts the tokenizer from a browser

Measured (copies under my scratch):
- Front door: 11 passed, nothing skipped, 40 s; controls 164 caught.
- Closed: my url() plant from d1b34d1 is refused. With url( no longer recognised by css_tokens, three controls named it (the url plant, URL( in capitals, a semicolon inside url()).
- Still open: css_tokens ends a string only at its closing quote or a LF. CSS Syntax 3 first turns CR, FF and CRLF into LF, so a browser also ends a string at a form feed. Python's read_text turns CR into LF but leaves FF, so FF reaches public/style.css. The site/styles plant `.src{content:'a<FF>;display:none;x:'` + LF + `}`: css_tokens reads one closed string holding `display:none`, so hiding_problems and local-only pass it. Rebuilt and run through `--require-all`: 11 passed, PASS. In Chrome 152 the parsed rules include `.src { display: none; }` and 49 of 124 labels are hidden. local-only's claim, that it refuses any shape where a text reading and a browser's could part, is false for this one.
For: lead

## 2026-09-29 19:33:02 -0700 - verdict on p0.2 at ed990fb: READY

Measured (copies under my scratch):
- Front door: 11 passed, nothing skipped, 41 s; controls 168 caught. CI simulation (`CI=true`, empty LOGANW_REPOS, LOGANW_FETCH=1): build, privacy, github skipped by name; facts 153 read again, 19 skipped; controls 165 caught, 3 skipped; the tinycss2 cross-check (88 blocks) and the CommonMark cross-checks (152, 37, 19) ran.
- The form-feed finding is closed: my plant is refused by hiding_problems and by local-only.
- The tinycss2 cross-check is a real backstop, watched failing on my own fault: with both form-feed fixes undone in a copy (no preprocessing, no control-character refusal) and my plant published, the numbers and local-only stages passed it, and the cross-check control failed the gate naming the block: ".src reads as [content] here and as [content, display, x] in tinycss2".
- Pins: tinycss2 1.5.1 and webencodings 0.5.1 in verify/requirements.txt are exactly PyPI's published wheel sha256 (JSON API); both are the versions installed here.
- By the standard, every item is now held by a gate I watched fail on a fault I chose, or stated as a limit where the claim is made, with my evading faults landing inside it (near-zero values, colour like the background, off screen; digits after a letter; unlisted number words; a paraphrase's meaning; snapshot figures; images; privacy's pixels and compressed data; a retitled numbered heading; a hand edit that also rewrites MANIFEST, in CI).
- Side note, not a finding: local-only's list says "a control character other than a line feed or a tab"; it refuses C0 and DEL, which is CSS's own non-printable set; a C1 control (U+0085) passes and causes no parsing difference.
Believed: the deploy job itself (the four action versions, Pages set to the Actions source) is untested until the first push.
For: lead
