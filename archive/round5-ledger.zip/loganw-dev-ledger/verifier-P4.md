# verifier-P4

## 2026-09-30 01:24:36 -0700 - starting: full ledger read done; watch to be armed next; clone next

Measured:
- Read in full before starting: `briefs/verifier-parcel.md`, `briefs/_common.md`, `briefs/P4.md`,
  this ledger's `README.md`, `lead.md` (all entries, through "P4 reported (4d11e60...); the lead
  control on verifier-P4 is sealed; verifier-P4 dispatched on Sonnet at bd44300" at 01:23:08),
  `P4.md` (all entries, through "done: Corrections and Propose built; merged 07b1526; full gate
  11 of 11, nothing skipped, 303 controls caught" at 01:16:14), `P5.md`, `P3.md`, `verifier-P3.md`,
  `P2.md`, `verifier-P2.md`, `P1.md`, `verifier-P1.md`, `verifier-seam.md` (all entries through its
  00:50:55 NOT READY on `0176ce4..c06a0ea`), and every file in `urgent/` (13 files at read time).
- My task: verify branch `verifier-P4-commit` at `bd44300` in the lead's repository
  `C:\Users\logan\source\repos\loganw.dev`, against base `wave2-prep` at `07b1526` (not main, which
  is frozen at `0176ce4` while verifier-seam checks the lead's seam work). Diff to review:
  `git diff 07b1526 bd44300`. Per `lead.md` 01:23:08: `bd44300` is the lead's control (decision 20)
  applied on branch `verifier-P4-commit`, over P4's own `4d11e60` (P4's `6dd3b06` merged with
  `07b1526`). The lead's sealed file for this control is `700bcd0f337df647c78cc8a126309e6c9f1d7a31f549235487c0283e9ec819fa`
  (sha256, noted only for later cross-check against the unseal message, never opened by me now).
- My shared scratchpad parent directory (`.../scratchpad/`) holds sibling folders from the lead's
  own session, including `plant-P4/` and a file `P4-control-sealed.txt`, dated around 01:19-01:22.
  Per my brief, I am working only under my own `scratchpad/verifier-P4/` and have not opened either
  of those, or any other sibling folder (`P1/`, `P2/`, `P3/`, `verifier-P0/` through `verifier-P3/`,
  `verifier-seam/`, etc.) - noting this now so it's on the record before any findings.
- Key facts carried forward, relevant to checking P4 specifically:
  - P4's own report (relayed in my dispatch) matches what `P4.md` and `lead.md` independently
    record: two new pages (`corrections.py`, `propose.py`), one new stylesheet, two issue-form
    YAMLs, three granted edits (`_dossier.py`'s `prove_it_wrong_opening`, the five `work_*.py`
    `_sections(built)`, `threads.py` control 3 rewritten in-memory), a merge of `07b1526` for the
    lead's snapshot-control fix P4 itself found and filed, and P4's own controls (row-typed-cell,
    fix-not-on-main x2, door-retyped, door-not-early x5, dossier-corrections-link x3 = 12 named,
    though the report's control total is 303 for the whole site, not just P4's own).
  - `lead.md`'s 01:23:08 entry: `git diff --stat 07b1526 4d11e60` outside `public/` shows exactly
    the 12 files the report names; no seam file touched beyond the three granted edits.
  - Prior-round defect patterns to watch for specifically here (from other verifiers' rounds):
    unbacked sentences in connective prose (verifier-P1 found 2, verifier-P3 found the lead's own
    2 plants); paraphrase drift inside a `display=` that still passes because it carries no numeral
    (verifier-P3's "and on the card" finding); a control that never exercises a real branch of the
    property it names (verifier-P2's case-folding gap); an unchecked reader-facing value with a
    second, redundant, checked value standing in for it (verifier-P1's two-hrefs finding). P4's
    brief itself flags cft-rebound's/HonestFramework's/ParcelRound's known-tricky citations and the
    "found by" cell as the easiest to type from memory.
  - The site's HTML-subset gate history (`verifier-seam.md`) is still NOT READY as of 00:50:55 on
    `0176ce4..c06a0ea`; `07b1526` (which P4 merged) answers that round's A-D findings and the PNG
    gap. verifier-seam's re-check of `07b1526` has not yet reported as I start. I am not verifying
    the seam itself; I note it only because P4's pages are held to that same HTML-subset gate
    (`build.PARENTS`, canonical tags, `HTML_SPACE`, no SVG title in text, etc.), and any residual
    gap there could in principle surface on P4's own two pages too.
  - `own_prose` (no `last=`, must match exactly once), `own_entry` (by heading's whole text),
    `own_commit` (refuses a commit main/the built commit doesn't descend from, refuses a tag's hash
    as of `c06a0ea`) are the seam P4's corrections ledger reads. `_dossier.py`'s `ledger_date`,
    `ledger_title`, `kept_failure` are P3's, imported not copied, per P4's own report.
  - CLAUDE.md trap 14 / the author address: never write it, never send it; refer to it only as
    "the author address" (per my dispatch instructions, which are stricter than the ledger's own
    "count occurrences, never text" - I will give counts and places only, never the text, and will
    say "Logan" never a pronoun).

Believed: nothing yet beyond the brief's and reports' own claims, pending my own re-measurement.

For: anyone

##  - verdict: NOT READY on bd44300; two of the lead's plants found, both unbacked by any gate; P4's own 4d11e60 does not carry them

Measured, on a fresh clone under my own scratch directory (checked out `bd44300`, confirmed `git log --oneline -1` starts `bd44300`):

- `git log --oneline 07b1526..bd44300`: three commits - `6dd3b06` (P4's own work), `4d11e60`
  (P4's merge of `07b1526`, matching what P4.md and lead.md both record as P4's reported tip), and
  `bd44300` (the lead's control, on top). `git diff --stat 4d11e60 bd44300`: exactly two source files,
  one line changed in each - `site/pages/corrections.py` and `site/pages/propose.py` - plus the
  mechanical `public/{MANIFEST,facts.json,corrections.html,propose.html}` rebuild. Read in full with
  `git diff --word-diff=porcelain 4d11e60 bd44300`.
- **Plant A, corrections.py `engagement()`:** the sixth rule of engagement, inside `S(...)` =
  `facts.stated(text, "Logan", "2026-09-29")`, reads "It is acknowledged within a day, and given its
  disposition when it's true." `docs/SPEC.md` line 54 ("The spec, word for word as Logan gave it"), the
  only place this commitment appears anywhere in the repository (grepped), reads "Acknowledged in days;
  disposition when it's true." No decision in SPEC.md section 2 revises it. `facts.stated()` does not
  check its text against any source, so nothing rebuilds or re-derives this claim; a full
  `bash verify/run.sh --require-all` on `bd44300` passes 11 of 11 with the altered text shipping,
  attributed to Logan, unlabelled `draft=True`. This is exactly brief P4.md's own Trap 1 ("acknowledged
  in days is not within 48 hours").
- **Plant B, propose.py `render_page()`:** "Money: neither required nor sufficient - changes the
  schedule, not the standard (stated by Logan, 2026-09-29). **Most proposals are answered within the
  week.**" - the second sentence is bare text appended after `S(MONEY)`, outside any `stated()`,
  `prose()` or fact call, carrying no digit and no number word from `facts.NUMBER_WORDS`, so the
  numbers stage's loose-text scan never sees it. `docs/SPEC.md` line 60 (the whole "Money" bullet) says
  nothing about response time; grepped the whole file for "answered"/"week"/"day": zero other
  matches. Confirmed on the rendered page (extracted visible text of `public/propose.html`): the
  sentence carries no source annotation at all, the only sentence on either page that doesn't.
- **Independently reproduced, not just read:** fresh clone, fresh `python site/build.py`
  (LOGANW_REPOS set, LOGANW_FETCH=1), fresh `bash verify/run.sh --require-all` on `bd44300`: **11
  passed, 0 failed, 0 skipped, VERDICT: PASS, nothing skipped**; facts 1583 read again and the same, 36
  stated; numbers 2600 marks in 36 files, 0 problems; controls 303 caught, 0 did not fail, 0 skipped
  (row-typed-cell x1, fix-not-on-main x2, door-retyped x1, door-not-early x5,
  dossier-corrections-link x3 - all P4's own, all present and caught). Neither plant is caught by
  anything in this run.
- **P4's own `4d11e60` does not carry either plant** (confirmed by the diff above: both lines read
  correctly - "in days" and no extra sentence - at `4d11e60`, only `bd44300` differs). Everything
  else in P4's report cross-checked independently and confirmed: the three `attack_first()` quotes
  (cft-fp256 77b8440, `docs/DETERMINISM.md:1412`, `docs/TRANSCENDENTALS.md:350`, `docs/HOSTAPI.md:686`,
  each grepped at the pin directly); `docs/COMPLIANCE.md`'s "The conformance statement" and the rest of
  the file genuinely never call a clause reading open to dispute (grepped for
  interpret/ambiguous/unclear/contest/etc., zero hits) - P4's choice to show 3 of 4 gaps is correct;
  both LICENSE files (HonestFramework 65447fd, ParcelRound 8767e23) open "MIT License" at their pins;
  all three corrections-ledger rows' `own_prose`/`own_entry`/`own_commit` patterns and cited fix SHAs
  checked against `docs/VALIDATION.md`'s "wave 1's verifier findings" entry directly; no seam file or
  `docs/VALIDATION.md` touched (`git diff --name-only 07b1526 bd44300` against `_common.md`'s table);
  no Wally, no stray email, no `display=` (no paraphrases in P4's own pages), no leading-slash link, no
  broken local href, nav correctly links both pages. Built independent faults (not reusing P4's own
  `controls()` code) for `door-not-early` (a hardcoded, unconditional Propose link in a copy of
  `thread_determinism.py`: caught) and `dossier-corrections-link` (two hand-written fake openings:
  both directions caught), and four fresh `own_commit` faults beyond P4's own two (all refused,
  including the lead's never-merged `9260b4f`, correctly distinguished from "not a commit at all").
  Also found `row-typed-cell`'s own docstring understates the site's real protection: hand-editing the
  text inside an *existing* marked ledger cell (no digit, e.g. "verifier-P1" -> "someone else") **is**
  caught by `check_numbers`' mark-vs-fact equality check, contrary to the control's comment that a
  no-digit typed cell "is not something any gate here can see" - a documentation imprecision in a code
  comment, not a page-facing claim, so not itself scored as a defect.

Believed: nothing beyond the above; both plants are the lead's control (decision 20), not P4's own
work, per the diff. This does not change my verdict on the commit I was dispatched to check, `bd44300`,
which is NOT READY by `verifier-parcel.md`'s own standard (two properties the shipped pages claim -
the true "acknowledged" timeframe, and "no sentence ships without a source" - are neither held by a
gate nor stated as a limit).

For: lead

## 2026-09-30 01:40:43 -0700 - correction to the entry above: its heading lost the timestamp

Measured: the entry above ("- verdict: NOT READY on bd44300...") has a heading reading "##  -
verdict: ..." with the timestamp missing - a `printf` call of mine dropped the `date` argument for
its own `%s`, so the substitution came back empty instead of a guessed time. Not edited in place,
per this ledger's own rule; recorded here instead. Everything measured in that entry was measured
at or immediately after this session's 01:24:36 start, before this correction, and is unaffected.

For: anyone reading the entry above

## 2026-09-30 01:47:03 -0700 - verdict: READY on 4d11e60 (P4's own tip)

Read the lead's newest `lead.md` entry (the unsealed control): confirms plant A ("within a day" vs
the spec's "in days") and plant B (the unsourced "Most proposals are answered within the week.")
exactly as I reported, the control on me passed 2 of 2, and asks for a verdict on `4d11e60` itself.

Measured, on my existing clone, re-used rather than re-cloned (same repository, no risk of a stale
checkout since I control it and nothing else writes to it):

- `git checkout -q 4d11e60 && git log --oneline -1`: printed `4d11e60 Merge commit '07b1526' into
  worktree-agent-a244fe1f572cb18f3`. `git diff --stat 4d11e60 bd44300`, re-run fresh: unchanged from
  my first read - only `public/{MANIFEST,facts.json,corrections.html,propose.html}` and
  `site/pages/{corrections.py,propose.py}`, 12 lines total.
- **Both spots read correctly, checked directly at `4d11e60`, both in source and in the built page:**
  - `site/pages/corrections.py:39`: `[S("It is acknowledged in days, and given its disposition when
    it's true.")]` - matches `docs/SPEC.md` line 54 exactly. `public/corrections.html`: "It is
    acknowledged in days, and given its disposition when it's true." - confirmed in the built output,
    not just the source.
  - `site/pages/propose.py:117`: `render(["Money: ", S(MONEY), "."])` - no appended sentence.
    `public/propose.html`: the Money paragraph reads `Money: <span class="stated" ...>neither
    required nor sufficient ... standard</span><span class="src" ...> (stated by Logan,
    2026-09-29)</span>.</p></div><h2>...` - closes immediately after the sourced text; `grep -c
    "within the week" public/propose.html` = 0.
- **Fresh build and full gate**, LOGANW_REPOS set, LOGANW_FETCH=1, on the clean `4d11e60` checkout:
  `python site/build.py`: wrote 36 files. `bash verify/run.sh --require-all`: **11 passed, 0 failed,
  0 skipped. VERDICT: PASS, nothing skipped.** facts 1583 read again and the same, 0 different, 36
  stated; numbers 2600 marks in 36 files, 0 problems; controls 303 caught, 0 did not fail, 0 skipped;
  runner-control caught its own planted broken link, as it must. Identical figures to my `bd44300`
  run, as expected (the two plants changed no counts, only two spans' text).
- **The two side notes** (`row-typed-cell`'s docstring, ledger row 2's fix-commit citation) sit in
  code the plant never touched (`corrections.py`'s `controls()` and `ledger_rows()` are byte-identical
  between `4d11e60` and `bd44300`), so my earlier judgement - documentation imprecision, and a
  disclosed editorial compression, neither a defect under the READY standard - stands unchanged for
  `4d11e60`. Per the lead's message, both go to the side-notes step.
- **Everything else** I checked against `bd44300` (items 1-10 of my first report: the three
  `attack_first()` quotes, the COMPLIANCE.md check, both LICENSE reads, the ledger's `own_prose`/
  `own_entry`/`own_commit` patterns, the granted edits, seams, links/nav, the applicable SPEC
  decisions, the report's counts) is unaffected by the two-line difference between `4d11e60` and
  `bd44300` - none of it touches the two changed spots except to check their content, which is where
  this entry's own check closes the loop.

Believed: nothing beyond the above. `4d11e60` is READY: every property P4's pages claim is either
held by a gate I watched fail on a fault I picked (my own `door-not-early`, `dossier-corrections-link`,
`own_commit` faults; P4's own 12 controls, re-run fresh), or independently confirmed against its
source directly (every `stated()` line, every quote, both LICENSE reads).

For: lead

## 2026-09-30 04:38:56 -0700 - closing: urgent/ watch died (exit 255); checked the ledger for anything missed; nothing pending for verifier-P4; watch not re-armed

Measured:
- The background watch armed at 01:24:36 exited with code 255 at some point after 02:05 (its last
  captured lines: a P5 send-back and a note to verifier-seam, neither addressed to verifier-P4).
- Read `urgent/` in full (15 files) and `lead.md` from my last entry forward. Grepped for
  "verifier-P4" across `urgent/`: one hit, `lead-to-verifier-seam-576b08a.md`, addressed to
  verifier-seam, not to me.
- **What happened while the watch was down, all in `lead.md`:** my READY verdict on `4d11e60` (my
  last entry here) was accepted at 01:47:43; P4 merged into main locally, never `bd44300`. P5 went
  through one send-back and a re-check (verifier-P5's own territory, not mine), then merged. Wave 2
  merged to main at `576b08a`, verifier-seam found two more subset gaps (fixed at `1142ab9`,
  `8260fa8`), then went READY; main pushed and deployed at `8260fa8`, all nine pages live. A late
  pronoun fix (CLAUDE.md trap 18) went out and was verified by verifier-P5, deployed at `57bd202`.
  At 03:42:13 the lead recorded "round 1's two waves done; the round waits on Logan's decisions and
  the close" and "no agent is running; the urgent/ watch is not re-armed until the next dispatch."
- **My two side notes were triaged**, in the lead's 03:21:04 entry, items 7 and 8: `row-typed-cell`'s
  docstring is filed as "a comment fix in corrections.py: next batch"; the ledger row-2 citation is
  "accepted, or re-cite both: next batch." Both read exactly as I judged them - not defects, not a
  send-back.
- Nothing in any of this asks verifier-P4 for anything further, and the lead's own watch is
  deliberately down for the same reason. Not re-arming mine: a live watch on a closed round serves
  no one and risks reading the eventual archive pass as new traffic.

Believed: verifier-P4's task is complete. `4d11e60` is merged and live (inside `8260fa8`, confirmed
by the lead's own deploy record above); nothing further is asked of this session.

For: lead, anyone
