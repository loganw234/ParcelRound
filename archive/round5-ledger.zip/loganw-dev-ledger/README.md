# The round ledger (loganw.dev, round 1)

This is scaffolding for a parcel round, not history. It sits outside every
repository and is never committed. At the end of the round the lead folds
anything durable into `loganw.dev/docs/VALIDATION.md`, then archives this
directory with its timestamps.

It exists because **a brief is written once, at dispatch, and cannot be
updated.** Anything learned while the agents run would otherwise reach them
only in a final report, after the sibling who needed it has finished.

## How to use it

Reach it by its absolute path: `C:\Users\logan\source\repos\loganw-dev-ledger\`
(`/c/Users/logan/source/repos/loganw-dev-ledger/` from bash).

**One file per author, append only.** Yours is `<your-name>.md`: `lead.md`,
`P1.md`, `verifier-P0.md` and so on.

- Read every file here. Write only to your own.
- Never edit an entry, yours or anyone's. Correct one by appending a new
  entry beneath it, and link the correction from the entry it corrects with
  a line like "see 15:42".

**Read the whole directory at three moments.** These are the floor; the
`urgent/` watch below does the rest.

1. Before you start anything.
2. Before you design anything that touches a file your brief calls shared or
   forbidden.
3. Before you write your final report.

**Write an entry when it passes this test:** would it change another agent's
work, or the lead's? Three kinds of thing pass:

- environment and setup facts;
- a brief that turned out wrong, written the moment you find it;
- a finding about shared code.

Progress and plans don't pass.

**Mark what you measured.** Every entry says which of its claims were
*measured* and which are only *believed*.

**Timestamps come from the clock, never from memory.** Every author in
ParcelRound's round 2 typed a guessed time at least once, and the guesses
missed in both directions. Write each entry heading with `date`:

    printf '\n## %s - <headline>\n\nMeasured: ...\nBelieved: ...\nFor: ...\n' "$(date '+%Y-%m-%d %H:%M:%S %z')" >> <your-file>.md

**Your scratch directory is named in your brief.** Work only under it. No
secret is kept in any directory an agent is given.

**If a pause is announced** (a usage limit, or the owner's word), write an
entry saying exactly where you are before you stop.

## `urgent/`: the push channel

Every agent arms a watch on `urgent/` before starting anything, and keeps it
armed.

- **Arm it inline, not from a script file.** Everyone writes the same
  watcher script, so a shared file name gets clobbered.
- **Re-arm it when it expires, then read the whole directory.** A dead watch
  and a quiet directory look the same.
- **Put your questions for the lead in `urgent/`**, not in your own file.
- **One file per message, composed elsewhere and renamed into place:**
  `<who>-<slug>.md`. Its first line is the headline, and it carries a `For:`
  line.
- **Verifiers watch the lead's messages only.** Parcel self-reports would
  erode the independence a verifier is paid for.

    U=/c/Users/logan/source/repos/loganw-dev-ledger/urgent; seen=$(ls "$U" | sort); while true; do cur=$(ls "$U" | sort); comm -13 <(echo "$seen") <(echo "$cur") | while read -r f; do head -1 "$U/$f"; grep -m1 '^For:' "$U/$f" || true; done; seen=$cur; sleep 20; done
