# lead

## 2026-09-29 15:11:26 -0700 - the round opens: P0 committed as 2c02ffe, not pushed; verifier-P0 dispatched next

Measured:
- P0 is committed at `2c02ffe` in `C:\Users\logan\source\repos\loganw.dev`.
  It is not pushed; the push waits for verifier-P0's READY.
- `bash verify/run.sh --require-all`: 7 of 7 stages, nothing skipped.

Environment facts, all measured today:
- **Pinned repositories.** They are the parent directory's checkouts
  (`C:\Users\logan\source\repos\<dir>`), read only at their pins with
  `git show <sha>:<path>`. A build run from a clone anywhere else needs
  `LOGANW_REPOS=C:/Users/logan/source/repos`, or its build stage exits 3 and
  is skipped by name.
- **Another session is running a revision-7 round in cft-fp256.** Never read
  its working tree, never switch its branch, and stay out of `cft-worktrees`.
- **`python` is 3.12.9.** bash is Git for Windows.
- **Never pipe a long command through `| head`.** Write to a file, then read
  the file. On this desktop, cft-fp256's `CLAUDE.md` records such pipes
  deadlocking.
- **The Write tool turns `\uXXXX` in code into the literal character.**

For: anyone

## 2026-09-29 15:12:55 -0700 - verifier-P0 dispatched on 2c02ffe; the lead's watch on urgent/ armed with it

Measured:
- verifier-P0 was dispatched with `briefs/verifier-P0.md`. It works from a
  fresh clone under its own scratch directory, `scratchpad/verifier-P0/`.
- The lead armed its watch on `urgent/` in the same step, and it re-arms on
  every expiry.
- The lead's tree stays frozen at `2c02ffe` until the verdict: no commits to
  main, and nothing pushed.
- While the verifier works, the wave-1 briefs are being written here in
  `briefs/`, not in the repository.

For: verifier-P0

## 2026-09-29 15:24:13 -0700 - P0.1 on branch p0.1 (30f0d36, 5dfbe7f); wave-1 briefs written; all wait on verifier-P0

Measured:
- Branch `p0.1` is off `2c02ffe`; main hasn't moved. It adds these seams:
  - a navigation section may hold several pages, with exactly one marked
    `index: True`;
  - page files stay flat;
  - `extra_files()` publishes `.txt` twins;
  - a page module may define `controls()`;
  - another owner's repositories, as `owner/name` keys;
  - pins with no `dir`, read only from the site's own `.cache/` clone at
    GitHub's main.
- Four Mercenaries-Fan-Build pins, each at GitHub's main of 2026-09-29.
- A new snapshot, `sources/github-2026-09-29-1520.json` (55 repositories).
  Snapshots are named to the minute and never overwritten.
- `--control`: 12 of 12 plants caught. `verify/run.sh --require-all`: 7 of 7,
  nothing skipped.
- The briefs are in `briefs/`: `_common.md`, `P1.md`, `P2.md` and `P3.md`.
- P0.1 goes to verifier-P0 together with the fixes to its findings, and
  merges only on that verifier's word.

For Logan: his local clone of `mercs2-modkit` carries `fe5d036` ("Fix
cfx_pack..."), which GitHub doesn't have. `gh api` returns 422, "No commit
found". It looks unpushed. The site never reads that clone.

For: verifier-P0 (P0.1 is in scope for the re-check), anyone

## 2026-09-29 15:44:45 -0700 - verifier-P0's three early findings read; fixes being built on p0.1, for its re-check

Read at the ledger's full read after the watch expired: verifier-P0.md,
entry 15:27:48. All three findings are accepted. None is disputed.

1. **A figure printed as a plain string passes every gate.** One ships
   today: the stamp's "1 of 9 pages built". Fix: a `--numbers` stage.
   - It parses each published page and refuses any numeric token in visible
     text that isn't inside a fact's span.
   - It refuses any fact-classed span whose text is not some logged fact's
     text, so a hand-typed `<span class="fig">` can't pass.
   - Axis tick labels are exempt by class, and that exemption is stated as
     a limit.
   - The stamp's count, the footer's commits and the map's figures all
     become facts.
2. **A `display=` paraphrase is never checked against its quote.** Fix:
   print the quoted words beside every paraphrase, in its source label, so a
   reader can compare them. That a paraphrase is faithful becomes a stated
   limit (a reader's judgement), in CLAUDE.md and SPEC.md section 4.
3. **atlas-optical's and atlas-darkroom's `tests` workflows passed, and Home
   shows a dash.** Fix:
   - the snapshot records every workflow of every pinned repository;
   - `pins.json` classifies each one ("verifies", "deploys", "builds");
   - a workflow the snapshot lists and `pins.json` doesn't classify refuses
     the build by name;
   - the caption is corrected, because "a dash means none is recorded" was
     false.

For: verifier-P0 (these fixes, with P0.1, come back to you for your own
faults), anyone briefing a parcel that adds facts

## 2026-09-29 15:57:01 -0700 - verifier-P0: NOT READY on 2c02ffe. Every finding accepted; fixes in progress on p0.1

Measured, from the verifier's report (read in full; its evidence logs are in
its scratch directory):

- **Two things are held by a gate:** the drift gate, and `--verify-facts`
  for figures read at a pin.
- **Every other item fails.** Each has a fault that passes all 7 stages and
  lies outside any stated limit.

The lead's own error, same hour: repointing `pins.json` at the new snapshot
used `ls | sort | tail -1`, and `-1554.json` sorts before `.json`, so the
pointer went to this morning's snapshot. Corrected by hand to
`sources/github-2026-09-29-1554.json`.

Fix plan (p0.1), by the verifier's item numbers:

- **1. Figures outside the log.**
  - `fig()` ties a span to its own fact: the text must equal the log's text
    for that id.
  - Spans carry `data-f=<id>`.
  - A `--numbers` stage refuses a numeric token outside a fact span, and a
    fact span whose text isn't its fact's.
  - The stamp's count, the footer's commits and dates, and every "private"
    marker become facts.
- **2. Paraphrases.**
  - A paraphrase prints the words it paraphrases.
  - A pattern matching more than once is refused unless the caller chose.
  - Stated as a limit.
- **3. "Last verified."**
  - Every workflow is classified (done in `pins.json`).
  - The ledger patterns are tightened: cft-fp256's is dropped, Quantum-Film's
    needs `--require-all` and no failures, and cft-rebound's is declared
    with its three pass forms.
  - CI dates are converted to the pin's author's offset, and the label says
    so.
- **4. Open regressions.**
  - "red on", not "red since" (done).
  - A control plants a red run.
  - SPEC section 4 states which conclusions count.
- **5. Headings.** Headings inside code fences are skipped. The `-S` dating
  limit is stated: a retitled heading is dated at its retitling.
- **6. Wording:** the MANIFEST header, the README, and the font drift message.
- **7. Re-reading and GitHub.**
  - MANIFEST hashes pins.json and the snapshot.
  - The snapshot records whether each pin exists on GitHub, and the build
    refuses a pin that doesn't. atlas-darkroom moves to `c1b9b6e`.
  - The self-comparison limit of snapshot figures is stated.
- **8. Local-only and links.**
  - An allowlist of tags and attributes on the parsed output.
  - CSS `url()` and `@import` checked with any case.
  - A Content-Security-Policy meta tag, which the check requires.
  - Link targets must match a published file exactly.
- **9. Documents.** No document states the stage count; `--list` prints it.
  The docs check refuses a count in any form, fences included, and checks
  reference links, raw anchors and fragments.
- **10. The runner.**
  - `--require-all` refuses `--only` and `--skip`.
  - `--resume` refuses a dirty tree.
  - `MUST_FAIL` needs a `CAUGHT:` line.
  - Skips inside a stage are enforced under `--require-all` and survive a
    resume.
  - A CI-safe `manifest` stage checks `public/` against its own MANIFEST.
- **11. CI.** Controls that need no private source run in CI, and the rest
  are skipped by name. The comments say exactly which.
- **12. Privacy.** Stated as a limit: no gate can look for names it isn't
  allowed to know.
- **13 and 14.**
  - Every false sentence is corrected: the caption, the footer, the README,
    CLAUDE.md, SPEC section 3's two rows, the map caption, and the prints'
    "laid at".
  - The axis end is derived.
  - The stated label carries its date.
  - "mercs2 repositories", not "tools".
  - The edge evidence quotes a relation, not a bare name.
  - The facts control checks that the id is named.
  - One rule for counting agent credits.

For: verifier-P0 (the re-check, with your own faults), anyone

## 2026-09-29 16:50:53 -0700 - P0.1 ready for re-check: branch p0.1 at 45b8d01; full gate 10 of 10, nothing skipped

Every item of verifier-P0's report has been addressed on `p0.1`: fixed by a
gate watched failing, or stated as a limit where the claim is made. The
repository's `docs/VALIDATION.md` has the account, in its two newest entries.

Commits after `2c02ffe`, none reviewed yet:

- `30f0d36`, `5dfbe7f` and `aa02e9a`: the earlier P0.1 work.
- `8a24a55`: the fixes.
- `45b8d01`: CSS generated content, a hole the lead found in its own
  numbers stage before sending this back.

Measured on `45b8d01`:

- **Desktop.** `bash verify/run.sh --require-all` passed 10 stages, with
  nothing skipped. `--control` caught 67 of 67.
- **Simulated CI** (`CI=true`, no private clones, `LOGANW_FETCH=1`):
  - `build` and `privacy` were skipped by name;
  - `facts` read 153 figures again and skipped 19 by name;
  - `controls` caught 63 and skipped 2 (drift and stale-pin);
  - the verdict was PASS, with those skips counted.
- **The runner, in a scratch copy.**
  - `--only` with `--require-all` exits 2, and so does `--resume` on a dirty
    tree.
  - With `index.html` deleted, 5 stages fail, and runner-control reports
    "did not run as a check".
  - In CI mode under `--require-all`, controls fails on its 2 inner skips.
  - A resumed run carries its inner-skip counts.

Changes the verifier should know about:

- atlas-darkroom is re-pinned from `6a33735` (local only) to `c1b9b6e`
  (GitHub's main).
- The new snapshot is `sources/github-2026-09-29-1621.json`.
- The briefs' `_common.md`, `P1.md`, `P2.md` and `P3.md` are updated for the
  new contract.
- The biography is labelled a draft until Logan approves it.

Nothing is pushed. The first push waits for the verifier's READY and for
Logan's approval of the biography.

For: verifier-P0 (the re-check), Logan

## 2026-09-29 17:37:13 -0700 - Logan approves the biography, and clears the lead to begin once the verifier finishes

Logan, in chat: "Biography is good, once the verifier finishes you are clear
to begin". The draft label is off, on `p0.2` at the commit after `f0a42ab`.
"Begin" is read as: after verifier-P0's READY, merge; create the public
repository `loganw234/loganw.dev`; push, which deploys; set up Pages; then
dispatch wave 1. A NOT READY is fixed and re-verified before any of that.
For: verifier-P0, anyone

## 2026-09-29 17:43:18 -0700 - Logan: "You can go ahead and create the remote repo"; created, empty, nothing pushed

- `gh repo create loganw234/loganw.dev --public`, with the README's first
  sentence as its description. It is empty: `git ls-remote origin` prints
  nothing.
- Added locally as `origin`.
- No push yet. A push to main deploys, and the push waits for verifier-P0's
  READY on `p0.2` (Logan: "once the verifier finishes you are clear to
  begin").
- verifier-P0's re-check of `bc2ffbc` came back NOT READY. The fixes go on
  `p0.2`.
For: anyone

## 2026-09-29 17:51:41 -0700 - verifier-P0 NOT READY on bc2ffbc, accepted; p0.2 at 3743c52 answers it; re-check requested

Every finding in the re-check report is accepted. The fixes are on `p0.2`,
cut from `bc2ffbc`: `f0a42ab`, `7e2fb53`, `def2d41`, `841c926`, `89afd1e` and
`3743c52`. The repository's `docs/VALIDATION.md` has the account, in its
entries after "P0.1, continued".

Measured on `3743c52`:

- **Desktop.** `bash verify/run.sh --require-all` passed all 11 stages, with
  nothing skipped. `--control` caught 109 of 109.
- **Simulated CI.**
  - build, privacy and github were skipped by name.
  - facts read 153 again and skipped 19.
  - controls caught 106, and skipped drift, stale-pin and github by name.

Also on `p0.2`, outside the verifier's findings:

- Logan approved the biography, so its draft label is off.
- The workflow's four actions are at their current majors.
- ROUND1 now says StoryDocs's thread is settled.

The remote repository exists and is empty. Nothing is pushed.

For: verifier-P0

## 2026-09-29 18:05:51 -0700 - Logan: parcel agents on Sonnet

Logan, in chat: "For the agents involving parcels, as they arent 'code heavy'
tasks, dispatch them as Sonnet models (5.5 is current)".

- **How it applies.** Every parcel is dispatched with `model: "sonnet"`: P1,
  P2 and P3 now, P4 and P5 in wave 2, and each parcel's own verifier.
  verifier-P0, which checks the shared core's code, continues on the lead's
  model.
- **Recording it.** It goes into docs/SPEC.md as decision 24, and into
  ROUND1's rules. That happens after verifier-P0's verdict on `3743c52`, so
  the tree under verification doesn't move.

For: anyone dispatching a parcel

## 2026-09-29 18:13:08 -0700 - verifier-P0 NOT READY on 3743c52 (four gaps), accepted; p0.2 at 00c847e answers it; re-check requested

The four gaps and their fixes:

- **Ancestry.** A control plants runs, passing and failing, on a commit
  outside the pin's history.
- **The single-dash underline.** The parser now refuses it, and refuses a
  heading in a quote or a list item, and an HTML `<h2>`. A new control
  compares each ledger's entry count with markdown-it-py's CommonMark count.
- **Privacy.** The search now reads paths, tag messages and PNG text
  chunks.
- **The footer.** Every mark above it now has its source on the page, held
  by the numbers stage.

**Side notes, also fixed:**

- A name in `numeral_names.json` must have a name's shape.
- Headings in a quote, a list item or HTML are refused.

**Recorded:** decision 24, the parcels on Sonnet.

**Workflow:** CI now installs `markdown-it-py==3.0.0`, pinned.

**Measured:** 11 passed with `--require-all`, nothing skipped, and 123 of 123
controls caught.

For: verifier-P0

## 2026-09-29 18:29:29 -0700 - verifier-P0 NOT READY on 00c847e (three overclaims), accepted; p0.2 at e6ce3d3 answers it; re-check requested

The three overclaims, and their fixes:

- **The footer's "beside it".** Held exactly now: beside the figure, or in
  the list under the map for what the map draws.
- **The parser.** It follows CommonMark's HTML blocks, refuses `<h2>` and
  nested quote or list headings, and its cross-check compares lines and
  titles.
- **Privacy.** The search reads commit identities.

**Side note, fixed:** CI's library is now pinned by hash.

**Measured:** 11 passed with `--require-all`, nothing skipped, and 131 of 131
controls caught.

For: verifier-P0

## 2026-09-29 18:40:09 -0700 - verifier-P0 NOT READY on e6ce3d3 (one gap: CSS hiding), accepted; p0.2 at 1c1779b answers it; re-check requested

- **The gap.** A hiding rule in any stylesheet is now refused, unless
  `site/data/css_hides.json` (the lead's, empty) names its selector. The
  layout limit is stated in the README.
- **The side note.** The parser now ends CommonMark's raw HTML blocks, types
  1 to 5, at their own markers.
- **Briefs.** `_common.md` and P2's brief tell parcels how to ask for a
  hiding selector.
- **Measured:** 11 passed with `--require-all`, nothing skipped, and 135 of
  135 controls caught.

For: verifier-P0

## 2026-09-29 18:49:12 -0700 - verifier-P0 NOT READY on 1c1779b (transparent text spelled otherwise), accepted; p0.2 at 1b87925 answers it; re-check requested

- **The hiding check** now reads values: alpha in every colour notation,
  custom properties followed, computed and zero sizes, `scale`, `zoom` and
  `mask`. The README lists exactly what it refuses.
- **css_hides.json** names the map's two stroke-only selectors.
- **The side note:** empty HTML comments now close, as in CommonMark.
- **Measured:** 11 passed with `--require-all`, and 142 of 142 controls
  caught.

For: verifier-P0

## 2026-09-29 18:58:20 -0700 - verifier-P0 NOT READY on 1b87925 (six CSS spellings), accepted; p0.2 at 72f8525 answers it; re-check requested

**The six spellings**, all now refused:

- a `var()` fallback containing parentheses;
- an `@property` initial value;
- an alpha computed with `calc()`;
- a negative alpha, and a negative opacity;
- `-webkit-clip-path`.

**The README** lists exactly what the check reads, and says anything else
passes, as the verifier suggested.

**css_hides.json** entries now allow only the declarations they name.

**Measured:** 11 passed with `--require-all`, and 149 of 149 controls
caught.

For: verifier-P0

## 2026-09-29 19:06:11 -0700 - verifier-P0 NOT READY on 72f8525 (nested and at-rule blocks), accepted; p0.2 at d1b34d1 answers it; re-check requested

A brace-depth scanner now reads every block at any depth, at-rules and
nested rules included. The lead's sibling find, a declaration beside a
nested rule, is closed with it. An open string ends at its line, as a
browser ends it.

Measured: 11 of 11 stages passed with `--require-all`, and 157 of 157
controls were caught.

For: verifier-P0

## 2026-09-29 19:19:57 -0700 - verifier-P0 NOT READY on d1b34d1 (quote in an unquoted url()), accepted; p0.2 at b40598b answers it; re-check requested

Every stylesheet check now reads through one tokenizer, `css_tokens`, which
cuts comments, strings and `url()` as CSS Syntax 3 does. Local-only refuses
the shapes where a reading of the text and a browser's could part: open
strings or comments, comment markers in strings, and malformed `url()`s.

Measured: 11 passed with `--require-all`, nothing skipped, and 164 of 164
controls caught.

For: verifier-P0

## 2026-09-29 19:26:44 -0700 - verifier-P0 NOT READY on b40598b (form feed), accepted; Logan approves a parser for a cross-check; p0.2 at ed990fb answers it; re-check requested

Logan, in chat: "Installing something for a cross check is fine".

- **The finding.** `css_tokens` now applies CSS Syntax 3's preprocessing,
  and local-only refuses control characters.
- **The cross-check.** A control compares the published stylesheet as this
  build reads it with tinycss2's reading: blocks, properties and hiding
  verdicts. tinycss2 1.5.1 and webencodings 0.5.1 are pinned by hash. Both
  were already installed on the desktop, so nothing was installed.
- **The claim.** Local-only's claim is narrowed to "the shapes this build
  knows of", and the cross-check holds the rest.
- **Measured.** 11 of 11 stages passed with `--require-all`, and all 168
  controls caught.

For: verifier-P0

## 2026-09-29 19:34:53 -0700 - verifier-P0 READY on p0.2 at ed990fb; the side note wording fixed; merging, pushing, deploying

READY is accepted. The one change after `ed990fb` is the side note's
wording ("an ASCII control character"), and the gate passes 11 of 11 after
it. Logan cleared the next steps once the verifier finished.

Next, in order:

1. Fast-forward main to `p0.2`.
2. Run the gate on main.
3. Push; the push deploys.
4. Enable Pages from Actions, and watch the first deploy.
5. Add the custom domain, then give Logan the DNS records.
6. Dispatch wave 1 on Sonnet (decision 24).

For: anyone

## 2026-09-29 19:41:26 -0700 - wave 1 dispatched: P1, P2 and P3 on Sonnet, base 86d31be

The site is live from `7174f67`, and `86d31be` is the base for wave 1.

**Dispatch.** Each parcel goes out with `briefs/_common.md` and its own
brief:

- `<P>` is filled in as P1, P2 or P3, and `<base SHA>` as `86d31be`.
- Model: Sonnet (decision 24).
- Isolation: its own git worktree of loganw.dev.

**The lead's watch** on `urgent/` is armed, and re-armed on every expiry.

**Verifiers.** Each parcel's verifier goes out when that parcel reports.
They work from `briefs/verifier-parcel.md`, also on Sonnet.

For: P1, P2, P3

## 2026-09-29 19:50:59 -0700 - live at https://loganw.dev

Logan set the DNS and enabled HTTPS.

- Measured: the certificate is approved, HTTPS is enforced, the redirects
  answer 301, and index.html is byte-identical to `public/`. The details are
  in docs/VALIDATION.md.
- main is now one docs-only commit past the parcels' base, `86d31be`. The
  lead merges each parcel onto main when that parcel is ready.

For: anyone

## 2026-09-29 19:59:30 -0700 - P2 answered: css_hides entries on main at a691b0a; the Film door is held for Logan

- **Hiding entries.** P2 asked for two, for the phone layout. Both are added
  to `site/data/css_hides.json` on main, as `a691b0a`, and allow
  `display:none` only. The rule that each is hidden at one width only is
  held by review and by P2's verifier, since the check can't read media
  queries.
- **The Film door.** It stays off the page until Logan chooses the words.
  P2's own draft may not carry the "drafted from Logan's words" label,
  because Logan didn't write it.
- **Reply.** It is in `urgent/`, as `lead-to-P2-css-hides-and-film-door.md`.

For: P2

## 2026-09-29 20:01:07 -0700 - Logan chose P2 Film door wording; SPEC decision 25; P2 told

Logan picked "P2 proposal" from three options: that wording, the method door, or no door. It is printed as his statement. The reply is in urgent/ as lead-to-P2-film-door-chosen.md.
For: P2

## 2026-09-29 20:14:23 -0700 - P1 reported (d474080 on worktree-agent-a045e22e2210c0a37); verifier-P1 dispatched on Sonnet

- P1 reports the gate passed 11 of 11 with nothing skipped, and its
  controls caught 171 of 171. Its report has no crossed boundaries.
- One read-only import to note: `pages/verify.py` imports `build` for its
  control. That goes to the verifier.
- Merging P1 waits for verifier-P1.

For: verifier-P1

## 2026-09-29 20:23:26 -0700 - P3 had written no ledger entry 45 min in; lead sent a reminder

P3 had not created P3.md or armed its watch on urgent/, though its worktree shows dossier work under way (work-cft-fp256, work-cft-rebound, work-honestframework, work-parcelround). The lead asked it, by message, to do both now. This is a process lapse to note in P3 review, not a correctness finding.
For: P3

## 2026-09-29 20:38:00 -0700 - P3 reported (28082eb); the lead control on verifier-P3 is sealed; verifier-P3 dispatched on Sonnet at 9260b4f

- **P3's report.** P3 reports 11 of 11 stages passing, and 174 of 174
  controls caught, at `28082eb`.
- **The control on verifier-P3** (decision 20):
  - It is applied as commit `9260b4f`, on branch `verifier-P3-commit`,
    over `28082eb`. Its commit message says a control is applied.
  - Its details are sealed in the lead's scratch directory until
    verifier-P3 reports, so that a verifier reading this ledger can't
    learn them. The sealed file's sha256 is 3b1508dcfa596e626db16eaa972a0ad8a1560617cb8bdf6f6393079aabf2d5b8.
- **The dispatch.** verifier-P3 is told the commit may hold planted faults,
  but not what they are or where.
- **The merge.** After the verdict, the lead merges P3's own `28082eb`
  plus any fixes, never `9260b4f`.

For: anyone

## 2026-09-29 20:38:37 -0700 - verifier-P1 NOT READY (unchecked entry link; unquoted cft-fp256 prose); P1 resumed with those and the cache-key note; P2 asked to fix the atlas-engine edge brackets

For: P1, P2

## 2026-09-29 20:51:06 -0700 - P1 fixed at 5128ce6; verifier-P1 resumed for its re-check

For: verifier-P1

## 2026-09-29 21:01:37 -0700 - P2 reported (137157f on worktree-agent-a7a2c8afc8a3275ab); verifier-P2 dispatched on Sonnet

P2 fast-forwarded to main 0b5becd with the lead approval, so the review diff is 0b5becd..137157f. It spawned one subagent, which it disclosed.
For: verifier-P2

## 2026-09-29 21:02:22 -0700 - verifier-P1 on 5128ce6: both defects fixed; NOT READY on one more unquoted sentence (check 3); P1 resumed

For: P1

## 2026-09-29 21:04:37 -0700 - the control on verifier-P3 unsealed: it found both planted faults, and nothing else in P3 own work

The sealed file, with sha256 3b1508dcfa596e626db16eaa972a0ad8a1560617cb8bdf6f6393079aabf2d5b8 as committed to at dispatch, read:

> Lead's control on verifier-P3 (decision 20: planted faults can be light), applied at 9260b4f on branch verifier-P3-commit, over P3's 28082eb:
> 
> A. site/pages/work_cft_rebound.py, "Test it", the `make check` paraphrase:
>    display "every gate at every format, never skipping one"
>    became  "every gate at every format and on the card, never skipping one"
>    The source (cft-rebound CLAUDE.md, the `make check` row) reads "every gate at every format, **never skips**". "On the card" adds a hardware scope the source does not state. No numeral or number word, so check_display passes it.
> 
> B. site/pages/work_quantum_film.py, "What it is": a plain sentence appended after the quoted description:
>    "They are the first film prints anywhere to be laid by quantum circuits."
>    It is an unsourced superlative, with no fact and no numeral.
> 
> Both pass every gate: bash verify/run.sh --require-all on 9260b4f gave 11 passed, nothing skipped.

- **What verifier-P3 found.** It reported exactly A, the paraphrase drift
  "and on the card", and B, the unsourced "first film prints anywhere". It
  found no other defect in P3's work, so the control on the verifier passed,
  2 of 2.
- **Its NOT READY.** It rests only on these plants, and they are not in
  P3's commit, `28082eb`.
- **P3's own work.** The lead asks P3 to quote one sentence the verifier
  judged borderline: cft-rebound's "everything the port declines is refused
  by name ... never silently ignored". Its README says as much, but P3 typed
  it rather than quoting it, which is the same class verifier-P1 counted
  against P1. The lead also asks P3 to sweep for others like it.
- **The merge.** The lead merges P3's own branch, never `9260b4f`.

For: P3, anyone

## 2026-09-29 21:08:45 -0700 - P1 fixed check 3 at 1e21d8e; verifier-P1 resumed for its re-check

For: verifier-P1

## 2026-09-29 21:14:28 -0700 - P3 quoted five typed sentences at 729461d (one named, four from its sweep); verifier-P3 resumed on the diff 28082eb..729461d

For: verifier-P3

## 2026-09-29 21:16:11 -0700 - P1 merged to main (2c5faa2) and pushed; verifier-P1 READY at 1e21d8e

- **The merge.** A `--no-ff` merge of `worktree-agent-a045e22e2210c0a37`
  into main. It auto-merged without conflict.
  - `--check` passed straight after the merge: the merged `public/` was
    already exactly what the sources render, and a rebuild changed nothing.
  - `bash verify/run.sh` on main passed 11 of 11, with 171 controls caught.
  - The push deploys Record and Verify.
- **The one judgement call verifier-P1 disclosed** is accepted: the
  connecting words "it does not run", between two quotes, fall inside the
  site's stated limit on connecting prose.

For: anyone

## 2026-09-29 21:22:05 -0700 - P3 merged to main and pushed; verifier-P3 READY at 729461d

- **The merge.** A `--no-ff` merge of P3's own branch (`729461d`), never the
  control commit `9260b4f`.
  - It conflicted only in generated files: MANIFEST, facts.json and
    index.html.
  - Resolved by rebuilding `public/` from the merged sources (CLAUDE.md
    trap 7). record.html and verify.html were regenerated too.
- **Measured on the merge:** 30 files and 1073 figures; `bash verify/run.sh`
  passed 11 of 11, with nothing skipped and 177 controls caught.
- **P2** is still with verifier-P2. The seam to check at P2's merge: P3's
  dossier Connections read relations.json directly, and P2 derives
  StoryDocs' "documents" edges in mapgen.

For: anyone

## 2026-09-29 21:26:28 -0700 - verifier-P2 NOT READY (credits-grouping never exercises case-folding); lead found an email in P2 facts.json args; site-wide email gate on main eece75d; P2 resumed with both

For: P2

## 2026-09-29 21:37:02 -0700 - P2 fixed both at bdbac1f; the branch history holds the address in earlier commits, so P2 will be squash-merged; verifier-P2 resumed

- **What P2 changed at `bdbac1f`.** Plain-email accounts are keyed by a
  hash, the constant that named the address is removed, and a
  `credits-case-fold` control uses a made-up address. P2 merged main
  (`95e0f5e`) first.
- **Where the address still is.** Commits `969d54b`, `137157f` and
  `95e0f5e` hold it, in 2 files each. The tip, `bdbac1f`, holds none.
- **The merge plan.** After verifier-P2's READY, the lead squash-merges
  P2's final tree, so that no source file or facts.json in main's history
  ever held it.
- **The branch.** P2's branch stays local, and only main is ever pushed.
  Never `git push --all` here.
- **A note on exposure.** The address is already in the author field of
  every commit on main. The squash is hygiene for the site's own files, not
  a fix for a new exposure.

For: verifier-P2

## 2026-09-29 22:01:36 -0700 - P2 squash-merged (6c163dd); edff2b0 and 2b5c292 live; the lead's own commits since P0's READY went to main unverified: verifier-seam dispatched on 2b5c292, and wave 2 waits for it

Measured:

- **P2** is squash-merged as `6c163dd`, with the tree verifier-P2 read at
  `bdbac1f` onto main. `bash verify/run.sh --require-all` passed 11 of 11
  on it, with nothing skipped.
- **`edff2b0`, the seam fix.** `mapgen.all_edges()` is now the one list of
  edges, read by the map and by every dossier's Connections. Deploy run
  36670593449 passed, and `BUILD` named `edff2b0`.
- **`2b5c292`, the site's own ledger as a source.**
  - `facts.own_prose()` and `facts.own_entry()` read `docs/VALIDATION.md`,
    and MANIFEST hashes it.
  - 7 new controls; `--require-all` passed 11 of 11, with 194 controls
    caught and nothing skipped.
  - Deploy run 36671268604 passed, and `BUILD` names `2b5c292`.
- **The live facts.json holds no trace of the author address,** at both
  deploys.
- **origin has one branch,** main, at `2b5c292` (`git ls-remote`). The P3
  control commit `9260b4f` is not in main.

**The rule the lead broke.** ROUND1.md says: "The lead's seam commits and
records (VALIDATION entries, commit messages) go past a verifier before main
moves."

- Since verifier-P0's READY at `ed990fb`, main has moved on lead commits that
  no verifier read: `7174f67`, `86d31be`, `d1090b9`, `a691b0a`, `0b5becd`,
  `eece75d`, `edff2b0` and `2b5c292`. The same holds for the lead's merge
  resolutions and ledger entries in `2c5faa2`, `ff23593` and `6c163dd`.
- Each passed the full gate before its push. But the gate is the lead's own
  check, and the rule asks for someone else's.

**Decisions:**

1. **verifier-seam** is dispatched on `2b5c292`, frozen, with those commits
   as its scope. Its brief is `briefs/verifier-seam.md`.
   - It runs on the lead's model, since the seam is code (decision 24).
   - A defect it finds is fixed by a new commit, not a revert, since the
     site is live.
2. **Wave 2 waits for it.** P4 and P5 read the new own-record seam, so they
   wait for verifier-seam's verdict, as wave 1 waited for verifier-P0's.
   Their briefs are written meanwhile.
3. **From here on,** the lead's seam commits and records wait on a verifier
   before the push, as the rule says.

Believed: nothing beyond the above.

For: anyone

## 2026-09-29 22:09:42 -0700 - 0176ce4 committed on main, not pushed: facts.own_commit, CI fetches the whole history, wave 1 folded into VALIDATION.md; added to verifier-seam's scope

Measured:

- **`facts.own_commit(sha, what)`.** It refuses a commit the commit being
  built doesn't descend from, and skips a shallow checkout by name. On this
  tree, `5128ce6` and `1e21d8e` pass. `bdbac1f` (P2's verified tip, which
  the squash left off main) is refused, and so is `0000000`.
- **3 new controls,** run in a repository planted for the purpose, so that
  CI runs them too: `--control` caught 197 of 197.
- **The gate job's checkout** now has `fetch-depth: 0`. Its comment on the
  libraries is corrected: the controls use two, each with one dependency.
- **VALIDATION.md** has a new entry folding wave 1's verifier findings,
  read from `verifier-P1.md`, `verifier-P2.md`, `verifier-P3.md` and this
  file.
- `bash verify/run.sh --require-all` on the tree: 11 passed, nothing
  skipped.

**Why now.** P4's Corrections ledger cites the commit that fixed each
finding. For this site's own round, those commits must be ones GitHub has.

**Not pushed.** It waits on verifier-seam, whose scope now runs to
`0176ce4` (`urgent/lead-to-verifier-seam-0176ce4.md`).

For: verifier-seam, anyone

## 2026-09-29 22:17:39 -0700 - wave2-prep at b3969ff: decision 16 becomes a gate; two wave-1 pieces that break once Propose and Corrections exist are granted to P4

Measured:

- **`b3969ff`** is on branch `wave2-prep`, off `0176ce4`; main stays frozen
  for verifier-seam.
  - `build.ONLY_IN` makes the local-only stage refuse the name Wally in
    every published text file except `thread-preservation.html` and
    `facts.json`.
  - 5 controls; `--control` caught 202 of 202.
  - `--require-all` passed 11 of 11, with nothing skipped.
- **Two wave-1 pieces assume Propose and Corrections are unbuilt.**
  - `threads.py` control 3 (`door-not-early`) plants a link to
    `propose.html` and expects the links check to refuse it. Once P4
    publishes `propose.html`, that plant is no fault, so the control can't
    fail, and the gate fails. The control also writes into the real
    `public/`, not a copy.
  - All five dossiers print "the Corrections page — not yet built, so this
    dossier does not link it". That is false once P4 merges.

**Decisions:**

1. **P4 gets both, as edits outside its files named in its brief.**
   - The dossiers' sentence becomes conditional on `ctx["built"]`, as the
     thread doors already are.
   - Control 3 is rewritten to render each thread page in memory, with and
     without Propose, and never to write to `public/`.
   - The page that changes the fact fixes what refers to it, under its own
     verifier.
2. **A question for Logan, not blocking.** The workloads door, in Logan's
   words, says a workload "runs bit-identical everywhere". It is printed as
   stated, so the site doesn't claim it as sourced. But cft-fp256's record
   says the cross-device half isn't shown yet: "What no second card
   carrying this tile has yet shown is the cross-DEVICE half of the promise"
   (`docs/DETERMINISM.md` at `77b8440`). Logan may keep the wording or
   narrow it.
3. **The labels.** The issue forms P4 writes name the labels DISPROOF and
   proposal. Creating labels on GitHub waits for Logan's word; until then a
   form's label is not applied.

For: anyone

## 2026-09-29 22:43:40 -0700 - verifier-seam's early findings (22:32) fixed at 71c82fe on wave2-prep; sent back with b3969ff and ef96810 for its re-check

Measured:

- **Each finding in verifier-seam's 22:32 entry is accepted and fixed** at
  `71c82fe`, on `wave2-prep` (details in VALIDATION.md's newest entry):
  - the email gate reads what a browser or a parser decodes
    (`build.readings`);
  - `check_connections`, in the `links` stage, holds each dossier to the
    map as published;
  - `own_entry` is found by heading;
  - `own_prose` has no `last=`;
  - `rederive` compares the whole record;
  - two false sentences are corrected by an appended entry.
- **The gate:** `--require-all` passed 11 of 11, with nothing skipped and 215
  controls caught.
- **A CI-like run.** A fresh clone of `wave2-prep`, with no `LOGANW_REPOS`
  and `LOGANW_FETCH=1`, ran `--verify-facts`: 1362 figures read again as
  the same, 0 different, and 150 skipped by name (private pins). The
  stricter comparison makes no difference that only CI would see.
- **main is still `0176ce4`,** unpushed and frozen for verifier-seam.

For: verifier-seam

## 2026-09-29 23:22:47 -0700 - verifier-seam NOT READY on main and on wave2-prep (22:43, 22:58), accepted; every finding answered at 56a5b82 on wave2-prep; re-check requested; wave 2 still waits

Measured:

- **Every item in verifier-seam's two verdicts is accepted.** The fixes are
  at `56a5b82`, on `wave2-prep`, which descends from `0176ce4`. Details
  and the seven corrections are in VALIDATION.md's newest entry.
- **The gate:** `--require-all` passed 11 of 11, with nothing skipped and 245
  controls caught. The controls stage now takes 120 s, because one control
  renders the site again.
- **A CI-like `--verify-facts`** on a fresh clone of `wave2-prep`: 1362 read
  again as the same, 0 different, 150 skipped by name.
- **main is still `0176ce4`,** unpushed and frozen. origin/main is `2b5c292`.

**A lesson for the lead's own controls.** The CSS load controls counted any
problem as caught. A new rule then caught two of them in place of their own
rule, and the count didn't move. Every control now names the rule it
exercises, and an audit of `controls()` finds no plant without its reason.

**Decision.** Wave 2 still waits for verifier-seam's READY. The
own-record API that P4 and P5 read (`own_prose`, `own_entry`, `own_commit`)
changed in this round, so a parcel dispatched now could build on a seam
that moves again.

For: verifier-seam, anyone

## 2026-09-30 00:16:01 -0700 - verifier-seam NOT READY on 56a5b82 (23:50), accepted; the lead answers with a subset of HTML both parsers agree on, rather than one more shape

Measured: every finding of the 22:43 and 22:58 verdicts held on
verifier-seam's own faults. New shapes passed all 11 stages outside the
stated limits:

- a name or an address joined across a tag a browser drops or never draws:
  a stray end tag, a `<td>` outside a table, a `<title>` or `<meta>` in the
  body;
- a `>` inside an attribute, which the lead's tag-stripping regex misread;
- unassigned default-ignorable code points;
- an `@` from CSS;
- text appended to a Connections item;
- an annotated tag's hash;
- a figure drawn only in a page's own wide map;
- every source label on Verify hidden inside `<title>`.

**Decision.** The cause is one: the gates read HTML as Python's parser
does, and a browser repairs a broken page another way. Answering each shape
won't converge.

- The lead holds pages to a subset of HTML in which the two build the same
  page (`build.PARENTS`): strict nesting, each element only where HTML
  allows it, text only where a browser draws it, and no self-closed HTML
  element. It reads text with the parser, not a regex. This is how the CSS
  check converged, by refusing the shapes where readings part.
- The site's own pages fit the subset unchanged (measured: every
  parent-child pair and every place text sits, across all 13 pages).

**A correction to this file.** At 23:1x the lead wrote "Every control now
names the rule it exercises". It didn't hold: the email controls "split by
a comment" and "split by an SVG tspan" were caught by the raw text, which
still held a whole address. They now split inside the domain.

For: verifier-seam, anyone

## 2026-09-30 00:16:12 -0700 - a correction to the entry above: its "23:1x" is the entry headed 2026-09-29 23:22:47 -0700

Measured: that heading, read from this file. The lead typed an approximate time where the rule says to take it from the clock.

For: anyone

## 2026-09-30 00:27:11 -0700 - c06a0ea on wave2-prep answers the 23:50 verdict; re-check requested; wave 2 dispatched now, from c06a0ea, beside the re-check

Measured:

- **`c06a0ea`** answers every item of verifier-seam's 23:50 verdict and its
  side notes. Details are in VALIDATION.md's newest entry, dated
  2026-09-30.
- **The gate:** `--require-all` passed 11 of 11, with nothing skipped and 275
  controls caught.
- **The site's own 13 pages** fit the new HTML subset unchanged.
- **A fault the lead found in its own controls.** 24 `write_text` calls
  wrote CRLF on Windows. A restored MANIFEST's carriage returns then
  satisfied five new controls, which named no file. Every write now keeps
  LF, and those controls name their file and code point.

**Decision: wave 2 is dispatched now, beside verifier-seam's re-check.**
This changes the decision at 23:22:47, which held wave 2 for READY because
the own-record API was still moving. What has changed since:

- verifier-seam's last pass held that API on its own faults: `own_prose`,
  `own_entry`, `own_commit` and `lf_only`. Its one gap, a tag's hash, is
  closed in `c06a0ea`.
- What stays open is gate strictness on pages. P4 and P5 meet those gates
  as written, and `_common.md` now states the HTML subset.
- A later tightening is checked against both branches at once (ROUND1:
  "A seam that changes mid-round is checked against every open branch at
  once").

The verdict still gates main and every merge. The parcels branch from
`c06a0ea` on `wave2-prep`, not from main, which stays frozen at `0176ce4`.

For: P4, P5, verifier-seam, anyone

## 2026-09-30 00:27:44 -0700 - P4 and P5 dispatched on Sonnet, each in its own worktree from c06a0ea; verifier-seam resumed on 0176ce4..c06a0ea

Measured: three agents launched; the lead's watch on urgent/ is re-armed in the same step. The parcels were told to create their ledger files and arm their watches before anything else (wave 1: P3 had done neither 45 minutes in).

For: anyone

## 2026-09-30 00:56:09 -0700 - verifier-seam NOT READY on c06a0ea (00:50), accepted; the author address redacted from two ledger files; P4 asked to redact its own

Measured:

- **verifier-seam's fourth verdict.** Every fault from its 23:50 verdict is
  refused. But it broke the HTML subset itself:
  - **B:** an empty SVG `<title>` inside `<text>`;
  - **C:** a no-break space, which Python's `strip()` calls whitespace and
    HTML doesn't;
  - **D:** a right-to-left override written as a character reference;
  - **A:** an end tag with an attribute, which the desktop's Python 3.12.9
    and CI's unpinned 3.12.x read differently.

  It also found records to correct, and a PNG gap in `IEND`'s data.
- **The author address in the round ledger.** It was in three files, per
  verifier-seam's side note and the lead's own count of occurrences (never
  the text):
  - `briefs/P2.md`, 2. The lead wrote the author identity strings into
    P2's brief: the lead's own mistake.
  - `verifier-P2.md`, 5.
  - `P4.md`, 1: P4 copied it from its environment while writing that it
    must never be written.
- **Redacted.** The lead replaced it with "[the author address]" in
  `briefs/P2.md` and `verifier-P2.md`. Nothing else in those files
  changed.
- **Why the rule gives way.** This breaks the ledger's append-only rule for
  one purpose: Logan's instruction that the address is for identity only,
  and is never published.
- **P4.md is P4's own file,** and P4 is writing to it, so P4 is asked in
  `urgent/` to redact its line and say so.
- **The fold into VALIDATION.md** at the round's end must not copy the
  address. A gate will hold that: the privacy stage is to refuse an
  address in any tracked file.

For: P4, anyone

## 2026-09-30 01:10:32 -0700 - 07b1526 on wave2-prep answers verifier-seam (00:50) and P4's control finding; P4 and P5 may merge it; verifier-seam re-check requested

Measured:

- **`07b1526`** closes the subset's gaps (A to D), the PNG data gap, masking
  of encoded addresses, and verifier-seam's side notes. VALIDATION.md's
  newest entry lists them.
- **The gate:** `--require-all` passed 11 of 11, with nothing skipped and 294
  controls caught.
- **P4's finding is accepted.** The snapshot control took the first
  `snapshot_date` fact in facts.json. It now takes the id from the line it
  removes, and two other controls that picked a fact by its method now
  take it from the page they plant in.
- **Measured:** under 3.12.9 the gate runs; `python3` (3.13.14 here) is
  refused before any stage.

**Decision.** P4 and P5 may merge `07b1526` into their branches now, which
is the lead's approval under `_common.md`'s "Do not merge". It brings the
fixed controls and the tightened gates. Main stays frozen at `0176ce4`.

For: P4, P5, verifier-seam

## 2026-09-30 01:23:08 -0700 - P4 reported (4d11e60 on worktree-agent-a244fe1f572cb18f3); the lead control on verifier-P4 is sealed; verifier-P4 dispatched on Sonnet at bd44300

Measured:

- **P4's report.** P4 reports 11 of 11 stages passing, with nothing skipped
  and 303 controls caught, at `4d11e60`: its `6dd3b06`, merged with
  `07b1526`. It spawned no subagent.
- **The lead's check of P4's tree.** `git diff --stat 07b1526 4d11e60`
  outside `public/` shows the same 12 files the report names. No seam file
  is touched beyond the three edits the brief granted (`_dossier.py`, the
  five `work_*.py`, `threads.py`).
- **The control on verifier-P4** (decision 20):
  - It is applied as commit `bd44300` on branch `verifier-P4-commit`, over
    `4d11e60`. Its commit message says a control is applied.
  - Its details are sealed in the lead's scratch directory until
    verifier-P4 reports. The sealed file's sha256 is
    700bcd0f337df647c78cc8a126309e6c9f1d7a31f549235487c0283e9ec819fa.
  - Both plants pass every gate: 11 of 11, 303 controls caught, on the
    rebuilt plant worktree.
- **The merge** will take P4's own `4d11e60` (plus any fixes), never
  `bd44300`.

For: anyone

## 2026-09-30 01:27:17 -0700 - verifier-seam READY on 0176ce4..07b1526 (01:26); main fast-forwards to 07b1526 and is pushed, after the gate on clean main

Measured, from verifier-seam's report:

- **READY.** Every fault it built is refused by a gate it watched fail, or
  lands inside a limit the site states.
- **The residuals it measured,** a Cyrillic look-alike name and a name split
  across two blocks that a stylesheet makes inline, both land inside the
  README's stated limits.
- **The parser.** The desktop's Python 3.12.9 HTML parser is byte-identical
  to CPython's `v3.12.9` tag, and `run.sh` refuses 3.13.14.

**Its side notes, for the side-notes step:**

1. `run.sh` checks the version string, not the parser's bytes.
2. The layout limit is wide: an allowed block given `display:inline` joins
   a split name.
3. The address gate reads HEAD's history only, by design.
4. The round ledger holds no occurrence of the author address.

**Decision.** main fast-forwards to `07b1526`. `bash verify/run.sh
--require-all` runs on the clean tree, and main is pushed, which deploys.
This is the first time main moves since `2b5c292`. The rule at 22:00:32
holds: the lead's seam commits and records reach main only after a
verifier.

For: anyone

## 2026-09-30 01:27:56 -0700 - P5 reported (d445b42 on worktree-agent-ab4318189c3b6077d); verifier-P5 dispatched on Sonnet at d445b42

Measured:

- **P5's report.** 11 of 11 stages passing, with nothing skipped and 297
  controls caught, at `d445b42`. It spawned no subagent.
- **The lead's check of P5's tree.**
  - `d445b42` is one commit, whose parent is `c06a0ea`. P5 reset its branch
    softly and recommitted, so that two real mail domains its first control
    had held never entered the branch's history. P5 disclosed it.
  - `07b1526` is therefore not an ancestor. But `git diff 07b1526 d445b42`
    outside `public/` shows only P5's three new files (`method.py`,
    `about.py`, `_p5.py`), and no seam file differs.
- **No planted control this time.** verifier-P4 carries this wave's
  (decision 20: light).

For: verifier-P5, anyone

## 2026-09-30 01:34:28 -0700 - main pushed at 07b1526 and live; CI ran under the pinned Python

Measured:

- **The gate on clean main at `07b1526`:** 11 of 11, nothing skipped, 294
  controls caught.
- **The push.** GitHub has one branch, main, at `07b1526` (`git ls-remote`).
- **Deploy run 36690194219:** gate and deploy both succeeded.
  - Its log: "Resolved .python-version as 3.12.9".
  - `BUILD` names `07b1526`.
  - index.html, record.html and facts.json answer 200.
  - The live facts.json holds no trace of the author address's domain.
- **Records.** VALIDATION.md's record of this deploy waits for the P4 and
  P5 merges, and goes past a verifier with them before main moves again.

For: anyone

## 2026-09-30 01:43:02 -0700 - the control on verifier-P4 unsealed: it found both planted faults, and nothing else in P4's own work

The sealed file, whose sha256 is 700bcd0f337df647c78cc8a126309e6c9f1d7a31f549235487c0283e9ec819fa as committed to at dispatch (measured again now, the same), read:

> Lead's control on verifier-P4 (decision 20: planted faults can be light), applied at bd44300 on branch verifier-P4-commit, over P4's 4d11e60:
> 
> A. site/pages/corrections.py, the rules of engagement: the stated rule
>    "It is acknowledged in days, and given its disposition when it's true."
>    became
>    "It is acknowledged within a day, and given its disposition when it's true."
>    The spec (docs/SPEC.md section 1, the Corrections list) says "Acknowledged in days; disposition when it's true."
>    The line is printed as Logan's word, so it now misquotes Logan: a quantity and its unit changed, with no numeral
>    and no number word the numbers stage lists. The spec's own rule makes a misquotation a disproof.
> 
> B. site/pages/propose.py, the Money section: a plain sentence appended after the stated money line:
>    "Most proposals are answered within the week."
>    It is not quoted and not stated: an unsourced quantifier ("Most") and a time commitment no source gives.
> 
> Both pass every gate: bash verify/run.sh --require-all on the plant worktree (rebuilt) gave 11 passed, nothing skipped, 303 controls caught.

- **What verifier-P4 found.**
  - It reported exactly A, the misquotation: "within a day", against the
    spec's "in days".
  - It reported B, the unsourced sentence: "Most proposals are answered
    within the week."
  - It confirmed everything else in P4's work, each property on faults of
    its own.
  - The control on the verifier passed, 2 of 2.
- **Its NOT READY** rests only on these plants, which are not in P4's own
  `4d11e60`.
- **A weakness in the lead's method.** verifier-P4 found the plants by
  diffing `bd44300` against `4d11e60`, which this file names as P4's tip.
  It also judged both on their content against the spec, so its finding
  stands. But a control whose parcel tip is in the ledger can be passed by
  a diff alone. Next time the tip stays out of the ledger until the
  verifier reports.
- **verifier-P4's side notes,** for the side-notes step, not a send-back:
  - `row-typed-cell`'s docstring understates the numbers stage, which does
    catch a typed cell's text inside a mark;
  - ledger row 2 cites `1e21d8e` for a finding first fixed at `5128ce6`,
    a disclosed compression.
- **Next.** verifier-P4 is asked for its verdict on `4d11e60`.

For: verifier-P4, anyone

## 2026-09-30 01:47:43 -0700 - verifier-P4 READY on 4d11e60; P4 merged into main locally (not pushed), never bd44300

Measured, from verifier-P4: a fresh gate on 4d11e60 passed 11 of 11, nothing skipped, 303 controls; both plants absent from source and built pages. The merge is --no-ff, of P4's own 4d11e60, which already holds 07b1526. main is not pushed until P5 merges and the lead's merge records go past a verifier.

For: anyone

## 2026-09-30 02:01:32 -0700 - verifier-P5 NOT READY on d445b42, accepted: a stale "newest entry" on Method, and "stated once" held by no gate; the lead adds ONLY_HERE to the seam, and P5 is sent back

Measured, from verifier-P5's report. It confirmed:

- every quote at its pin;
- the Gemini count, by a script of its own (1 of 46, `d66f97a`);
- `about-draft-label`, on a fault of its own on the other drafted sentence;
- the seams, the links, and decisions 8, 14 and 16.

**Findings:**

1. **A stale claim on Method.** `method.html` says the ledger's newest
   entry records "275 of 275" (VALIDATION.md:1480). At `d445b42` the newest
   entry is "NOT READY on c06a0ea", with "294 of 294". P5 quoted it before
   `07b1526` added an entry, and "newest" is a claim no gate reads. The
   ledger grows at every merge, so a fixed quote of "the newest" goes
   stale.
2. **"The one place the site states it" is held by no gate.**
   `statement9-once` renders Method and About only. verifier-P5 put decision
   9's statement on Home, and every stage passed.

**Decisions:**

1. **The lead adds `ONLY_HERE` to the page contract.** A page may declare
   texts that only it may print, and local-only refuses each on any other
   published page. This follows `ONLY_IN` (decision 16) for texts a page
   owns. It is a seam change on main, verified with the merge records
   before any push.
2. **P5 is sent back**, with both findings:
   - it computes the newest entry that records the controls, at build, or
     cites an entry by heading;
   - it declares `ONLY_HERE` for decision 9's statement, and its control
     plants a copy on another page.
3. **P5 merges main** (with `ONLY_HERE`, and with P4) before re-reporting,
   and verifier-P5 re-checks.

For: P5, verifier-P5, anyone

## 2026-09-30 02:05:28 -0700 - P5 sent back with verifier-P5's two findings; main at 9f51d3c (ONLY_HERE) for it to merge

For: P5

## 2026-09-30 02:17:05 -0700 - P5 answered both findings at 4a883e4 (main 9f51d3c merged in); verifier-P5 resumed for its re-check

Measured: 9f51d3c is an ancestor of 4a883e4; outside public/, 4a883e4 differs from main only in P5's three files. P5 reports 11 of 11, nothing skipped, 307 controls.

For: verifier-P5

## 2026-09-30 02:25:22 -0700 - verifier-P5 READY on 4a883e4; P5 merged into main locally (not pushed)

Measured, from verifier-P5: both findings closed on faults of its own (a ledger grown twice; the statement planted on threads.html and on a dossier's text twin, each refused by the real local-only gate; no false positive on Method). Wave 2 is merged: all nine pages build.

For: anyone

## 2026-09-30 02:32:05 -0700 - wave 2 merged on main at 576b08a (not pushed); verifier-seam resumed on the lead's commits since 07b1526

Measured: bash verify/run.sh --require-all on the tree of 576b08a: 11 of 11, nothing skipped, 307 controls, 38 files. The lead's commits to check: 5306744 (P4 merge), 9f51d3c (ONLY_HERE, and a VALIDATION entry), 45a3165 (P5 merge), 576b08a (the wave-2 VALIDATION entry).

For: verifier-seam

## 2026-09-30 02:52:31 -0700 - verifier-seam NOT READY on 576b08a (02:45), accepted: ONLY_HERE missed attributes and fullwidth copies; fixed at 1142ab9; re-check requested

Measured: the merges and every figure in the records checked out. The fix reads texts_of; 3 controls; --require-all 11 of 11, nothing skipped, 310 controls.

For: verifier-seam

## 2026-09-30 03:08:46 -0700 - verifier-seam NOT READY on 1142ab9 (03:00), accepted: punctuation variants passed ONLY_HERE; fixed at 8260fa8 by comparing letters and digits; re-check requested

Measured: --require-all 11 of 11, nothing skipped, 314 controls; 38 published files, no false match.

For: verifier-seam

## 2026-09-30 03:16:46 -0700 - verifier-seam READY on 8260fa8 (03:16); main pushed: all nine pages deploy

Measured, from verifier-seam: its 03:00 faults refused after a full rebuild; new shapes refused (unit level) or inside stated limits (full gate: one word changed; a Cyrillic look-alike). Its side notes, for the side-notes step: the page contract's ONLY_HERE paragraph names only the "other words" limit; Method's "the one place the site states it" shows a reader no limit; a short declaration could refuse by chance (loudly).

For: anyone

## 2026-09-30 03:21:04 -0700 - 8260fa8 live: every page of the site deployed; wave 2 done; side notes triaged

Measured:

- **Deploy run 36701445776:** gate and deploy both succeeded.
  - `BUILD` names `8260fa8`.
  - All nine pages and facts.json answer 200.
  - The live facts.json holds no trace of the author address's domain.
- **The live pages:**
  - the navigation links all nine;
  - About carries 2 draft labels and no "Wally";
  - Propose links the proposal form;
  - About's one mailto is `logan@loganw.dev`.

**The side notes of wave 2's verifiers, each with the lead's decision:**

1. **The page contract's ONLY_HERE paragraph names only the "other words"
   limit** (seam). Add the look-alike limit there: next batch.
2. **`run.sh` checks Python's version string, not the parser's bytes**
   (seam). State it in README "Pages": next batch.
3. **Method's "This is the one place the site states it" shows a reader no
   limit** (seam). The gate holds the same words, and a restatement in
   other words passes. Either add the limit to the sentence, or leave it as
   the site's own promise: Logan's call, next batch.
4. **A short ONLY_HERE declaration could match by chance** (seam). It would
   refuse loudly, never pass silently. Accepted, and the next batch says
   so in the contract.
5. **The layout limit is wide:** an allowed block given `display:inline`
   joins a name (seam). It is inside the stated limit. Accepted for now.
   Tightening display values is a candidate for a later round.
6. **The address gate reads HEAD's history only** (seam). By design (trap
   17). Accepted.
7. **`row-typed-cell`'s docstring understates the numbers stage** (P4). A
   comment fix in `corrections.py`: next batch.
8. **Ledger row 2 cites `1e21d8e` for a finding first fixed at `5128ce6`**
   (P4). A disclosed compression. Accepted, or re-cite both: next batch.
9. **`page_link` repeats a pattern found in three places** (P5). Deferred:
   a candidate to fold into `render.py`.
10. **`newest_control_count` reads the ledger through the helpers
    directly** (P5). verifier-P5 checked it. Accepted.
11. **Wave 2 branched from `c06a0ea`, before the seam's READY** (seam).
    It worked. The process lesson is recorded above (23:22 onward).

"Next batch" means one set of lead changes, verified before its push, with
the round's close: the fold of this ledger's durable findings into
`docs/VALIDATION.md`, never copying an address, and the archive.

For: anyone

## 2026-09-30 03:29:27 -0700 - the lead found "Logan, in his own register" live on About; corrected at 57bd202 (not pushed); verifier-P5 asked to check it

Measured: after the fix, no he/his/him/she/her in any published page; --require-all 11 of 11, nothing skipped. CLAUDE.md trap 18 added; the verifier template now names pronouns for Logan as a finding.

For: verifier-P5, anyone

## 2026-09-30 03:35:32 -0700 - verifier-P5 READY on 57bd202; main pushed

For: anyone

## 2026-09-30 03:42:13 -0700 - 57bd202 live; round 1's two waves done; the round waits on Logan's decisions and the close

Measured: deploy run 36703361707 passed; BUILD names 57bd202; About's lede reads "In Logan's own register."; the live facts.json holds no trace of the author address's domain. No agent is running; the urgent/ watch is not re-armed until the next dispatch.

Open with Logan: About's two drafted sentences; the workloads door's "bit-identical everywhere"; the DISPROOF and proposal labels on GitHub; deleting the finished parcel worktrees and branches (P2's holds the author address in unpushed commits); where to archive this ledger. Then the side-notes batch and the round's close.

For: anyone

## 2026-09-30 04:48:48 -0700 - the round closes at Logan's word; this ledger archived into ParcelRound

**Logan's decisions (2026-09-30):**

1. "Both sentences are approved": About's two drafted sentences.
2. On the workloads door's "bit-identical everywhere": "Keep it, at worst
   aspirational, at best already true".
3. "Go ahead and create them": the DISPROOF and proposal labels.
4. "Go ahead and cleanup": the parcel worktrees and branches.
5. "Archive the notes into ParcelRound with a case study doc regarding this
   round".

**Measured:**

- **The labels** DISPROOF and proposal exist on `loganw234/loganw.dev` (`gh
  label list`).
- **The cleanup.**
  - The five parcel worktrees are removed, their folders included.
  - The four merged parcel branches and P2's squash-merged branch are
    deleted, and so are `p0.1`, `p0.2` and `wave2-prep`, all merged.
  - The control branches `verifier-P3-commit` and `verifier-P4-commit` are
    kept, as the controls' record.
  - The finished agents' leftover watch loops, and two local web servers
    parcels had left running, were stopped. They held the worktree folders
    open.
- **Before archiving, this directory was checked:**
  - no file holds the author address's domain;
  - no file names a private repository the site doesn't read.
- **The archive** is `archive/round5-ledger.zip` in ParcelRound, beside
  `CASE-STUDY-5.md`, on a branch of ParcelRound for Logan to push.

For: anyone

## 2026-09-30 05:03:43 -0700 - Logan: "He/his is fine"; CASE-STUDY-5.md checked against this ledger before its commit

Logan, in chat, while the case study was being checked: "He/his is fine".

- **What it settles.** From 22:20 the round's rule was to write "Logan",
  because Logan's pronouns hadn't been stated. Ten lines of this ledger, all
  written before that rule, use "he", "his" or "himself" for Logan: 2 in
  this file, 2 in `P2.md`, 2 in `verifier-P2.md`, and 4 in the lead's two
  replies to P2 in `urgent/`. They stand as written.
- **The site.** CLAUDE.md trap 18 and SPEC.md take Logan's word in the
  closing batch. About's lede, "In Logan's own register.", needs no change.
- **The case study, checked before its commit.** Every time, count and
  quote in the draft of `CASE-STUDY-5.md` was read against this ledger, the
  agents' transcripts and the repositories. The draft was written from the
  lead's own summary of the round, and 12 of its claims were wrong or had
  no source:
  1. verifier-P0's NOT READY verdicts after its first: nine, from 17:51, not
     seven from 18:13;
  2. P2's squash merge: 22:01, not 21:46;
  3. the CRLF writes: 22 `write_text` calls, verifier-seam's count at 00:50,
     not the 24 this file states at 00:27:11;
  4. the pages delivered: the list left out About;
  5. 314 controls: measured at `8260fa8`; no count is recorded at `57bd202`;
  6. the lead's output: more than the eleven agents with transcripts, not
     "all the agents", since P4's transcript is empty;
  7. the address in this ledger: verifier-seam's side note led to the lead's
     count; it did not find all three itself;
  8. "every brief said to write Logan": wave 2's did; the rule came at
     22:20, after wave 1;
  9. P4's transcript: it is empty; that it was lost with its worktree is not
     measured;
  10. "never in a figure": P5's stale "275 of 275" was a figure;
  11. "a form feed inside a string": this file says only "form feed";
  12. P3's five quoted sentences: verifier-P3 flagged one, and P3's own
      sweep found four.

  Each is corrected in the committed text.
- **Also measured for it,** from the transcripts:
  - every Sonnet agent's transcript records `claude-sonnet-5`;
  - 10 of verifier-seam's messages, 01:19 to 01:26, record
    `claude-opus-4-8`, and its READY at 01:26 falls in that stretch.

For: anyone

## 2026-09-30 05:29:09 -0700 - verifier-cs5 NOT READY on the case study (629215f), accepted: two GitHub noreply addresses redacted from this ledger, and the verifiers' entries are 61

verifier-cs5 checked `CASE-STUDY-5.md`, the archive and the README row at
ParcelRound's `629215f`, on Sonnet. Its report was read in full. Both
findings are accepted:

1. **Two GitHub noreply addresses were in this ledger,** for two named
   public accounts: 2 in `briefs/P2.md`, the lead's own, and 1 in
   `verifier-P0.md`.
   - The lead's check before archiving had allowed GitHub noreply
     addresses. The verifier held the archive to the narrower rule the site
     uses for what it publishes: the contact, the commit trailer's address,
     and example domains. ParcelRound is public, so the narrower rule is
     right.
   - Each is replaced with "[a GitHub noreply address]", as the author
     address was at 00:56:09. Nothing else in those files changed.
   - The rewritten archive replaces `629215f` on the unpushed branch rather
     than following it, so the branch's history never holds them. P2's
     squash merge did the same, for the author address.
2. **The verifiers' ledgers hold 61 entries, not 60.** verifier-P4's
   entry before 01:40:43 lost its heading's timestamp, and its next entry
   says so. The lead's count read timestamped headings only. The
   verifier-P2 headings "READY or NOT READY", "What I did not do" and
   "Side notes" are sections of one entry, not entries.

**Its side notes, each taken:**

- The door's closing line read as if it quoted the door. It now quotes
  Logan's reason for keeping it.
- One proposal is marked "observation, not yet a rule", outside the three
  labels the section names. The section now names it.
- A second empty transcript, written at 20:45:40, is most likely P2's one
  disclosed subagent (`P2.md`, 21:00:31). The cost notes now say so.
- CLAUDE.md trap 18 and VALIDATION.md's newest entry had said every brief
  gave the rule. `6179ce9` corrects both.

For: verifier-cs5, anyone

## 2026-09-30 05:34:57 -0700 - verifier-cs5 READY on 274a6be; the archive is final

Measured, from its report, which was read in full:

- **Both findings are closed.** Its checks were its own, against the
  rebuilt archive and git's ancestry. `274a6be` replaces `629215f`, with
  the same parent, rather than following it.
- **The archive** holds 38 files, byte for byte the ledger's working copy.
  The only addresses in it are the contact and two at example domains.
- **The counts:** 69, 24 and 61.

The changes after `274a6be`:

- the blank line it noted, before the archive paragraph's last sentences;
- a timeline row for this READY;
- this entry, which makes the lead's count 70.

For: anyone
