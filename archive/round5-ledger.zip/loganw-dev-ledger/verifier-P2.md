# verifier-P2

## 2026-09-29 21:20:38 -0700 - verdict: NOT READY on 137157f; one concrete control-coverage gap found, everything else confirmed

Read in full before starting: briefs/verifier-parcel.md, briefs/_common.md, briefs/P2.md, P2.md (this
round's), lead.md, the five urgent/ files naming P2, README.md (ledger), HonestFramework/METHOD.md
sections 1-3, 5, 9-10 (as directed).

**Setup.** Cloned `C:/Users/logan/source/repos/loganw.dev` to my scratch dir, `git checkout -q 137157f`;
`git log --oneline -1` began `137157f`. `LOGANW_REPOS=C:/Users/logan/source/repos`, `LOGANW_FETCH=1` once.
Watch on urgent/ armed inline before anything else (the README's loop, backgrounded), re-checked by a full
directory read just before writing this; nothing new since the five files the brief named. Worked only
under my scratch dir; never touched `.claude/worktrees/agent-a7a2c8afc8a3275ab` or any other repository's
working tree (StoryDocs, cft-fp256, etc. were read only via `git show`/`git -C <repo> log <pin>`, never
checked out). All fault-building was done in copies inside my own scratch clone, reverted or deleted
after; `git status --short` on the clone was clean after every experiment.

**Review diff:** `0b5becd..137157f` (confirmed this is exactly P2's own work: `git log 0b5becd..137157f`
shows only `969d54b` and `137157f`; `git diff --stat 0b5becd..137157f` touches only
`site/mapgen.py`, `site/data/relations.json`, the four new `site/pages/thread*.py` + `threads.py`,
`site/styles/map.css`/`threads.css`, and the generated `public/*` - no seam file from `_common.md`'s table
is touched).

---

### 1. Unbacked sentences

Read every sentence of `threads.py`, `thread_determinism.py`, `thread_film.py`, `thread_preservation.py`
(source and rendered HTML). Diffed `969d54b` against `137157f` to see exactly what the self-check +
subagent round changed (five hunks, four files):

- `thread_preservation.py`: "most of them under the Mercenaries-Fan-Build organisation rather than
  Logan's own account" &rarr; "under Logan's own account. The credits below name every contributor to
  [3 own-account repos] ... and to the Mercenaries-Fan-Build organisation's own repositories." Verified:
  `facts.family()`'s owner filter structurally only ever counts loganw234-owned repos, so the old sentence
  was not just unsupported but impossible; the new one is accurate and no longer implies the credited
  people are a set separate from Logan's own repos (3 of the 7 credited repos are his).
- `thread_film.py`: "the Atlas volumes" &rarr; "the Eidograph volumes". Read atlas-darkroom's and
  StoryDocs' READMEs at their pins myself: StoryDocs 673148c's own README says "the pipeline the two
  Eidograph volumes were made with" - confirms the fix, not just the correction the ledger claimed.
- `thread_film.py`: "touched most of what this site covers" &rarr; "touched half of the map's other
  projects". Recomputed: 17 total map nodes, StoryDocs documents 8 of the other 16 (atlas-engine,
  atlas-film, atlas-optical, cft-fp256, HonestFramework, ParcelRound, PrettyCloud, Quantum-Film) - exactly
  half, exactly as claimed.
- `thread_determinism.py`: "distilled out of cft-fp256 and cft-rebound both" &rarr; separated into
  "cft-rebound's own round history says it was [lifted into a standalone repository], ParcelRound...; and
  cft-fp256's case study in HonestFramework". Checked `relations.json`: the two `distilled-from` edges each
  name one source (cft-rebound&rarr;ParcelRound, cft-fp256&rarr;HonestFramework), never jointly. Fixed
  correctly.
- `threads.py`: "the paper pipeline it grew into" (ambiguous antecedent) &rarr; "the paper pipeline the
  print engine grew into". Real fix, the "fourth, lower-confidence" one the ledger mentions.

No further unbacked sentences found after this. Every remaining `most/all/every/only/both` hit is either
inside a literal quoted pattern (e.g. HonestFramework's own "nearly all of it"), inside a Python
docstring/comment (never rendered), a forward reference to the credits table's own completeness (which I
independently confirmed - see §4 below), or general connective prose about how forks/git work rather than
a specific unbacked number.

**Verdict: confirmed** (the shipped prose is accurate). **Kind: the shipped page is right** - and also
gate-backed prospectively, since the `numbers` stage (0 problems, 878 marks/21 files, independently
re-run by me) refuses any digit outside a fact span; the quantifier-word drift itself is not
gate-catchable (stated limit already, in `verifier-parcel.md`'s own framing) and was instead caught here
by reading, matching CASE-STUDY's expectation that this class of defect lives in the words around a
figure, not the figure.

### 2. Paraphrase drift

Checked every `display=` in the four new files against the quoted words printed beside it (all in the
rendered HTML, `data-f`-marked): StoryDocs' "a book-and-paper pipeline built from Markdown manifests"
beside "Books and papers compiled from Markdown manifests" (tense/domain preserved); "a fork of openXC7's
router, which does not converge on the tile" beside the longer cft-fp256 quote (accurately trimmed, no
added claim); "lifted into a standalone repository" printed as both quote and display (identical, so
trivially faithful); "the project's own pointer to where that work moved" beside the Mercenaries2
sentence it paraphrases. None add a quantifier, unit, or tense the source lacks.

**Verdict: confirmed. Kind: the shipped page is right.**

### 3. The parcel's figures - recomputed independently

- **Credits.** Recomputed commit-author counts myself directly from `git log <pin> --format=%ae` on all
  seven Preservation repos (three via `LOGANW_REPOS` clones, four via the fetched `.cache/repos/...`
  clones), grouping by hand exactly the way `account_of()` claims to (noreply id+login, else
  case-folded email). My independent counts matched the published table exactly, cell for cell: Logan
  45/39/207/-/1/-/-, austinkregel 1/-/-/85/12/969/366, headless-rebase -/-/4/40/1/436/129 (repo order:
  Mercenaries2, Merc2-Mods-Exp, mercs2-lua-essentials, mercs2-modkit, mercs2-qol-mods,
  mercs2-wad-simulator, notes-on-the-released-game). Only three distinct accounts exist across all seven
  repos' raw author-email lists; the table has exactly three rows. Nothing missed, nothing double-counted.
- **nextpnr-xilinx.** Read `sources/github-2026-09-29-1621.json` directly (bypassing `mapgen.py`):
  `createdAt: 2026-09-23T20:06:30Z`, `isFork: true`. Matches the map's placement (2026-09-23) and the
  page's contrasting mention of the upstream 2018-05-23 first commit, both independently confirmed and
  both correctly marked as separate facts (`data-f` 208 and 210).
- **StoryDocs.** Read `README.md` and `projects/` at pin `673148c` via `git show`/`git ls-tree` directly:
  "taken out of atlas-darkroom" is verbatim; `projects/` holds exactly the 7 directories the brief names;
  `projects/method/README.md` says "A storydocs paper about HonestFramework and ParcelRound" verbatim,
  confirming the one directory that maps to two nodes is justified by the source, not asserted.
- **The atlas-engine&rarr;cft-fp256 bracket fix.** Confirmed in the rendered HTML: reads "...serve is
  atlas-engine" with a working link, no literal brackets.

**Verdict: confirmed for all of the above. Kind: the shipped page is right**, independently re-derived by
a route other than the parcel's own code (raw `git log`/`git show`/`git ls-tree`, hand aggregation, direct
JSON read).

### 4. The parcel's controls

Ran `python site/build.py --control` myself on the clean checkout: 173 caught, 0 did not fail, 0 skipped,
including this parcel's five (`map-parity`, `credits-grouping`, `door-not-early` x3), matching the report.

Then built my own faults, in copies, beyond what the parcel's own controls demonstrate:

- **`check_parity()`, directly:** with real wide/narrow node and edge sets in hand, I (a) dropped a single
  edge while keeping both node sets equal - caught; (b) added a phantom node to the narrow side only,
  edges equal - caught; (c) relabelled one edge's kind only (same tail/head) - caught. All three land
  correctly as parity problems, so the check is not merely tuned to the one node-drop case the parcel's
  own `map-parity` control exercises.
- **StoryDocs directory-mapping refusal:** removed `quantum-film` from `storydocs_projects` (a directory
  that is genuinely present at the pin) - `build()` raised `Refusal: StoryDocs's projects/quantum-film is
  not named in relations.json's storydocs_projects; a directory that maps to no node refuses the build`,
  by name, as the brief requires. Separately, mapped a real directory to a node name not on the map -
  raised `Refusal: StoryDocs documents NoSuchNode, which is not on the map`, also by name.
- **css_hides, an unauthorized selector:** added `.map .lane{display:none}` (not in `css_hides.json`) to a
  copy of `site/styles/map.css`, rebuilt, ran `verify/run.sh --only numbers`: FAIL, `PROBLEM style.css:
  '.map .lane' hides what it styles (display: none); a selector that may hide goes in css_hides.json...`.
  Reverted; clean tree confirmed after.
- **credits-grouping - a gap I found (see below).**

**A concrete finding: the `credits-grouping` control does not exercise the branch of `account_of()` that
actually protects Logan's own credit.** `account_of()` has two branches: a GitHub-noreply id+login branch,
and an "any other address, case-folded" branch. The shipped control's only fixture,
`Mercenaries-Fan-Build/mercs2-modkit`, has real ambiguity in the *first* branch only (2 accounts, 4 name
strings, all noreply addresses) - it never touches the case-folding branch. But the case-folding branch is
exactly what the page's own caption claims ("grouped ... by its email (case folded)") and exactly what
protects the one plain-email ambiguity that's real in this data: Logan committing as both
`[the author address]` and `[the author address]`.

I demonstrated this concretely, in a copy, without touching the parcel's files: I patched `account_of` to
drop the `.lower()` call on the plain-email branch only (a one-token regression) and reran, in the same
process, both (a) `thread_preservation.controls()` and (b) `thread_preservation.all_accounts()`:

- (a) `credits-grouping`'s result was **byte-for-byte unchanged**: `caught=True`, identical message,
  because it recomputes `by_account` from `mercs2-modkit`'s emails only, which are all noreply addresses
  and never touch the regressed branch.
- (b) `all_accounts()` **did** break: Logan's real, single identity split into two keys -
  `email:[the author address]` (287 commits: 42+38+207, the overwhelming majority of "Logan"'s real
  total) and `email:[the author address]` (4 commits: 3+1). `credits_block()` did not refuse (the
  `LOGAN_ACCOUNT` constant is itself lowercase and still matched the small key) - it silently rendered:
  Logan's row would show only 4 commits, and a second, unlinked, garbled contributor row
  ("email:[the author address]", no derivable login so no link) would carry the other 287 - a
  direct, silent violation of decision 10 ("credited directly, with links back") in the *opposite*
  direction from what the shipped control tests, and undetected by it.

I reverted the patch and re-ran `controls()` to confirm the real code is unaffected (it is; the shipped
data has no plain-email ambiguity beyond Logan's own two identities, which are correctly folded today).

**Verdict: defect. Kind: the gate would NOT catch it** (a fault in the "next change" sense, not in what's
shipped - I independently confirmed the shipped credits table is correct, in §3 above). This is a real gap
in exactly the property the brief and decision 10 care most about, and it is not stated as a limit
anywhere on the page. By `verifier-parcel.md`'s own READY test ("every property ... held by a gate you
watched fail on a fault you picked, or stated as a limit"), this property - case-folding, the branch that
actually matters for Logan's own credit - is currently neither. The fix looks small (assert
`account_of()`'s two raw-cased Logan addresses collapse, using real data already in `_emails("Mercenaries2")`
or `_emails("Merc2-Mods-Exp")`, rather than only testing the noreply branch via mercs2-modkit), but I have
not made it; reporting only, per my brief.

### 5. The brief's named traps and refusals

- "The narrow map silently drops what the wide one shows" - guarded by `check_parity()`, confirmed above
  (§4) beyond the parcel's own single case.
- "Crediting by display name" - guarded by `credits-grouping` against real `mercs2-modkit` ambiguity
  (confirmed genuine: 2 accounts really do carry 4 name strings there, I read the raw `%an`/`%ae` history
  myself); **but see §4 for the branch it misses.**
- "A door linked too early" - `door-not-early` planted a real `propose.html` link into each of the three
  built thread HTML files and re-ran `build.check_links()`: caught on all three, by name, confirmed by my
  own re-run of `python site/build.py --control`.

**Verdict: confirmed for two of three; the third (crediting by display name) is confirmed-with-a-gap, per
§4.**

### 6. Seams

`git diff --stat 0b5becd..137157f` touches only: `site/mapgen.py`, `site/data/relations.json` (both P2's
own, per `_common.md`'s table), four new `site/pages/thread*.py` + `threads.py` (new files, found by glob),
two new `site/styles/*.css` (new files), and generated `public/*`. No lead-owned seam
(`facts.py`, `render.py`, `build.py`, `verify/run.sh`, `pages/__init__.py`, `style.css`, `pins.json`,
`sources/`, `pages/home.py`, `docs/*`, `README.md`, `CLAUDE.md`) is touched. The two disclosed boundary
crossings (fast-forwarding onto the lead's `0b5becd`, and the lead's own fix to the relations.json pattern
on P2's urgent request) are both real, both disclosed, both attributed correctly in P2.md and lead.md.

**Verdict: confirmed. No undisclosed seam crossing.**

### 7. Links and navigation

Grepped all four new page modules, both new stylesheets, and all five rendered P2 pages for
`href="/`/`src="/`/`url(/`: none found: every internal link is a bare relative filename
(`index.html`, `thread-film.html`, etc.), external links go to `https://github.com/...`. `links` stage: 0
problems (re-run myself). Confirmed `threads.py` is the one page marked `"index": True` for the section;
the three thread pages share `"nav": "Threads"`.

**Verdict: confirmed. Kind: held by a gate** (the links stage) **and directly read.**

### 8. SPEC decisions

- **Decision 16 (Wally only on Preservation):** grepped all five rendered pages: exactly one hit, in
  `thread-preservation.html`; zero elsewhere.
- **Decision 10 (direct credit, with links):** both non-Logan accounts (austinkregel, headless-rebase) are
  linked to `https://github.com/<login>` in the rendered table and again in the caption's "Direct links"
  sentence. Logan himself correctly carries no link (he is not "other"). See §4 for the one gap in what
  protects this decision against a future regression.
- **Decision 5 (private for now):** binary-sites, StoryDocs, atlas-darkroom, atlas-optical are each marked
  "for now" beside `facts.api_visibility(...)` in the new prose, consistent with the pre-existing idiom
  (checked against `home.py`'s own usage).
- **Decision 25 (Film door, Logan's exact words, no draft label):** compared `thread_film.py`'s `door()`
  string against `docs/SPEC.md` decision 25 character by character (em dashes included): identical.
  `facts.stated(text, "Logan", "2026-09-29")`, no `draft=True`. Also checked the Determinism and
  Preservation doors ("workloads (bring one...)" / "dead things (services, formats, communities...)")
  against `docs/SPEC.md`'s "Three standing doors" line (part of "the spec, word for word as Logan gave
  it"): both verbatim.

**Verdict: confirmed for all four. Kind: the shipped page is right**, directly read against the source of
each claim.

### 9. The report's claims

Re-ran the full gate myself on a fresh checkout: `bash verify/run.sh --require-all` &rarr; 11 of 11 passed,
nothing skipped: `facts: 523 read again and the same, 0 different, 10 stated, 0 skipped`; `numbers: 0
problem(s); 878 marks tied to their own facts in 21 files`; `controls: 173 caught, 0 did not fail, 0
skipped by name`. Every one of these numbers matches P2's report exactly. The subagent dispatch is
disclosed in P2.md per the ledger's own rule (said so before finishing, described what it found). The
"what I did not do" claim in P2's report (nothing beyond scope) held up against everything I checked.

**Verdict: confirmed. Kind: held by a gate, re-run by me from a clean checkout, not pasted output.**

### 10. Anything else (outside the numbered list)

- **The phone measurement.** Independently measured in the browser pane, not trusting P2's numbers: at an
  emulated 375px viewport, `document.documentElement.scrollWidth === clientWidth === 375` on all five
  pages P2 touched (index, threads, thread-determinism, thread-film, thread-preservation) - confirmed, no
  page-level sideways scroll. One nuance P2's report didn't mention: on `thread-preservation.html`, the
  credits *table*'s own wrapper (`.table-wrap`) is 831px wide inside a 343px column, so it scrolls
  internally - this is a pre-existing, lead-owned site convention (`site/style.css`: `.table-wrap
  {overflow-x:auto}`, used for every wide table on the site, `min-width:1000px`), not something P2 added
  and not a violation of "the page doesn't scroll sideways" (the document itself doesn't). Worth the lead
  knowing it's there, not a defect.
- **css_hides contract, both widths, all five pages, measured myself:** at 375px, `.map-narrow` is
  `block` and `.map-wide` is `none` on every page with a map; at a real (non-emulated-zero) desktop
  width the pane settled at (1280px effective), `.map-wide` is `block` and `.map-narrow` is `none`.
  Exactly one map shown at each width, on every page, matching the contract in `css_hides.json`'s own
  "why" text.
- **Tooling note, not a finding:** the Browser pane's `window.innerWidth`/computed styles read back as 0
  a few times immediately after a resize while the pane was backgrounded/hidden; fronting the tab and
  forcing one render (a screenshot, or a short `wait`) before reading always produced correct,
  self-consistent numbers afterward. Mentioning this only so a future verifier doesn't mistake it for a
  site defect.

---

## READY or NOT READY: **NOT READY**

By `verifier-parcel.md`'s own standard, one property the parcel's pages claim - grouping credits by
account with the email case-folded, decision 10's own guarantee - is neither held by a gate I watched
fail on a fault I picked, nor stated as a limit; I built a fault inside exactly that property (a one-token
regression in `account_of`'s non-noreply branch) that passes the parcel's own `credits-grouping` control
unchanged while silently breaking the real page (see §4). Every other item in the brief, and everything I
checked outside it, came back confirmed: the shipped pages, the shipped figures, the shipped edges, the
shipped doors, and four other controls are all correct and are all backed by a gate I watched fail on my
own fault, not merely trusted from the parcel's report.

## What I did not do

- Did not check P1's or P3's work, or anything on `main` past `0b5becd` beyond confirming the two commits
  P2 fast-forwarded through (`a691b0a`, `0b5becd`) touch none of P2's files.
- Did not build a fault for every one of the pre-existing (lead-owned) mechanisms P2 merely relies on
  (`check_parity`'s use inside `block()`/`lane_slice()`, the numbers stage's general marking rules, the
  facts re-derivation stage) beyond the one unauthorized-selector and one directory-mapping fault above;
  these are heavily proven already across verifier-P0's many rounds (`lead.md`), and re-proving all of them
  for P2 specifically seemed a poor use of time next to finding the credits-grouping gap.
- Did not attempt a from-scratch visual/design review of the narrow map's legibility (row jitter, label
  stacking) beyond confirming it draws the same nodes/edges as the wide one and doesn't cause page-level
  horizontal scroll; typography/aesthetic judgement is outside a facts-and-gates review.
- Did not test on a real phone or a real second browser engine; the browser pane's Chromium emulation is
  what I had.

## Side notes

- The credits table's internal horizontal scroll on phones (§10) is worth the lead knowing about, though
  it is pre-existing, lead-owned behavior, not a P2 defect.
- P2's own ledger entries are unusually well-disciplined about marking "measured" vs "believed" and about
  disclosing the two boundary crossings (the fast-forward, and letting the lead fix the relations.json
  pattern) with clear reasoning for why each was sanctioned rather than silent - matches what
  `verifier-parcel.md` asks me to check for in item 6 with no gaps found.
- The one defect in this report (§4) is narrow and, I'd guess, cheap to close: the existing
  `credits-grouping` control could assert `account_of()` collapses `Mercenaries2`'s or
  `Merc2-Mods-Exp`'s own two raw Logan addresses (real data already read by `_emails`), alongside the
  existing `mercs2-modkit` assertion, so both branches of the function are exercised by a fixture rather
  than by data I had to construct myself.

For: lead

## 2026-09-29 21:42:42 -0700 - re-check on bdbac1f: verdict changes to READY

Re-cloned/fetched the branch, `git checkout -q bdbac1f`; `git log --oneline -1` began `bdbac1f`. Watch on
urgent/ re-read in full (still just the five files the brief named; nothing new). Coordinator asked for
four specific checks plus a fresh verdict.

**1. Rebuilt my fault against the new `credits-case-fold` control.** In a scratch copy of the running
process (never touching the checkout's files), monkeypatched the real `account_of` to drop `.lower()` on
the plain-email branch only - the exact fault from my first report - and re-ran
`thread_preservation.controls()`. Result: `credits-case-fold` flipped from `caught=True` (real code) to
`caught=False` ("two case variants ... group to 2 account(s) by account_of; a copy with the case-fold
dropped ... shows 2" - the differential collapses, which is exactly the fail signal). Beyond the control,
the same fault now also makes `credits_block()` raise a hard `Refusal` ("expected exactly one plain-email
account among the Preservation contributors; found 2: email-sha256:..., email-sha256:...") via the new
`_logan_account()` structural check - so this class of regression is now caught two ways, not one.
Reverted the monkeypatch; `controls()` confirmed back to normal after.

**2. Searched for the address.** `git grep -ilI "<the domain>" bdbac1f -- .` (whole tracked tree) and again
restricted to `-- public/`: both exit 1 (zero matches), filenames-only/no-content flags used throughout so
the address itself never appeared in any tool output I read or could have copied. A third search
confirmed `email-sha256:` (the new key prefix, not the address) is present in `public/facts.json`, as
expected, and confirmed it appears nowhere in the rendered `thread-preservation.html` itself (0 hits) -
only inside `facts.json`'s own fact arguments, as an opaque hash. Not writing the address into this entry.

**3. Rechecked the credits.** Parsed the live table out of `public/thread-preservation.html` at `bdbac1f`:
Logan 45/39/207/-/1/-/-, austinkregel 1/-/-/85/12/969/366, headless-rebase -/-/4/40/1/436/129 (repo order:
Mercenaries2, Merc2-Mods-Exp, mercs2-lua-essentials, mercs2-modkit, mercs2-qol-mods,
mercs2-wad-simulator, notes-on-the-released-game). Identical, cell for cell, to my independent recount
from raw `git log --format=%ae` at the pins in my first report. Only the internal keying changed; the
counts and the "Logan"/`austinkregel`/`headless-rebase` display names and links did not.

**4. Checked the merge.** `95e0f5e`'s parents are exactly `137157f` (P2's prior tip) and `eece75d` (main's
tip, itself carrying P1's `2c5faa2`, P3's `ff23593`, and the lead's own `eece75d`). `git diff 137157f..95e0f5e`
restricted to P2's own files (`mapgen.py`, `relations.json`, the four thread pages + `threads.py`, the two
new stylesheets) is empty. `git diff eece75d..95e0f5e` restricted to every lead/P1/P3-owned file
(`facts.py`, `render.py`, `build.py`, `verify/run.sh`, `pages/__init__.py`, `home.py`, `style.css`,
`pins.json`, `sources/`, `docs/*`, `README.md`, `CLAUDE.md`, `css_hides.json`, `numeral_names.json`) is
also empty. Computed the intersection of "files changed vs each parent": every single file in that
intersection is under `public/` (19 files, all generated) - nothing else overlaps. The merge carried
nothing but a rebuild.

**Full gate, re-run myself, clean checkout:** `bash verify/run.sh --require-all` - 11 of 11 passed, nothing
skipped. `facts: 1414 read again and the same, 0 different, 14 stated, 0 skipped`. `numbers: 0 problem(s);
2450 marks tied to their own facts in 34 files`. `local-only: 0 problem(s) in 34 published files`
(exercises the new email-address gate on every page, including P1's and P3's). `controls: 185 caught, 0
did not fail, 0 skipped by name`. Grepped the controls log directly: `credits-grouping`, `credits-case-fold`,
`map-parity`, and all three `door-not-early` entries show `caught, as it must be`; the lead's two new
`local-only` controls ("an email address on a page" / "in facts.json") show the same. Every number matches
P2's report exactly, from my own from-scratch run, not pasted output.

Nothing outside the four requested checks needed re-verification: the diff `95e0f5e..bdbac1f` touches only
`site/pages/thread_preservation.py` (plus generated files) - the map, the doors, StoryDocs' edges,
nextpnr-xilinx's placement, the phone/css_hides contract, and the seams I checked in my first report are
all untouched by this fix and stand as already confirmed.

### Verdict: **READY**

Both open items are closed, each with a gate I watched fail on the fault that used to slip past it: my own
finding (the case-fold branch) now has a working differential control *and* a structural refusal behind
it; the lead's finding (the raw address in `facts.json`) is closed by removing the address from the key
entirely (a truncated hash) *and* by a new generic, content-scanning gate that would catch it (or any other
address) regardless of which page or parcel leaked it. The credits table itself is unchanged and still
matches my independent recount. The merge that brought in P1, P3, and the lead's fix carried nothing into
P2's own files beyond a straight rebuild.

**What I did not do (this round):** did not re-verify the map/doors/StoryDocs/nextpnr-xilinx/phone-layout
items from my first report, since this diff does not touch any file they depend on. Did not audit P1's or
P3's own controls or claims beyond confirming their files were untouched by the merge.

For: lead
