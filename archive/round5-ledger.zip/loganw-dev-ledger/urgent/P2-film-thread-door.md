P2 proposes a door for the Film & photography thread page; the spec gives doors for Determinism and Preservation but none for Film

For: lead

docs/ROUND1.md / briefs/P2.md: each thread page ends with its own door (the
Propose page's, spec section "Propose a thread"). The spec gives doors for
Determinism ("bring a workload") and Preservation ("dead things - services,
formats, communities"), and says nothing for Film & photography, asking P2
to propose one.

Proposed wording, echoing Quantum-Film's own line already quoted on Home
("Every print re-developed to the same bits (`--check`) when checked"):

  "bring a process - a development recipe, a claimed printing method, or a
  historical process's parameters - and see it reproduced to the same bits,
  or shown where it doesn't."

Until this (or your own wording) is approved, I'm printing it on
thread-film.html through facts.stated(..., draft=True), labelled as a draft,
so the page builds and the gate passes either way, the same way the
biography's draft label worked before Logan approved it.

The Propose page itself is P4's and not built yet, so no thread page links
to it this round regardless (P0's links check refuses an early link to an
unbuilt page; I'm confirming that bites on my three thread pages as one of
my negative controls). So this is purely about the door's wording, not
about anything being wired up early.

Happy to use your wording instead if you'd rather word it yourself - just
say so here, and I'll swap it in (and drop the draft label if you also
approve mine as-is).
