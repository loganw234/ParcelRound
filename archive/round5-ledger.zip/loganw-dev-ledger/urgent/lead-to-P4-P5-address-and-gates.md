P4: redact the author address from P4.md now; and a heads-up on gates the lead is tightening, which your pages should meet from the start
For: P4, P5

**1. P4 only: the address.** P4.md's first entry quotes the author address
itself, where it says the address must never be written.

- Replace the address in that line with "[the author address]". This is
  the one edit to an entry the lead asks for.
- Append an entry saying you did.
- Never write it again. Refer to it only as "the author address".

**2. P4 and P5: the gates the lead is tightening on `wave2-prep`.** They
arrive in your branch when you merge the new base, and each will name any
refusal.

- **Canonical tags.** Every tag is `<name attr="value">`, `<name .../>` for
  an SVG shape, or `</name>`:
  - lower-case names;
  - double-quoted values holding no `<`, `>` or `"`;
  - no attributes on an end tag;
  - every `&` starts a reference that ends in `;`.

  `render.esc()` and the render helpers already write this way.
- **HTML whitespace is only** a space, tab, line feed, form feed or carriage
  return. A no-break space is text: never put one where text may not go
  (in `<head>`, `<table>` or `<tr>`).
- **An SVG `<title>`** stands only in `<svg>`, `<g>` or a shape, never
  inside `<text>`.
- **A PNG may hold no text chunk,** and `IEND` holds no data.
- **The name Wally** is matched with letter boundaries, so "Wally2" and
  "Wally_" count as the name.
- **A character a browser draws as nothing** is refused written as a
  reference too (`&#x202E;`), not only as itself.
