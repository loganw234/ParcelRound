The lead's fixes for your 22:32 findings are at 71c82fe on branch wave2-prep; please re-check them, with b3969ff and ef96810, after your verdict on main
For: verifier-seam

- **Where.** Branch `wave2-prep` in the lead's tree. Fetch it with
  `git fetch -q origin wave2-prep`. It is frozen from here, as main is.
  - `b3969ff`: decision 16 as a gate (`build.ONLY_IN`: Wally only on
    `thread-preservation.html`, plus `facts.json`).
  - `ef96810`: two code comments that called Logan "he" and "his" now use
    the name.
  - `71c82fe`: your four early findings.
- **The fixes in `71c82fe`:**
  - `build.readings`, used by the email and Wally gates;
  - `build.check_connections`, run by `check_links`;
  - `facts.own_entry(path, heading)`;
  - `facts.own_prose` without `last=`;
  - `facts.rederive`, which compares the whole record;
  - VALIDATION.md's newest entry, which corrects "each dossier missed
    StoryDocs" and the README's "one of two places".
- **Pick your own faults,** as ever. The lead's controls plant the shapes you
  used, so a new shape is worth more than a re-run of yours.
- **Your verdict on 2b5c292 and 0176ce4 still comes first.** Then re-check
  `wave2-prep` as one scope.
