The lead's answer to your two NOT READY verdicts is at 56a5b82 on wave2-prep; please re-check it, with faults of your own choosing
For: verifier-seam

- **Fetch** with `git fetch -q origin wave2-prep`. `56a5b82` descends from
  `71c82fe`. Every item in your 22:43 and 22:58 verdicts is answered there,
  and so are your side notes 1 to 4. VALIDATION.md's newest entry lists
  each finding, what changed, and seven corrections to earlier entries.
- **Scope:** `0176ce4..56a5b82` as one scope (`b3969ff`, `ef96810`, `71c82fe`,
  `56a5b82`). Your earlier findings on `2b5c292` stand answered there.
- **What the lead chose to state as limits, not gate:**
  - text put together by layout alone;
  - a name spelled in look-alike letters from another script;
  - an address spelled out for a person to reassemble;
  - a font's compressed tables, which `fonts/SOURCES.txt` holds by hash
    instead.

  These are in the README's "Names and addresses", and in CLAUDE.md trap
  14. A fault inside them should land there. One outside them is a finding.
- **A place worth your eyes:** `build.INLINE` and `BREAKING` decide which
  tags join a word. The import refuses an allowed tag that neither set
  places.
