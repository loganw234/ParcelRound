P4 found: build.controls()'s "a figure the map draws, with its line under the map removed" picks the wrong fact id once any page sorts alphabetically before home.py; the underlying numbers check is fine

For: lead

**The control, not the gate, is wrong.** In `build.py`'s `controls()` (section D):

    snap_id = next(r["id"] for r in data["facts"] if r["method"] == "facts.snapshot_date")
    planted("numbers", "a figure the map draws, with its line under the map removed",
            re.sub(r'<li>the line marked "snapshot": .*?</li>', "", t, count=1, flags=re.S),
            check_numbers, "fact %d is drawn in the map" % snap_id)

`facts.snapshot_date()` is called once per page (every page's `stamp()`, via `render.stamp()`), so it is
logged many times - 34, on my tree. `snap_id` takes the *first* logged occurrence across the whole build,
which only happens to be the one the map actually draws (and the evidence list under it cites) when the
first page `render_all()` processes is the one whose own build sequence reaches that specific call first.
That held by accident while no page module sorted alphabetically before `home.py`. My `corrections.py` does
(`c` < `h`), so now the very first `facts.snapshot_date()` call in the whole build is corrections.html's own
stamp, and `snap_id` names that fact, not the one drawn in the map.

**Measured**, in a copy, reproducing the control's own logic directly (not trusting the runner's line):

    control's chosen snap_id: 24
    control's want string: 'fact 24 is drawn in the map'
    want found in problems: False
    all problems mentioning 'drawn in the map':
       index.html: fact 111 is drawn in the map, and the list under the map does not give its source
       index.html: fact 111 is drawn in the map, and the list under the map does not give its source

`check_numbers` itself is correct: removing the evidence line is still refused, by name, naming fact 111 -
the one actually drawn in the map. The control just asks about fact 24 instead, which check_numbers never
complains about (it is an ordinary stamp figure, not one the map draws), so the control reports "passed"
under `bash verify/run.sh --require-all`, and the `controls` stage - and so the whole gate - fails.

**Not something in my files can fix.** `render_all()`'s page loop, `render.stamp()`, and this control are all
in files `_common.md` names as yours. I have not touched any of them, and my own two pages' facts are
ordinary, unrelated ones (their own quotes and figures); nothing about my pages is itself wrong, and I
verified separately that every other control still passes on my tree (280 of 281 caught).

**One fix that doesn't touch what the control means to test:** find the fact actually referenced by the
evidence-list `<li>` this control mutates, rather than the first logged occurrence of the method. In this
copy, something like reading the `data-f` on the `<li>` itself (it already carries one - `<span
class="fig" data-f="111">`) before removing it, and asserting *that* id is the one still drawn in the map
afterward, would hold regardless of how many other pages also call `facts.snapshot_date()` first. I have not
made this change myself, since `build.py` is not mine this round; flagging it here as briefs/_common.md asks
("if you need a seam changed... ask in urgent/").

I'm continuing the rest of my own gate and report meanwhile; this is the one control failure on my tree, and
I'll say so plainly in my report either way.
