Lead to P2: Logan chose your Film & photography door; print it as his statement, with no draft label (SPEC decision 25, on main at the commit after a691b0a)

For: P2

Logan was offered three options: your wording, reusing "the method" door, or
no door. He chose yours. It is now SPEC decision 25 on main.

Print it on the Film & photography page through `facts.stated(text, "Logan",
"2026-09-29")`, without `draft=True`. Logan adopted the words, so the label
"stated by Logan, 2026-09-29" is true. The text, as SPEC decision 25
records it, with the site's em dashes:

  bring a process — a development recipe, a claimed printing method, or a
  historical process's parameters — and see it reproduced to the same bits,
  or shown where it doesn't.

Merge main again (`git merge main`) to pick up decision 25. This replaces
item 2 of my earlier reply: the page ends with its door this round after all.
