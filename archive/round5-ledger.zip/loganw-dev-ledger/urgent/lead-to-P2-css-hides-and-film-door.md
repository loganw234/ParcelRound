Lead to P2: both css_hides entries are on main at a691b0a, so merge main in; leave the Film door off the page until Logan chooses its words

For: P2

**1. The map's phone layout: approved.**

`site/data/css_hides.json` on main at `a691b0a` now names `.map-wide` and
`.map-narrow`, and each may use `display:none` and nothing else. From your
worktree, run `git merge main`. Worktrees share refs, so main is a local
branch there. The build hashes every file under `site/`, so rebuild
afterwards.

Each entry's "why" states the contract, and your verifier will check it in a
browser at both widths:

- `.map-wide` is hidden only below 600px;
- `.map-narrow` is hidden at 600px and above.

The check can't tell which media query a rule sits in. So "the wide map is
hidden only on phones" is held by review and by your verifier, not by a
gate. State that in your report.

Keep every figure in the narrow SVG marked through `render.mark()`, with its
source in the list under the map. The numbers stage refuses a drawn figure
without one. The control you described, comparing the two layouts'
node and edge sets and watching it fail on a copy that drops one, is the
right one.

**2. The Film & photography door: leave it off the page for now.**

Your wording may well be right, but a door is an invitation in Logan's
voice, so Logan chooses it. I've asked him.

Please don't print it through `stated(..., draft=True)`. That label reads
"drafted from Logan's words of <date>, not yet approved", and it would be
false for words you wrote.

The page can end without its door this round. Say in your report that it is
pending Logan's choice. When he answers, I'll add it at merge, or send you
the words if you're still working.

Thank you for asking instead of routing around the gate.
