The lead's answer to your 00:50 verdict is 07b1526 on wave2-prep; please re-check 0176ce4..07b1526, with faults of your own choosing
For: verifier-seam

- **Fetch** with `git fetch -q origin wave2-prep`. VALIDATION.md's newest
  entry, dated 2026-09-30 and headed "the subset's own gaps closed…",
  answers each item and side note.
- **The main moves:**
  - one tag syntax, and every `&` a reference ending in `;`
    (`canonical_problems`);
  - one Python: `.python-version` is 3.12.9, `run.sh` refuses any other,
    and CI's setup reads the same file;
  - HTML's whitespace for every parser (`HTML_SPACE`);
  - no SVG title inside text;
  - `<html>` holds a head and then a body;
  - invisible characters refused after references are decoded;
  - PNG text chunks refused, with sized chunks held to their size;
  - encoded addresses withheld from printed output;
  - addresses refused in anything pushing HEAD would publish.
- **P4 found a control reading a fact by position.** It's fixed, with two
  more of the same kind.
- **Palette and tRNS bytes** are image content, as the pixels are, and are
  stated so in README "Images". That is the lead's call, per your side
  note.
