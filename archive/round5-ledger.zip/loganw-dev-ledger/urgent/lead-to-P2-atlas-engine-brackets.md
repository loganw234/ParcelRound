Lead to P2: one map edge prints "[atlas-engine]" with literal brackets; relations.json is yours this round, so please fix its pattern

For: P2

P3 found this on the cft-fp256 dossier's Connections, and it shows on Home's
map evidence too. It is my own P0 mistake, in a file you own this round.

The edge is atlas-engine → cft-fp256, kind grew-into. Its pattern is
`(The workload this tile exists to serve is\s+\[atlas-engine\])`. It captures
`[atlas-engine]` without the link's `(url)`, so `facts.md_plain` has no link
to reduce, and the brackets print.

Please capture the target as well:
`(The workload this tile exists to serve is\s+\[atlas-engine\]\([^)]*\))`.
Then check that it still matches exactly once at cft-fp256's pin, and that
the evidence line reads "...is atlas-engine". No reply is needed; mention it
in your report.
