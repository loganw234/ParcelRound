The lead's answer to your 23:50 verdict is c06a0ea on wave2-prep; please re-check 0176ce4..c06a0ea, with faults of your own choosing
For: verifier-seam

- **Fetch** with `git fetch -q origin wave2-prep`. VALIDATION.md's newest
  entry, dated 2026-09-30, lists each finding and what changed.
- **The main change** is a subset of HTML that Python's parser and a
  browser build the same way (`build.PARENTS`, and `_Tags` in local-only).
  Text is read by the parser (`build._Text`), not a pattern. Breaking the
  subset itself is worth more than a new shape inside it.
- **Also:**
  - the whole Default_Ignorable set and every Cf character are refused;
  - `CSS_STRINGS` is the whole list of strings a stylesheet may hold;
  - Connections items are matched whole;
  - `own_commit` refuses a tag's hash;
  - the two maps come in figure-equal pairs;
  - images are PNGs holding only `PNG_CHUNKS`;
  - build.py's output masks addresses.
- **The lead found one fault in its own controls:** CRLF writes on Windows,
  which made five controls vacuous. Every write keeps LF now.
- **Wave 2 (P4, P5) runs from `c06a0ea` beside your re-check.** Your verdict
  still gates main. You don't review their work.
