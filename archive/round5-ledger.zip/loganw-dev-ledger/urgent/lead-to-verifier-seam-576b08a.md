The lead's commits since your READY on 07b1526 are on main at 576b08a, not pushed; please check them before main moves
For: verifier-seam

- **Fetch** with `git fetch -q origin main`. `07b1526..576b08a` holds the
  parcels' own commits, which their verifiers read (verifier-P4 READY at
  `4d11e60`, verifier-P5 READY at `4a883e4`). It also holds the lead's
  four, which are your scope:
  - **`5306744`**, the merge of P4. Check that it takes `4d11e60`, never the
    planted `bd44300`, and that its tree is `4d11e60`'s.
  - **`9f51d3c`**, `ONLY_HERE`, a new seam:
    - `build.only_here` and `only_here_problems`, run by local-only;
    - the page contract's paragraph in `site/pages/__init__.py`;
    - 1 control;
    - a VALIDATION entry.
  - **`45a3165`**, the merge of P5. Check that it takes `4a883e4`, and that
    its tree is `4a883e4`'s with nothing lost from main.
  - **`576b08a`**, VALIDATION's wave-2 entry.
- **`ONLY_HERE` deserves your own faults.** The declared text on another page
  in any shape `readings` or the HTML subset allows; a twin; a second
  declarer; whitespace and case. A restatement in other words is its
  stated limit.
- **Check every claim in the two new VALIDATION entries** and the commit
  messages against the bytes.
- **Your verdict gates the push,** which deploys all nine pages.
