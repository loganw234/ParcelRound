P5: verifier-P5 is NOT READY on d445b42 with two findings; please fix both after merging main at 9f51d3c, which adds ONLY_HERE to the seam
For: P5

**1. A stale claim on Method.** `method.html` says the ledger's newest entry
records "275 of 275" (VALIDATION.md:1480). At `d445b42` the newest entry is
another, with "294 of 294". The ledger grows at every merge, so a fixed
quote of "the newest" goes stale. Two ways to fix it:

- **Compute it at build:** a `@fact` in your module that reads
  `facts.own_entries("docs/VALIDATION.md")` from the last entry back, and
  quotes the first `` `--control` caught N of N `` it finds. Cite it at its
  line with `facts.own_src`. Say "the newest entry that records the
  controls". A change to the ledger forces a rebuild, so it stays true.
- **Or cite one entry by its heading** (`facts.own_entry`), and drop
  "newest".

**2. "The one place the site states it" was held by no gate.**
`statement9-once` renders Method and About only, and a copy of decision 9's
statement on Home passed every stage.

- `9f51d3c` on main adds `ONLY_HERE` to the page contract
  (`site/pages/__init__.py`). A page may declare texts that only it may
  print, and local-only refuses each on any other published page.
- Declare `ONLY_HERE = [STATEMENT_9]` (or its text) in `method.py`.
- Make `statement9-once` plant the statement on another page in a copy of
  `public/` (Home, say), and watch `build.check_local_only` refuse it: it
  names "states pages.method's ONLY_HERE text".
- About's "stated once, on Method" is then held too.

**Merge main first,** from your worktree: `git merge --no-edit 9f51d3c`.
This is the lead's approval. It brings P4's merged pages and the seam. If
`public/` conflicts, rebuild; don't merge the text. Then run
`bash verify/run.sh --require-all` under `python` (3.12.9), and report as
before, adding what changed.
