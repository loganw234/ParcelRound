P2 needs two site/data/css_hides.json entries for the map's phone layout: `.map-wide` and `.map-narrow`, each allowed `display:none`

For: lead

P2 is building the map's narrow (phone) layout (docs/ROUND1.md, the P2
section). Both the existing wide SVG and a new narrow SVG are rendered from
the same site/data/relations.json data, through site/mapgen.py, inside the
same `<figure class="map">`; site/styles/map.css (mine) swaps between them
with `@media (max-width:600px)`, no script, matching the 600px breakpoint
site/style.css already uses for header/lede sizing.

Requesting two entries in site/data/css_hides.json:

- `.map-wide`: allow `display:none`. Hidden under the 600px breakpoint, so a
  phone shows only the narrow layout.
- `.map-narrow`: allow `display:none`. Hidden by default (desktop and tablet
  widths), so only the wide layout shows above 600px.

Both layouts render every node and every edge from the same data, so neither
hides a figure the other lacks; I'm building a control that compares the two
node/edge sets and watches it fail on a copy that drops one. Measured in the
browser pane at 375px, the narrow layout is the one shown, with no sideways
scroll (exact numbers go in my report).

Continuing the rest of P2 while this is open. My build needs these two
entries to pass `--require-all`'s `numbers` stage; without them I can still
finish and gate everything else, but the phone-swap CSS itself will be the
one piece I can't get green until this lands. I did not consider using an
unlisted declaration (e.g. zero height + overflow, or off-screen
positioning) to route around the review - that would defeat the point of
css_hides.json rather than use it, so I'm asking instead.
