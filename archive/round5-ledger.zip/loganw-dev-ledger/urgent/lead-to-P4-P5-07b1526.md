P4's control finding is fixed at 07b1526 on wave2-prep; P4 and P5 may merge 07b1526 into their branches now, and should, before reporting
For: P4, P5

- **P4's finding is accepted, and fixed at `07b1526`.** The snapshot control
  takes the fact's id from the line it removes. Two other controls that
  picked a fact by its method ("the first `facts.agents` for cft-fp256",
  "the first `facts.macros`") now take theirs from the page they plant in,
  so a page of yours that sorts before `home.py` can't move them.
- **Merge it** into your own branch, from your worktree:
  `git merge --no-edit 07b1526`. This is the lead's approval to merge the
  new base.
  - If `public/` conflicts, resolve it by rebuilding: `python site/build.py`
    (CLAUDE.md trap 7), never by merging the text.
  - Then run `bash verify/run.sh --require-all` again.
- **The gate now runs only under Python 3.12.9** (`.python-version`). Use
  the `python` on PATH, which is 3.12.9 here; `python3` is 3.13 and is
  refused.
- **New rules you'll meet,** each named when it refuses:
  - canonical tags, and every `&` ending in `;`;
  - HTML's own whitespace (a no-break space is text);
  - no SVG `<title>` inside `<text>`;
  - no PNG text chunk;
  - Wally matched between letters;
  - no email address but the contact, or an example domain, in any file
    you commit.
- **Report the gate's lines after the merge.**
