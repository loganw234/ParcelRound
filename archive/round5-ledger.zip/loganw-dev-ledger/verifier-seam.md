# verifier-seam

## 2026-09-29 22:02:42 -0700 - started: verifying the lead's seam work ed990fb..2b5c292 on main

Measured: brief read (briefs/verifier-seam.md); ledger README read; urgent/ holds 5 files, none new since 20:38.
Believed: nothing yet.
For: lead.

## 2026-09-29 22:16:58 -0700 - setup reproduced at 2b5c292 and 0176ce4; 0176ce4 taken into scope

Measured:
- Clone under my scratch, `git checkout -q 2b5c292`; `git log --oneline -1` printed 2b5c292. `LOGANW_REPOS=C:/Users/logan/source/repos LOGANW_FETCH=1 bash verify/run.sh --require-all`: passed 11, failed 0, skipped 0, VERDICT: PASS, nothing skipped; 73 s; facts 1512 read again, 14 stated; numbers 2462 marks in 34 files; controls 194 caught.
- Read urgent/lead-to-verifier-seam-0176ce4.md; `git fetch -q origin` into my clone; worktree at 0176ce4 (my clone's .cache copied, no fetch): same gate, passed 11, nothing skipped, 71 s; controls 197 caught.
Believed: nothing yet.
For: lead

## 2026-09-29 22:32:29 -0700 - early findings on shared code (email gate, edge control, own-record seam); verdict still to come

Measured (faults built in worktrees of my scratch clone, rebuilt, then `bash verify/run.sh --require-all`; made-up addresses only):
- Email gate: a plain made-up address in verify.py fails local-only (count only, as claimed). But one page carrying the same made-up address as `&#64;` text, a `mailto:` with `%40`, a GitHub `commits?author=` link with `%40`, and split by `<wbr>`, plus a url-quoted address in facts.json's arguments: passed 11, nothing skipped. Chromium decodes each to the address. The check reads raw bytes of text files only; the site's own html.parser (convert_charrefs) reads the text as the address.
- Edges: the `connections` control compares `edges_for()` with `all_edges()`, not the pages. Dropping StoryDocs' edges where a dossier renders them, or one edge where the map draws them: each passed 11 of 11, control saying "all agree"; my own reading of the published pages shows 4 dossiers missing an edge, or 1 listing an undrawn one. Reverting `edges_for` to relations.json is caught.
- Own ledger: appending an entry without a rebuild fails build and manifest (watched). `own_prose(..., last=True)`: an appended entry repeating the words moves the citation from L3 to L7 and re-derivation calls it the same. `own_entry(line)`: an entry inserted mid-file makes it return another entry silently.
- Records: README line 11 says "one of two places" over three bullets; VALIDATION's "each dossier missed StoryDocs" and mapgen.all_edges' "every one of them" are false for cft-rebound (complete at 6c163dd, measured).
Believed: nothing beyond the above.
For: lead

## 2026-09-29 22:43:11 -0700 - verdict: NOT READY on 2b5c292 and 0176ce4; the merges, the live site and main's history are confirmed

Measured (full report delivered to the lead; every fault built in my scratch clone, rebuilt, then `bash verify/run.sh --require-all`; made-up addresses only):
- Confirmed: 2c5faa2 and ff23593 took exactly 1e21d8e and 729461d; 9260b4f is not on main; 6c163dd's tree is bdbac1f's tree byte for byte; `--check` and `--manifest` pass at 2c5faa2, ff23593, eece75d, 6c163dd and edff2b0; 0 of 322 blobs reachable from main hold the author address; GitHub has main only, at 2b5c292; the live site is 2b5c292's public/, 33 of 33 files byte-identical, BUILD naming it. Gates 11 of 11 at 7174f67 (168), 6c163dd (185), 2b5c292 (194), 0176ce4 (197); edff2b0 controls 187.
- Not held, not stated (each passed 11 of 11): an address as `&#64;`, `%40` in a mailto or query, or split by `<wbr>`; a dossier or the map dropping an edge where it renders or draws (the connections control compares two functions, not the pages); source labels given class map-narrow, hidden at desktop width by the css_hides entry; a line inserted into an old ledger entry. Measured API gaps: own_prose last=True re-points on an append; own_entry(line) cites another entry after a mid-file insert; own_commit takes HEAD~1 and re-derives it "the same" as it moves.
- False sentences: README "one of two places" (three); "each dossier missed StoryDocs" and "every one of them" (cft-rebound had none to miss); "four A records" (the authoritative zone serves three now); "Fixed at 5128ce6, by quoting" (two were cut); "nothing else in P3's work"; own_commit "refuses one that main doesn't hold" (it accepts an unpushed HEAD, and a squashed-away commit once HEAD merges it); facts.py's "one of three places, and from nowhere else".
Believed: nothing beyond the above.
VERDICT: NOT READY.
For: lead

## 2026-09-29 22:58:57 -0700 - re-check of wave2-prep at 71c82fe (with b3969ff, ef96810): fixes hold on my faults; NOT READY on new shapes

Measured (worktrees of my scratch clone at 71c82fe; made-up addresses only):
- Gate: 11 of 11, nothing skipped, controls 215; b3969ff controls 202. CI-like `--verify-facts` (empty LOGANW_REPOS, fetch on): 1362 same, 0 different, 150 skipped (all private), as the lead measured.
- Held, on my own faults: my first email plant now fails local-only (counts only); my render and draw edge faults fail links, naming the edges; own_prose refuses a second match; own_entry refuses a heading in other case and a retitled one; rederive calls a shifted pinned line, a flipped private flag and an edited detail different. own_commit still prints HEAD~1 or a tag as the figure, but a moved HEAD~1 now re-reads as different (loud in CI).
- Not held, not stated (full gate, 11 of 11, VERDICT PASS): Wally after the site name on every page via CSS `content:" / Wal" "ly"`, and on Verify as `Wal&shy;ly` and split by SVG `<tspan>`; the address split by `&#8203;`, by an HTML comment inside the domain, by `<tspan>`, and by CSS `content` from two strings. Chromium renders each as the word (comment and tspan give textContent exactly; widths equal within 0.55 px). Also passing at unit level: IDN and non-ASCII domains, address literals. A false Connections item, "StoryDocs documents cft-rebound (in its projects): ...", passes check_connections, which parses one markup.
- Still open from my 22:43 verdict (71c82fe predates it): the css_hides class reuse; "four A records"; "Fixed at 5128ce6, by quoting"; "nothing else in P3's work"; own_commit "refuses one that main doesn't hold"; facts.py's "one of three places"; the enumerations that omit the ledger.
Believed: nothing beyond the above.
VERDICT on wave2-prep: NOT READY.
For: lead

## 2026-09-29 23:50:50 -0700 - re-check of 0176ce4..56a5b82 as one scope: every earlier finding holds on my faults; NOT READY on new shapes outside the stated limits

Measured (worktrees of my scratch clone at 56a5b82; faults built through the pages' own sources, rebuilt, `bash verify/run.sh --require-all`; made-up addresses only; rendering in my own loganw.dev tab, injected and removed):
- Gate at 56a5b82: 11 of 11, nothing skipped, controls 245. CI-like `--verify-facts`: 1362 same, 0 different, 150 skipped by name, as the lead measured.
- Held, on my own faults: my class reuse (numbers, 10 problems), my 22:58 readings plant (local-only, 7), my Connections markup plant (links); the INLINE/BREAKING import guard (a tag in ALLOWED only; a tag in both); own_prose refusing a heading dated at its end and a numbered one; own_commit refusing HEAD~1, upper case, a 6-digit prefix, a tree hash and a replace-ref graft; lf_only refusing bare-CR line endings (build and manifest); iTXt and tEXt address chunks. The seven corrections check out against the bytes.
- Not held, not stated (each passed 11 of 11, VERDICT PASS):
  1. Wally and the address joined across tags BREAKING reads as a space but a browser ignores or never draws: <td></td>, a stray </dd>, <title></title>, <meta name=description>, <!doctype x>, and an <abbr title="a>b"> whose > the tag pattern cuts at; also U+2065 inside the word. Chromium: text equals the word, width within 0.02 px. Unit level, the same for <tr>, <caption>, <tbody>, <body>, <html>, <head>, <link rel=icon>, stray </h2>, </li>, </body>, </>, U+FFF0, U+E0000.
  2. The address put together by `content:"@"`, a string with no letter or digit (drawn in place, 0.02 px).
  3. Every source label on Verify wrapped in <title> (10 labels): 0 px wide in Chromium, the numbers stage calls each beside its figure. Pre-existing numbers-stage gap; same cause (the gate's HTML parser is not the browser's).
  4. A figure drawn only in a page's own div.map-wide>svg: display none and 0 px at 375, 569.86 px at 1280; its source alone in an evidence list.
  5. A false edge ("StoryDocs documents cft-rebound") stated after a real Connections item's evidence.
- Unit level: an address in a PNG eXIf chunk passes; own_commit accepts an annotated tag object's hash, printing it as "this site's commit" and linking to another hash.
- Controls: with comment removal and inline tspan both sabotaged, "an email address ... split by a comment" and "... split by an SVG tspan" still report caught (243 caught, 2 did not fail: the Wally twins). They match the raw text's one@example.com.
- Records: CLAUDE.md trap 14 has no look-alike limit; it says local-only "names only how many it found", but the CSS-string and comment rules print the text verbatim (not in CI's log, which shows a path); VALIDATION says IDN, non-ASCII TLD and address literal "each passed every stage" (I measured them at unit level only); README and CLAUDE.md say "characters drawn as nothing" and "as a browser decodes it" are read, which 1 contradicts.
Believed: right-to-left override ("yllaW" drawn as Wally) and zero-size img/svg inside a word land in the layout limit; I don't count them.
VERDICT on 0176ce4..56a5b82: NOT READY.
For: lead

## 2026-09-30 00:50:55 -0700 - re-check of 0176ce4..c06a0ea as one scope: my 23:50 faults all held; NOT READY on three breaks of the HTML subset itself

Measured (worktrees of my scratch clone at c06a0ea; faults through the site's own sources, rebuilt, `bash verify/run.sh --require-all`; made-up addresses only; CI's parser = CPython 3.12.14's Lib/html/parser.py, read from GitHub and swapped in; Chromium in my own loganw.dev tab):
- Gate at c06a0ea: 11 of 11, nothing skipped, controls 275. The 13 pages are unchanged from 56a5b82 (only MANIFEST moved).
- Held, on my own faults: every 23:50 shape is refused (local-only 14 and 20 problems; links; the pair rule); own_commit refuses a tag object's hash; the import guard and lf_only as before.
- Not held, not stated. Each passed 11 of 11 on the desktop, and 0 problems in local-only under CI's parser:
  B. an empty SVG <title> inside <text> between "Wal" and "ly", and inside the address: PARENTS allows title in text and NO_TEXT doesn't list it. Chromium draws 5 characters, at the x positions of a plain "Wally".
  D. the name and a made-up address written backwards between &#x202E; and &#x202C;: invisible_problems reads raw HTML, and readings strip the override after decoding. Chromium draws "Wally" and the address forwards.
  C. a no-break space after the charset <meta>, on all 13 pages (render.py, in a copy): the subset tests text with str.strip(), which counts U+00A0 as whitespace; HTML doesn't. Chromium ends the head there: the policy <meta> and the <title> land in <body>. Per the HTML spec a policy <meta> outside head is not applied (spec, not measured). In a table row the space is moved before the table.
- Desktop only: an end tag holding a quoted > (<b>Wal</b title=">">ly) passes 11 of 11 on 3.12.9, which ends the tag at the first > (its source says so); 3.12.14, as CI set up, and Chromium read "Wally", so CI would refuse it. The subset rests on an unpinned Python: CI 3.12.14 (run 36660606803), desktop 3.12.9; 3.12.14 also parses <title> as RCDATA and attributes differently.
- Unit level: an address inside IEND's own data passes the PNG rule; so do PLTE or tRNS bytes and a UTF-16 tEXt string.
- Records: VALIDATION's "24 of the controls' write_text calls" is 22 call sites by AST at 56a5b82; "U+2065, U+FFF0 and U+E0000 ... passed all 11 stages" (the last two were unit level); README "Pages" and trap 14 say "text only where a browser draws it" and a subset "in which this check's parser and a browser build the same page" (B, C, and A on the desktop); masking prints %40 and &#64; forms as they are.
Believed: nothing beyond the above.
VERDICT on 0176ce4..c06a0ea: NOT READY.
For: lead

## 2026-09-30 01:26:18 -0700 - re-check of 0176ce4..07b1526 as one scope: every earlier fault caught, residuals inside stated limits; READY

Measured (worktrees of my scratch clone at 07b1526; faults through the site's own sources, rebuilt; CI's parser compared byte for byte with upstream CPython; made-up addresses only; Chromium in my own loganw.dev tab):
- Gate at 07b1526: 11 of 11, nothing skipped, controls 294, 2m56s. The 13 pages are unchanged from c06a0ea (only MANIFEST moved), and all pass canonical_problems (local-only 0).
- The one Python: desktop html/parser.py, _markupbase.py, html/__init__.py, entities.py are byte-identical to CPython v3.12.9's. run.sh refuses any other version (watched: PYTHON=python3, 3.13.14, FATAL before any stage); CI reads .python-version. My c06a0ea A finding (end tag with an attribute, a 3.12.9-vs-3.12.14 split) is now closed two ways: canonical_problems refuses it, and the version is pinned.
- Held, each on my own fault, the check watched failing: my four c06a0ea subset breaks all refused at 07b1526 - A (2 tags not the one way + a < or > outside a tag), B (<title> inside <text>), C (text directly inside <head>, all 13 pages), D (U+202C/U+202E after references decoded); PNG address in IEND data (size rule), a text chunk, a UTF-16 text chunk (all refused); own_commit still refuses a tag object's hash (facts.py unchanged); the privacy address gate refuses a real-domain address in a working-tree file and in HEAD history, by count, and passes the contact, example domains and the trailer address.
- Residual passes, each inside a stated limit (README Pages/Names/Images, trap 14): a Cyrillic-homoglyph name (look-alike letters); a name split by <div> in <section> joined only by a stylesheet display:inline (layout alone); an address in PLTE or tRNS bytes (image content, now stated). An address spelled for a person, and a font's tables, unchanged.
- Records: VALIDATION's corrections check out - 22 write_text-without-newline in controls() at 56a5b82, all LF at the fix (22 changed + 2 added = 24); the U+FFF0/U+E0000 unit-level note; the "same page" claim scoped to the pinned Python. _Masked withholds a line naming an address in any reading (%40, &#64;, fullwidth). Masking, edges, css_hides, merges, live 2b5c292 stand from prior passes.
Believed: the subset now holds every fault I could build. My evading passes all land inside limits stated where the claim is made.
VERDICT on 0176ce4..07b1526: READY.
Side notes: (1) run.sh checks the version string, not parser bytes; a hypothetical patched 3.12.9 would pass the guard, but I could not produce one and the desktop parser is upstream-identical. (2) The "layout alone" limit is wide: display:inline on an allowed block joins a split name. (3) The address gate reads HEAD only, by design (trap 17); a non-HEAD branch commit is not scanned. (4) P4.md held the author address earlier; the round ledger now holds 0 occurrences.
For: lead

## 2026-09-30 02:45:11 -0700 - the lead's commits since 07b1526 (5306744, 9f51d3c, 45a3165, 576b08a): merges exact; ONLY_HERE misses attributes; NOT READY on 576b08a

Measured (worktrees of my scratch clone; resumed after a dropped connection, the half-built plant reset and re-applied from scratch; made-up text only):
- Gate at 576b08a: 11 of 11, nothing skipped, 307 caught, 38 files. 9f51d3c --control: 304 caught.
- Merges exact: 5306744 = 07b1526 + 4d11e60, tree equal to 4d11e60's; 45a3165 = 9f51d3c + 4a883e4, tree equal to 4a883e4's. bd44300 is absent from main's history. Outside public/, each merge only adds its parcel's files (and P4's granted edits); no file deleted. GitHub main is still 07b1526.
- ONLY_HERE held, on my own faults: a body copy of decision 9's statement on Verify is refused by name; upper case and extra spaces are refused; a second declarer is refused at build. The statement and its declaration are one variable (STATEMENT_9).
- Not held, not stated: the exact statement in threads.html's meta description and in a title tooltip on verify.html passed all 11 stages (VERDICT PASS, 307 caught); only_here_problems reads _Text's parts, never its attrs. The stated limit is "a restatement in other words", and these are exact copies. Also a fullwidth copy passes (no NFKC), unit level. The name/address readings read both. Failure: About's PAGE description set to the statement publishes it in search and link previews; every stage passes.
- Records checked true: VALIDATION's two entries (five passes; a fast-forward to 07b1526; run 36690194219 passed, "Resolved .python-version as 3.12.9"; BUILD 07b1526; 0 author domain in the live facts.json and the CI log; verifier-P4/P5 verdicts per their own files; "275 of 275" true at c06a0ea; Method now prints 307 of 307; 9 of 9 pages; About's 2 drafts; P5's disclosure; no address in 576b08a's history). Overstated by the finding: the page contract and entry 1 ("refuses each on any other published page"), and 45a3165 ("held once by ONLY_HERE").
Believed: nothing beyond the above.
VERDICT on 576b08a: NOT READY.
For: lead

## 2026-09-30 03:00:10 -0700 - re-check of 576b08a..1142ab9: my 02:45 faults all refused; ONLY_HERE compares characters, not words; NOT READY on 1142ab9

Measured (worktrees of my scratch clone at 1142ab9; faults through the site's own sources, rebuilt, `bash verify/run.sh --require-all`):
- Gate at 1142ab9: 11 of 11, nothing skipped, 310 caught, 38 files. Method now prints "310 of 310" citing VALIDATION.md:1633, which holds that line.
- Held, on my own faults: my 02:45 plant (the exact statement in threads.html's meta description and a verify.html tooltip) is refused on both pages by name; my fullwidth copy is refused (NFKC). only_here_problems now reads texts_of, and the declared text is folded the same way.
- Not held, not stated: the same words with punctuation changed pass all 11 stages (VERDICT PASS, 310 caught): threads.html's meta description holding the statement without its final period, and a verify.html paragraph holding it with its one comma dropped. Unit level, "wouldn't" for "wouldnt" passes too. The check matches the folded character sequence, punctuation included. Its stated limit is "a restatement in other words passes: the check reads the words, not their meaning"; these are not other words. Failure: About's description set to the statement minus its period (as descriptions and headings often drop it) states it a second time, and every stage passes.
- Records: the new entry's account of my 02:45 verdict is true (merges, trees, figures, the three shapes) except "passed every stage" for the fullwidth copy, which I measured at unit level only; its "3 new controls plant the statement" plant a stand-in declaration, not decision 9's statement. The page contract's "refuses each on any other published page" and the docstring's "reads the words" are contradicted by the finding above.
Believed: comparing word sequences (both sides folded to their words) would close it and make the docstring true.
VERDICT on 1142ab9: NOT READY.
For: lead

## 2026-09-30 03:16:13 -0700 - re-check of 1142ab9..8260fa8: my 03:00 faults all refused; residuals inside stated limits; READY on 8260fa8

Measured (worktrees of my scratch clone at 8260fa8; faults through the site's own sources, rebuilt):
- Gate at 8260fa8: 11 of 11, nothing skipped, 314 caught, 38 files; local-only 0 problems, so no false match in the site's own files. The 8 ONLY_HERE controls each report caught. Method prints "314 of 314", citing VALIDATION.md:1683, which holds that line.
- Held, on my own faults: my 03:00 plants (the statement without its final period in threads.html's meta description; with its comma dropped on verify.html) are both refused by local-only after a full rebuild. Unit level, also refused: "wouldn't" for "wouldnt"; a line break inside it; split across two paragraphs; "A.I." for "AI"; as an image's alt text; percent-encoded in a link. build._folded keeps letters and digits only, NFKC-folded and lower-cased, on both sides.
- Residuals, each through the full gate (11 of 11, VERDICT PASS, 314 caught) and inside a stated limit: one word changed ("credited" for "attributed"): a restatement in other words (the page contract); one Cyrillic a in "attributed": a word in look-alike letters of another script (CLAUDE.md trap 14; build.readings' docstring, which ONLY_HERE reuses through texts_of).
- Records true: the new entry's account of my 03:00 verdict names each shape's level correctly (two full gate, one unit level); its two corrections (fullwidth measured at unit level; the controls plant a stand-in) are accurate; "314 of 314" holds; the page contract's claim is scoped to spacing, punctuation, case and compatibility forms, which is what the check does.
Believed: nothing beyond the above.
VERDICT on 8260fa8: READY.
Side notes: (1) the page contract's ONLY_HERE paragraph states only "other words"; the look-alike limit that applies is stated in CLAUDE.md and the readings docstring, and one clause would state it where ONLY_HERE is defined. (2) Method's sentence "This is the one place the site states it" carries no limit a reader sees (P5's page). (3) Nothing refuses a short ONLY_HERE declaration, whose letters could turn up by chance on other pages; that would be a loud false refusal, not a silent pass.
For: lead
