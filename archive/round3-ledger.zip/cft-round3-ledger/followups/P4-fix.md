## 2026-09-24 15:40 - P4 send-back fixer: `generated` already ran after `libcft` in CI; the brief's premise was wrong

Measured: verify/run.sh orders stages by file position, and `libcft` is stage 10, `generated` 11 - at 0aede0f, at
main (3b15d52) and on this branch. CI run 36051107585 (gates, 3b15d52, host job) logged `libcft ok 546s` then
`generated ok 0s`. host/Makefile `test: all $(TESTS)` and `all: libcft.a $(SHLIB) ...`, so CI's libcft stage leaves
host/libcft.so behind for generated. Believed (CI logs carry stage rows only, not the inner lines): CI's
make_seq_corpus check was running, not skipping. The fix was still made (generated builds $(SHLIB) itself when a
compiler is present, commit 96cb317) - it matters for --only/--skip runs, measured: `--only generated` on a clone of
309ea98 with nothing built PASSed with 1 inner skip and FAILed --require-all; on 3799f63 it builds cft.dll and passes.
For: lead

## 2026-09-24 15:40 - Windows: verify/run.sh cannot build a checkout reached through Git Bash's /tmp mount

Measured: a clone under C:\Users\logan\AppData\Local\Temp\... entered with `cd "C:/Users/.../Temp/..."` makes Git Bash's
`pwd` print /tmp/claude/..., so the runner's ROOT is /tmp/...; HOSTMAKE then runs /c/msys64/usr/bin/make (MSYS2's own
runtime, whose /tmp is C:\msys64\tmp) and every build fails: "make: *** /tmp/claude/.../host: No such file or
directory". Enter the clone as /c/Users/logan/AppData/Local/Temp/... (or call the runner by that path) and it builds.
Every HOSTMAKE stage has this, not only mine; pre-existing. Anyone testing the runner in a scratch clone: use /c/ paths.
For: every verifier and parcel running verify/run.sh in a scratchpad clone

## 2026-09-24 15:40 - docs gate on this branch fails only on docs/README.md's numbers (lead's at merge)

Measured: after P4 and this fix VERIFICATION.md is 379 lines; docs/README.md still says 364, total 48,914, "you
consult" 16,437. With 379 / 48,929 / 16,452 (uncommitted, in a clone) `--only docs,generated --require-all` PASSed,
nothing skipped. Other parcels' VERIFICATION.md edits will move these again.
For: lead

## 2026-09-24 15:55 - golden still has 3 inner skips on this desktop after test_chars stopped skipping

Measured (3799f63, clones, FORCE_COLOR=1 PY_COLORS=1 PYTEST_ADDOPTS=--color=yes, `--only golden --require-all`):
3 inner skips, FAIL - test_serial_replay.py:192 and :271 ("no loopback binary; make -C bindings/arduino/loopback")
and test_softfloat.py:81 ("math.fma needs Python 3.13+", python 3.12.9 here). test_chars's 4 are gone. With the
colour fix removed (both halves) the same run says "PASS, nothing skipped", exit 0 - the verifier's defect, reproduced;
with either half alone it FAILs with 3. So `--require-all` over golden still fails on any host without the loopback
binary and Python 3.13; CI's golden job runs pytest directly (3.13), not through the runner.
For: lead

## 2026-09-24 17:00 - CI's host-job stage list, --require-all, on this desktop at 3799f63: 0 inner skips

Measured (run 20260924-152859-3799f63, worktree wf_7e48fbe5-662-2): 22 stages executed, 0 skipped, 0 inner skips,
2 FAIL - docs (docs/README.md line counts, entry above) and lang-rust (rustc's MSVC link.exe against the mingw
libcft.a: __mingw_snprintf, __mingw_vsnprintf, ___chkstk_ms unresolved - unrelated, as on 2026-09-15). No line
containing "skip" in any case in any of the 22 logs; the replay read 168 sets. Believed for ubuntu-24.04: no
inner-skip path in those 22 stages can fire with the job's toolchain (audit in the P4-fix report).
For: lead
