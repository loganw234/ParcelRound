## 2026-09-24 17:36 - P1b: cft_config.h's CFT_ERRMSG_MAX rationale is false - the tiny profile has many last-error producers

Measured (reading cf8f00f; cft_config.h is not mine, not changed): host/include/cft_config.h:316-320 says the last-error
slot's "one producer in a build with no device backend is cft_program_load's capacity refusal, which CFT_NO_PROGRAM
removes", and CFT_TINY sets CFT_ERRMSG_MAX 1 on that ground. device.c alone has 18 cft_set_error calls outside any
#if (preprocessor-context scan of device.c: e.g. :965/:977 format refusals, :990 the op-group refusal, :1291 IMUL,
cft_run_ex's shape refusals ~:1993-2014, cft_reduce_seg's ~:2590/:2594). So in a CFT_TINY build every one of those
refusals keeps its status and returns "" from cft_last_error(). The same false sentence was in device.c:882-887
(mine) and is corrected on my branch; cft_config.h's copy is left for its owner.
Believed: a design question (is "" acceptable on the tiny profile?), not a correctness defect - statuses are unchanged.
For: P6 (the profile-compile target and docs/EMBEDDED.md), lead

Correction to the entry above: its time is 17:35 by `date +%H:%M`, not 17:36.

## 2026-09-24 17:41 - P1b: `python host/tools/gen_2opi.py` on this desktop writes CRLF, and its --check cannot see it

Measured (python 3.12 from Miniconda, worktree wf_efc44c87-a33-2): after the one-literal edit, regenerating wrote
host/src/mp_2opi.h with 1,456 CR bytes (every line CRLF, 118,682 bytes); `--check` then PASSED anyway, because it
compares `read_text()` (universal newlines) against the rendered text. gen_2opi.py uses Path.write_text(text), which
translates \n to \r\n on Windows. git's `*.h text eol=lf` would normalise it at `git add`, but sync.py hashes and
copies the WORKING file, so a CRLF header would put a CRLF vendored copy and a CRLF sha256 into vendor.json. I
normalised the file to LF (117,226 bytes, +6 over base = the literal) BEFORE running sync.py; both checks pass.
Believed: any generator here that uses write_text without newline="\n" does the same on Windows; not audited.
For: anyone regenerating a generated file on this desktop, lead
## 2026-09-24 17:42 - P1b: `bash verify/run.sh --only libcft` FAILS on a fresh worktree - do_libcft never calls ensure_vectors

Measured (run 20260924-174124-cf8f00f, worktree wf_efc44c87-a33-2, no earlier run): libcft FAIL 47s, its log
ending "replaying ../vectors/out / no vector sets found under ../vectors/out - nothing was checked / 0 cases checked
/ CONFORMANCE FAILED". verify/run.sh:870-880 says cpptest, node and wasm call ensure_vectors because "an --only run
may not have" vectors/out; do_libcft (:626-629) replays the same directory and does not. The failure is loud (good:
a replay of nothing refuses to pass), but the brief's `--only libcft` cannot pass on a fresh checkout without
`vectors` beside it. I am running `--only vectors,libcft,generated` instead.
Believed: do_libcft is P6's this wave; `ensure_vectors && ...` there would match its siblings. Not changed by me.
For: P6, lead, anyone told to run `--only libcft` in a new worktree
Correction to the 17:35 entry: the count is 19 unguarded cft_set_error calls in device.c, one of them
cft_seq_cap_refusal's (the capacity refusal itself, called only from program.c) - so 18 OTHER producers, which is
what "18" meant; measured again at 17:48 with the same preprocessor-context scan.

Correction to the correction above: measured at 17:44 by `date +%H:%M`, not 17:48.

## 2026-09-24 18:01 - P1b: lead-P1b-crlf done (8f2f52e) - only gen_2opi.py and gen_mp_consts.py wrote CRLF

Measured: before the fix, --out to scratch: mp_2opi.h 1,456 CR bytes, mp_consts.h 110, and --check PASSED both
CRLF files. After (write_text(text, encoding="utf-8", newline="\n")): regenerated in place, 0 CR each, git sees no
change, --check passes. The other five the lead listed (gen_divfull, gen_seq_flags, gen_layouts, make_seq_corpus,
gen_seed_rom) ALREADY write LF (io.open/write_text with newline="\n"): regenerated in place, every file they write
(20 files incl. 12 hw/layouts/*.cfg and docs/LAYOUTS.md) has 0 CR and git sees no change; each --check passes,
test_seed_rom_sync.py and test_mp_consts.py pass. No change made to them.
Believed (not changed, per the grant): --check should compare BYTES (read_bytes() vs text.encode()) - safe, since
.gitattributes pins eol=lf so every checkout's working file is LF, and it is the only way a CRLF file can fail it.
For: lead, verify-P1b; P2 (make_page.py / make_demos.py are yours)
## 2026-09-24 18:14 - P1b: P6's two device.c points taken (f481d0b); my b3608c0 wording was still too narrow

Measured (reading my branch): b3608c0 said the slot's producers are "this file and program.c" - false, as P6's
per-profile count shows (clause5.c, chars.c, divsqrt.c, augmented.c, formatof.c, reduce.c, transcend.c refuse through
backend.h's helpers) - and kept "the library's only formatted output" for the vsnprintf, false at device.c:943-959
(render_format_mask's snprintf, unguarded). f481d0b says both truthfully; comment only; vendored copy re-synced,
vendor.json moves device.c's sha256 only. P6's HOSTAPI.md:2038 point is not mine and not changed.
For: P6, lead, verify-P1b
