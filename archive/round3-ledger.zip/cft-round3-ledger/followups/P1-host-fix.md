## 2026-09-24 15:25 - P1-host send-back fixer: docs/ORBITS.md and two orbits.c refusal strings carry the stale claim the verifier found in orbits.c's comment

Measured (reading b574fc6 on worktree-wf_7e48fbe5-662-4; not changed by me - docs and code are outside a comments-only parcel):
- docs/ORBITS.md:49-55 ("both of them were facts about the program model ... revision 3's scratch block has since
  answered the first"), :293-297 ("the second still cannot be worked around by writing the program differently") and
  :329-343 ("(2) Correctly rounded divide and square root are not programs ... needs the host between its halves, and
  it would not leave room for the orbit state") are the same claim orbits.c's comment made. Since 7b3c10c (2026-09-14)
  python/cft_golden/divfull.py (libcft: divsqrt.c full_via_program, opt-in CFT_DIVSQRT_FULL=1) is ONE program each;
  a probe run of it at fp32/fp64, five attributes, 300 random pairs, is bit- and flag-identical to softfloat and every
  image spans r0..r31 (so "room" is a spill-to-scratch question, not a model limit, since revision 3).
- host/tools/orbits.c:2105-2108 die("--engine program needs --rsqrt newton: the correctly rounded route is host-prep,
  program core, host finish (python/cft_golden/seqprogs.py) and cannot sit inside another program's loop body") and
  :2110-2112 ("... only three registers can be loaded") are CODE strings stating the same stale model facts. The
  refusals themselves are right (the tool does not do it); the reasons they name are the tool's, not the model's.
Believed: whoever owns docs/ORBITS.md and orbits.c's code next should restate these as tool gaps.
Also: this branch now changes vendor.json's backend.h sha256 twice (0431828 and b574fc6); if another parcel edits
host/src/backend.h, re-run python bindings/arduino/sync.py after the merge and --check.
For: lead, the docs parcel, whoever next edits host/tools/orbits.c code
