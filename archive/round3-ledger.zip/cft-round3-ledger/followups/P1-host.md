## 2026-09-24 12:30 — the brief's Windows host-build line fails as written; add TMP and TEMP

Measured: in a fresh worktree at 0aede0f, `PATH="/c/msys64/mingw64/bin:$PATH" make -C host CC=gcc OS=Windows_NT all`
fails on every object with `Cannot create temporary file in C:\WINDOWS\: Permission denied` (make Error 3).
verify/run.sh:107-108 (HOSTMAKE) passes `TMP="$WTMP" TEMP="$WTMP"` as MAKE variables, WTMP being
`<USERPROFILE>/AppData/Local/Temp` with forward slashes (run.sh:89). Adding
`TMP=C:/Users/logan/AppData/Local/Temp TEMP=C:/Users/logan/AppData/Local/Temp` to the make line is what the runner does.
Believed: this bites any parcel that builds host/ by hand from the brief's line; the runner itself is unaffected.
For: anyone building host/ on this desktop (P3, P4, P1-rtl), lead

## 2026-09-24 12:31 — confirmed: with TMP/TEMP the host build is clean at 0aede0f

Measured: `PATH="/c/msys64/mingw64/bin:$PATH" make -C host CC=gcc OS=Windows_NT TMP=C:/Users/logan/AppData/Local/Temp TEMP=C:/Users/logan/AppData/Local/Temp -j12 -Otarget all`
in a fresh worktree at 0aede0f: EXIT 0, zero lines matching "warning" (145-line log). No GOROOT was needed for `all`.
For: anyone comparing warnings before/after on this desktop

## 2026-09-24 12:39 — the brief gives host/tests/* to two parcels; P1-host will touch four docstrings there

Measured: the brief lists host/tests/* under P3, and gives P1-host "comments only, in host/ EXCEPT
host/src/program.c, host/src/device.c and host/include/cft.h" - which includes host/tests/. My work-list
has notes on host/tests/{mersenne,orbits,collatz,enclose}_check.py (module docstrings crediting "the
tool's" SHA-256 derivation, which has been host/src/sha256.c's since c0effe9).
Plan: I will edit ONLY those four module docstrings (a line or two each, near the top of each file:
mersenne_check.py ~:57, orbits_check.py ~:50, collatz_check.py ~:45, enclose_check.py ~:67). No other
host/tests file, and not the ok() message strings (code). A disclosed crossing, reported as such.
P3: if you are editing any of those four files, say so here and I will leave them for the lead instead.
For: P3, lead

## 2026-09-24 12:49 — cft_supports(CFT_IMUL) is 0 on every device; device.c's CAPS[28] check for it is unreachable

Measured (reading 0aede0f; not changed by me - code, and P3's files):
- host/src/softfloat.c:791-796 cft_sf_op_assigned() is true for 0..14, 16..23, 24..29 and 31 - NOT 30 (IMUL).
- host/src/device.c:1080 cft_supports() returns 0 when !cft_sf_op_assigned(op), BEFORE :1091-1094, which is the
  IMUL-specific "CAPS[28] vouches for it" check - so that check can never run and cft_supports(dev, CFT_IMUL, f)
  is 0 on every device, the software one included, although program.c:553-556 publishes CFT_ALU_EXT_IMUL.
- host/tests/api_test.c:1828-1834 pins  with the comment "no CAPS bit
  publishes it"; docs/ARCHITECTURE.md's CAPS row says CAPS[28] IMUL is published from 2026-09-07.
Believed: either op_assigned should include 30 (and the api_test line flip to == 1 on software), or the device.c
IMUL branch and its comment are dead and should say so. Which one is a contract decision, not mine.
Also (comment, mine, fixed on my branch): host/src/softfloat.h:78 "15 and 31..255 are unassigned" -> "15 and
32..255 ... (31 is CFT_SF_MAXALL, below.)", as P1-rtl asked (P1-rtl.md 12:44); vendored copy re-synced.
For: P3 (seq_features / caps truth), lead

Correction to the entry above (a shell ate a quoted span): the api_test.c:1828-1834 bullet should read
"pins `CHECK(cft_supports(dev, CFT_IMUL, CFT_FP32) == 0, "imul is not published in CAPS yet")` with the comment
'no CAPS bit publishes it'". The "Measured" there is by reading the code; api_test's own pass is the run evidence.

## 2026-09-24 12:51 — softfloat.h is edited on my branch (comment at :78 only); vendor.json will need a re-sync at merge if P3 edits it too

Measured: my branch changes host/src/softfloat.h lines 78-81 (the "Opcodes. 15 and 32..255 are unassigned" comment)
and its vendored copy, and so the softfloat.h sha256 line in bindings/arduino/vendor.json. I did not touch
softfloat.c. If P3's IMUL work edits softfloat.h as well (e.g. the cft_sf_op_assigned comment at :155), the two
branches change the SAME vendor.json line: the merge of the .h itself is line-disjoint, but vendor.json will
conflict on that one sha, and the fix is to re-run python bindings/arduino/sync.py after merging and --check.
For: P3, lead
