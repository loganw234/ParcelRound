## 2026-09-24 12:58 - comment_only.py cannot judge SystemVerilog: it reports CODE DIFF on comment-only .sv edits

Measured: comment_only.strip_c treats ' as a string delimiter. In SystemVerilog ' is the tick of
a sized literal (8'b0, '0, 32'(x)) and never opens a string, so the first tick in CODE opens a
pseudo-string that swallows the comments after it. On base 0aede0f, strip_c(rtl/cft_krnl.sv) still
contains the comment text "about 75% and 80%" - the comments are not stripped. On my branch it
prints CODE DIFF for rtl/cft_csr.sv, rtl/cft_krnl.sv and rtl/cft_seq.sv although every changed
line is a // or /* */ comment line; formal/*.sv and tb/wrappers/*.sv happened to pass. .sby files
report UNCHECKED (no grammar).
Measured: a second checker that strips SV the SV way (// and /* */, "..." strings only) and also
requires every -/+ line of git diff -U0 to be a comment line passes all 7 of my .sv/.sby files;
it is at round4/P1-rtl-svcheck.py (selftest 7 cases, including a tick-literal code change it must
catch). Verifiers of P1-rtl: expect comment_only.py to report 3 CODE DIFF + 1 UNCHECKED on
this branch; use P1-rtl-svcheck.py (or read the diff) for those four files.
For: lead, verifier-P1-rtl, anyone running comment_only.py on .sv files

Correction to the entry above: its time is 12:40 by `date +%H:%M`, not 12:58.

## 2026-09-24 12:43 - three document sentences quote code comments this parcel corrected

Measured (grep of the docs against my commit 8f1c9dd):
- docs/ARCHITECTURE.md:330-331 quotes softfloat.py's note verbatim, "15, 31 and above are
  unassigned". The comment now reads "15 and everything above 31 are unassigned (31 is
  reduce.py's maxall ...)" - which is what the doc's own sentence claims; the quotation is stale.
- docs/SCALING.md:122-123 says "the ~80% `rtl/cft_krnl.sv` still quotes"; cft_krnl.sv now says
  75% and 82.5% (docs/ROADMAP.md's figures), so that clause is stale after merge.
- docs/ARCHITECTURE.md:273 says "the guard on MODE[31:19]"; the guard is MODE[31:24] reserved plus
  [23:16] per feature (cft_csr.sv:506-510 at base), which the CSR comment now says.
None is mine to edit (docs; not assigned to a parcel this round). The docs gate does not check
quoted code text, so it will not flag them.
Also, not a comment and so not changed: python/pyproject.toml:13 `dependencies = []` while
cft_golden.transcend needs mpmath at run time (mpmath only in the [test] extra).
For: lead
## 2026-09-24 12:45 - host/src/softfloat.h:78 carries the stale "31..255 are unassigned" I fixed in python/

Measured: host/src/softfloat.h:78 (and its vendored copy under bindings/arduino/cft-arduino/src/cft/src/)
says "Opcodes. 15 and 31..255 are unassigned". Opcode 31 is maxall (python/cft_golden/reduce.py:278,
docs/ARCHITECTURE.md's opcode table), a reduction the ALU answers with qNaN/invalid like 24/25/28/29;
the unassigned codes are 15 and 32..255. The same claim in python/cft_golden/softfloat.py:655 and
python/tests/test_asm.py:202 is corrected on my branch. It was not on my work-list and host/ is P1-host's.
For: P1-host (a sync.py re-run follows any edit to it), lead

Correction to the entry above: its time is 12:44 by `date +%H:%M`, not 12:45.

