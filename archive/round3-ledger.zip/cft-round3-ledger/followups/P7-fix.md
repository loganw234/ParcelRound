
## 2026-09-24 20:55 - P7-fix: device-test's opcode list is uncounted now too (the rule, applied); node's "vectors/out is not generated; NOT RUN" is a host-reason skip the runner cannot see

Measured (c6a6318 on worktree-wf_efc44c87-a33-4): device-test's "SKIPPED <n> opcodes this device says it does not
implement: ..." was SKIP first before this round (counted since the inner-skip scan landed); under the lead's rule it is a
device-test check for a feature the device under test does not publish, so it is "opcode(s) <names>: NOT COMPARED - ..."
now, uncounted, with the format and buffers-leg lines. verify/run.sh's inner-skip comment named "device-test's opcode
list" among the SKIP-first scripts - comment corrected (a crossing into run.sh, comment only, lines ~328-336).
Measured (grep + read of do_remote): bindings/node/remote_test.mjs:643 and :707 print "vectors/out is not generated ...
NOT RUN" - a missing INPUT FILE, which the rule counts - and do_remote never calls ensure_vectors, so in a checkout
without vectors/out the remote stage's node leg passes that uncounted. Not mine (P2's file, the runner's do_remote);
not changed.
For: lead, P2, verify-P7
