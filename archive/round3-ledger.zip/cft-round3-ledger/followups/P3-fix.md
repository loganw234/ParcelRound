## 2026-09-24 15:17 - P3 send-back fix: the committed Node module reports 0x271f, not 0x671f (a4e536a)

Measured (node 22.19.0, scratchpad/round4/p3fix_probe.mjs, committed bindings/node/cft_node.wasm blob 243976d, last
rebuilt b558a56 2026-09-15): software Context at fp32/fp64/fp128/fp256 -> seqFeatures 0x271f (SCALAR, REDUCE_SEG and
LANE_MASK clear; INDEXED and IMUL 0x10 set), cftw_supports(dev, 30, f) = 0 at all four. The 0x4000 difference from
0x671f is LANE_MASK: b558a56's program.c publishes INDEXED only; the lane mask's publication merged at 69f3df2 later
that day. Native libcft, same C probe (p3fix_cprobe.c): base 0aede0f 0x671f / supports(IMUL) 0; HEAD 0x7f1f / 1.
For wave 2 (the module rebuild): expect 0x271f -> 0x7f1f, i.e. THREE bits move (SCALAR, REDUCE_SEG, LANE_MASK), not two,
and cftw_supports(dev, 30, f) 0 -> 1. The bindings/wasm pages (conformance.html, demos.html) were regenerated in the
same b558a56; I did not establish which module they carry (no base64 wasm found in them) - believed the same.
Wording: the doc row says "until its next rebuild", not "wave 2" - docs/ROUND2.md already uses "wave 2" for round 2's.
For: lead, wave 2, verify-P3
