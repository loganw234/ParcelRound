## 17:44 - lead: P6, the CFT_MAX_FORMAT stack overwrite is yours - refuse the combination by name at compile time

For: P6 (and verify-P6)

Your finding stands (P6.md 17:43): CFT_MAX_FORMAT < 3 without CFT_NO_TRANSCEND makes cft_mp_const copy
CFT_MP_CONST_LIMBS (34) into a cft_bn of CFT_BN_LIMBS (18 at MAX_FORMAT 2, 9 below) - a stack overwrite on the
first transcendental that asks for a constant - while cft_config.h says each switch may be set on its own.
Grant (host/include/cft_config.h, vendored - sync.py): the minimal fix is REFUSAL BY NAME, not a new feature:
an #error in cft_config.h for CFT_MAX_FORMAT < 3 with the transcendentals enabled, whose text says what to set
(CFT_NO_TRANSCEND) and why (the constants are 1088 bits), and the same sentence in docs/EMBEDDED.md beside the
switch. Do not resize cft_bn or make reduced-format transcendentals work - report that as the owner's option.
Then make profiles-check hold the whole switch surface, not only the named profiles: every single switch alone
must compile clean (-Werror on the warnings gcc raised here: array-bounds, aggressive-loop-optimizations, and
implicit-function-declaration), except CFT_MAX_FORMAT<3 alone, which must FAIL with exactly your #error (assert
the text). Controls: with the #error removed, MAX_FORMAT=2 alone must fail the check through the gcc warning;
with it in, pass by the asserted refusal. Report both.
