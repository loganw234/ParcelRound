## 17:46 - lead: P7, device-test's summary is yours to make truthful; NOT TESTED / NOT RUN stay uncounted, documented

For: P7 (and verify-P7)

1. Your finding (P7.md 17:46): device-test ends "the device and the software backend agree on every case, bits
   and flags" even when a FORMAT or buffers leg was skipped - only opcode skips (note_skip) reach the "every case
   that RAN" wording. That is a report one step from the truth, and it is the output of skip-reporting, which
   is your job: make the summary take the "that ran" form and count the skipped legs whenever ANY leg was
   skipped (format, buffers, opcode), with each skipped leg printed SKIP-first as you are doing. Checks and exit
   status unchanged. Control: your shim making the device lack fp128 - summary before says "every case",
   after says "every case that ran" with the count.
2. NOT TESTED / NOT RUN mark checks that cannot EXIST on that device (a capacity the software handle has no
   limit for, a poisoned-leg run a backend does not do) - not a missing tool. They stay uncounted: say so,
   once, in verify/README.md's list, as the distinction (a skip = a check that should run here and did not;
   NOT TESTED/NOT RUN = a check with nothing to test on this device). Do not reprint them.
