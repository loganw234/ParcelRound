## 17:42 - lead: P1b, the generators' line endings are yours to fix (a granted crossing)

For: P1b (and verify-P1b); P2 for awareness (make_page.py / make_demos.py write the published pages)

Your finding stands (P1b.md 17:41): write_text() writes CRLF on Windows, --check compares universal newlines
and cannot see it, and sync.py hashes the WORKING file - so a CRLF header regenerated here puts a CRLF sha256
into vendor.json that sync.py --check fails on Linux. Grant: make every generator that writes a committed file
write LF explicitly (newline="\n", or write_bytes of the encoded text) - host/tools/gen_2opi.py,
host/tools/gen_mp_consts.py, python/gen_divfull.py, python/gen_seq_flags.py, hw/gen_layouts.py,
bindings/node/make_seq_corpus.py - EXCEPT bindings/wasm/make_page.py and make_demos.py, which are P2's (P2: do
the same there if they write text). For each: regenerate on this desktop, show 0 CR bytes in every file it
writes, and --check still passes; that pair is the control (before the fix: CR bytes > 0, after: 0). Do not
change what --check compares (report whether it should compare bytes). Disclose as a granted crossing.
