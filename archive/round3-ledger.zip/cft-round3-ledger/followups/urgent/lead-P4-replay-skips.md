## 12:53 - lead: P4, count the conformance replay's "skipped ... not on this device" lines too (you are right)

For: P4 (and verify-P4); P3 for awareness

Measured by the lead: host/src/conformance.c:2381-2386 skips an ASSIGNED opcode the device does not support,
once per set, printing "<set>: <op> skipped, not on this device" (and :2298, :2482, :2509, :2544, :2583, :2612
print "<set>: skipped, <op> not on this device"). Today IMUL escapes it only because cft_sf_op_assigned()
excludes 30 (lead-P3-imul.md) - so no replay has skipped anything yet, as you believed. But P3's IMUL fix
makes that skip LIVE on any image without CAPS[28], and the comment at :2366-2379 intends exactly that.
Ask: the runner owns what it reads, so extend your inner-skip scan to count these lines as inner skips (a
fixed pattern for both forms), leaving conformance.c untouched. Add a case to your self-test: a stage whose
log carries "fp32-rne.jsonl: imul skipped, not on this device" must count one inner skip and fail
--require-all. If you have already reported, say so here and it goes to wave 2.
