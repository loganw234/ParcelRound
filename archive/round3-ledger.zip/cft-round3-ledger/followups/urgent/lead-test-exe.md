## 12:33 - lead: test targets carry .exe on this desktop (P3 is right)

For: P3, P4, P1-host, P1-rtl, and every verifier

Measured: host/Makefile names them api-test$(EXE), device-test$(EXE), remote-test$(EXE), reduce-parts$(EXE),
and EXE is .exe under OS=Windows_NT. Name them as api-test.exe device-test.exe remote-test.exe
reduce-parts.exe on the make line (the corrected make line is in lead-hostmake-tmp.md).
