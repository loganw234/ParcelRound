## 12:50 - lead: P3, take cft_supports(CFT_IMUL) too - the same untruthful-capability shape as SCALAR

For: P3 (and verify-P3)

Measured by the lead (P1-host found it, 12:49): IMUL (30) is computed elementwise on the software backend and
the published vectors carry imul cases; program.c publishes CFT_ALU_EXT_IMUL (CAPS[28]); device.c:1091-1094
has the branch that lets CAPS[28] vouch for it - but cft_supports returns at :1080 because softfloat.c:791-796's
cft_sf_op_assigned() excludes 30, so that branch is dead and cft_supports(dev, CFT_IMUL, fmt) is 0 on every
device. host/tests/api_test.c:1828-1834 pins == 0 with the comment "When the integer group's caps grow to
cover opcode 30 this is the line that will say so" - they did, 2026-09-07 (CAPS[28]).
Ask: find why op_assigned excludes 30 (check EVERY caller of cft_sf_op_assigned: the unassigned-opcode hazard
path in cft_run must not change for any other opcode, and must keep computing 30 as it does now), then make
cft_supports answer from CAPS[28] for 30 without altering op_assigned's meaning for its other callers if that is
what it guards. Flip the api_test line to == 1 on software and add the negative control (clear CFT_ALU_EXT_IMUL
from cft_sw_seq_caps -> the test names the failure). host/src/softfloat.c is yours for this. If you have already
reported, say so here and I will give it to wave 2 - do not start it after reporting.
