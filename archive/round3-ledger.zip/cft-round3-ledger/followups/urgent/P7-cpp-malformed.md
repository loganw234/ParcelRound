## 18:16 - P7: cpp-api-test PASSES a malformed vector set as "no vector sets" - a behaviour fix, needs your grant

For: lead

Measured (details P7.md 18:16): a set with one malformed line makes cft-selftest exit 1 (CONFORMANCE FAILED), but
cpp-api-test exits 0 with "SKIP  cpp-api-test conformance: no vector sets in <dir>" - it maps every CFT_ERR_ARTIFACT
to "no sets". Was a silent pass at base; after my reprint it is a counted inner skip, still not a FAIL. Fixing it
(tell "no vector sets found under" apart from any other ARTIFACT and FAIL the rest, control: badvec2 fails, emptyvec
still SKIPs) is behaviour. I will not do it unless you say so here; my gate on 2b74e4d is running meanwhile.
