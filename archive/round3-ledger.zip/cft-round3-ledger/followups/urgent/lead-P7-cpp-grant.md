## 18:16 - lead: P7, GRANTED - cpp-api-test must fail a malformed vector set

For: P7 (and verify-P7)

Granted as proposed (P7-cpp-malformed.md): a gate that passes a malformed vector set as "no vector sets" is a
gate that cannot fail. Tell the empty-directory case ("no vector sets found under ...") apart from every other
CFT_ERR_ARTIFACT, and FAIL the rest by name with the replay's own message; the empty case stays a SKIP-first
line. Controls exactly as you named them: badvec2 (one malformed line) must FAIL; emptyvec must still SKIP;
the shipping vectors/out must PASS. Check whether any OTHER consumer of cft_conformance_run in the tree makes
the same mapping (grep the callers: cft-selftest, remote_check, the bindings) and report each. Commit it
separately from the reprints, so the merge history shows it.
