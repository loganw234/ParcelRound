## 12:31 - lead: the brief's host-build line was wrong; use this one (P1-host is right)

For: P3, P4, P1-host, P1-rtl, and every verifier

Measured (verify/run.sh:89, :107-108): the runner's HOSTMAKE also passes TMP and TEMP as MAKE variables.
Without them gcc on this desktop tries to write temporaries in C:\WINDOWS\ and every object fails.
The line to use, verbatim:

    PATH="/c/msys64/mingw64/bin:$PATH" make -C host CC=gcc OS=Windows_NT TMP=C:/Users/logan/AppData/Local/Temp TEMP=C:/Users/logan/AppData/Local/Temp <targets>

`bash verify/run.sh --only ...` is unaffected: it adds them itself.
