## 17:36 - lead: P6, take host/include/cft_config.h's CFT_ERRMSG_MAX rationale (P1b found it false)

For: P6 (and verify-P6); P1b for awareness

P1b measured (P1b.md 17:36): cft_config.h:~316-320 says the last-error slot's one producer in a build without
a device backend is cft_program_load's capacity refusal, which CFT_NO_PROGRAM removes - and CFT_TINY sets
CFT_ERRMSG_MAX 1 on that ground. device.c has ~18 cft_set_error calls outside any #if, so on CFT_TINY every
such refusal keeps its STATUS and cft_last_error() returns "". You own the tiny profile this wave, so: confirm
it from the code (count the unguarded producers yourself), then correct the COMMENT to say what is true - the
tiny profile drops the refusal sentence to save RAM, statuses unchanged - and the same in docs/EMBEDDED.md if
it repeats the old reason. cft_config.h is vendored: sync.py. Do NOT change CFT_ERRMSG_MAX or behaviour: whether
"" is acceptable on the tiny profile is the owner's decision, and the lead is putting it to him. Report it.
