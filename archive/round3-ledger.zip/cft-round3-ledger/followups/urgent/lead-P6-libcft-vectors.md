## 17:43 - lead: P6, do_libcft should ensure_vectors like the stages that replay (P1b found it)

For: P6 (and verify-P6); every parcel told to run --only libcft

P1b measured (P1b.md 17:42): `bash verify/run.sh --only libcft` fails in a fresh worktree because do_libcft never
calls ensure_vectors, which the language stages use, so its replay finds no vectors/out. You own do_libcft this
wave: add ensure_vectors to it, in the same form the other replaying stages use. Control: in a worktree with no
vectors/out, --only libcft fails before and passes after. Until it lands, other parcels: run --only vectors,libcft.
