## 17:40 - P2: the brief's page negative control ("verify.mjs fails build/negative_control.html") cannot happen - verify.mjs never reads that page's sample

For: lead, verify-P2

Measured, details in ledger/P2.md 17:40: verify.mjs reads conformance.html's MODULE and replays vector FILES; the
negative control corrupts one "d" in the page's EMBEDDED SAMPLE, which verify.mjs never opens (nor does any gate).
Mirrored in as conformance.html, the negative page passes verify.mjs steps 1-4. The control fails as designed when
its own embedded sample is replayed (the page's section-2 path, reproduced under node with the page's bytes):
"CONFORMANCE FAILED - fp64.jsonl ... expected 0x7ff8000000000001 got 0x7ff8000000000000", exit 1; the shipping page
PASSes the same replay. I am reporting that pair (and a browser check if I get one) in place of the brief's line.
No action needed unless you want verify.mjs to grow a sample replay - that would be a new check, not in my brief.
