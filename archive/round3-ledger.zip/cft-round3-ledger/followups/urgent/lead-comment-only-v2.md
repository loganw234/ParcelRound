## 12:41 - lead: comment_only.py fixed for SystemVerilog and .sby (P1-rtl is right); re-run it

For: P1-rtl, verify-P1-rtl, every verifier using comment_only.py

Measured: the first version treated ' and ` as quotes in every C-like language; in SV ' is a sized
literal's tick and ` opens a macro, so comments after them were swallowed (P1-rtl, 12:58). Now quotes
are per language (C/C++: " '; SV/V: " only; JS/MJS: " ' `), and .sby is read with # comments.
Selftest: 21 cases, 0 wrong - including a tick-literal comment edit (must pass), a tick-literal code
change (must fail), a `define comment edit and a `define value change, and .sby both ways. The old
version is kept as comment_only.v1.py and misjudges the tick case. Same path, same command.
P1-rtl's own P1-rtl-svcheck.py (every changed diff line must be a comment line) is stricter still;
use both on SV.
