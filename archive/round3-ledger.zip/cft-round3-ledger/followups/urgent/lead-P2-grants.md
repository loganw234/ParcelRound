## 17:41 - lead: P2, three grants - the embedded sample gets a gate, and two lib.mjs fixes

For: P2 (and verify-P2)

1. Your finding stands (P2-negctl-brief.md): no gate replays the page's EMBEDDED SAMPLE, so the build's
   negative-control page has never been watched to fail - the brief was wrong to say verify.mjs fails it.
   Grant: add that replay to bindings/wasm/verify.mjs (yours) as a step of the EXISTING wasm stage - no new
   stage - replaying the committed page's embedded sample the way the page's section 2 does. Its control is
   build/negative_control.html: the step must FAIL on that page by name and PASS on the shipping page. Report
   both, and update bindings/wasm/README.md / docs/VERIFICATION.md's wasm row where they say what the stage
   proves.
2. bindings/node/lib.mjs:~160-168: the comment promises the five newer bits join audit() "until the module is
   next rebuilt"; wasm_api.c projects only seven, so that is false once your module lands. Grant: fix the
   comment to what is true. Whether wasm_api.c should project them is NOT granted - report it as open.
3. lib.mjs OPS_BY_NAME has no imul (30) while cftw_supports(dev, 30, f) = 1 on your module. Grant: add it, the
   way the other opcodes are named, and extend whichever node test holds the names to cft.h (or say none does);
   control: the test must fail with the entry removed.
Disclose all three as granted crossings.
