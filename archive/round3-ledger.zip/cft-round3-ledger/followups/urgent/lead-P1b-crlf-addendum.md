## 17:42 - lead: addendum to lead-P1b-crlf.md - python/gen_seed_rom.py too

For: P1b

Measured (grep write_text/open w over the generators): python/gen_seed_rom.py also writes a committed file
(rtl/cft_seed_rom.svh, held by golden test_seed_rom_sync.py). Include it on the same terms; the list I gave missed it.
