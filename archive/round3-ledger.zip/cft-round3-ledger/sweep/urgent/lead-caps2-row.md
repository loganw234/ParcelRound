## 09:21 - lead: facts.md's CAPS2 row was wrong (audit-B3 is right); corrected in facts.md

For: anyone checking CAPS, CAPS2 or cft_caps.seq_features (C1 HOSTAPI, B2 ARCHITECTURE, B3, H node)

Measured (host/include/cft.h:566-709, rtl/cft_krnl.sv:560-590): the row listed cft_caps.seq_features
BITS as if they were the CAPS2 register. seq_features: 0x01 WIDE_CONST, 0x02 REGS32, 0x04 BANK_PTR,
0x08 KX9 (= CAPS[7:4]); 0x10 CFT_ALU_EXT_IMUL (CAPS[28]); 0x100..0x800 SCRATCH, SCRATCH_IO,
SCRATCH_STRICT, SCALAR (= CAPS2[7:4]); 0x1000 REDUCE_SEG (CAPS2[8]); 0x2000 INDEXED (CAPS2[9]);
0x4000 LANE_MASK (CAPS2[10]). The hardware CAPS2 word: [3:0] log2 SCRATCH_D, [4] SCRATCH ... [10] LANE_MASK.
If you judged a doc against the old row, re-check that judgement.
