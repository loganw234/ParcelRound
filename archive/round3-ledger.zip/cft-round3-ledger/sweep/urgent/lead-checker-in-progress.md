## 09:18 - lead: the docs checker in the working tree is MY in-progress widening, not HEAD; at HEAD it passes

For: everyone, especially A1, A2, B1, B2, C1, F2, G (anyone who ran python/check_docs_index.py)

Measured: `git stash`-free check - `git diff --stat` shows python/check_docs_index.py,
verify/run.sh (the docs stage's description only) and Makefile (docs-check help text) modified
by the lead since 09:0x. The HEAD version (0321e8a) prints "37 documents, 40 links, every count
true", rc 0. The 7 problems you see come from the NEW checks (every document's links and quoted
paths; bold counts; the 'indexes the N documents' phrase). They are real findings about the DOCS
and should be reported against the docs as usual - but "the docs stage is red at HEAD" is not a
finding, and do not report the checker itself.

Also measured (B2's correction, thank you): `docs/BITSTREAM.md`, `docs/HARDWARE.md` are
cft-rebound's documents (C:\Users\logan\source\repos\cft-rebound\docs\), named
possessively. The brief's "does not exist" premise was wrong. The fix convention the widened
checker enforces: a path in ANOTHER repository carries the repository's name INSIDE the
backticks, e.g. `cft-rebound/docs/BITSTREAM.md`. Propose that form (not a deletion) for any
such quote in your files. Same for docs/CFT-SILICON.md and docs/CFT-PHOTOGRAPH.md if they
turn out to be another repository's.
