# audit-A1 (README.md, CLAUDE.md, docs/README.md, docs/INTEGRATION.md)

## 09:25 - two bitstream "traps" shared by CLAUDE.md and docs/BITSTREAM-BUILDS.md are false about host/Makefile; and the trap COUNT disagrees three ways

Measured (read the source lines):
- Without XRT=1, `backend_xrt.cpp` is NOT compiled at all: host/Makefile:77-87 adds `src/backend_xrt.o`/`.lo`
  to OBJ/PICOBJ only inside `ifeq ($(XRT),1)`, and it has been that way since the backend's first commit
  (`git show f1ae8a9:host/Makefile`, lines 43-49). The build looks clean because device.c's XRT branch is
  `#ifdef CFT_ENABLE_XRT`. So CLAUDE.md:66-67 ("`backend_xrt.cpp` still *compiles* without it") and
  BITSTREAM-BUILDS.md:127-129 ("still compiles to an object and lands in `libcft.a`") are both wrong; the
  consequence they describe (cft_open of an xclbin -> CFT_ERR_NO_DEVICE, "no such device") is right.
- `make -C host clean` does NOT remove `cft-zoom`: `clean:` depends on clean-resident, enclose-clean,
  clean-orbits, clean-mersenne, clean-remote, clean-programs, fuzz-clean - never `zoomclean`
  (host/Makefile:674-676 says so on purpose: "`clean` above is deliberately untouched"; rm of cft-zoom only
  at :700-701). CLAUDE.md:73 ("removes every tool in `host/`") and BITSTREAM-BUILDS.md:150-152 (lists
  `cft-zoom` among what clean removes) are wrong by that one tool.
- Trap count: BITSTREAM-BUILDS.md has FIVE numbered trap sections (1,2,3,5,4 at :104-196; #5 added edb88ed,
  2026-09-16) under a heading ":102 The four traps" and an intro ":3 the four ways"; docs/README.md:83 says
  "the five traps" (4ead688, same day); CLAUDE.md:55 still says "four traps".
- Also for BITSTREAM-BUILDS: its :106 says "`hw/rebuild-2022.sh` line 17: `KERNEL_FREQ=...`" - that
  assignment is at line 19 today (line 17 is PLATFORM).
- The Verilator UNSIGNED waiver is in ALL FOUR tb/wrappers/tb_fpfma_*.sv (fp64/128/256 since 2026-09-14,
  per tb_fpfma_fp128.sv:29-37); at the default MUL_PASSES=1 every rung is one pass (cft_mul_passes,
  rtl/cft_mulgeom.svh:74-81). CLAUDE.md:138-142's "fp32 is the one format whose mantissa fits a single
  multiplier pass" is stale (I report it).
Believed: nothing else states these; `git grep 'still compiles\|removes every tool' -- '*.md'` finds only
CLAUDE.md and BITSTREAM-BUILDS.md.
For: whoever audits docs/BITSTREAM-BUILDS.md; the lead (CLAUDE.md edits are mine to report).

## 09:29 - cft_get_caps does NOT publish opcode groups; and two small gaps in facts.md

Measured: the public struct `cft_caps` (host/include/cft.h:456-564) has struct_size, format_mask, tiles,
abi_version, device_version, flags_readable, backend, max_deposits, max_insns, max_consts, seq_features,
max_scratch, buffers_resident - no opcode-group field; cft_get_caps (host/src/device.c:1027-1056) fills only
those. The groups live in the device (`op_groups`, device.c:60) and are reached through cft_supports
(op_group_bit, device.c:95-118). docs/INTEGRATION.md:232-233 says cft_get_caps publishes "the formats and
opcode groups" (I report it). docs/HOSTAPI.md:1864-1866 says cft_get_caps "reports ... the server's device
for the format mask, opcode groups, tile count, ..." - believed the same slip; for the HOSTAPI auditor.
facts.md gaps (measured): the "top-level make targets" row misses `cycles krnlfused krnlplain simmc`
(one multi-target rule, Makefile:202, which the row's grep cannot match); the "host tools in all" row lists
cft-resident, which `all` builds only under XRT=1 (host/Makefile:225-235), and omits the `vector-fma`
example that `all` always builds (`$(EXAMPLES)`, host/Makefile:168,180).
For: C1 (HOSTAPI), the lead; anyone quoting the make-target or `all` lists.
