# audit-H (bindings/wasm/README.md, bindings/node/README.md, bindings/python/README.md)

## 09:39 - four shared binding facts: the published set's per-family counts; cftmpfr's decimal route; node cannot name REDUCE_SEG; the wasm build's 15 sources

Measured:
- Per-family case counts of the published 1,068,915 (counted in vectors/out, which holds make-vectors output: 168 files):
  opcode 236,000 (20 x 11,800 - make_page.py:17-20,50-55, LINES_PER_SET = 11800, STRIDE = 59 since opcode 31 became
  MAXALL), transcendental 533,265, augmented 89,616, reduction **10,240** (maxall added 1,280; VALIDATION.md:11717-11718),
  character 13,816, minmaxmag 9,728, formatof 176,250. The page's own prose, bindings/wasm/page_template.html:154-161,
  still gives "240,000 over twenty opcode sets" and "8,960 over twenty reduction sets" - which sum to 1,071,635, not the
  1,068,915 it heads with (a build product/template: out of scope for edits, but anyone quoting per-family counts beware).
  The embedded sample is still 4,015 cases, stride 59 (conformance.html build block); reserved codes left: 15 and 255.
- cftmpfr (bindings/python): Context.from_str / ctx("1.5") rounds through the LIBRARY (cft_from_decimal_char) since the
  0.6 step, needs no gmpy2 and works under RNDNA (core.py:636-667; test_cftmpfr.py:640-647, 656-659). Float.to_str is
  still gmpy2's digits (core.py:262-280, ). So docs/COMPATIBILITY.md:349
  "from_str/to_str now go through the library's own conversions" is wrong for to_str, and COMPATIBILITY.md:605
  "cftmpfr ... carries no reduction entry point" is wrong as worded - batch.tree_sum/tree_dot/tree_sumsq/tree_sumabs and
  the scaled products exist (batch.py:559-611); what it lacks is reduce_seg. I report the python and node READMEs' side.
- bindings/node cannot name seq_features bit 12: SEQ_FEATURE_NAMES (lib.mjs:176-183) has no CFT_FEAT_REDUCE_SEG (0x1000,
  CAPS2[8], cft.h:665), so a CAPS2[8] tile prints "bit12"; test.mjs:130's header regex is
  CFT_SEQ_FEAT_\w+|CFT_ALU_EXT_\w+, which cannot see a CFT_FEAT_* name, so the "every bit cft.h defines" test is green.
- The wasm build compiles host/Makefile's SRC, now FIFTEEN sources (host/Makefile:57-60: + sha256.c, backend_remote.c).
Believed: C2's 09:25 note (remote.mjs has no REDUCE_SEG) matches what I read (remote.mjs:73-94).
For: B1 (COMPATIBILITY), C1 (HOSTAPI, CAPS2/seq_features), anyone quoting per-family vector counts; the lead.

(Correction to the 09:39 entry, line 15: a shell ate the quoted call. It reads "core.py:262-280, which calls
_require_gmpy2("decimal-string conversion") and then to_mpfr().digits(10)".)
