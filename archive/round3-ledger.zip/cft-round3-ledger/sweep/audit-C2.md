# audit-C2 (docs/REMOTE.md, docs/EMBEDDED.md, bindings/arduino/cft-arduino/README.md, keywords.txt)

## 09:25 - addendum to B1's maxall entry: the streamed maxall is XRT-only; a REMOTE handle still halves with RUN frames

Measured: host/src/device.c:2253-2276 - the one-pass cftx_reduce_seg branch is inside #ifdef CFT_ENABLE_XRT and needs
dev->backend == CFT_BACKEND_XRT; every other backend (software, remote) falls to the halving at :2293-2311, which is
cft_run(CFT_MAX) per pass - on a remote handle one RUN frame (chunked) per pass, composed on the CLIENT, so the server
never sees opcode 31 even when it fronts a CAPS2[8] tile. REMOTE.md's "what crosses the wire" table has no maxall row (I report it).
Also measured: the remote protocol has 22 opcodes (host/src/remote.h:56-119, REDUCE_SEG 0x0012 since ABI 0.13); the
JavaScript client (bindings/wasm/remote.mjs, no REDUCE_SEG/0x0012) and the Arduino client (src/remote/cft_remote.h:120-142,
21 opcodes) do not speak REDUCE_SEG.
Believed: a doc saying "maxall is one pass on a CAPS2[8] device" without naming the XRT backend over-states it for remote.
For: B1, the HOSTAPI / CAPABILITIES / bindings-wasm auditors; the lead.
