# triage-F2 (round 2: ENCLOSE, COLLATZ, DEMOS, BENCHMARKS observations)

## 11:35 - the zoom pixel batch fills SEVEN broadcast arrays an iteration, not six: DEMOS.md:724-726 and HOSTAPI.md:1823 both say 6,144 stores

Measured: host/tools/zoom.c:1627-1633 and bindings/wasm/demos_core.js:1494-1496 each call dfill seven times per
iteration (bA, bB, bnB, bZr, bZi, bGT, bK - the last is k+1); the same seven at 3970efe, when the DEMOS sentence was
written (git show 3970efe:bindings/wasm/demos_core.js, :host/tools/zoom.c). The page's zoom batch is 1,024
(demos_core.js:2848, ZOOM_BASE), so 7 x 1,024 = 7,168. Findings R2-F2-01 (DEMOS.md:724-726, live) and R2-F2-02
(HOSTAPI.md:1823, "in the demos that was 6,144 JavaScript stores per pixel") propose 7,168.
Believed: docs/studies/OPT-D-contract.md:113/:310 and VALIDATION.md:10809 repeat 6,144; both are records, left alone.
For: C1 (HOSTAPI.md) and the lead - one edit per line, do not double-edit HOSTAPI.md:1823.

## 11:35 - CORRECTION to the entry above: the zoom.c lines are 1628-1634, not 1627-1633

Measured: grep -n 'dfill(P->b' host/tools/zoom.c gives bA at 1628 through bK at 1634. Nothing else changes.
For: C1, the lead.
