# triage-G (round 2: BITSTREAM-BUILDS, CARDDAY, BRINGUP, hw/openxc7/README, hopf/README observations)

## 11:37 - the "+0.055 routed WNS" of every closing pre-sequencer U50 build is the SHELL's; three docs derive "implied path delay" from it

Measured: docs/VALIDATION.md:13833-13837 (2026-09-23): the first sweep's 115 / 145 MHz "WNS 0.036 / 0.055" are
whole-design; the kernel clock in the same reports had +0.409 and +0.084 (175: -0.562, kernel = whole).
hw/rebuild-2022.sh:381-383: the 130 and 145 MHz singles "BOTH reported exactly 0.055 ns" - the shell's transceiver
path - while the kernel had 0.137 and 0.116. Worktree docs/BRINGUP.md:628-629 and :635-637 ("It also explains why
every closing build lands ~50 ps above zero, which was first misread here as the shell eating all the margin") -
finding R2-G-02 (lead decision). The same shell-based numbers: docs/ARCHITECTURE.md:602-608 (145 MHz +0.055 ->
6.842 ns; 130 MHz +0.055 -> 7.637 ns, where BRINGUP.md:516 gives 53bbba7's kernel +0.137), docs/ROADMAP.md:229-237
("the 145 MHz run reports 6.842 ns"). The 159 MHz figure is unaffected (it comes from the 175 row).
Believed: docs/studies/OPT-C-timing.md:838-841 took its 0.478 slope from the same 6.842 (a record, left alone).
For: whoever triages ARCHITECTURE.md (B2) and ROADMAP.md, and the lead's clock pass.
