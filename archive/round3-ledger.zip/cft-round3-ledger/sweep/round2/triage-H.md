# triage-H (round 2: bindings/wasm, bindings/node, bindings/python README observations)

## 11:38 - the software backend publishes neither SCALAR (0x800) nor REDUCE_SEG (0x1000); node README:398's seqFeatureNames example lists SCALAR

Measured: `Context.open('binary64')` through worktree bindings/node/index.mjs (the committed cft_node.wasm, the only
backend the node package opens - core.mjs:550-555, README:821-822) reports backend "software", seq_features 0x271f,
names ["kx","REGS32","BANK_PTR","KX9","IMUL","SCRATCH","SCRATCH_IO","SCRATCH_STRICT","INDEXED"]. HEAD's
host/src/program.c:553-570 (cft_sw_seq_caps) adds LANE_MASK (0x671f) and still omits CFT_SEQ_FEAT_SCALAR and
CFT_FEAT_REDUCE_SEG. Worktree bindings/node/README.md:398-400 shows ctx.seqFeatureNames returning a list with
"SCALAR" in it - finding R2-H-01 (lead decision on the form).
Believed: docs/BITSTREAM-BUILDS.md:242 "`cft_sft_seq_caps` carries every feature the contract defines" (and the
program.c:548 comment) is loose for the same reason; not checked against device-test's branches.
For: G (BITSTREAM-BUILDS.md) and the lead.

## 11:38 - COMPATIBILITY.md:349's 0.6 row says to_str goes through the library; it never did (gmpy2 digits since 1dd035d)

Measured: git show 9d53337:bindings/python/cftmpfr/core.py (the 0.6 step) to_str = self.to_mpfr().digits(10) behind
_require_gmpy2; unchanged at HEAD (core.py:262-279). Worktree docs/COMPATIBILITY.md:349 "`from_str`/`to_str` now
go through the library's own conversions" (written e3e6267, 2026-09-03) - finding R2-H-04 (lead decision: a dated row
that was false when written). bindings/python/README.md:238 already says it right (H-23).
For: whoever triages COMPATIBILITY.md (A2 touches :44) and the lead - do not double-edit :349.

## 11:38 - CORRECTION to the first entry above: the quote is "`cft_sw_seq_caps` carries every feature the contract", not "cft_sft_seq_caps"

Measured: worktree docs/BITSTREAM-BUILDS.md:242. Nothing else changes.
For: G, the lead.
