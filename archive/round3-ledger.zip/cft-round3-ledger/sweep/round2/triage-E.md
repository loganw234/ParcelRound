# triage-E (round 2: docs/PLATFORMS.md observations)

## 11:32 - ARCHITECTURE.md:905-906 still says "the routed design reports **262**"; the round-2 single reports 311 (262 is the ladder alone)

Measured: worktree docs/ARCHITECTURE.md:903-906 "... predates the seed ROM becoming case tables; the routed design reports
/ **262**:" (blame 552daa78, 2026-09-10; untouched by 080fe30). docs/VALIDATION.md:12808 (2026-09-16 table: single 311
DSPs, quad 1,232) and :13720-13727 (2026-09-23 correction: 311 = the ladder's 262 + the integer multiply's 45 + 4; the
quad is four tiles of 307 + the same 4). The 262 was routed at 046adae (ARCHITECTURE.md:797), which git orders before
4e8dfff, the multiply's commit. Finding R2-E-03 proposes "the routed design's FMA ladder reports / **262** (the round-2
single-tile image reports 311 in all ...)", in J-10's form (NOVEL.md:139-142, lead-accepted).
Also measured: SCALING.md:282-288 (D1-03) and PLATFORMS.md:22 (E-09) are already fixed in the worktree.
Believed: ARCHITECTURE.md:932 ("a tile's 262 DSPs would have been 31% ...") is counterfactual and left alone.
For: whoever triages ARCHITECTURE.md (B2) and the lead - do not double-edit ARCHITECTURE.md:905-906.
