# triage-A2 (round 2: VERIFICATION, verify/README, formal/README, CONFORMANCE, COMPLIANCE, host/fuzz/README observations)

## 11:33 - COMPATIBILITY.md:44 lists the pyxrt card host vector_fma.py as the "Python (ctypes)" example; the wasm lane's page count differs at the runner's counts

Measured: host/examples/vector_fma.py:3-16 is "Minimal pyxrt host" checked against the golden model (no libcft, no
checksum); the ctypes identity example is host/examples/vector_fma_ctypes.py. Finding R2-A2-03 proposes the Path cell
"`host/examples/vector_fma_ctypes.py`" (COMPATIBILITY.md:5-7 is already fixed in the worktree).
Also measured: the wrapper families' sizes (--transcend .. --formatof, vectors/gen_vectors.py:748-765) are passed by
neither `make vectors` (Makefile:117-121) nor the runner (verify/run.sh:471-474), so the 832,915 cases over 148 sets
through verify.mjs's wrappers are the same in both; only the 20 elementwise sets grow, so the page's-bytes replay is
1,068,915 on `make vectors`' sets and 1,224,915 (VALIDATION.md:13322) after the runner's vectors stage. Finding
R2-A2-02 qualifies VERIFICATION.md:185 that way.
Believed: no other live doc names vector_fma.py as a ctypes example (git grep over *.md).
For: whoever triages COMPATIBILITY.md, and the lead - do not double-edit COMPATIBILITY.md:44.
