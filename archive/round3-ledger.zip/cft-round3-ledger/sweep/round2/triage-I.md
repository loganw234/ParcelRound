# triage-I (round 2: docs/ROADMAP.md observations)

## 11:37 - the wasm program API reached JavaScript at ABI 0.8 (2026-09-07), not 0.9; HOSTAPI.md:1847 still says 0.9

Measured: 53f41e0 (2026-09-07 08:20, "116 cftw_* exports, five new") merged as ea621eb, whose host/include/cft.h has
CFT_ABI_VERSION_MINOR 8; docs/VALIDATION.md:5069 (2026-09-07 entry) says at :5089 "no ABI number moved";
docs/COMPATIBILITY.md:51 "the program API reached the page at 0.8"; docs/DEMOS.md:269 "since 2026-09-07". Worktree
docs/HOSTAPI.md:1847 "**DONE** - the program calls at ABI 0.9 and the last" - finding R2-I-06 proposes
"the program calls at ABI 0.8 (2026-09-07)". ROADMAP.md's copies (I-15, I-16) are already fixed in the worktree by date.
Believed: no other live doc says the program calls reached wasm at 0.9 (grep "program calls at ABI" over docs/*.md, README.md).
For: C1 (HOSTAPI.md) and the lead - do not double-edit HOSTAPI.md:1847.
