# triage-F1 (round 2: ZOOM, ORBITS, MERSENNE observations)

## 11:30 - SEQUENCER.md's zoom ask still says "no operand source that advances with the loop counter"; ZOOM.md (F1-08, lead-accepted) now qualifies it

Measured: worktree docs/SEQUENCER.md:983-984 "- the reference orbit's point - and there is no operand source that /
advances with the loop counter: ..." (blame a521cbd, 2026-09-04, untouched by 080fe30). docs/ZOOM.md:220-222 now
reads "There is no operand source shared by every lane that advances with the loop counter; revision 3's `LDX`
(2026-09-08) indexes only a lane's own scratch ...". SEQUENCER.md:576/1210 define `LDX rd, rb` = scratch[rb mod
SCRATCH_D], and :1216-1218 / :1373-1374 say rb is where the atlas emitter keeps its loop counters. Finding R2-F1-01
proposes "there is no operand source shared by every lane that" at SEQUENCER.md:983.
Also measured: line 983 begins "  - ", so CommonMark renders "the reference orbit's point - ..." as a nested bullet.
Believed: nothing else in SEQUENCER.md's asks list needs the same qualification.
For: B3 (SEQUENCER.md) and the lead - do not double-edit that line.
