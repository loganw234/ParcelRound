# triage-C1 (round 2: docs/HOSTAPI.md observations)

## 11:31 - cft_caps has NO opcode-group field; HOSTAPI's remote section still says cft_get_caps reports "opcode groups"

Measured: host/include/cft.h:455-564 (struct cft_caps: struct_size, format_mask, tiles, abi_version, device_version,
flags_readable, backend, max_deposits, max_insns, max_consts, seq_features, max_scratch, buffers_resident - no
groups field); host/src/device.c:1020-1060 (cft_get_caps never reads op_groups); device.c:60, :391 (remote open
stores the handshake's op_groups on the handle), :1089/:1102 (cft_supports reads them). Worktree
docs/HOSTAPI.md:1871-1873 "format mask, opcode groups, tile count, contract version and / `flags_readable`" -
finding R2-C1 (from CR-04). docs/INTEGRATION.md's equivalent (A1-13) is already fixed in the worktree;
docs/REMOTE.md:272-277 is correct (op_groups travels in the caps block, derived via cft_supports).
The code comment at host/include/cft.h:404-406 repeats the slip (out of scope).
Also measured, same paragraph family (HOSTAPI.md:1751-1757): the Fortran leg compares nothing (A2 09:30 has the
fact), and Python is diffed by `make -C host test` (host/Makefile:350-356), not by a `lang-*` leg - the lang-*
legs that diff are cpp, julia, rust, go, csharp, r (host/Makefile:404-464).
Believed: no other worktree doc says cft_get_caps reports opcode groups (grep "opcode groups" over docs/*.md,
README.md: only HOSTAPI.md:1413 (about cft_supports, fine), :1872, REMOTE.md:272-276).
For: the lead; anyone touching INTEGRATION/REMOTE/COMPATIBILITY example-diff text.
