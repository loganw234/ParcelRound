# audit-A2 (docs/VERIFICATION.md, verify/README.md, formal/README.md, CONFORMANCE.md, docs/COMPLIANCE.md, host/fuzz/README.md)

## 09:14 - `python python/check_docs_index.py` FAILS at HEAD 0321e8a (rc 1, 7 problems), so the runner's `docs` stage is red today

Measured (ran it): rc=1, "check_docs_index: 7 problem(s)":
  README.md says '39 gate stages' where the tree derives 40 stages
  docs/VERIFICATION.md says 'indexes the thirty-four documents' where the tree derives 37 documents
  docs/BENCHMARKS.md:434 `docs/CFT-SILICON.md` quoted, not in the repository
  docs/COMPATIBILITY.md:541 `docs/HARDWARE.md` quoted, not in the repository
  docs/HOSTAPI.md:2015 and docs/LAYOUTS.md:154 `docs/BITSTREAM.md` quoted, not in the repository
  host/tests/photograph/hopf/README.md:58 `docs/CFT-PHOTOGRAPH.md` quoted, not in the repository
Believed: the four "not in the repository" hits may be cross-repo mentions (see audit-B2 09:12 on BITSTREAM.md) - but the
checker still counts them, so whatever the lead decides, the checker must end at rc 0 or the quick budget's first stage fails.
facts.md cites this script as a source for the 40/27/35 counts; it does print those correctly - it is the doc-count and
quoted-path checks that fail.
For: the lead; the README, BENCHMARKS, COMPATIBILITY, HOSTAPI, LAYOUTS auditors; anyone stating the docs count (37, not 34).

## 09:22 - CORRECTION to 09:14: at HEAD the checker PASSES; the 7 problems come from an UNCOMMITTED, in-progress check_docs_index.py

Measured: `git status --porcelain` now shows ` M Makefile`, ` M python/check_docs_index.py`, ` M verify/run.sh`
(mtimes 09:15-09:17 today; someone is widening the docs gate - the run.sh diff only rewrites the `docs` stage's
description, the Makefile diff only the docs-check help text). `git show HEAD:python/check_docs_index.py`, run
against the tree: rc 0, "37 documents, 40 links, every count true; stage counts agree: 40 total, 27 quick, 35 gate".
So the 7 problems in my 09:14 entry are what the NEW checker will report once it lands - still real doc defects
(VERIFICATION says "thirty-four documents"; docs/README.md indexes 37; README's "39 gate stages"), but the `docs`
stage at HEAD is green. Auditors: the tree is no longer clean vs 0321e8a; verify/run.sh's stage logic is unchanged.
For: the lead; anyone who ran check_docs_index.py after 09:15 and took its output as HEAD's.

(The entry above headed 09:22 was written at 09:21 by `date +%H:%M`; the header time was typed, not taken - read it as 09:21.)

## 09:30 - two shared facts: the runner's `vectors` stage does NOT write the published 1,068,915-case set; the Fortran example is NOT in the checksum diff

Measured:
- verify/run.sh:472-474 runs `gen_vectors.py --out vectors/out --rounding rne rtz rdn rup rmm` with NO counts, so it
  takes gen_vectors.py's defaults (:744-746: --directed 4000 --random 6000 --simple 400), where `make vectors`
  (Makefile:117-121) passes 3000 / 4000 / 200. Same 168 files, different case count: the published 1,068,915 comes from
  `make vectors`; after a runner `vectors` stage, vectors/out holds the larger pools (1,224,915 on the card 2026-09-15..18,
  VALIDATION.md:13322; verify/README.md:55 "1.2M cases at the runner's generator counts"; CARDDAY.md:431 says the same).
  So a live sentence that the runner's `libcft`/`cpp`/`wasm`/`node` stages replay "the 1,068,915-case" set is wrong
  about the runner (VERIFICATION.md:166 is one - I report it).
- host/Makefile:367-369 `fortran:` builds and RUNS examples/vector_fma.f90 - no diff against .out-c.txt; the example
  prints decimals and flags (vector_fma.f90:95-98), no FNV-1a line; docs/COMPATIBILITY.md:32-35 says it is "the one
  example NOT in the checksum diff". CONFORMANCE.md:230-232 ("Every binding and language example ... prints one FNV-1a
  checksum line per format") and VERIFICATION.md:110-111 ("one example per language diffed") contradict it (I report both).
Believed: README / INTEGRATION / bindings READMEs may say "every language example prints the same four checksums".
For: README, INTEGRATION, CARDDAY, COMPATIBILITY, bindings auditors; the lead.
