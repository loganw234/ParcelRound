# audit-B3 (docs/SEQUENCER.md, docs/PROGRAMS.md, programs/README.md)

## 09:21 - facts.md's "CAPS2 feature bits" row mixes two registers and omits IMUL

Measured: host/include/cft.h:577-709 - WIDE_CONST 0x01, REGS32 0x02, BANK_PTR 0x04, KX9 0x08 are CAPS[4..7]
(cft_caps.seq_features bits 3:0), not CAPS2; CFT_ALU_EXT_IMUL 0x10 (CAPS[28], cft.h:611) is a seq_features bit the
row leaves out (its grep 'CFT_.*FEAT_' cannot see it). The hardware CAPS2 word (rtl/cft_krnl.sv:560-590) is
[3:0] log2 SCRATCH_D, [4] SCRATCH, [5] SCRATCH_IO, [6] SCRATCH_STRICT, [7] SCALAR, [8] REDUCE_SEG, [9] INDEXED,
[10] LANE_MASK; seq_features bit 8+k mirrors CAPS2[4+k].
Believed: nobody's finding hinges on it, but a doc that says "CAPS2[0] is WIDE_CONST" would be wrong and one that
lists seq_features without IMUL would be incomplete.
For: anyone checking CAPS/CAPS2/seq_features (HOSTAPI, ARCHITECTURE, REGISTERS-type docs); the lead.

## 09:21 - the sequencer's reads are steered to A, B or C by buffer; ARCHITECTURE.md:126 still says it "borrows the A and D masters"

Measured: rtl/cft_seq.sv:298-321 (m_rd_sel: 0 = image and A operand, 1 = B, 2 = C), cft_seq.sv:2791 (dense stream
loads: rd_sel <= ld_reg), cft_seq.sv:2917 (a GATHERED element: rd_sel <= gt_scr ? 0 : ld_reg - the stream's own
master; only the index table, cft_seq.sv:2855, and the scratch pool ride A), rtl/cft_krnl.sv:677-679.
docs/ARCHITECTURE.md:126-129 (live bullet): "It borrows the A and D masters from the streaming engine ... benched
bit-exact against it, hw_emu and silicon still ahead" - both halves stale. SEQUENCER.md:1741-1742 (R16) says the
gathered elements come "through the A master" (I report that one).
Believed: docs/ROADMAP.md:510 is a dated history entry (VERSION 0x600, 9/9 suites) and stays.
For: B2 (ARCHITECTURE.md); anyone whose doc describes the sequencer's masters.
