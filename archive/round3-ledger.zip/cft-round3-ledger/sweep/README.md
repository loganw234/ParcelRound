# The docs-sweep ledger (cft-fp256, 2026-09-24)

Scaffolding for one audit round, not history. Outside the repository;
the lead folds anything durable into the repo's own records at the end
and throws this away. From ParcelRound's templates/ledger.md.

A brief is written once and cannot be updated. This directory is the
only way one auditor's discovery reaches another while both are working,
and the only way the lead can correct a brief after dispatch.

**One file per author, append only.** Yours is `<your-label>.md` (the
label in your brief, e.g. `audit-A1.md`, `verify-A1-0.md`). Read every
file; write only your own; never edit an entry, append a correction
beneath it.

**Read at three moments:** before starting; before you conclude that a
claim in your files is wrong because of something outside them; before
you return your final result. Always read `urgent/` at those moments
too - it is the lead's channel.

**Write when it clears the bar:** would it change another auditor's
work? Three things do: (1) a fact on facts.md that is wrong, or missing
and cross-cutting (a count, a path, a name that several documents
state); (2) a finding about a SHARED fact - "ARCHITECTURE says X, the
code says Y, and SEQUENCER/HOSTAPI state X too"; (3) an environment
fact (a file that is not where the docs say, a command that does not
work on this desktop). Do not write progress.

**Mark what you measured.** Every entry says which claims were measured
(you ran the command or read the source line) and which are believed.

Entry format:

    ## <HH:MM from `date +%H:%M`> - <one-line headline>

    Measured: ...
    Believed: ...
    For: <which auditors / documents, or "anyone">

Take the time from `date +%H:%M`; never type a guessed one.
