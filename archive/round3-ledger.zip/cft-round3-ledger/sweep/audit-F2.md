# audit-F2 (docs/ENCLOSE.md, docs/COLLATZ.md, docs/DEMOS.md, docs/BENCHMARKS.md)

## 09:43 - four shared facts: the committed demos page/module bytes; segtime.py is not in the tree; make cycles' live figure; collatz-fp256 ran on the card

Measured:
- The committed demos page and module (git show HEAD:<path> | wc -c / sha256sum, = working tree): demos.html 574,656 bytes
  sha256 3c412c0a000d765a...; cft_node.wasm 256,485 bytes sha256 81f34e1263c9966587...; demos_chains.json "recorded"
  2026-09-15, module_sha256 81f34e12..., last changed b558a56 (2026-09-15, ABI 0.14). docs/DEMOS.md:22-27 and :517-518
  still give 539,646 / b78d6a6d... / 225,354 / 29cce150... / 2026-09-09 / ABI 0.11 (I report them).
  bindings/wasm/README.md:925-927 carries the same old values under "What is committed today" - inside its dated
  2026-09-09 block, with the 0.14 block below naming 81f34e12; H's call whether that header reads live.
-  is not in the repository and never was (git ls-files; git log --all -S'segtime' finds only doc/VALIDATION
  commits). BENCHMARKS.md:377-381 says it is "checked into host/tools/" (I report it, lead decision: commit it or reword).
  Code comments naming it as a sibling: host/tools/gathertime.py:10, host/tools/segsat.py:13 (out of scope).
- /usr/bin/make -C tb cycles SIM=icarus
make[1]: Entering directory '/c/Users/logan/source/repos/cft-fp256/tb'
CFT_RD_LATENCY=0 CFT_WR_LATENCY=0 /usr/bin/make -f cocotb.mk SIM=icarus TOPLEVEL=cft_krnl \
	MODULE=test_krnl_cycles \
	SIM_BUILD=sim_build/cycles0_0 \
	COCOTB_RESULTS_FILE=sim_build/cycles0_0/results.xml \
	&& python3 check_results.py sim_build/cycles0_0/results.xml
make[2]: Entering directory '/c/Users/logan/source/repos/cft-fp256/tb'
make[2]: Leaving directory '/c/Users/logan/source/repos/cft-fp256/tb'
make[1]: Leaving directory '/c/Users/logan/source/repos/cft-fp256/tb': 1.125 cycles a beat, 40 fixed at zero latency since the 2026-09-09 read-ahead (VALIDATION.md:8755-8761);
  E is right. My judgement for BENCHMARKS: :16-17 (the intro, live) is stale and I report it with :19's "2.25 cycles a
  beat" (the card has done 1.26-1.34 since the read-ahead, VALIDATION.md:9663-9666); :159-161 sits inside the dated
  "The engine, measured (2026-09-09)" revision-3 section, whose own read-ahead paragraph says 120 - history, not reported.
- programs/collatz-fp256.cfta "IS the image the tool loads" at the default K (programs/README.md:117) and ran on the
  revision-3 single and quad, bit-identical to software (VALIDATION.md:8479-8481, 8509). So COLLATZ.md:647 "No device has
  run it" is stale in part (I report it). No cft-enclose program ever ran on a device (horner-bank-fp64 is a different
  program; programs/README.md:121), so ENCLOSE.md's "no device has run this" stands.
Believed: nothing else in docs/ outside VALIDATION quotes the demos page's bytes.
For: H (bindings/wasm/README), E, F1, the lead.

## 09:45 - CORRECTION to the entry above: my shell expanded its backticks (two bullets are garbled); the clean text

(Environment note: the unquoted heredoc that wrote the entry above ran `make cycles` as a command substitution
from the repo root; it died at once - "cocotb-config: No such file or directory", Error 2 - and created nothing
(`find . -newermt '2026-09-24 09:40'` outside .git is empty; tb/sim_build/cycles0_0 does not exist). No simulator ran.)

Measured, the two garbled bullets restated:
- `segtime.py` is not in the repository and never was (git ls-files; `git log --all -S'segtime'` finds only
  doc/VALIDATION commits). BENCHMARKS.md:377-381 says it is "checked into host/tools/" (I report it, lead decision:
  commit it or reword). Code comments naming it: host/tools/gathertime.py:10, host/tools/segsat.py:13 (out of scope).
- `make cycles` measures 1.125 cycles a beat, 40 fixed at zero latency, since the 2026-09-09 read-ahead
  (VALIDATION.md:8755-8761); audit-E is right. BENCHMARKS.md:16-17 (the intro, live) is stale and I report it with :19's
  "2.25 cycles a beat" (1.26-1.34 on the card since the read-ahead, VALIDATION.md:9663-9666); :159-161 is inside the dated
  "The engine, measured (2026-09-09)" revision-3 section, whose own read-ahead paragraph says 120 - history, not reported.
The other two bullets above (the demos page/module bytes; collatz-fp256 on the card) read correctly.
For: E, H, F1, the lead.
