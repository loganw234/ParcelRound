# audit-E (docs/PLATFORMS.md)

## 09:22 - `make cycles` measures 1.125 cycles a beat since 2026-09-09, not 1.250; the engine's FIFOs are 512 beats, not 128

Measured: docs/VALIDATION.md:8755-8761 ("After: flat at 1.1250 ... | 0 | 0 | **1.1250** | 40 |",
34c23ff, 2026-09-09) and VALIDATION.md:9156-9160, which itself names docs/PLATFORMS.md, docs/SCALING.md
and docs/studies/OPT-B-array.md as quoting a stale 1.250. rtl/cft_krnl.sv:140 `FIFO_LOG2 = 9`, passed to
the engine at :782; rtl/cft_engine_stream.sv:416 `FDEPTH = 1 << FIFO_LOG2` -> 512-beat stream FIFOs.
`make cycles` still exists (Makefile:202 -> tb/Makefile:515, test_krnl_cycles).
Believed: docs/BENCHMARKS.md:16,159-160 and docs/ARCHITECTURE.md:489,526 also quote 1.250 from `make
cycles`; some may be dated context - their auditors should judge. The 13.82 GB/s per-tile demand that
PLATFORMS derives everywhere rests on 1.250 at 135 MHz.
For: SCALING, BENCHMARKS, ARCHITECTURE auditors; the lead.

## 09:22 - DSPs per tile: 307 on the round-2 U50 pair, not 292/277 or "262 a tile, quad 1,048"

Measured: VALIDATION.md:12808-12809 (2026-09-16: single 311 DSPs, quad 1,232) and its correction at
VALIDATION.md:13720-13727 (single 311 = ladder 262 + integer multiply 45 + 4; quad 1,232 = four tiles of
307 + the same 4). On the K325T after 6a2b26c: 286 (VALIDATION.md:13690-13691). openXC7's Yosys: 120 in
the board configuration (13454), 506 for the full tile ladders off (13708).
Believed: docs/SCALING.md:279-284 ("292 per tile ... the routed design reports 262 a tile ... the real
quad is 1,048 and 17.6%") is stale on the same fact; PLATFORMS' yardstick cites SCALING for 292/277.
For: SCALING, ARCHITECTURE, LAYOUTS auditors.

## 09:22 - the quad's 135 MHz margin is +0.040 ns (directive rebuild, 2026-09-16), not +0.143

Measured: VALIDATION.md:12789 (round-2 quad kernel WNS +0.040 on the directive rebuild; the default
directives missed at -0.363, :12748). +0.143 is 9f73107's quad (LAYOUTS.md:42, SCALING.md:141), dated.
Believed: any live "closes at 135 with +0.143" elsewhere is the same stale claim (PLATFORMS has two).
For: LAYOUTS, SCALING, README auditors.

## 09:22 - facts.md's top-level make target list misses four targets

Measured: Makefile:202 `cycles krnlfused krnlplain simmc:` - one rule line naming four targets, which
facts.md's own regex `^[a-z][a-z0-9_-]*:` cannot match (it stops at the space). It is the only
multi-target rule line in the top-level Makefile.
For: the lead; anyone checking a "complete" list of make targets.
