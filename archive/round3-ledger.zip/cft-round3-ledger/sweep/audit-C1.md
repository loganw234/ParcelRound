# audit-C1 (docs/HOSTAPI.md)

## 09:25 - five shared host-API facts other docs may state stale (addressable constants, resident roles, CAPS[15:8], the 0.14 refusals, device-test's count)

Measured (read the source lines):
- `max_consts` is 512 on BOTH the software backend and the tile, not 256: host/src/program.c:103
  `SEQ_ADDR_CONSTS 512u` (what cft_sw_seq_caps publishes, :542), rtl/cft_krnl.sv:355 `SEQ_KMEM_D = 512`,
  :368 `SEQ_KIDX_W = 9`. 256 was true 2026-09-07 until KX9 (revision 3). The software backend also publishes
  every feature bit (program.c:553-570), not "both". HOSTAPI.md:1960 and :1974-1975 still say 256 / "both".
- On XRT, `cft_program_run_ex` BINDS (resident where the pointer is a cft_alloc buffer) a, b, c, deposits, the two
  scratch blocks AND the four index tables (host/src/device.c:641-694); only the image, bank, counts and lane mask
  are staged. Text saying the scratch blocks are staged is stale (HOSTAPI.md:332-335; header comment cft.h:2128-2130).
- CAPS[15:8] opcode groups: [13] reduction, [14] divide/sqrt seeds, [15] the SEQUENCER (was "conversion - reserved")
  - rtl/cft_krnl.sv:495-519, host/src/device.c:100-125. "reserved bits for reduction, divide/sqrt and conversion"
  is stale (HOSTAPI.md:1787-1788; RTL comment cft_csr.sv:82 still labels [14] "reserved").
- The ABI 0.14 fields are refused by NO backend for being unbuilt any more: grep of host/src for a refusal naming a
  parcel finds none; a device lacking the feature is refused naming CAPS2[9]/[10] (device.c:606-629, :1750).
  Stale comments saying otherwise: cft.h:112, cft.h:2446-2450, program.c:1884-1889, backend.h:268-270.
- `device-test` takes the element count as `-n N` only; a second positional argument is a usage error (exit 2):
  host/tests/device_test.c:5713-5752. So `run-device-test.sh <xclbin> 64` and `./device-test <xclbin> 256`
  (HOSTAPI.md:356; host/Makefile:332 comment) do not run. Other runbooks may carry the same form.
Believed: CARDDAY/BRINGUP/INTEGRATION/SEQUENCER may repeat any of these; not checked.
For: SEQUENCER, ARCHITECTURE, CARDDAY/BRINGUP, INTEGRATION, BENCHMARKS auditors; the lead.
