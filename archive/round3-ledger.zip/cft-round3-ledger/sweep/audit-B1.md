# audit-B1 (docs/DETERMINISM.md, docs/COMPATIBILITY.md, CAPABILITIES.md)

## 09:22 - three shared facts other docs may state stale: maxall streams on a CAPS2[8] tile; cft_div/cft_sqrt on a device are ONE program; CI runs the language legs on every push

Measured:
- maxall: host/src/device.c:2248-2268 - on the XRT backend with CFT_FEAT_REDUCE_SEG, cft_reduce(CFT_MAXALL) is one
  cftx_reduce_seg call (a streamed pass), not ceil(log2 n) halvings; rtl/cft_engine_stream.sv:556
  cfg_is_reduce = (cfg_op == 8'd24) || (cfg_op == 8'd31). So "maxall is composed, ceil(log2 n) passes on the tile",
  "no tile streams it" and "cfg_is_reduce is (cfg_op == 8'd24)" are stale as live claims (they were true at ABI 0.12,
  2026-09-12). I report CAPABILITIES.md:153. docs/ROADMAP.md:2643-2647 says the same in what may be a dated section.
  Code comments carrying it (out of scope): host/include/cft.h:309-311 ("no tile streams it"), host/src/device.c:2218-2226.
- cft_div/cft_sqrt: host/src/divsqrt.c:826-831 and 1347-1366 - any device backend (XRT or remote) takes the
  sequencer-program route, one program per call "instead of ~28"; the software backend keeps the chunk route. So
  "cft_div ... ~25-30 passes per call" is stale for a device. I report CAPABILITIES.md:242.
- CI: .github/workflows/gates.yml:18 (on: [push, pull_request]) and :99 - the host job runs verify/run.sh --require-all
  over libcft, bindings, cpp, lang-cpp, lang-rust, lang-go, lang-csharp, lang-fortran, node, wasm (not julia, not R).
  I report COMPATIBILITY.md:19 ("Nothing here is checked in CI's default lane").
Believed: README/HOSTAPI/INTEGRATION may state the ~25-30-pass price of a division as current; not checked.
For: the ROADMAP, HOSTAPI, README, INTEGRATION and BENCHMARKS auditors; the lead.
