# audit-B2 (docs/ARCHITECTURE.md, docs/LAYOUTS.md)

## 09:12 - "docs/BITSTREAM.md" in this repo's docs is cft-rebound's file, and it exists; not a broken reference

Measured: every mention outside VALIDATION (`grep -rn BITSTREAM\.md`) is
possessive - LAYOUTS.md:46 "its docs/BITSTREAM.md, ask 5", LAYOUTS.md:154
"`docs/BITSTREAM.md` there", HOSTAPI.md:2015 "its `docs/BITSTREAM.md`, ask 3",
plus code comments (rtl/cft_krnl.sv:54 says "cft-rebound's docs/BITSTREAM.md").
C:\Users\logan\source\repos\cft-rebound\docs\BITSTREAM.md exists; its section
"What it asked of cft-fp256" (line 401) numbers seven asks: 3 = "A format
refusal carries no sentence", 5 = "fp32 has no generic" - matching both uses.
Believed: the lead's premise ("quotes docs/BITSTREAM.md, which does not exist")
is false for LAYOUTS and HOSTAPI; nothing to fix unless the lead wants the
owner named explicitly ("cft-rebound's docs/BITSTREAM.md").
For: the HOSTAPI auditor, the lead.

## 09:25 - ABI 0.14's MODE bits are LIVE on this build: CAPS2[9] and [10] are set, the reserved range is MODE[31:24], and 0x88..0xA8 are read

Measured: rtl/cft_krnl.sv:299-300 `FEAT_INDEXED = 1'b1; FEAT_LANE_MASK = 1'b1`, published at :550 and :558 as
CAPS2[10] and [9]; rtl/cft_csr.sv:506-510 `cfg_mode_bad = (mode_q[31:24] != 0) || (mode_q[23] && !feat_lane_mask)
|| (|mode_q[22:19] && !feat_indexed) || (|mode_q[18:16] && !feat_scalar)`; the sequencer reads the tables and the
mask through the A master (rtl/cft_seq.sv:2603, 2855), P1 89c0dc4 and P3 429e0ce (2026-09-15). So a LIVE sentence
saying "MODE[31:19] reserved, must be zero", "CAPS2[9]/[10] zero", "nothing reads 0x88..0xA8" is stale. Stale code
comments saying so too (out of scope): cft_krnl.sv:291-298, cft_csr.sv:386-389 and 445-455, cft_csr.sv:200 and 322
("[31:6] reserved" for CAPS2). I report ARCHITECTURE.md:254, 268, 273.
Believed: COMPATIBILITY.md:629 and ROUND2.md:227 describe the P0 seam (dated); CARDDAY.md:85 describes an 0x800 image.
Also measured: STATUS is six bits - rtl/cft_csr.sv:689 `{26'b0, eng_err}`, eng_err[5] = the scratch range report
(cft_krnl.sv:485; cft.h:2227 CFT_STATUS_SCRATCH_RANGE). ARCHITECTURE.md's STATUS row and cft_csr.sv:128-165 list [0]..[4].
For: HOSTAPI, SEQUENCER, COMPATIBILITY, ROUND2, CARDDAY auditors; the lead.
