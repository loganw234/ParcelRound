# audit-D1 (docs/TRANSCENDENTALS.md, docs/SCALING.md, python/README.md)

## 09:21 - the sequencer has run on silicon since card day 2026-09-08; "silicon still ahead" is stale in SCALING.md:306 AND ARCHITECTURE.md:129

Measured: docs/VALIDATION.md:7235-7240 (2026-09-08, step 7) - cft-zoom's orbit "deposited by the sequencer 32 steps a call"
on the single and the quad, one hash; VALIDATION.md:11725-11740 (2026-09-14) - seq5 image program costs "measured on the
card" with fp32, fp64 and fp128 columns; VALIDATION.md:11309 (2026-09-14) the whole divide as a program on the card.
SCALING.md:305-306 says "with fp64 and wider, a bitstream and silicon still ahead of it"; ARCHITECTURE.md:129 says
"benched bit-exact against it, hw_emu and silicon still ahead." (grep -rn "silicon still ahead\|bitstream and silicon" docs).
Believed: nothing else in docs/ says it (that grep found only those two).
For: B2 (ARCHITECTURE.md), the SEQUENCER auditor, the lead.
