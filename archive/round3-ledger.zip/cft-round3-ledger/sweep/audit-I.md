# audit-I (docs/ROADMAP.md)

## 09:42 - `make seqcycles` is a tb/Makefile target only; from the repo root it does not exist

Measured: `grep -n "seqcycles" Makefile tb/Makefile` finds only tb/Makefile:600. The top-level Makefile forwards
exactly four tb targets (Makefile:202-204, `cycles krnlfused krnlplain simmc:`), with the comment at :197-199 that
forwarding is there so "the way the documents cite them ... is also the way you run them". seqcycles is not among
them, so `make seqcycles` typed at the root fails. Cited that way at docs/ROADMAP.md:2686 and :2926 (I report
them, lead decision: forward the target or write `make -C tb seqcycles`), docs/SEQUENCER.md:1688, :1774, :1853 and
docs/ROUND2.md:99, :581, :983 (ROUND2 below its Outcome box is a record).
Believed: nothing else in docs/ outside VALIDATION cites it (`grep -rn "make seqcycles" docs/*.md README.md`).
For: B3 (SEQUENCER.md), J (ROUND2), the lead.
