# audit-F1 (docs/ZOOM.md, docs/ORBITS.md, docs/MERSENNE.md)

## 09:20 - SHA-256 is the library's one copy (host/src/sha256.c) since c0effe9, 2026-09-08; only zoom.c still derives its own

Measured: `grep -n 'sha256.h' host/tools/*.c` - collatz.c:163, enclose.c:243, mersenne.c:164, orbits.c:264 all
`#include "../src/sha256.h"`; zoom.c has its own root_frac32/SHA_K (zoom.c:268-313). host/src/sha256.c:1-11 says
"Lifted verbatim from host/tools/collatz.c ... which those four now include instead"; created in c0effe9 (2026-09-08).
So "derived **in the tool**" is stale in COLLATZ.md:354, ORBITS.md:498 (also "exactly as host/tools/collatz.c derives
them"), MERSENNE.md:369, and ENCLOSE.md:487 ("the tool's derivation") if it means the tool's own code. ZOOM.md:447 is true.
Believed: facts.md could carry this as a shared fact.
For: the COLLATZ and ENCLOSE auditors; the lead.

## 09:20 - the card HAS run cft-zoom's reference orbit (2026-09-08 onward); "No device has run it" is stale in ZOOM.md only

Measured: docs/VALIDATION.md:7235-7236 (2026-09-08 card day, step 7): "cft-zoom, the reference orbit to 2,000 iterations,
32 steps a call - single 10 runs, one checkpoint hash, quad 10 runs, the same hash 51476c5d... - and the software backend,
same arguments, 51476c5d..."; again at :8493, :8514 (revision-3 pair) and :9716, :9725 (read-ahead pair, 2026-09-09).
No card run of cft-orbits or cft-mersenne found (grep of VALIDATION.md for the tool names).
Believed: VALIDATION.md:8480 lists "collatz, zoom-scan, ... horner-bank" among 18 library programs compared software
against the card - whoever audits COLLATZ.md:532/647 and ENCLOSE.md:823/844 ("no device has run this") should check
whether those are the tools' own programs.
For: the COLLATZ, ENCLOSE, BENCHMARKS auditors.

## 09:20 - revision 3 BUILT the "load more than three registers" ask; ORBITS.md still rests an obstacle on it

Measured: docs/SEQUENCER.md:940-947 marks "More input streams, or a way to load registers from the deposit buffer
(Collatz, orbits)" as "BUILT, revision 3, as R5's scratch block ... a program is entered at any state it can spell".
ORBITS.md:50-54, 291-294, 304-322, 347-350 (and orbits.c:2095-2106's refusal text) still say only three registers can
be loaded. Round 2 (ABI 0.14) also added index tables for the streams and the scratch block (cft.h:2477-2480).
Believed: COLLATZ.md's "only fits because the fourth is an output that always starts at +0" is the same pre-revision-3
framing; SEQUENCER.md:970-987 still lists the zoom broadcast and the Mersenne cross-lane asks as open, although LDX
(SEQUENCER.md:1198-1207) and idx_scratch_in may now reach part of them - a lead question, not measured.
For: the COLLATZ and SEQUENCER auditors; the lead.
