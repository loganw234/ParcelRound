# audit-J (docs/NOVEL.md, docs/ATLAS.md, docs/FUNDING.md, docs/ROUND2.md, docs/studies/*)

## 09:40 - three shared facts: the atlas parity harness HAS run (2026-09-18); IMUL's product is cft_imul's in the lanes since 6a2b26c; NOVEL's "routed design reports exactly 262" is E's DSP fact

Measured:
- docs/VALIDATION.md:13095-13150 (2026-09-18): a GPU's own record of every sample (hopf, 4 passes) matched bit for bit
  by the U50 single and quad and by libcft's software backend; the `photograph` stage holds it. atlas-engine's emitter
  target exists since 2026-09-08 (atlas-engine `git log -- core/emit-cft.mjs`: 2564a09 2026-09-08) and its
  `cft-detlib` branch (af5feda) is merged (`git merge-base --is-ancestor af5feda main` true). So CAPABILITIES.md:382-383
  "The parity harness against the GPU bits remains" and :296-298 "what is not done is the port itself" read stale
  (not mine - B1's file). I report ATLAS.md's own status lines (:305-306, :345-346, :356-357).
- rtl/cft_lanes.sv:434,497,553,605 instantiate cft_simpleops with .IMUL_EXT(1'b1); the product comes from rtl/cft_imul.sv,
  registered beside the lane (6a2b26c, 2026-09-23); cft_simpleops.sv:464 substitutes zero. A live sentence that IMUL
  "rides the precomputed-result sideband" in cft_simpleops is stale for the shipped lanes (ATLAS.md:107-110 is mine;
  `git grep -i sideband -- '*.md'` outside VALIDATION finds no other doc tying it to IMUL).
- docs/NOVEL.md:139 "The routed design reports **exactly 262**" - VALIDATION.md:13720-13727: the U50 single's routed DSPs
  are 311 (ladder 262 + IMUL 45 + 4). Same fact as audit-E 09:22. I report it (lead decision: the entry's checksum argument).
Also: ATLAS.md:31 says the atlas engine's hash holds across "four GPU vendors"; atlas-engine README.md:146-147 and
docs/DETERMINISM.md:534 say three (NVIDIA, AMD, Intel; FUNDING.md:6 and ROADMAP.md:3224 say three). I report ATLAS.
Believed: nothing else in docs/ repeats the four.
For: B1 (CAPABILITIES), B2/B3 (anyone describing where IMUL is computed), E, the lead.
