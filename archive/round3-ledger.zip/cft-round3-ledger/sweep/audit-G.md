# audit-G (docs/BITSTREAM-BUILDS.md, docs/CARDDAY.md, docs/BRINGUP.md, hw/openxc7/README.md, host/tests/photograph/hopf/README.md)

## 09:38 - A1's four BITSTREAM-BUILDS items confirmed and reported here; hopf's CFT-PHOTOGRAPH.md is atlas-engine's; two runbook facts left as history

Measured:
- A1 (09:25) is right on all four for BITSTREAM-BUILDS, and I report them against that file (A1 keeps CLAUDE.md):
  host/Makefile:75-87 + 205-206 (backend_xrt.o only under XRT=1; `ar rcs libcft.a $(OBJ)`), :674-701 (cft-zoom
  only via `zoomclean`), rebuild-2022.sh:19 (KERNEL_FREQ, not :17), five trap sections under "The four traps".
  The clean list in BITSTREAM-BUILDS:150-152 also omits cft-bench, cft-enclose, cft-mersenne, cft-resident,
  device-test and remote-test, all of which `clean` does remove (host/Makefile:240-242, 294-296, 737-739, 808-809, 860-878).
- `C:\Users\logan\source\repos\atlas-engine\docs\CFT-PHOTOGRAPH.md` exists (10,933 bytes); hopf/README.md:58's "Its"
  is atlas-engine d4178cc. Per the lead's convention I propose `atlas-engine/docs/CFT-PHOTOGRAPH.md`.
  (VALIDATION.md:13098 says "its `docs/CFT-PHOTOGRAPH.md`" too - VALIDATION is never edited, but a widened
  checker that scans it would trip there.)
- The `cardday-base` tag BRINGUP.md:600-605 calls "a moving marker ... it advances as the week does" is at 91728a9
  (2026-08-29), locally and on origin (`git ls-remote --tags origin`). Only BRINGUP mentions it.
- BRINGUP.md:223 and :546 give a link ~12 GB; VALIDATION.md:13909-13911 measured the singles at 15,021 / 15,262 MB.
  docs/studies/OPT-C-timing.md:485, 949, 1055 carry the same 12 GB / "31 GB box" but are a record.
Believed / left as history: CARDDAY.md's step 6 "1.25 cycles per beat" (E's fact) and step 4's "~30-invocation"
divide (B1's fact) sit inside the runbook-as-followed of 2026-09-08; I list them out of scope, not as findings.
For: A1 (no need to report the BITSTREAM-BUILDS side), E, B1, the lead.
