# verifier-P3

## 2026-09-26 00:30Z - main's runner (5fe9741) refuses every tree under %TEMP% as "git cannot read the repository"; P3 merges cleanly onto 5fe9741 otherwise

Measured (a scratch clone, C:/Users/logan/AppData/Local/Temp/verify-p3-work/sab, P3's 34c759e merged onto 5fe9741 as c9fe2fa; no Atlas call):
- `bash verify/run.sh --budget quick` from `/c/Users/logan/AppData/Local/Temp/verify-p3-work/sab` prints
  "FATAL: git cannot read the repository at /c/Users/.../sab; a run id needs its commit" and runs nothing.
- Cause: Git Bash mounts C:/Users/logan/AppData/Local/Temp on /tmp (`mount`: "C:/Users/logan/AppData/Local/Temp on /tmp
  type ntfs (...usertemp)"). The new toplevel test compares ROOT (`cd .. && pwd` = /c/Users/logan/AppData/Local/Temp/...)
  with `cd "$(git rev-parse --show-toplevel)" && pwd` (= /tmp/...). Two spellings of one directory, so every clone
  under %TEMP% (verifier-P0's qf-verify-p0, verifier-P2's, mine) is refused, and the message names the wrong cause.
- Invoked through the /tmp spelling (`cd /tmp/verify-p3-work/sab`), the same tree runs: 10 passed, 0 failed, PASSED
  (circuits "50 passed in 178.61s" with the desktop loaded; docs 8, golden 46).
- No file is touched by both P3 (b0e9ed1..34c759e) and main (b0e9ed1..5fe9741); the merge had no conflict.
Believed: asking git instead of comparing spellings (the runner has already cd'd into ROOT, so an empty
`git rev-parse --show-cdup` means ROOT is its own toplevel) would fix it; not tried, not mine to fix. P3's full
verification follows in this file.
For: lead; verifier-P0 and verifier-P1 (any clone under %TEMP%)

## 2026-09-26 00:39Z - verifier-P3 on 34c759e: the committed QASM lays the shelf's law exactly, and the run scores as P3 says; the commitment's timing rests on the code and the local clock alone; --score cannot fail; kind, fixed_at and occurrences are bound by nothing

Measured: every line below except those marked believed. My clone is C:/Users/logan/AppData/Local/Temp/verify-p3,
cloned from the lead's repository; `git rev-parse HEAD` = 34c759e040433ceb89ae68851567b93e8e80cefe, clean. Host: Windows
11 22631, Python 3.12.9, numpy 2.2.6, mpmath 1.3.0. `bash verify/run.sh --budget quick`: 10 passed, 0 failed, PASSED
(circuits "50 passed in 25.45s"). Every number was re-run by me; none is copied from P3. My simulator, scorer and
record checks share no code with P3's: they use decode.layouts (the one allowed reader), fixer's format functions, and
golden's kernel only to confirm my exact closed form.
Believed: the lines marked so. Interrupted by the usage pause at about 23:33Z, after the record plants; resumed 00:09Z
after a full ledger read, with the clone checked (34c759e, clean) and verify-p3-work/ listed before anything was redone.
For: lead; P3; verifier-P0 (D3's attacks extend its fixer table)

### Defects, first

**D1. `tools/pauli_atlas_run.py --score` cannot fail.** It prints its checks and exits 0 whatever they say, and it skips
a refused record after printing it. Planted in a scratch clone:
- the committed QASM swapped q5<->q6, re-hashed, the commitment recomputed and all 1,995 rolls re-sealed: it prints
  "the QASM against the authority: kernel 3.1e-02, law 2.0e-03", rc 0;
- one shot moved between two rolls, both re-sealed: it prints "... occurrences and all: False", rc 0.
The report presents --score as the offline check a re-run rests on. The gate that does fail is the circuits stage
(test_p3_records.py): it fails both plants. --controls, by contrast, exits "A CONTROL DID NOT FAIL" when one passes.

**D2. The timing evidence is weaker than the report reads, although the ordering claim holds by the code.**
- The server records no completion time. The submit response is {submitted_at 22:52:49Z, status "queued"}. The terminal
  status is {submitted_at 22:52:49Z, updated_at 22:52:51Z, status "completed", progress step "executing"}.
- This job's own POST bounds the clock offset. Its local send was 22:52:48.032 and its saved response 22:52:50.175,
  from the name and mtime of P3's git-ignored .atlas/responses file; I read names and mtimes only, never contents.
  With the server's 22:52:49Z, the server clock is within -1.2 to +2.0 s of the local one. So updated_at (22:52:51Z)
  and the commit (22:52:50 local, to the second) cannot be ordered from timestamps.
- If updated_at is the completion time, the job may have completed before 434c705 was made. It likely is not: in the
  22 committed 2026-09-25 status records it sits within 1 s of the terminal poll, but here the tool's /result request
  went out 19 s after the commit (local 22:53:09.649, file name 20260925T225309649061Z_GET_..._result.json). Believed:
  updated_at marks the last progress step ("executing" began), not completion.
- "Result fetched 22:53:09Z" is in no committed record. The tool that ran (6130b39) wrote no fetched_at; 6f2da1f added
  it after the run, which the report's "fetched_at kept" does not make clear. The committed result's keys are job_id,
  path, response, status and taken_from. The status polls ran with save=False, so the first status call's time is
  recorded nowhere.
- 434c705 is local and unpushed, so its time is the committer's clock. The reflog of P3's branch (the lead's .git,
  read only) is linear: b0e9ed1 at 22:28:31, 6130b39 22:52:28, 434c705 22:52:50, 45fc9f8 22:53:58, 6f2da1f 23:01:42,
  34c759e 23:02:39. No amend or reset, and also only the local clock.
- What holds is the code path, read at 6130b39 and at 34c759e: live() returns from commit() before finish() makes its
  first status call. Every exit before that (submit refused, QASM file conflict, git commit failing) comes before any
  status call. client.call never retries. --fetch refuses a dirty tree, so the line it reads is in HEAD.
- Strength: consistent and self-attested. Nothing third-party timestamps the commitment.
- Believed: pushing the commitment commit before the first status call, or putting the hash of (salt, circuit, decode)
  in the job request so the server's submitted_at covers it, would make this evidence external.

**D3. `kind`, `fixed_at` and `occurrences` are bound by nothing.** A committed roll re-sealed with kind "atlas-emu" ->
"qpu" passes the fixer's command line and the whole circuits stage (50 passed). So does fixed_at backdated to
22:52:00Z, before the commitment existed. The account has no QPU, yet an emulator roll can be sold as one.
`occurrences` of -5, "many" or absent are sealed and checked clean by the fixer. The circuits stage catches occurrences
only by comparing them with the committed result. P3's "the format needed nothing more (occurrences rode as an extra
source field)" is too strong. The commitment's scope is P0's (fixer.py). That test_p3_records.py does not hold
kind == "atlas-emu" or fixed_at after the commitment is P3's.

**D4 (minor). The coherence test cannot see a sign.** <XX>_01 and <YY>_01 both negated in the committed result pass the
stage (50 passed): it compares magnitudes "because the gauge may flip its sign". The gauge is fixed once the QASM is:
the committed circuit's own state gives <X0X1> = <Y0Y1> = +0.375 exactly (computed), and the engine measured +0.3755
and +0.3687. The report's "the sign is golden's (+)" is true of the data and held by no test.

**D5 (minor). "With the four places kept (raw floats, no skip): 55 rotations ... kernel error 4.9e-15" is not
reproducible as stated.** The first empty place (layer 1, row 1, column 12) has both entries exactly 0.0, so a forced
rotation divides 0/0 and the plan fills with NaN; with nothing skipped anywhere, the row phase NaNs too.
- Skipping only exact 0.0 (ZERO = GAP = 0): 53 rotations, 106 cx, kernel 4.8e-15, law 3.6e-17. The kept angles are
  -pi/2 on (9,10) and pi on (8,9).
- Giving the 0/0 place the angle 0: 55 rotations, 110 cx, depth 62, cx depth 30, kernel 5.4e-15, law 3.9e-17. The other
  three angles are pi, +pi/2 and pi, set by entries of +-2.27e-17.
- So P3's substance holds (exact either way, 8 cx dearer, angles set by noise), but it used an unstated 0/0 convention.

**Not P3's, for the lead**
- Main's runner (5fe9741) refuses every clone under %TEMP% (my 00:30Z entry). verifier-P0's 00:25Z defect 1 found it
  first; I found it independently.
- The commitment is recomputable from the record, salt included. A roll with job_id or circuit re-attributed and its
  commitment recomputed passes the fixer (A11, A12 below). Control 2 exercises only a naive tamper. The anchor is the
  committed commitments.jsonl, which test_p3_records.py holds every roll to.
- The fixer refuses a device layout of the wrong crystal count ("count: 4 crystals where the determinantal law lays
  exactly 5"). A QPU's leaked layouts can therefore never be device rolls, only entries in the score's not_fixed list.
  That sits oddly with "a device records what it laid".

### The eleven items

1. **The branch: CONFIRMED.**
   - Commits: 5, linear, 6130b39's parent is b0e9ed1.
   - `git diff --diff-filter=M --stat b0e9ed1 34c759e`: empty. D: empty. R, C and T (with -M -C): empty. A: 2,007
     files, 12 plus 1,995 rolls.
   - The commitment's three files are unchanged after 434c705, and docs/records is unchanged after 45fc9f8.
2. **The circuit lays the shelf's law: CONFIRMED, exactly.** sim_check.py has its own QASM reader and its own
   statevector (qubit q is bit q, little-endian; P3's is C order). K comes exact from the closed form, entries k/16 as
   Fractions, and equals golden fermi.kernel(4, 1, prec=128) to 0.0.
   - Gates: 311 (x 5, on q0-q4; h 102; cx 102; ry 102). There are 51 blocks, each h/cx/ry/ry/cx/h on (p, p+1).
   - Every cx is nearest-neighbour. Depth 62, cx depth 30, from my own ASAP count.
   - Against the exact law, over all 4,368 five-site layouts:
     - max |P - det(K_Y)| 3.56e-17, total variation 7.0e-15;
     - probability outside five crystals 2.2e-32, and on the 1,360 forbidden layouts 1.2e-31;
     - <n_i> error 4.55e-15, <n_i n_j> 4.16e-15; sum of det(K_Y) = 1 exactly.
   - The submitted QASM (in the submit exchange) equals the committed file and this machine's module output:
     sha256 ed767c01bd4b851d08993da80f715676e345fc95a10f3bda05400f738e400b36.
   - The reference givens.py by my counter: 236 cx, 118 ry, depth 115, cx depth 76, as P3 says.
3. **The 51: CONFIRMED, and sound. The QASM text is libm-dependent through atan2.**
   - The plan examines 145 entries. 41 are at or below 1e-12 (largest 6.49e-17, 16 exactly 0.0) and 104 are at least
     0.25. The four empty places are layers 1-4, row 1, columns 12, 11, 10 and 9.
   - The nonzero basis entries are exactly 1/4 and sqrt(1/8): IEEE-exact wherever libm is faithful. The ~1e-16 ones are
     set to 0.0 before use.
   - Measured:
     - 100 bases whose tiny entries are random in [-1e-13, 1e-13]: all 51 rotations, all the same QASM (ed767c01...);
     - 200 bases with every entry moved by up to 4 ulp: 51 in all 200, none refused;
     - math.atan2 one ulp high on every 7th call: 51 rotations, kernel 5e-15, but sha256 1e4980ad9e77b4b2.
   - So the count is 51 on any faithful libm, and noise past 1e-12 is refused by name. The text, and so the hash, can
     differ where atan2 does.
   - A reader recomputes circuit_sha256 only from the committed bytes. They are committed, LF under .gitattributes
     eol=lf, and named by the line's qasm_file. The rolls carry the hash, not the file name.
   - code_commit names the code, not the platform that turned it into this text (Python 3.12.9, numpy 2.2.6, MSVC's
     libm). Worth recording beside the QASM.
   - P3's 22:50Z "every entry examined is <= 6.5e-17 or >= 0.25" is exact.
4. **The commitment's timing: CONFIRMED by the code; NOT DETERMINED by the server's timestamps (D2).**
   - 434c705 carries no result. It has 3 files: commitments.jsonl, the QASM, and the submit exchange, whose response
     is {job_id, status "queued", submitted_at}.
   - 0 matches in them for measurements|counts|observables|density|"result"|completed.
   - P3's 22:50Z finding is confirmed on the committed 2026-09-25 records: 20 of 22 completed status responses carry a
     result, and all 4 tomography ones equal /result's.
5. **The score: CONFIRMED.** rescore.py reads through decode.layouts only.
   - Label IIIIIIIIIIIIIIZZ; 4,096 layouts, 1,995 distinct, all of 5 crystals, at most 18 of one.
   - 0 shots on the 1,360 forbidden layouts.
   - One-site: max |z| 1.4832, chi^2 9.798 over 16. Pairs: max |z| 2.5174 at (3, 9), chi^2 112.333 over 120.
   - Beyond P3, the whole distribution over the torus's 53 symmetry orbits (34 allowed): chi^2 33.74 on 33 dof.
   - Scale, 300 exact-law replicates (my seed):
     - distinct layouts 2020.2 +- 19.5; the run's 1,995 is z -1.29;
     - pair max |z| 2.75 mean, 3.49 at the 95th percentile; chi^2/dof 0.997 +- 0.210.
     - P3's scale figures agree.
   - The open-box run 0082f37b through my scorer: 10.01 / 521.2 and 20.20 / 5328.3, with 1,361 of 4,096 shots on
     pauli-4x4's forbidden layouts.
   - The engine's own <Z_13> z is -2.29.
   - The decode rests on measurement, not extrapolation, with one gap:
     - (i) bitorder_probe.py and bitorder_probe2.py send exactly this request: qubit_list 0..15, pair [[0,1]], 4096
       shots, single and double tomography, MI off. Their four recorded orders are all [15..0], which is
       decode.order("IIIIIIIIIIIIIIZZ"). The gap: those runs' labels were not recorded, and no committed record before
       P3's shows this label. That they were IIIIIIIIIIIIIIZZ is believed, from the identical request.
     - (ii) The frozen vector holds the rule on a pair-only Z setting (IIIIIIZIIIIIIZII).
     - (iii) New, inside this run (within_run.py): the engine's own <ZZ>_01 is 0.00390625, exactly decode's reading of
       the IIIIIIIIIIIIIIZZ strings. The big-endian reading gives -0.0225.
     - All 16 engine <Z_q> equal decode's reading of IIIIIIIIIIIIIIXZ (q0) and ZZZZZZZZZZZZZZZX (q1-q15) exactly.
     - Qubits 2-15 inside IIIIIIIIIIIIIIZZ are held by (i) alone. The tile's mirror q -> 15 - q is a symmetry, so the
       physics cannot hold them.
   - Coherence: engine <XX>_01 0.37548828125 and <YY>_01 0.36865234375, against 2K_01 = 3/8 exactly; z +0.03 and
     -0.44.
6. **The records: CONFIRMED.**
   - `ls .../rolls-8586f1cc/*.json | xargs -n 200 python -m quantum_film.fixer check`: rc 0; 1995 "fixed", 0 "REFUSED".
   - 1,995 files, 1,995 distinct layouts, occurrences 1-18 summing to 4,096, equal to decode.layouts of the committed
     result.
   - Each file is exactly fixer.text, and each carries the line's six committed fields and commitment.
   - The commitment recomputes from its documented definition, sha256(stream(COMMITMENT_DOMAIN, ...)), and the QASM
     hashes to circuit_sha256.
   - Attacks, each re-sealed and fed to the fixer's command line:
     - refused, naming the commitment: job_id, decode, shots, salt, engine;
     - accepted: crystals swapped (to an allowed or a forbidden layout); occurrences 400, -5, "many" or absent;
       fixed_at backdated; kind -> qpu; an extra source field;
     - accepted: job_id (A11) or circuit (A12) re-attributed with the commitment recomputed.
7. **Secrets and privacy: CONFIRMED clean. Counts only.**
   - Every file P3 added, at each of its 5 commits: `moth_` plus 8, 0; e-mail addresses, 0; 0432e094, 0.
   - x-amz-, Bearer, amazonaws, Signature= and Authorization occur only in pauli_tile.py's SECRET pattern (lines
     46-47) and in the test's assembled plants (test_pauli_tile.py 149-150).
   - Submit, status, result (733,997 bytes), commitments and score: 0 for every pattern. No url or download_url key.
     The only host is https://api.mothquantum.com, in $schema.
   - Commit messages: 5 e-mail matches, all the Co-Authored-By trailer at anthropic.com.
   - One author/committer identity, the same as b0e9ed1's.
8. **The controls: CONFIRMED.**
   - `--controls`: "51 of 51 fail the kernel check (error > 1e-6); smallest error 0.1875 (rotation 50), largest
     0.6875". Control 2: "REFUSED ... source: the commitment does not bind ...", rc 1.
   - My simulator, each 6-line block dropped from the committed QASM text: 51 of 51 fail, smallest 0.1875 (block 50),
     largest 0.6875.
   - The swap P3 did not try:
     - No transposition of two qubits (0 of 120) leaves the law unchanged.
     - q5<->q6 and q0<->q1 each move total variation 0.1875 and put 8.6% of the probability on forbidden layouts. The
       pair error is 1/32, the one-site statistics are untouched, and the swapped cx are no longer nearest-neighbour.
     - pauli_tile.check_circuit gives kernel 0.031.
     - Re-hashed and re-sealed through the records, it passes the fixer on all 1,995 rolls and --score at rc 0. The
       circuits stage fails exactly test_the_commitment_recomputes_and_its_committed_qasm_lays_the_law.
     - The tool's outgoing() would refuse to send it (read).
   - New "cannot fail" controls, for CLAUDE.md beside the gauge:
     - The line reversal q -> 15 - q keeps every cx nearest-neighbour and lays the same law, to 3.6e-17: the torus's
       point inversion.
     - 17 of 1,326 single and double rotation negations are also the same film (single: rotations 10 and 43).
9. **The tool: CONFIRMED except D1.**
   - Import is refused three ways (import, a spec loader, runpy under another name): "ImportError: this script calls
     Atlas ...".
   - A dirty tree is refused, whether an untracked file or a tracked edit: live and --fetch print "REFUSED: the tree is
     dirty", rc 1, and --dry-run notes DIRTY.
   - Branches main and master are refused, live and --fetch: "REFUSED: on main", rc 1.
   - An unknown job gets "no committed commitment", rc 1.
   - A detached HEAD is not refused, even at main's commit: the check reads the branch name (minor).
   - --score and --controls ran offline and reproduce every figure above.
   - The live path: see item 4. The live path at 34c759e has never run, since 6f2da1f changed finish() after the run.
     The order is unchanged.
10. **The tests: CONFIRMED, with 43 new (27 + 11 + 5). They can fail:**
    - two extra cx on the first rotation (law unchanged): only test_the_layout_is_the_hardware_one fails;
    - the basis tilted by 1e-13 rad: only test_every_empty_place_is_a_structural_zero fails;
    - one shot moved between two rolls: only test_the_records_are_intact_and_are_the_committed_result fails;
    - <XX>_01 set to 0: only the coherence test fails;
    - the re-sealed swap: item 8.

    What passes that should not: D3 and D4.

    NOT DETERMINED: whether test_the_circuit_lays_the_whole_golden_law has teeth of its own. None of 1,326 rotation
    negations and 204 single-gate faults (one ry negated, one h dropped) passes the kernel check and fails the law test.
11. **Else.**
    - The merge: P3 shares no file with b0e9ed1..5fe9741. The trial merge (c9fe2fa, scratch) had no conflict. The quick
      budget passes 10 of 10, run through the /tmp spelling (see the 00:30Z entry).
    - The circuits stage took 25 s, 3-19 s and 179 s here, with the desktop loaded; P3's 3.8 s is the quiet case.
    - The lead's to-do at merge:
      - the 51/102 counts in ROADMAP, givens.py's docstring and VALIDATION: confirmed;
      - "before the first status call" in fixer.py, ATLAS.md and run_job;
      - a home for DECODE;
      - line reversal in CLAUDE.md's "Controls that cannot fail";
      - kind and fixed_at (D3), and --score's exit code (D1).

### What I did not do

- I called no Atlas API, set no QF_ATLAS_AUTH, used no amd-arc-box and pushed nothing. I edited no tracked file in any
  repository.
- In the lead's tree and P3's worktree I wrote nothing. I read only two things there: the reflog file for P3's branch,
  and the names and mtimes of P3's .atlas/responses. The Atlas responses' contents I did not read.
- I never read or wrote the shared scratchpad. The harness did put the output of two of my backgrounded commands under
  the session's tasks/ directory, a sibling of scratchpad/: bonmbnhtn.output and bah11841t.output (the second stopped).
  I read neither.
- No second host or libm: the atan2 sensitivity is simulated. P3's p3-work/ prototypes are not examined.
- Kept:
  - the clone C:/Users/logan/AppData/Local/Temp/verify-p3 (34c759e, clean; its origin refs were fetched to 5fe9741);
  - C:/Users/logan/AppData/Local/Temp/verify-p3-work/: sim_check.py, rescore.py, within_run.py, records_check.py,
    attack_records.py, swap_sabotage.py, kept_and_drops.py, kept2.py, kept3.py, law_only_faults.py and its .log,
    law_only_faults2.py, replicates.py, plant.py, run_plants.sh, tool_refusals.sh, secret_scan.sh, fixer_all.log, and
    the swapped and reversed QASM.
- Deleted: the scratch clone sab/ (every plant, and the merge trial) and the attack copies. run_plants.sh and
  tool_refusals.sh expect a fresh sab/ clone of 34c759e.

## 2026-09-26 00:44Z - P3 merged onto 900b9e5 passes the quick budget from the /c/ path; the runner fix holds

Measured: a fresh scratch clone, with main at 900b9e5 (fetched from the lead's repository). The trial merge of 34c759e is
8c5d087; it had no conflict, and P3's files overlap none of main's since b0e9ed1.
- `bash verify/run.sh --budget quick`, run from /c/Users/logan/AppData/Local/Temp/verify-p3-work/sab: 10 passed,
  0 failed, PASSED, 39 s. circuits "50 passed in 14.37s", docs "8 passed".
- So the %TEMP% refusal of 5fe9741 (my 00:30Z entry) is gone at 900b9e5, as the lead's 00:40Z entry says.
- Scratch clone deleted.
Believed: -
For the lead's next commit ("import is inert: ... an allowlist of pure calls at import"): P3's library modules make
three calls at import. They are givens_line.py:60 `re.compile(...)`, givens_line.py:196 `np.array(...) / math.sqrt(2.0)`,
and pauli_tile.py:46 `re.compile(...)`. test_p3_records.py reads docs/records at import, to parametrize. The tool
refuses import first.
For: lead

## 2026-09-26 04:18Z - verifier-P3 re-check: 961b385 fixes D1-D5 as found and changes no committed record; it merges cleanly onto 73a79af and 2df3112 with every gate green; five minor items remain

Measured: every line below except those marked believed. My clone is C:/Users/logan/AppData/Local/Temp/verify-p3,
fetched from the lead's repository. `git rev-parse HEAD` = 961b3852540fbf4e81d76130054971aa626ffd43, parent 34c759e,
clean. Main moved during this pass, from 73a79af to 2df3112 (the lead's 03:58Z entry), and I tried both merges. Faults
were planted only in scratch clones under verify-p3-work/, now deleted.
Believed: the lines marked so.
For: lead; P3

### Defects, first (all minor; none stands between 961b385 and main)

1. **No gate holds --score's exit code.** With `raise SystemExit(1)` removed from rescore (D1's fix reverted), all 57
   circuits tests still pass. The audit that --score runs is held by tests (answer 2 below).
2. **The audit does not hold the platform record.** Deleted, or with its circuit_sha256 zeroed, it leaves --score at
   rc 0, "ALL CHECKS HOLD". The stage's test_the_platform_that_wrote_the_qasm_is_recorded_beside_it fails both.
3. **fixed_at has no upper bound.** A roll re-sealed with fixed_at 2099-01-01T00:00:00Z passes the fixer, --score and the
   stage.
4. **A forgery that keeps every committed file consistent passes the audit.** The anchor design expects this, since git
   history is the anchor.
   - submitted_at moved to 22:40:00Z in the line and the submit exchange together, with one roll's fixed_at at
     22:41:00Z: --score rc 0. The status record is the server's other copy (22:52:49Z), and nothing cross-checks it.
     One stage test did fail, but only incidentally: the in-memory "backdated" plant's 22:52:00Z is no longer before
     the forged submission.
   - One IIIIIIIIIIIIIIZZ shot moved (crystal 0 -> 1), with its two rolls and the score re-sealed: --score rc 0,
     57 passed.
   - Believed: an exact check inside the run would catch any forgery that changes the Z0Z1 parity. The engine's own
     <ZZ>_01 (0.00390625) must equal decode's reading of IIIIIIIIIIIIIIZZ exactly.
5. **DECODE has two homes on 2df3112.** pauli_tile.DECODE is its own string: equal to decode.DECODE today, but not the
   same object. If decode moves to v2, P3's new runs would still bind v1 while reading with v2. At merge,
   pauli_tile.DECODE should become decode.DECODE (P3's file; the lead's call).

### The lead's five questions

1. **961b385: CONFIRMED.**
   - It is one commit over 34c759e, touching 7 files. The only new record is circuit-ed767c01bd4b851d.platform.json.
     Against b0e9ed1, no pre-existing file is modified, deleted or renamed.
   - No committed record changed. Blob and tree ids are identical at 45fc9f8 and 961b385 for:
     - the QASM (d1bdeb8b) and commitments.jsonl (1e2d8f91), both also as at 434c705;
     - rolls-8586f1cc (tree 1afec26c);
     - the result, status, submit and score files.
   - `bash verify/run.sh --budget quick --require-all`: 10 passed; circuits "57 passed in 4.85s".
   - --score: rc 0, "ALL CHECKS HOLD". Every score is as before: 1.48 / 9.8, 2.52 / 112.3, 0 forbidden, engine 2.29.
   - --controls: 51 of 51 fail; control 2 is refused.
2. **D1-D5: FIXED as found.** On-disk plants, in a scratch clone of 961b385:

   | plant | fixer CLI | --score | circuits stage |
   |---|---|---|---|
   | none | 1995 fixed | rc 0 | 57 passed |
   | q5<->q6 swapped; line, submit, score, platform and all 1,995 rolls re-sealed | 1995 fixed | rc 1, "law: ... kernel error 3.1e-02" | fails |
   | one shot moved between two rolls | 1995 fixed | rc 1, "records: ... 2 layouts differ" | fails |
   | kind -> qpu | 1995 fixed | rc 1, "kind 'qpu' ..." | fails |
   | fixed_at 22:52:00Z | 1995 fixed | rc 1, "... before the job was submitted" | fails |
   | a roll deleted / an extra forbidden roll | 1994 / 1996 fixed | rc 1 | fails |
   | score's pairs.chi2 altered | - | rc 1 | fails |
   | engine <Z_5> = -0.9 / <XX>, <YY> negated | - | rc 1 (z -88 / -51.8, -51.3) | fails |
   | an unknown source field (b0e9ed1's fixer) | 1995 fixed | rc 0 | 57 passed (main's fixer refuses it; answer 3) |

   - D4: the committed circuit's state gives <X0X1> = <Y0Y1> = +0.375, and a test pins it.
   - D3: test_p3_records.py holds kind == "atlas-emu" and fixed_at >= the submit exchange's submitted_at, for all
     1,995 rolls.
   - D5: the docstring's three conventions reproduce here:
     - 51 rotations, kernel 4.8e-15;
     - 53, with -pi/2 on (9,10) and pi on (8,9);
     - 55, the identity at the 0/0 place on raw floats: 110 cx, kernel 4.9e-15, law 3.7e-17, with angles pi, pi/2 and
       pi set by entries of +-2.3e-17.
   - D2: the docstrings now say the order is the code's alone, with only local timestamps.
   - The new tests can fail. Each of these code plants fails a named test:
     - the audit's kind check removed;
     - its fixed_at check removed;
     - its law check removed;
     - |.| restored on <XX> and <YY>;
     - Y's sign flipped in pauli_expectation.
   - The platform record reproduces. Recomputed here by pauli_tile.platform_record, it equals the committed one in
     every field but head, note and recorded_at.
     - ucrtbase's atan2 equals math.atan2 on 51 of 51 calls and on 10,000 of 10,000.
     - A QASM with one angle changed is refused.
     - Its checked code is 961b385's givens_line (blob 825fd662), not the run's (8610dc1d at 6130b39), at head
       "34c759e+dirty". Its note says as much.
3. **The merge: CLEAN, and green on both mains.** No file changed on both sides since b0e9ed1.
   - Onto 73a79af (1a0c8ce):
     - `--budget quick --require-all`: 10 passed;
     - the full front door, with QF_CFT_ROOT at the lead's build and PYTHONDONTWRITEBYTECODE=1: 11 passed, atlas
       skipped by name. The rule forbids setting the key, so the full door cannot run under --require-all.
   - Onto 2df3112 (f9c1f86):
     - `--budget quick --require-all`: 10 passed; docs "9 passed", the new basename gate included; circuits 57 passed;
       --score rc 0.
     - P3's three test basenames are unique against main and against P1's 857065b.
   - Main's import rule:
     - problems() returns [] for pauli_tile.py, givens_line.py and the tool.
     - It flags plants in pauli_tile.py: platform.node(), json.loads or law_of() at import, and a datetime default.
     - Behaviourally, importing P3's modules under a PEP 578 audit hook raised no subprocess, socket or write-open
       event. The one ctypes.dlopen('kernel32') is numpy's own (`import numpy` alone raises it).
     - So verifier-P0's 04:12Z allowlist holes do not reach P3's code.
   - Main's fixer:
     - All 1,995 rolls are "fixed" and 0 refused (xargs rc 0, at 1a0c8ce and at f9c1f86), with digests unchanged.
     - Refused both by the fixer and by --score: an unknown source field; occurrences 0, 4097 or "1"; fixed_at
       "2026-09-25 22:53:12".
     - Accepted by the fixer, as main intends: occurrences absent, and a 4-crystal device roll. --score and the stage
       refuse both as not the committed result.
4. **The platform JSON: nothing that should not be public.**
   - It carries no credential, key, account id, e-mail, hostname, username, user-profile path, IP or MAC. I checked
     against this host's own values.
   - It does name:
     - the CPU (Intel64 Family 6 Model 151 Stepping 2) and the Windows build (10.0.22631);
     - conda-forge's Python build string, and numpy's compiler and SIMD;
     - C:\WINDOWS\System32\ucrtbase.dll, with its version and hash.
   - That is a coarse fingerprint, and the UCRT version hints at that one DLL's patch level.
   - Believed harmless to the record's purpose to trim, if the owner wants: the stepping, the path and the Python build
     date.
5. **Anything else.**
   - lead.md 01:56Z's merge to-do stands, and defect 5 joins it.
   - The circuits stage ran 57 tests in 4.9-18 s here.
   - No CI runs P3's tests on another libm.

### What I did not do

- I called no Atlas API, set no QF_ATLAS_AUTH, pushed nothing and edited no tracked file.
- I wrote nothing in the lead's tree or in P3's worktree. There I ran one `git status` (the index's mtime, 04:00:19Z,
  predates it), and the cft stage loaded the lead's DLL with bytecode writes off; nothing under vendor/cft-fp256 is
  newer than my runs.
- I did not touch the shared scratchpad.
- Kept in verify-p3-work/: plant2.py, plant3.py, run_plants2.sh, run_plants3.sh, and the logs run961.log,
  merge73-quick.log, merge73-full.log, merge2df-quick.log and fixer_main.log.
- Deleted: the scratch clones, with every plant and the merges 1a0c8ce and f9c1f86. My clone is at 961b385, clean.

READY TO MERGE: D1-D5 are fixed as found, no committed record changed, and 961b385 merges cleanly onto 73a79af and 2df3112 with every gate green and all 1,995 rolls passing main's fixer; the five minor items above can follow the merge.
