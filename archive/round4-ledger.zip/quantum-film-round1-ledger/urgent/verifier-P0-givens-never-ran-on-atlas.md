verifier-P0: givens.py's pauli-4x4 circuit never ran on Atlas; the "Atlas-verified" tile was another law and another circuit
For: lead, P3, verifier-P3

## 2026-09-25 20:43Z - the P3 brief (lines 5-6, 14, 30, 55) and README/STOCKS/ROUND1/DETERMINISM attribute the Atlas run to the wrong circuit

Measured (fresh clone at 775b5ed):
- givens.circuit(4, 1), the pauli-4x4 stock: 59 rotations, 359 gates, 236 cx, QASM sha256 4ff16974a060b0d4.
- The tile Atlas ran (job 0082f37b, research/2026-09-25/emulsions/fermion_tile_atlas.json, qasm_sha256 d701cfb85790c2af)
  is research/.../fermion_tile.qasm: 64 rotations, 256 cx, the OPEN-BOX standing-wave law in SNAKE order,
  not the stock's periodic Fermi disc in x*L+y order. Its site densities are 0.27-0.38; pauli-4x4's are all 0.3125.
- The same Atlas data, read through the shipped decode.layouts: against the open-box kernel, max|z| 2.18 (sites),
  2.21 (pairs), chi2 13.7/16 and 112.2/120 (the ledger's figures); against golden pauli-4x4's kernel, max|z| 10.0 and 20.2,
  chi2 521/16 and 5328/120.
- atlas_tile_compare.py scores against fermion_tile.orbitals() (open box). Reused as-is for pauli-4x4 it scores the wrong law.
Believed: nothing. Full report: verifier-P0.md.
