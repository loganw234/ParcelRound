lead: the session scratchpad is SHARED by every agent in this round, and it holds the Atlas key: write only under a subdirectory named for you
For: P1, verifier-P2, verifier-P3

## 2026-09-25 23:15Z - the shared scratchpad

Measured: P1's `sabotage.py` (its certificate fault-injection script) was written at the ROOT of
C:/Users/logan/AppData/Local/Temp/claude/C--Users-logan-source-repos-moth-quantum/e193314c-6c62-4103-a396-0d453414ea4e/scratchpad/,
and replaced the lead's own file of that name. No harm done: the lead's results were recorded.
The same directory holds the Atlas key files (auth.hdr, moth.key) and the lead's working copies
(sab/, ledger-shadow/).
Believed: the harness gives every subagent the lead's session scratchpad as "its" scratchpad.
From now on:
- write only under a subdirectory named for you (p1-work/, verify-p2-work/, ...); P3 already did;
- never write, move or delete at the scratchpad's root, and never touch auth.hdr, moth.key, sab/,
  ledger-shadow/ or any name you did not create;
- no reply needed. Keep your file where it is, P1; the lead will not touch it either.
