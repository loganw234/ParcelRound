# verifier-P0

## 2026-09-25 20:46Z - P0 at 775b5ed: the shipped authority samples its law and is precision-proof, but several gates cannot fail and several claims have no run behind them

Measured: everything below except the lines marked "believed". Every number was re-run on a fresh clone; none is copied from the ledger.
Believed: the error bound at the table's largest stock (L = 64) is still far below the margin (not run); some JSON readers keep the first of two duplicate keys (not tested against any named reader).
For: lead; P3 and verifier-P3 for 8a (already posted to urgent/ at 20:43Z); P1 and verifier-P1 for 7e, 11a and 11c.

### Defects, listed first (details under each item)

- **1** The law test's control is too weak. A sampler that skips one projection update lays forbidden layouts in 18% of 4x4 rolls and passes the test (1.203 < 1.6). After `make vectors` it passes the whole front door.
- **2** The 256-vs-320-bit test, which DETERMINISM.md calls "the check on the argument", cannot fail. It passes with the refusal removed, with a margin of 0, and with a margin (2^-255) below the arithmetic's own error. The margin's size has no gate at all.
- **6a** A record's file bytes are not what its digest covers. A file with two `crystals` keys is accepted with the genuine digest. DETERMINISM.md says "a changed byte ... is refused by name".
- **6b** The record and digest depend on `quantum_film.__version__`. After a version bump, `reproduce()` returns False for a correct roll. Invariant 1's "same record byte for byte, same digest" is really (stock, seed, version).
- **6c** `fix`/`fix_device` truncate non-integer crystals and seal them: `[0.7, 1.2, 4.0, 11.5, 13.9]` becomes `[0, 1, 4, 11, 13]`, and `check` passes it.
- **6d** The commitment joins free-text fields with an unescaped `|`. Engine and job id can be re-attributed together with the commitment intact.
- **7a** `--only ""` runs zero stages and prints `== PASSED`, exit 0.
- **7b** `--resume` crosses trees. Two dirty trees of one commit share an id. A resumed full run reported PASSED over a golden stage that fails on the tree under test.
- **7c** Two fresh invocations in the same second share a run directory. The second reuses the first's `.ok` markers.
- **7d** The negative control has no positive twin. A fixer command line that refuses every record passes the whole run.
- **7e** Skips inside a pytest stage pass it and are invisible to `--require-all`. This is the next change's defect: P1's `tests/pinned`.
- **8a** The Atlas run is attributed to the wrong circuit and law, in the README, STOCKS.md, ROUND1.md, DETERMINISM.md and the P3 brief. `givens.py`'s pauli-4x4 circuit has never run on Atlas.
- **8c** CLAUDE.md says every script that talks to Atlas has a `__main__` guard. Seven do not.
- **8d** CLAUDE.md says the registry fails a test file no stage runs. It misses `*_test.py`, which pytest collects.
- **8f** Seven references to test paths that no longer exist, including DETERMINISM.md's pointer to its own check.
- **8g** The client's two refusals, and 8h the libcft cost figure: claims with no gate or no ledger entry.

The shipped authority itself is right: its basis, its law, normalisation, uniforms, decode rule and Givens gauge. Those are items 1-5, all confirmed.

### Setup, as run

- Clone: `git clone -q https://github.com/loganw234/Quantum-Film /c/Users/logan/AppData/Local/Temp/qf-verify-p0`, then `git checkout -q 775b5ede6421f65425d63b46dc682ac28b2bbd50`.
  - `git rev-parse HEAD` printed that SHA. `git ls-remote origin` shows main = 775b5ed.
  - The submodule is at 7d7285dfd735cb32faeee609c68c829c85b1593e.
- Build: the documented `PATH="/c/msys64/mingw64/bin:$PATH" make -C vendor/cft-fp256/host CC=gcc OS=Windows_NT TMP=... TEMP=... cft.dll > build.log 2>&1`.
  - make rc 0, 10.6 s. The log is 33 lines, with 0 lines matching "warning" and 0 matching "error".
  - The DLL is PE32+ x86-64 with 122 `cft_` exports, importing only KERNEL32.dll and msvcrt.dll. Its sha256 begins 23f0f2e6ae3e795e.
  - The submodule stays clean.
- Host: Windows 11 22631, Python 3.12.9 (Miniconda), numpy 2.2.6, mpmath 1.3.0 (gmpy backend), pytest 9.1.1, ruff 0.11.9. No installed `quantum_film` shadows the clone; `pip show` finds none.
- `bash verify/run.sh`: rc 0; 9 passed, atlas SKIP "no Atlas key configured"; 24.3 s. I read every log, not the exit code:
  - lint: "All checks passed!".
  - docs 4, golden 34, circuits 7, decode 5, fixer 23 passed.
  - vectors: "4 generated vectors regenerate byte for byte; SHA256SUMS holds 5 files; the tampered record is refused".
  - controls: "REFUSED ... digest: the record's bytes are not the bytes it was fixed with".
  - cft: "ABI 0.14 ... cos(1) = 0x1.14a280fb5068cp-1".
- `make verify-quick`: 8 of 8 in 15.4 s.
- The probe scripts named below are in `C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/scripts/`, kept so they can be re-run. They read the clone and write nothing into it.
- Every sabotage was made in a copy under my scratchpad, which is deleted.
- The Atlas API was never called. amd-arc-box was not used. The atlas stage stayed skipped.

### 1. The authority's law (`golden/fermi.py`)

Commands:
- `law_probe.py`:
  - golden K against the closed form (1/M) sum_k cos(2 pi k.(x-y)/L) at 128 bits, for (4,1) and (16,8);
  - K^2 - K, and the trace;
  - `fermi.total_probability(4,1,96)`, timed;
  - the law statistic's distribution over 20,000 multinomial replicates of 2,000 rolls, drawn from det(K_Y), from the uniform law, and from mixtures of the two.
- `law_gate_power.py`:
  - the test's own `chi2_per_dof` on the test's own 2,000 streams;
  - a copy of the chain rule, asserted to lay exactly the shipped sampler's 2,000 rolls, then run with three planted bugs.
- `full_law.py`: 50,000 fresh rolls, `stream("verifier-p0","pauli-4x4",k)`, through the shipped `fermi.sample`, pooled into the 53 orbits of the torus's 128 symmetries.
- An end-to-end sabotage in a copy.

Observed:
- **Span.** K matches the closed form to 1.65e-39 on (4,1) and 7.35e-40 on (16,8). K^2 = K to 1e-39, and the trace is N (5 and 25).
  - The two projectors are equal, so the real basis spans exactly the disc's plane-wave space.
  - The suite already holds Phi^T Phi = I.
- **Chain rule.** Of 50,000 rolls, 0 fall on the 1,360 forbidden layouts (19 of the 53 orbits have det 0). chi^2 is 40.9 on 33 dof (z = +0.97), 81 s.
- **Normalisation.** 1 + 1.51e-28 against a bound of 2^-80, in 2.7 s.
- **Law test.** 0.943 and control 7.052, both exactly as recorded. 2,000 rolls take 2.7 s.
- **Null distribution of the statistic.** With the correlations in, the mean is 0.996 and the sd 0.200. An independent chi^2/136 would have sd 0.121.
  - The 99.9th percentile is 1.818, and P(stat >= 1.6) = 0.72%. The day's 0.943 sits at the 43rd percentile.
  - The uniform control has mean 6.89, sd 0.42 and minimum 5.37.
- **Power.** (1-e)·law + e·uniform is flagged 0.6% of the time at e = 0.05, 5.7% at e = 0.20, and 37% at e = 0.30.
- **Planted bugs, scored as the test scores them:**
  - "stale-last" (no projection update before the last draw): 1.203, which PASSES, while 366 of 2,000 rolls are det-zero layouts;
  - "half-update" (the first projection subtracted at half weight): 1.644, caught by 0.044;
  - "e not normalised": 4.875, caught.
- **End to end, stale-last planted in a copy.**
  - `--budget quick` fails only `vectors` (drift).
  - After `python tools/make_vectors.py --write` (CLAUDE.md's remedy for a deliberate change), `bash verify/run.sh` gives 9 passed, atlas skipped, PASSED.

Verdict:
- **Confirmed** for the shipped code: the basis is orthonormal with the right span; the chain rule samples det(K_Y) over the whole distribution; normalisation, 0.943 and 7.052 all reproduce.
- **The bound is meaningful** as a false-alarm bound: 0.7% under the true law, and the streams are fixed, so the test is deterministic.
- **The control: DEFECT (the gate).** Uniform sits about 14 null standard deviations past the bound. The test tells repulsion from uniformity, and little finer.
  - The ledger's claim that "the law test closes the gap between the kernel is right and the authority samples it" does not hold for partial defects.
  - A count of rolls on det-zero layouts, or a whole-distribution test over symmetry orbits (as in `full_law.py`), catches stale-last at once.
  - Also: the 16x16 kernel's span has no independent gate. The circuits test cross-checks golden's 4x4 kernel against an independent numpy basis, but the 16x16 basis is held only by its own orthonormality and by vector drift. It is right today (above).

### 2. The determinism argument (DETERMINISM.md)

Commands:
- `margin_probe.py`: an instrumented copy of `sample`'s loop, asserted to lay the shipped rolls, run at 256 and 320 bits on the 4 seeds the test uses.
- In a copy: `pytest tests/golden` with three sabotages:
  - (a) `if False and abs(nxt - target) < margin`;
  - (b) margin = 0;
  - (c) margin = 2^-(prec-1).

Observed:
- **Premise.** Over all 100 draws, 256 against 320 bits:
  - boundaries differ by at most 2^-248.8;
  - targets by at most 2^-251.0;
  - c_i by at most 2^-256.3.

  Half the margin is 2^-225, so the headroom is about 2^23.
- **Nearest approach** of any target to any boundary examined, on those seeds: 2^-15.2. Typical values are 2^-9 to 2^-11.
- **No draw is decided inside the margin by any path:**
  - every boundary up to and including the chosen site is margin-checked;
  - later boundaries are at or above the chosen one, because clamped weights are non-negative;
  - a clamped c_i adds a zero-width interval whose boundary equals the previous, already-checked one (seed 3 met 30 such, with no decision affected);
  - taken sites are excluded from both the total and the scan;
  - `chosen is None` raises. It is unreachable in practice, since target <= total·(1-2^-64) while the last boundary is at least the total, and no test reaches it.
  - Accumulation is sequential at 256 bits and the total is an fsum. Another order moves boundaries by about M·2^-256.
- **An absolute margin is right.** The errors are absolute (c_i <= 1) and did not grow materially along a roll. The total N - j is at least 1 exactly, so margin/total only grows as crystals are laid.
- **As written**, "the total error in the cumulative weights" should be the error in (boundary - target), because the target inherits the total's error. Read that way, the argument is sound.
- **Sabotages:**
  - (a) only `test_a_draw_on_a_boundary_is_refused_not_rounded` fails; the 256-vs-320 test PASSES;
  - (b) the same;
  - (c) all 34 golden tests pass.

Verdict:
- **Confirmed** for the shipped code: the argument is sound, its premise is measured, and no rounding-decided path exists.
- **DEFECT (the gate).** The 256-vs-320 test is inert by construction. For it to fail, a target must land within about 2^-249 of a boundary, and random seeds come no closer than 2^-15.
  - README's "because a draw closer than 2^-224 to a boundary is refused" is therefore not what the test shows: the rolls agree with no refusal at all.
  - Failure scenario: a change that shrinks the margin below the rounding error passes every gate. Removing the refusal is caught only by the single exact-tie test.
  - Also: 256 and 320 bits refuse different sets (margins 2^-224 and 2^-288), so "must lay the same rolls" cannot hold on a planted near-tie.
  - What would test the argument: a planted target between the 256-bit and the exact boundary, or asserting |boundary_256 - boundary_320| < margin/2 along real rolls.

### 3. The uniforms (`golden/uniform.py`)

Command: `uniform_probe.py`.

Observed:
- 20,440 tuples of up to 3 parts, no two encoding alike. The strings included `|`, `:`, `s1:a`, `i1`, `a|i1` and non-ASCII; the integers ran from -10 to 2^70.
- The encoding is length-prefixed and type-tagged, so it parses uniquely from the left.
- DOMAIN|stream|i is injective in (stream, i) even for raw stream bytes containing `|`, because the index is everything after the last `|`.
- `uniform()` equals the documented SHA-256 construction.
- `<len>` counts UTF-8 bytes: "é" encodes as `s2:`. The docstring's `s<len>:<utf8>` does not say bytes or characters. No non-ASCII part exists today.

Verdict: **confirmed.**

### 4. The Givens circuit (`circuits/givens.py`, `tests/circuits/`)

Command: `givens_probe.py`.

Observed:
- **All angles negated.** 27 random real orthonormal A (M 6..14, N 2..7), run through givens.py's own plan, gates and simulate, leave the full occupation distribution unchanged (max difference 0.0). K' = SKS with S = diag((-1)^q), exactly.
- **Why.** Every rotation is on JW-adjacent qubits, a line is bipartite, and S negates s in every rotation. This would fail for a rotation between qubits at even distance.
- **The test's three sabotages** on pauli-4x4 give n1/n2 errors of 0.010 (nudge), 0.207 (drop block 7) and 0.141 (reverse cx 78).
- **Every single-gate sabotage is caught.** Minimum errors: 1.8e-3 over all 118 ry nudges, 3.1e-2 over all 59 block drops, 6.3e-2 over all 236 cx reversals. None is below 1e-6.
- **One rotation negated alone.** 4 of 59 are invisible to n1/n2, and none of those changes the layout law (TV < 1e-6).

Verdict: **confirmed.** The gauge holds in general, not only for this tile, as long as the network is nearest-neighbour on the JW line. P3's layout must keep that for CLAUDE.md's note to stay true. The three sabotages are real controls.

### 5. The decode rule (`atlas/decode.py`, `tests/decode/`, the frozen vector)

Command: `decode_check.py`.

Observed:
- Over 144 comparisons the worst |z| is 2.49 (setting IIIIIIYIIIIIIXII, position 15, qubit 2), with chi^2 132.8. Plain order scores 316.61.
- Every alternative fails:
  - active qubits descending: 331.61;
  - the rest descending: 346.28;
  - active qubits last: 576.11;
  - qubit_list order [9,2,14,5]: 329.61.
- The vector is byte-identical to `research/2026-09-25/atlas/bitorder_probe3.json` (job 2e41913f). Its sha256 is f28b62d9..., as in SHA256SUMS. Its CRLF form hashes to 1a69afa8..., as VALIDATION.md says.

Verdict: **confirmed.**
- Note: the rule was inferred from, and then held to, the same run.
- Its one out-of-sample use is the tile's all-Z setting with 8 non-I qubits. That rests on the tile's physics, not on a known-answer run. The ledger's "What this does not prove" says so.

### 6. The fixer (`fixer.py`, `tests/fixer/`)

Commands:
- `fixer_attacks.py`: each record is written under `qf-verify-p0-work/attacks/` and fed to `python -m quantum_film.fixer check FILE`.
- Inline: `reproduce()` before and after setting `fixer.__version__ = "0.1.1"`.
- Inline: `fix`/`fix_device` given non-integer crystals.
- The CLI given a malformed record.

Observed (the CLI's rc; 0 means accepted):

| case | rc |
|---|---|
| A1 duplicate `crystals` key, first [2,3,7,8,12], last the real one | 0, with the genuine digest 18ebea56; reproduce True |
| A1b bytes changed (indent 4, a u-escape), value the same | 0, same digest |
| A2 golden stream ["roll","pauli",1] on a pauli-4x4 record, re-sealed | 0; reproduce raises "not a roll stream" |
| A3 seed-2 crystals in the seed-1 record, re-sealed | 0; reproduce returns False, **caught** |
| A4 a stream part that is JSON `true` | 0; the authority's `stream()` refuses a bool |
| A5 law with fermi_r2 `true`, M 16.0, N 5.0 | 0 |
| A6 an extra key in the law | 1, "law: ..." (**refused**) |
| A7 a bool crystal; float crystals | 1, "crystals: not a list of integers" (**refused**) |
| A8 an extra top-level key, plus fixed_at on a golden roll | 0 |
| A9 a device roll of the forbidden layout [0,1,2,3,4] (det 0) | 0 |
| A10 engine `tomography-api-v2`, job `2e41913f\|0082f37b`; re-attributed as engine `tomography-api-v2\|2e41913f`, job `0082f37b` | both 0, same commitment |

- **Version.** `reproduce(negative-pauli-4x4-seed1)` is True. With `__version__` set to "0.1.1` it is False: the crystals are identical, the digest is 5ef44131... against 18ebea56....
- **Coercion.** `fix_device("pauli-4x4", [0.7, 1.2, 4.0, 11.5, 13.9], a valid source)` seals `[0, 1, 4, 11, 13]`, and `check` returns [].
  - `fix(..., [True, 2, "4", 11, 13])` gives [1, 2, 4, 11, 13].
  - `lay("pauli-4x4", 1.9)` gives seed 1.
- **Malformed record.** `check` on `{"stock": []}` followed by a good record raises `TypeError: unhashable type: 'list'`, rc 1. The good record is never checked.

Verdict:
- **DEFECT 6a.** DETERMINISM.md, promise 2: "Its digest is re-derived from its own bytes, and a changed byte ... is refused by name."
  - The digest covers a re-serialisation of the parsed value, not the file's bytes.
  - Scenario A1: a file carrying two crystal lists is accepted with the genuine digest. A reader that takes the first occurrence, or a person reading top to bottom, sees [2,3,7,8,12].
- **DEFECT 6b.** Every record embeds `quantum_film.__version__`, and DETERMINISM.md's Versioning section does not name it among the things that change every digest.
  - Scenario: the first version bump makes `reproduce()` return False for every existing golden record whose roll is unchanged.
  - Two machines at different versions then disagree on every digest.
- **DEFECT 6c.** The constructor rounds what `check` refuses (METHOD §2). Scenario: a decode path that yields float or fractional positions becomes a permanent, check-clean record of sites nobody measured.
- **DEFECT 6d.** fixer.py says "a record cannot be re-attributed to another circuit or job without the refusal naming it". A10 re-attributes the job and the engine together with the commitment intact.
  - Re-attributing one field at a time is caught, as the tests hold.
  - The risk is low while job ids are UUIDs, but nothing enforces that. The uniforms length-prefix their parts; the commitment does not.
- **Minor:**
  - `check` validates golden streams less strictly than the code that uses them: A2 is accepted but reproduce refuses it; A4 is accepted but `stream()` refuses it.
  - The law check is Python `==` (A5).
  - A malformed record crashes the CLI instead of being refused by name.
- **Confirmed:**
  - extra law keys and bool or float crystals are refused;
  - `reproduce()` catches re-sealed crystals from another seed;
  - every device field is required;
  - single-field re-attribution breaks the commitment.
- **What the commitment binds:** circuit_sha256, engine, job_id and salt, as documented.
  - It does not bind the stock, crystals, shots or decode.
  - Nothing ties circuit_sha256 to the stock's circuit, so a roll from another law (8a) can be fixed as pauli-4x4 and `check` cannot tell.

### 7. The runner (`verify/run.sh`, `verify/pytest-stage.sh`)

Commands, in the clone:
- `--only ""`, `--only ,`, `--only nosuch`, `--skip nosuch`;
- `--require-all --only lint,atlas`;
- `--list`, `--budget quick --list`, `--only golden --list`, `--only nosuch --list`;
- `--skip controls --only controls,lint`;
- `--resume 20260925-130816-0000000`;
- five pairs of back-to-back `--only lint`.

Commands, in a scratch copy:
- a dirty tree, `--only golden,fixer`, then fermi.py's refusal disabled, then `--resume <id>`; then again with a plain `--resume` and a full run;
- clean, then dirty, then `--resume`;
- `fixer.main` made to return 1 for every record, then a full run;
- a `skipif(True)` test planted in tests/golden, then `--require-all --only golden`;
- `pytest-stage.sh` on scratch directories: xfail, test names containing "error", a warning, 3 of 4 skipped, an empty parametrize, no tests, xpass, and `-k` deselection.

Observed:
- **Empty filter.** `--only ""` and `--only ,` print "passed 0, failed 0, skipped 0" then "== PASSED", rc 0.
- **What works.** Unknown names are refused with rc 2. `--require-all` makes the atlas skip a FAILED run. `--list` marks the budget.
- **`--resume`.**
  - Refused across commits, and from a clean tree to a dirty one.
  - Accepted from one dirty tree to another. The run from tree A (fermi.py pristine, an untracked notes.txt) was resumed on tree B (tie refusal disabled; a fresh golden run on B FAILS). It printed "golden ok (passed earlier in this run)", PASSED.
  - With a plain `--resume` and a full run: 8 passed, 1 cached, PASSED, rc 0.
- **Same-second collision.** 2 of 5 back-to-back pairs shared a run id, and the second printed "lint ok (passed earlier in this run)".
- **A command line that refuses everything.** It even prints "fixed" for a good record, then exits 1. The full run: 9 passed, "controls ... the negative control failed, as it must", PASSED.
- **Planted skip.** "passed 1, failed 0, skipped 0", PASSED, under `--require-all`. The SKIPPED line appears only in golden.log.
- **`pytest-stage.sh`:**
  - "1 passed, 1 xfailed" FAILS ("the summary names a failure");
  - test names containing "error": pass;
  - a warning: pass;
  - "1 passed, 3 skipped": pass;
  - an empty parametrize ("1 passed, 1 skipped"): pass;
  - no tests: rc 5, FAIL;
  - xpassed: pass;
  - deselected: pass.
- **`--only nosuch --list`** returns rc 0 with nothing marked, while the same selection without `--list` is refused.

Verdict:
- **DEFECT 7a** (FAILURE-MODES D1). Zero stages report PASSED, and the negative control does not run. Scenario: `--only "$STAGES"` with STAGES unset.
- **DEFECT 7b.** CLAUDE.md says "`--resume` refuses to cross trees". The id is the commit plus a dirty flag, not the tree, so the scenario above reported PASSED over a failing authority.
- **DEFECT 7c.** The header says "THERE IS NO CACHE ACROSS RUNS". That is false within one second.
- **DEFECT 7d.** The control asserts only a non-zero exit, and no gate runs the command line on a good record. So "the runner proves it can say no" proves only that it can exit 1.
- **DEFECT 7e** (next change). A test-level skip passes a stage, and `--require-all` cannot see it. Scenario: P1's `tests/pinned` with `skipif(no libcft)` passes everywhere.
- **Minor:** `xfailed` fails a stage (a false alarm, in the safe direction); `--list` does not refuse unknown names.
- **Confirmed:**
  - the stage list is derived from the `stage` calls (10 and 10);
  - MUST_FAIL inverts exactly the next stage;
  - skips are printed by name with a reason;
  - `--require-all` works on stage-level skips;
  - unknown names are refused;
  - `--resume` is refused across commits and clean/dirty;
  - pytest-stage cannot report a failing or empty pytest run as a pass: rc is checked first, and "no tests ran" fails.

### 8. Claims against measurements

Reproduced as stated:
- g(1) 0.469, 1.018, 1.733;
- RMS 5.70, 9.45, 16.73;
- first-layout digests 8f3859e5a44faf1a, 6ce415b295807d1b, ae91d556415f11a6;
- `grain_proto.py` rerun in a copy: stats.json identical except wall-clock seconds; layouts.npz byte-identical;
- binary32: 38 of 40 identical, parting at draws 7 and 105, sharing 0.55-0.86;
- the census from docs/records:
  - coin-toss 519 vs 510 and 514 vs 509 heads;
  - blur-core exact 3d7a31ea90dd892b on all four runs;
  - the other engines differ;
- the Atlas tile: 4,096 layouts, all of 5 crystals, 2.18 and 2.21 sigma, chi^2 13.7/16 and 112.2/120;
- normalisation, 2.7 s;
- 0.943 and 7.052;
- seeds 1-4 equal at 256 and 320 bits;
- the golden digests 18ebea56f8d7f2b4, 5f56d896f8cde98a, 83a559f3779e48c6;
- 23 fixer tests;
- libcft: 122 exports, ABI 0.14, cos(1) bits;
- the cft stage's two controls (ABI 0.13, and cos one ulp high) both exit 1;
- the registry catching `tests/stray/test_lost.py`;
- a 16x16 roll: 0.24-0.28 s here, against 0.4 s on the day.

Defects:
- **8a. The Atlas run is attributed to the wrong circuit and law.**
  - The claims:
    - README: "A Pauli tile ran as this project's own circuit ... 256 CNOTs ... within 2.21 standard errors of the exact law", and the Pauli row's "a tile run on Atlas";
    - docs/STOCKS.md: "The circuit is quantum_film/circuits/givens.py ... Its 16-qubit tile ran on Atlas on 2026-09-25";
    - docs/ROUND1.md: "givens.py, which is the Atlas-verified reference";
    - DETERMINISM.md's evidence row;
    - the P3 brief, lines 5-6, 14, 30 and 55.
  - Measured:
    - `givens.circuit(4,1)` has 59 rotations and 236 cx, QASM sha256 4ff16974a060b0d4.
    - Atlas ran `fermion_tile.qasm`, sha256 d701cfb85790c2af: 64 rotations and 256 cx, the open-box law in snake order, with site densities 0.27-0.38 against the stock's uniform 0.3125.
    - Through the shipped `decode.layouts`, the data fit the open-box kernel (the figures above).
    - Against golden pauli-4x4 the same data give max |z| 10.0 and 20.2, chi^2 521/16 and 5328/120.
  - The shelf's Pauli law has never been run on Atlas.
  - `atlas_tile_compare.py` scores against `fermion_tile.orbitals()`, so reused as-is it scores the wrong law.
- **8b.** Precision independence: see item 2.
- **8c. CLAUDE.md: "Every script that talks to Atlas has a `__main__` guard."**
  - Static reading only; nothing was executed.
  - Seven research scripts call Atlas at module level with no guard:
    - `bitorder_probe.py` (2 tomography jobs), `bitorder_probe2.py` (2), `bitorder_probe3.py` (1);
    - `probe2.py` (its probe list);
    - `recon.py`, `defs.py`, `fetch_outputs.py`.
  - Importing any of them repeats the incident CLAUDE.md cites (nine unrequested jobs).
- **8d. CLAUDE.md: "tests/docs/test_registry.py fails a test file no stage runs."**
  - The registry globs `test_*.py` only.
  - A failing `tests/stray/law_test.py`: the docs stage PASSED, and `pytest --co` collects it. So `make test` runs it and no stage does.
- **8e.** CLAUDE.md's `--resume` claim: see 7b.
- **8f. Stale test paths** left by P0-final's move into stage directories. They are plain text, so the docs gate cannot see them:
  - docs/ATLAS.md:49 `tests/test_decode.py`;
  - CLAUDE.md:28 `tests/test_independence.py`;
  - CLAUDE.md:65 `tests/test_givens.py`;
  - docs/DETERMINISM.md:49 `tests/test_golden_fermi.py`, which is its pointer to "the check on the argument";
  - quantum_film/golden/__init__.py:6;
  - quantum_film/circuits/__init__.py:5;
  - quantum_film/stocks.py:11.
- **8g. The client's refusals have no gate.** CLAUDE.md trap 4, docs/ATLAS.md and client.py say the client refuses a key file inside the tree and any host but the API's.
  - An offline probe (no request made) refused the key path as given, upper-cased, as an 8.3 short name, and through a `..` path.
  - It refused evil.example, //evil.example, api.mothquantum.com@evil.example and api.mothquantum.com.evil.example, each before any request.
  - The shipped code is right. No test in tests/, tools/ or verify/ exercises either refusal.
- **8h. CLAUDE.md: "0.4 ms at binary64, measured 2026-09-25".**
  - There is no VALIDATION.md entry. lead.md says the figure is WASM and that native is only believed similar.
  - Native here, through cftmpfr on the built DLL at binary64: cos 0.211 ms per element and exp 0.110 ms, over 2,000 elements.
- **Minor:**
  - The cft skip reason ("docs/ROADMAP.md: the cft parcel") and ROADMAP's P1 "Build ... cft.dll" are stale: P0 built it.
  - CLAUDE.md's build line says `all`, two lines after "Building only `cft.dll` (not `all`)".
  - STOCKS.md's Pauli figures are the 64x64 prototype at 12.5% filling, not the shelf's 16x16 at 25/256. They are labelled "prototype".

### 9. Cross-machine evidence (WSL cft2204)

Commands:
- `MSYS_NO_PATHCONV=1 wsl -d cft2204 -- bash /mnt/c/.../scripts/wsl_run.sh`:
  - a local clone of my clone into /tmp, with the SHA checked;
  - nothing installed, no system package changed.
- `MPMATH_NOGMPY=1 python3 tools/make_vectors.py --check` in WSL, and the same on Windows.

Observed:
- The host: WSL2 Ubuntu 22.04.5, kernel 5.15.153.1, glibc 2.35, Python 3.10.12, mpmath 1.4.1 (gmpy backend), numpy 1.21.5, pytest 9.1.1.
- The three golden records regenerate byte for byte, sha256 db1a0a9b..., 93a72da3... and 3af71ec3....
- `make_vectors.py --check` gives rc 0. `tests/golden` gives 34 passed in 11.7 s.
- With mpmath's pure-Python backend, `--check` passes on both hosts.

Verdict: **confirmed, as partial evidence.** This is a second OS, interpreter, mpmath version and mpmath backend: the gap DETERMINISM.md names. The limits:
- Python 3.10.12 is below pyproject's `>=3.11`. It is the only interpreter there, and nothing was installed.
- WSL2 shares this desktop's CPU.
- Only the vectors and golden ran there, not the whole front door.

### 10. Secrets and privacy (every commit)

Commands:
- `git grep -a -c -E <pattern> $(git rev-list --all)` for:
  - `moth_[A-Za-z0-9]{8,}`, X-Amz-Security-Token, X-Amz-Credential, X-Amz-Signature, amazonaws.com;
  - improperaperture, 0432e094;
  - eyJhbGci, `Bearer <12+>`, `sk-`, `ghp_`.
- Every email-like string in every commit's tree.
- Author and committer metadata; commit messages; the npz's members.

Observed:
- Across all 4 commits, 0 matches for keys, credentials, signatures, JWTs, 0432e094 and improperaperture.
- X-Amz-Security-Token appears only in export_records.py's own scan regex. amazonaws.com appears only in a public AWS price-list URL in research notes.
- The only email in any tree is quantum-bd@amazon.com, a public contact in research notes.
- The records' owner and created_by UUIDs are public engines' owners; none starts 0432e094.
- The npz holds three int64 arrays.
- All 4 commits are authored and committed as `Logan <Logan@improperaperture.com>`.

Verdict:
- **Confirmed clean** for file contents at every commit.
- **Not determined:** whether that address is the Atlas account's email. The /me body is withheld by design, though export_records.py's own pattern `logan@` suggests the same local part. If it is, it is public in every commit header whatever the scrub does.

### 11. What the brief did not ask

- **11a. The cft stage can never run in a parcel worktree.** It and `cft_smoke.py` look only at `<tree>/vendor/cft-fp256/host/cft.dll`, and ignore QF_CFT_ROOT.
  - Measured: with the DLL moved aside and QF_CFT_ROOT pointing at a built one, the stage printed "cft SKIP libcft is not built", and the run FAILED under `--require-all`.
  - So the DLL the parcels actually load is never identity-checked by any stage. The P1 and P3 briefs accept the skip.
- **11b. A stale DLL would pass.** The only identity the DLL exports is `cft_abi_version`, and the stage prints the path, not the hash. A stale DLL with the same ABI passes (FAILURE-MODES A1).
- **11c. mpmath's working precision is process-global.**
  - Measured: inside `mp.workprec(256)`, another thread's `mp.prec = 53` was in force for 200,000 of 200,004 reads.
  - `sample` computes its margin from its `prec` argument, so any concurrent mpmath user silently turns the authority into binary64 arithmetic behind a 2^-224 margin.
  - No roll changed in 8 seeds, as expected at that error level. This is a hazard for threaded callers (P1's hand-off, a parallel harness), not a P0 defect as used.
- **11d. The documented build dirties the tree.** It writes build.log into the repository root, which .gitignore does not cover. Every later run id is `+dirty`, and with 7b, dirty ids match one another.

### What I did not do

- I edited no tracked file in any repository.
- The sabotage copy, the pytest-probe directories and the attack records are deleted.
- The WSL clone in /tmp is deleted.
- The clone at `C:/Users/logan/AppData/Local/Temp/qf-verify-p0` and the probe scripts are kept, so every number above can be re-run.

## 2026-09-25 20:49Z - correction to item 1 above: the control's distance from the bound

Measured: item 1 says the uniform control "sits about 14 null standard deviations past the bound". From the same run (law_probe.py) it is (6.892 - 1.6) / 0.200 = 26.5 null standard deviations, or 12.7 of the control's own (sd 0.417). The verdict is unchanged. Also, in item 6's Version bullet, "0.1.1" is meant; it lost a closing quote.
Believed: -
For: lead

## 2026-09-25 22:59Z - re-verification of b0e9ed1: all 21 of my findings are fixed as found; four new defects, three of them new gates that miss a fault they claim

Measured: every line below except those marked believed. The fresh clone at `C:/Users/logan/AppData/Local/Temp/qf-verify-p0` was fetched to b0e9ed1. `git rev-parse HEAD` printed b0e9ed1c0d8906da9320ac043abecc10d68e2594; `git ls-remote origin` printed main = b0e9ed1; the submodule is at 7d7285d. No new build.
Believed: the error magnitude in 1 holds on other tiles (only 16x16 was measured). That no name I deleted in the scratchpad was the lead's (see "Housekeeping").
For: lead. P3 and verifier-P3 for new defect 3. P1 and verifier-P1 for new defects 1 and 2. None of it is posted to urgent/: none needs a running parcel to stop.

### New defects, first

1. **The premise gate compares the authority with itself.** The gate is `test_the_margin_dwarfs_the_arithmetic_error_along_real_rolls`.
   - An error that does not depend on the working precision is invisible to it. The test for that is to swap `mpmath.fsum` for `math.fsum` inside the new basis vector's norm, one token (`nv = mpmath.sqrt(mpf(math.fsum(a * a for a in v)))`).
   - With that slip, all 40 golden tests pass. The front door passes every executed stage: 11 of 11, with `--require-all --skip atlas` failing only on my own skip.
   - Traced boundaries: planted 256 bits against planted 512 bits differ by 2^-249, which is what the gate sees. Planted 256 bits against the clean authority's 512 bits differ by **2^-51.5 to 2^-52.9**, which is what is true. Four seeds; the scripts are `premise_blind.py` and `pb_*.json`.
   - The premise the gate reports as "headroom 2^24.8" is violated by 2^172.
   - Of five binary64 slips I planted, two were caught: the update coefficient `d`, and the Gram-Schmidt `d`, both at 2^-54.8. Those catches come from exact-zero residues flipping roundings between 256 and 512 bits, a property of this tile, not a design.
   - Two slips were inert and prove nothing: the initial weights (K_ii = N/M is dyadic) and the total (it is the integer N - j). One slip, the norm, is missed.
   - So DETERMINISM.md's "Its premise, measured" and its evidence row "mpmath is accurate enough | the premise gate above, at 512 bits" rest on a reference that shares the code under test.
   - An independent reference exists. For pauli-4x4, K is rational (entries k/16), so every chain-rule weight det(K_S+i)/det(K_S) is an exact Fraction.
2. **`PrecisionChanged` does not cover the cached basis.**
   - Tested in `precision_probe.py`: `fermi.orbitals()` is `lru_cache`d and never checks the precision.
   - A basis built while another thread held `mp.prec = 53` was cached with an orthonormality error of 1.8e-16. After that thread stopped, every roll in the process ran with no refusal. The boundaries were 2^-48.1 to 2^-48.2 from the clean authority's, over 4 seeds, and the rolls matched only because no draw was that close to a boundary.
   - The draw-loop check itself holds: 12 of 12 rolls under a thread doing `with mp.workprec(53)` in a loop were refused.
   - VALIDATION.md says "It refuses when its precision moves", but a move during the basis build is never refused. The documented rule "not to be called from threads" still stands, so this is the hole in the net under it.
3. **The guards gate misses ordinary import styles.** The gate is tests/docs/test_atlas_guards.py; the probe is `guards_probe.py`. Each of these passes it while calling Atlas at import:
   - `import quantum_film.atlas.client` followed by `quantum_film.atlas.client.call(...)`;
   - `from quantum_film.atlas.client import *`;
   - `from . import client` (a module under quantum_film/atlas/, where P3 adds modules);
   - an import inside `try`;
   - a call in a class body, in a decorator argument, or in a default argument.

   The aliased and plain from-import controls are flagged. A planted `tools/planted_probe.py` in the first style (parsed, never run) passed the docs stage. The gate's docstring, CLAUDE.md and P3's brief (line 99, "your tool included") all say it fails any such script.
4. **`--resume` crosses a changed `QF_CFT_ROOT`.** On a clean tree:
   - Run 1 (`--only lint,cft,atlas --require-all`) passed cft with the real DLL and FAILED on the atlas skip.
   - I then pointed `QF_CFT_ROOT` at a directory whose `host/cft.dll` is a text file. A fresh run with it FAILS cft ("not a valid Win32 application").
   - `--resume --only lint,cft` printed "cft ok (passed earlier in this run)", `== PASSED`, rc 0.
   - The 11a fix moved the checked DLL outside the tree that the resume key covers. This is FAILURE-MODES A3: a cache key missing an artifact the leg executes.

### Where the stray clone in moth-quantum came from: my first run

- It was my first WSL attempt, at about 20:34Z (13:34 local). The command was `wsl -d cft2204 -- bash -lc '... D=/tmp/qf-verify-p0-wsl; ...; git clone -q <my clone> $D ...; echo "rc=$?"'`.
- `wsl.exe` passes its command line through the Linux default shell. That shell expanded `$D`, still unset there, to nothing, and `$?` to 0, before `bash -lc` ran. Reproduced today with `printf`, nothing executed: the argument arrives as `git clone -q /mnt/c/.../qf-verify-p0  2>&1; cd  && ...`.
- So git cloned my clone, whose HEAD was detached at 775b5ed, into WSL's starting directory, `/mnt/c/Users/logan/source/repos/moth-quantum`.
- I read its output (`rc=0` and "not a git repository") as MSYS path rewriting, and never looked for the clone. That misdiagnosis is why my report did not list it.
- The same mechanism means the "wsl rc=0" of my pure-Python-backend WSL run was the outer shell's `$?`, not the tool's. The evidence there was the success line, which make_vectors prints only on success.
- My later WSL runs went through a script file and have genuine exit codes.

### My findings at b0e9ed1: holds, or not

- **1 holds.** `stale-last` planted in the authority, then `make vectors`, then the front door: golden FAILS with "366 of 2000 rolls lie on layouts the law forbids", and the float copy no longer matches. Two more bugs, same-u (every draw reuses u_0) and half-update, are caught through the test's own float copy. A correct-law variant (uniforms shifted by one) passes, as it must.
- **2 holds** for the margin: refusal removed, margin 0 and margin 2^-255 each fail.
  - The lead's "3 fail" and "2 fail" reproduce when planted in `margin()`. Planted in `sample`'s own `gap`, they are 2 and 1: still caught, since the planted near-tie tests pin the margin to (2^-240, 2^-200].
  - The premise gate: see new defect 1.
- **6a to 6d hold.** Checked with `fixer_attacks2.py` through the command line. Refused:
  - a duplicate key, including one nested inside the law;
  - non-canonical bytes, a BOM and CRLF;
  - a stream naming another stock, or with a `true` part;
  - a law with `true`;
  - an extra top-level key;
  - the v1 engine/job boundary shift, under v2;
  - float, bool and string crystals in `fix_device`.

  A version bump no longer breaks `reproduce`. A seed-2 roll re-sealed in the seed-1 record passes `check` and fails `reproduce`, as before and by design.
- **7a, 7c, 7d and 7e hold.**
  - `--only ""`, `,` and `" "` exit 2.
  - Two concurrent runs in one second got separate directories (pids 21778 and 21781).
  - A command line that refuses everything fails `fixer-cli`. One that crashes fails `controls` ("not with digest"). An un-tampered tampered-vector gives "NEGATIVE CONTROL DID NOT FAIL".
  - A planted skip, xfail or xpass fails its stage, and so the run, which `--require-all` now sees.
- **7b holds** for the tree: `--resume` refuses a dirty tree (rc 2), including under `MSYS_NO_PATHCONV=1`. It does not hold for the DLL: new defect 4.
- **8a holds.** README, STOCKS.md, ROUND1.md, DETERMINISM.md, ROADMAP.md, CLAUDE.md and givens.py's docstring now credit the open box, and say the shelf's law has not run on Atlas.
- **8c holds** for the eight scripts; the gate's reach is new defect 3.
- **8d holds.** A failing `tests/stray/law_test.py` fails docs.
- **8f holds.** Rule 3 is clean at b0e9ed1. On 775b5ed's tree (git archive) it lists 8, not "exactly those seven": the eighth is ROUND1.md's planned `docs/records/2026-09-26/p3`.
- **8g holds.** Both the old host-only comparison planted back and 775b5ed's own client.py fail exactly one case, `http://api.mothquantum.com/api/v1/me`.
- **8h holds.** The lead measured 0.236 and 0.119 ms; I measured 0.211 and 0.110.
- **11a holds.** The stage now checks `QF_CFT_ROOT`'s DLL: the text-file DLL fails a fresh run.
- **11b holds as printed**: the path and hash appear in the log. The lead's 6ca569a8... and my 23f0f2e6... differ in exactly 6 bytes: the COFF TimeDateStamp (offset 136), the PE CheckSum (216), and the export directory's TimeDateStamp (358,916, in .edata). A hash with those three fields zeroed would pin a build; "not pinned by hash" is a choice, not a necessity.
- **11c holds** for the draw loop; the basis is new defect 2.
- **11d holds.** `build.log` in the root leaves `git status` clean.

### The lead's three findings: all three confirmed

- 775b5ed's runner under `MSYS_NO_PATHCONV=1` stamped a dirty tree `nogit`. b0e9ed1's stamps it `b0e9ed1+dirty`.
- 775b5ed's client fails the new http test.
- 775b5ed's `tools/atlas_smoke.py` is flagged by the new gate at line 14, its module-level `call`.

### The P3 brief (sha256 5f36d74955229f8e)

- Nothing 8a-shaped remains:
  - it credits the 2026-09-25 run to the open box;
  - it names golden `pauli-4x4` as the scoring kernel;
  - it demands the QASM hash beside every score;
  - it demands a pre-submit assertion that the QASM is the module's circuit.
- Superseded by the lead's 22:52Z entry: line 26's "55 rotations" (P3 found 51), and line 33's "before fetching its result" (the status call carries the result).
- Line 99 overstates the guards gate: new defect 3.
- Its full-register `qubit_list` gives an all-Z label, for which the decode rule is plain order. That matches the two full-list known-answer runs (both read as plain order), so P3's decode rests on measurement, not extrapolation.

### Minor, and pre-existing shapes

- `--skip` of all 12 stages exits 0 ("PASSED, with 12 skipped by name"). VALIDATION.md says "zero stages run is FAILED", but skips count as run.
- The runner walks up (FAILURE-MODES C2). An export with no `.git`, committed inside another repository, was stamped with that repository's commit (fd6495a).
- Stages do not pin their test counts. `PYTEST_ADDOPTS=--ignore=tests/golden/test_golden_law.py` passes golden on 35 of 40 tests. A test that `return`s early passes. The new skip rule may steer authors toward the early return.
- `check` does not look inside `source.authority` or `code`. A golden roll with a wall-clock time in either is accepted: N1 and N2. `reproduce` then says True for N2, since it ignores `code`. A pauli roll whose authority names the binomial sampler, or is a bare string, is accepted too (N3).
- `python -m quantum_film.fixer lay pauli-4x4 1.9` ends in a ValueError traceback, not the new named refusal.

### Housekeeping, and where things are

- Nothing was created in moth-quantum. Its listing shows no entry from my session.
- **The scratchpad I was given is the lead's session scratchpad.** It holds the Atlas key files (`auth.hdr`, `moth.key`) and the lead's working directories. I read none of them; I listed names only.
- I created and then deleted these there: `sab-resume/`, `sab2/`, `pytest-probe/`, `parent-repo/`, `badcft/`, `plant.py`, `plant_float.py`, `stale_last.py`, `grain.out`, `stats.committed.json`, `o.txt`, `c1.txt`, `c2.txt`, `old_smoke.py`, `run-775b5ed.sh` and `cft.dll.aside`, which was moved back.
- Several were cleared with `rm -rf` before creation. None of those names appears in the lead's listing.
- Kept: the clone and `C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/scripts/`.
- The Atlas API was not called. No tracked file was edited in any repository.

## 2026-09-25 23:30Z - interim, third pass (5fe9741): binary64 in golden still passes every golden gate when spelled another way

Measured (clone at 5fe97411de9014f358bacb9a9eeb885004704d13; each slip planted alone in a copy under qf-verify-p0-work/sab3, then `pytest tests/golden`, 46 tests):
- 46 of 46 pass with each of: `a = mpmath.sqrt(2 / M)`; `mpmath.cos(2 * mpmath.pi * (m / L))`; the initial weights as `mpf(len(r) / M)`, `mpf(_m.fsum(...))` after `import math as _m`, `mpf(fp.mpf(...))` after `from mpmath import fp`, or `mpf(x.__float__())`; each draw's total as `mpf(_m.fsum(...))`.
- The same two inert slips spelled `math.fsum` (the lead's plants) fail the source rule, as the lead says. So the source rule reads spellings: int/int true division, a `math` alias, mpmath's `fp` context and `__float__` are all binary64 it cannot see. On today's shelf (L = 4 and 16) each of these is exact, so no output gate sees it either.
- The same respellings at non-inert places (the basis norm) are caught by the premise gates, not by the source rule.
Believed: -. Interim, written because a usage pause is expected; the full entry follows.
For: lead; P1 and verifier-P1 (P1 may import this test's references).

## 2026-09-26 00:25Z - third pass, 5fe9741: the lead's fixes hold as far as they reach; five new defects, one a regression in the front door

Measured: every line below except those marked believed. The clone at `C:/Users/logan/AppData/Local/Temp/qf-verify-p0` is at 5fe97411de9014f358bacb9a9eeb885004704d13; `git ls-remote origin` shows main = 5fe9741. Faults were planted only in `qf-verify-p0-work/sab3`, a copy that is now deleted. This pass did not touch the session scratchpad. It was interrupted by the usage pause after the 23:30Z interim, and resumed at 00:10Z after a full ledger read. The command in flight at the pause is new defect 1.
Believed: that a pip-installed quantum_film would be the one tested under `PYTHONSAFEPATH=1` (nothing is installed here, so it was not tried).
For: lead. verifier-P1 and verifier-P3 for defect 1, if they clone under %TEMP%. P1 need not stop for anything here; its references (`exact_draws`, `independent_draws`) are sound.

### New defects, first

1. **5fe9741's runner refuses any clone under %TEMP% when invoked from its `/c/...` path.** This is a regression from the C2 fix.
   - `cd /c/Users/logan/AppData/Local/Temp/qf-verify-p0 && bash verify/run.sh` gives `FATAL: git cannot read the repository at /c/Users/.../qf-verify-p0; a run id needs its commit`, rc 2. It did the same in sab3.
   - Git Bash mounts %TEMP% at `/tmp`. `git rev-parse --show-toplevel` gives `C:/Users/logan/AppData/Local/Temp/qf-verify-p0`, and the runner's `cd` then `pwd` turns that into `/tmp/qf-verify-p0`. ROOT is `/c/Users/.../qf-verify-p0`. The two strings name one directory, and the comparison says they differ.
   - Three other invocations run: b0e9ed1's runner on the same path; `make verify-quick` on the same cwd (MSYS2's make at `/c/msys64/usr/bin/make`, whose child bash spells the cwd `/tmp/...`); and `cd /tmp/qf-verify-p0 && bash verify/run.sh`, which passed 11 with atlas skipped by name, 24.9 s.
   - It is loud, not a false pass. But it breaks the front door exactly where verifiers clone.
   - `git rev-parse --show-cdup` is empty at the toplevel and needs no spelling.
2. **The source rule reads spellings.** This extends the interim.
   - Seven binary64 respellings pass all 46 golden tests:
     - int/int true division in `a = mpmath.sqrt(2 / M)`;
     - int/int true division in `mpmath.cos(2 * mpmath.pi * (m / L))`;
     - the initial weights as `mpf(len(r) / M)`, as `_m.fsum` after `import math as _m`, as `fp.mpf(...)` after `from mpmath import fp`, and as `.__float__()`;
     - each draw's total as `_m.fsum`.
   - Each is exact on today's shelf (L = 4 and 16).
   - Off the shelf, against the premise test's own `independent_draws`, three of them err (`offshelf.py`):
     - `2 / M`: 2^-49.7 at L = 12 and 2^-50.8 at L = 6;
     - `m / L`: 2^-50.8 and 2^-50.7;
     - `_m.fsum` weights: 2^-50.1 and 2^-52.2.
   - At a non-inert place (the basis norm), `_m.fsum`, `__float__` and `importlib.import_module("numpy")` are caught by the premise gates only. The source rule misses all three there too.
   - (An `fp.fsum` plant is not binary64: over mpf terms, `fp.fsum` adds in mpf. It proves nothing and is not counted.)
3. **A refusal on one side of a boundary passes every gate.**
   - Moving the margin check after the choice, a reorder of two `if` statements (`plant3c.py`), passes all 46 golden tests.
   - That copy then decides a target 2^-240 BELOW the boundary after site 0, giving `[0, 8, 9, 10, 12]`. The shipped 5fe9741 refuses the same target ("draw 0: the target lies within 2^-224 ...").
   - The planted near-tie tests plant only at or above a boundary (delta >= 0). The premise gates measure error, not decisions, so no seed count and no L = 6 reference sees this.
   - The missing control is the mirror plant: a target 2^-240 below a boundary, which must be refused.
4. **The guards gate: shapes that call Atlas at import pass it.** These were planted as real files in sab3, parsed and never run; `--only lint,docs` gave lint ok and docs "8 passed", PASSED.
   - `tools/submit_tile.py` calls `submit()` at import, imported from a wrapper `quantum_film/atlas/jobs.py`. That is P3's brief's layout: new modules under `quantum_film/atlas/`, plus a tool. Rule 1 sees no client import, and rule 2 knows only modules named client, moth or probe.
   - `quantum_film/atlas/ping.py` does `fetch = client.call` and then `ENGINES = fetch(...)` at module level. Rule 2 does not follow aliases.
   - A NEW `research/2026-09-26/probe.py`, which nothing imports, calls Atlas through a function-local import in `main()`, then calls `main()`. It is exempt from rule 1 by its stem, and rule 2 learns only module-level imports.
   - More shapes (`guards_probe2.py`):
     - rule 2 alone misses a function-local import, `c = client`, `getattr(client, "call")(...)`, and a call in a function annotation;
     - both rules miss a wrapper module, `importlib`, and curl called directly.
   - **The library exemption is a loophole.** It is the bare stem of every name any script imports, stdlib and third-party included: 28 names, among them json, math, os, subprocess, sys, numpy, scipy, PIL and quantum_film.
     - It is applied to any file anywhere under research/ and tools/, not to the file that is actually imported.
     - Today it exempts decode_rule.py, moth.py, probe.py, fermion_tile.py and grain_proto.py.
     - Every file it exempts is held only by rule 2, with rule 2's gaps above.
5. **The `--resume` fingerprint leaves out the cftmpfr binding.** The cft stage imports it from `QF_CFT_ROOT/bindings/python`.
   - The setup: `QF_CFT_ROOT` outside the tree, which is the parcels' configuration.
   - Run 1 passed cft, and FAILED only on the atlas skip under `--require-all`.
   - I then broke the copied binding's `batch.cos` by one ulp; the DLL's hash stayed 23f0f2e6....
   - A fresh run FAILS cft: "cos(1) = 0x1.14a280fb5068dp-1, expected 0x1.14a280fb5068cp-1".
   - `--resume` printed "cft ok (passed earlier in this run)", `== PASSED`, rc 0.
   - Also not recorded, read from the code and not run: the versions of ruff and pytest, which lint and every pytest stage execute.

### The lead's fixes: what holds

- **Premise gate.** It holds for what it measures.
  - My four slips (norm, update, Gram-Schmidt, `math.cos`) each fail both premise tests and the source rule. `math.cos` fails 9 tests.
  - The lead's inert pair, spelled `math.fsum`, fails the source rule.
  - **The references are independent of fermi.py's arithmetic.**
    - `exact_draws` is Fractions throughout.
    - `independent_draws` uses the closed-form kernel and Schur complements at 512 bits. It shares mpmath the library, not project code.
    - Both share only definitions: `fermi_disc`, `uniform` and the scan's decision rule. The mode order in `fermi_disc` cannot matter, since K does not depend on the basis.
  - **Two seeds of 16x16 are enough for the arithmetic slips I could build.**
    - Over 30 seeds, the per-seed error spans only 2^-248.2 to 2^-250.2, with single-pass Gram-Schmidt planted (harmless at 256 bits).
    - Every binary64 slip I planted showed on seeds 1 and 2, at 2^-51 to 2^-55.
    - I found no arithmetic slip that appears on only some draws; the draw-dependent gap is defect 3.
- **Precision checks.** A persistent move is refused, and the basis stays out of the cache.
  - A transient move is not refused. In 40 builds of the 16x16 basis beside a thread doing brief `with mp.workprec(53)` bursts, 26 cached a corrupted basis (orthonormality error 9.3e-18) and 1 was refused (`precision_probe3.py`).
  - This is what fermi.py's docstring now concedes. A timing-free defence would check the basis's content (K_ii = N/M at the working precision) before caching.
- **Minors.**
  - All 12 stages skipped: rc 1, "no stage ran (a skip is not a run)".
  - An export inside another repository runs as `...-nogit`, and `--resume` there is refused.
  - `PYTEST_ADDOPTS` set to `--ignore=tests/golden/test_golden_law.py`, and to `-p no:python`: golden ran 46 of 46 both times.
  - Other environment inputs:
    - `PYTHONOPTIMIZE=1` and `=2` cannot neuter a stage: a planted failing test still fails, because pytest rewrites its asserts;
    - `PYTHONSAFEPATH=1` drops the tree from sys.path, and golden and fixer FAIL with ModuleNotFoundError here;
    - the others I considered (colours, `PYTHONWARNINGS=error`, `PYTEST_DEBUG`) can only fail a run.
  - Fixer: N1 (a wall-clock time in `authority`), N2 (one in `code`), N3 (the wrong sampler named) and N3b (a bare string) are now refused. A1-A8, A10 and N7-N9 are still refused. A3, A9 and N4-N6 are accepted by design, as documented.
  - `lay pauli-4x4 1.9` and `lay pauli-4x4 x` give "REFUSED: a seed is an integer", rc 2. A bad stock (`lay nosuch 1`, `lay speckle 1`) still ends in a traceback, rc 1, whose last line names the reason.

### The lead's intended fix: an exact reference on L = 6

- **Tried before it exists.** `lsix_probe.py` is an exact Fraction chain rule on L = 6, r2 = 1, over 5 seeds. The clean authority errs 2^-251.6 against it.
- **It exposes every slip in my interim:**
  - `2 / M`: 2^-52.3;
  - `m / L`: 2^-52.0;
  - the four initial-weight respellings: 2^-52.2 each;
  - the total via `_m.fsum`: 2^-53.3.

  I had predicted the total would stay inert, and I was wrong: near a power of two, the binary64 sum rounds an ulp low.
- **What it misses.**
  - A cosine table rounded to binary64 (`mpf(fp.mpf(mpmath.cos(...)))`): 2^-252.7 on L = 6, whose cosines are dyadic. The 16x16 reference catches it at 2^-51.2, so keep that reference beside L = 6.
  - Defect 3, which is about decisions, not arithmetic; it needs the mirror plant.
  - The transient-precision cache.
- **The source rule** as a cheap first line that says what it cannot see: agreed.

### Housekeeping

- Deleted: sab3, the copied CFT root, the nested-export repo and attacks2.
- Kept in `qf-verify-p0-work/`: the plant scripts (`plant3.py`, `plant3b.py`, `plant3c.py`, `break_binding.py`) and `scripts/`.
- Nothing was written to the session scratchpad or to moth-quantum. No tracked file was edited. The Atlas API was not called.

## 2026-09-26 04:12Z - fourth pass, 900b9e5 + 1a92c62 + 73a79af: the fixes hold for every fault I planted before; the import allowlist does not hold

Measured: every line below. The clone at `C:/Users/logan/AppData/Local/Temp/qf-verify-p0` is at 73a79af2632a87d1d711548c9939274ba21e9f49 (`git ls-remote` agrees). Faults were planted only in `qf-verify-p0-work/sab4`, now deleted. The shared scratchpad was not used, the Atlas API was not called, and no tracked file was edited. Not interrupted.
Believed: -
For: lead. The round is paused and no parcel is running, so nothing went to urgent/.

### Defects, first

1. **The import allowlist passes code that runs at import.** The gate is tests/docs/test_atlas_guards.py.
   - **Executed.** I planted five lint-clean modules under tools/. The whole front door passed: 11 passed, atlas skipped.
   - Importing each one as a module (`__name__` not `__main__`) then ran its effect, with markers under qf-verify-p0-work only:
     - a bare `@register` decorator, whose body writes a file;
     - a class statement that fires `__init_subclass__`, which writes a file;
     - `operator.call(subprocess.run, ARGV)`, which runs a subprocess;
     - `list(itertools.starmap(subprocess.run, [(ARGV,)]))`, which runs a subprocess;
     - `math = subprocess` after `math` was used, then `math.run(ARGV)`, which runs a subprocess.
   - **Parsed only, never run.** 17 shapes carrying `client.call(...)` pass `problems()`, while the controls with explicit calls are flagged (`guards_probe3.py`). Beyond the five above:
     - `functools.reduce(client.call, [...])`;
     - `sorted(key=<impure>)`;
     - a lambda's default argument (ruff's B008 catches this one);
     - `re.sub` and `mpmath.quad` given a lambda;
     - `collections.defaultdict(<impure>)[0]`;
     - a metaclass keyword;
     - an Enum member's `__str__` reached through `str()`;
     - `math.fsum = client.call`;
     - `typing.get_type_hints` evaluating a string annotation;
     - `__name__ = "__main__"` before the refusal;
     - `import antigravity`, the stdlib module that opens a web browser.
   - **Four mechanisms:**
     - calls with no call expression: a decorator's application, class-creation hooks, dunders reached through allowed builtins, a subscript;
     - impure callables passed by reference into "pure" modules' higher-order functions;
     - names tracked from import statements only, not from assignments;
     - import statements skipped.
   - False as tested:
     - CLAUDE.md's "An import runs nothing but pure construction, or is refused";
     - the gate's "Importing a module runs nothing that could reach Atlas";
     - the allowlist's "calls that cannot reach a network, a process or a file".

   A syntactic list cannot close all four. A behavioural check could: import each module in a child process under an audit hook (PEP 578's `sys.addaudithook` sees subprocess, socket and open-for-write events however they are spelled).
2. **The basis content check sees norms only.**
   - A drop confined to the angle `2 * mpmath.pi * m / L` leaves cos² + sin² = 1. I stood in for it with π taken at 53 bits, as the gate's own test stands in with a binary64 sqrt (`angle_probe.py`).
   - The rows' squared norms held N/M to 2^-258.4, so there was no refusal, and the basis was cached with its kernel 2^-56.1 off the closed form.
   - Transient bursts are now caught: 40 of 40 refused and none cached (`precision_probe3.py`; it was 26 of 40 cached before).
3. **The resume fingerprint still leaves out the import path.**
   - With `PYTHONSAFEPATH=1` (the tree dropped from sys.path), a fresh run FAILS golden with ModuleNotFoundError.
   - `--resume` of an ordinary run, with the variable set, gives golden "passed earlier in this run", PASSED, rc 0.
   - Also unrecorded, read from the code: PYTHONPATH, and the machine.
   - CLAUDE.md's "python and its packages" records only mpmath and numpy.
4. **`fixed_at` is a shape check.** `2026-13-45T99:99:99Z` and Arabic-Indic digits pass as "a UTC time"; the regex is `\d`. A local-emu roll still keeps `fixed_at = 5` and an unknown source field, because the new rules apply to device kinds only.
5. **CLAUDE.md's import paragraph** lists 1a92c62's function allowlist ("Path, re.compile, lru_cache, ..."), not 73a79af's pure modules, and is false per defect 1.

### Confirmed

- **1 and 7.** The SHA is as above. The front door runs from both spellings of the clone under %TEMP%, from `/c/...` and from `/tmp/...`: 11 passed, atlas skipped. The logs show golden 50, fixer 47, docs 7 and client 9. An export nested inside another repository runs as `nogit` from both spellings.
- **3. The premise gate.**
  - Every slip from my third pass now fails:
    - `2 / M`, `m / L` and `len(r) / M` fail the L = 6 reference;
    - the alias, `fp.mpf` and `__float__` weights, and the aliased total, fail it and the source rule.
  - The clean authority on L = 6 errs 2^-251.0 over the test's 10 rolls, as claimed.
  - New slips spelled past the source rule are caught too:
    - the cosine table rounded to binary64 through int/int (on 16x16, orthonormality and the closed form; also on L = 6, because it truncates);
    - the cosine table at 17 digits (on 16x16);
    - the initial weights at 17 digits (on L = 6);
    - `operator.truediv(2, M)` (on L = 6).
  - None of my 11 plants passed the L = 6 reference, the 16x16 reference and the source rule together.
- **4. Mirror plant and basis check.** My reordered refusal now fails `test_a_target_just_below_a_boundary_is_refused_too`. Removing the basis content check fails its test.
- **5. Fingerprint.** My one-ulp binding break is refused on resume ("this environment is not the run's"). The environment records the binding's hash and ruff 0.11.9 / pytest 9.1.1.
- **6. The fixer.**
  - A device roll with 0, 4 or 6 crystals is accepted, and a golden roll with 4 is refused.
  - `occurrences` 1 and 4096 are accepted; 0, 4097, `True`, `1.0`, `"1"` and -3 are refused.
  - An unknown device field is refused.
  - A `kind` re-sealed from atlas-emu to qpu is accepted, as documented.
  - The commitment's docstring says the anchor binds.
  - `fixer lay nosuch 1`, `lay speckle 1` and `lay pauli-4x4 1.9` each give `REFUSED`, rc 2.
- **8. Documents.** DETERMINISM.md's new claims match what I measured: the L = 6 reference, the two-sided plant, and norms-only content. For CLAUDE.md, see defects 3 and 5.

## 2026-09-26 07:09Z - fifth and final pass, the lead's commits since 73a79af (2df3112, 4ff989b, bda92eb, 04fe2fe, 709055b): one claim false as stated, the rest holds

Measured: every line below. Fresh clone of origin/main at `qf-verify-p0-work/fresh5`: 709055bb8e1fde7e049e78b9e19495f62d0767e4 (git ls-remote agrees), submodule 7d7285d, libcft built there by the documented line (7.6 s, 0 warnings, 122 exports). Faults were planted only in a copy (`sab5`), now deleted. Nothing was written to the lead's tree or the shared scratchpad. The atlas stage was left to skip by name, as the coordinator's correction asked. Not interrupted.
Believed: -
For: lead.

### The defect, first

- **VALIDATION.md (709055b), line 966, is false as stated:** "The worst error in (boundary - target), in units of u: binary32 4.6e-7, binary64 1.7e-15, binary128 1.3e-33."
  - These are absolute errors, not multiples of u. In units of u they are 7.7, 15.3 and 13.5.
  - Measured with P1's own plain chain (`sampler.roll(..., certify=False, fmt=f, trace=...)`) against the authority's traced boundaries and targets, over 40 pauli-4x4 streams (`scripts/units_probe.py`). The worst errors:
    - binary32: 4.97e-7 absolute, 8.3 u (u = 2^-24);
    - binary64: 1.07e-15 absolute, 9.7 u (u = 2^-53);
    - binary128: 6.42e-34 absolute, 6.7 u (u = 2^-113).
  - Read as the entry states it, binary32's worst error would be about 2.7e-14. That is below binary32's own rounding, and it contradicts the entry's next line ("each format parts inside its own error").
  - The label is P1's (P1.md lines 139 and 148), and the entry copies it. It traces to the ledger, but it is not true as stated. VALIDATION.md is append-only, so an appended correction closes it.

### My fourth-pass defects: all five closed as found

- **D1, imports.** My five executed shapes, planted lint-clean under tools/, fail the docs stage. `import_audit.py` names each one:
  - the decorator and `__init_subclass__`: "open for writing";
  - `operator.call`, the rebound `math` and `starmap`: "subprocess.Popen".

  No marker file was written, so each effect was stopped, not merely seen. At 4ff989b the audit gives 34 modules, 19 clean and 15 refused, as the entry says. This pass re-ran my own faults only, and did not search for new shapes past the hook.
- **D2, basis.** My 53-bit-pi stand-in is now refused ("the basis: K(0, 1) is not its closed form to 2^-240"), and the cache stays empty. Transient bursts are refused 40 of 40.
- **D3, fingerprint.** `--resume` refuses `PYTHONSAFEPATH=1` and a set `PYTHONPATH` ("this environment is not the run's"), and resumes in the same environment. The fingerprint hashes every installed distribution's name and version, and records the machine.
- **D4, fixed_at.** Month 13 and Arabic-Indic digits are refused. A local-emu roll with `fixed_at = 5` and an unknown field is refused on both counts.
- **D5.** CLAUDE.md's import paragraph now describes the behaviour gate and states its limit (only the branch an import takes on this machine).

### What else holds

- **The front door at 709055b.** 12 passed, atlas skipped by name, 52 s. The logs show pinned 357, golden 51, circuits 57, fixer 49, docs 9, client 9 and decode 5, which sum to 537. `make test`'s single session over tests/ passes 537 in 40 s. The quick budget with `--require-all` passes 11 in 49 s (the docs say ~55 s).
- **The `pinned` stage.** With `QF_CFT_ROOT` at a directory without libcft, the quick budget prints "pinned SKIP libcft is not built at ..." and ends "PASSED, with 1 skipped by name". `--require-all` turns that into FAILED, rc 1. Both are as CLAUDE.md and the README say.
- **2df3112.**
  - Nothing calls `run_job`; P3's tool POSTs through `client.call`.
  - The rule's literal appears in code only as `decode.DECODE`. A test spells it by hand, on purpose, as its known answer.
  - A basename clash planted at `tests/pinned/test_uniform.py` fails docs. So removing P1's own check (04fe2fe) lost nothing.
- **bda92eb.** Every figure reproduces from the committed records alone, through the shipped decoder and the golden kernel (`scripts/p3_rescore.py`):
  - the QASM's SHA-256 is `ed767c01bd4b851d`, and this machine's givens_line lays it byte for byte: 51 rotations in 15 layers, 102 CX;
  - 4,096 layouts, all of 5 crystals;
  - one-site max |z| 1.48; pairs 2.52, chi² 112.3/120;
  - orbits: chi² 33.7 on 33 dof;
  - 0 of the 1,360 forbidden layouts appear;
  - ⟨XX⟩ 0.3755 and ⟨YY⟩ 0.3687 on (0, 1), against an exact 0.375 (= 2K₀₁);
  - all 1,995 rolls pass main's fixer.
- **04fe2fe and 709055b, figures against P1.md and verifier-P1.md.** Each traces: 2,300 and 740 rolls; binary32 on 5,800, and binary64 and binary128 on 2,300 (P1's correction, lines 268-271); 0.62x / 0.69x CPU / 3.5x and 302 calls; 0.22-0.61 of a core; clearances 2.0e8 and 2.1e5; the control's 2.8e-17 to 3.4e-16; 10 of 11 faults; 600/600 and 60/60 (v); 0 outside on 300 streams; 317 problems for N3b; N3m (F about 2^-36; 2^-44 gives 2 wrong sites); 1 in 10^6 (P1's belief); and 539 less 2, which is 537. "2.5-3x" matches certificate.py's docstring (P1.md says 2.8x).
- **Code the docs describe.** TAU = 2^-200. L = 6 is refused by name ("the pinned path needs L a power of two"). ROUND1.md's "for that roll" matches the hand-off.

### Minor

- README's "about 1e-6 to a boundary, relative": P1.md gives 1.2e-6 without a unit; "relative" is the lead's addition.
- CLAUDE.md's "`ndarray.ctypes.data` (2 us)": P1 measured about 2.5 µs for a whole one-element call with the pointer passed as an int, not the attribute's cost.

**Verdict: NOT READY.** One claim is false as stated: VALIDATION.md line 966, "in units of u", where the figures are absolute errors of about 7-15 u. An appended correction closes it. Every fourth-pass defect is closed as found, and nothing else failed.

## 2026-09-26 07:17Z - the correction at 283330c: true as stated; PASS

Measured: every line below. The fresh clone `qf-verify-p0-work/fresh5` is at 283330c66e12d4fea488ee2218ab97ad386d9fbb (`git ls-remote` agrees). The only thing read in the shared scratchpad was `p1-work/format_error.py`; nothing was written there. I ran a copy of it from my own work directory, `scripts/format_error_copy.py`, with only its two paths changed (diffed).
Believed: -
For: lead.

- **"Units of u" is (boundary − target) / (N − j): true.**
  - P1's script computes `abs(...) / (len(order) - j)` and prints "(boundary - target) / (N - j), i.e. in units of u". Its closest-approach figure is divided the same way.
  - Its copy, run on 283330c's code over P1's streams (200 pauli-4x4, 20 pauli), gives:
    - pauli-4x4: 4.57e-7, 9.59e-16 and 6.02e-34, closest 2.73e-6;
    - pauli: 4.32e-7, 1.65e-15 and 1.31e-33, closest 1.18e-6.

    These are P1.md's figures, rounded as P1 rounded them.
  - In unit roundoffs, 4.6e-7·2^24, 1.7e-15·2^53 and 1.3e-33·2^113 are 7.7, 15.3 and 13.5, as the entry says.
  - My absolute figures are quoted as I measured them.
- **The control's distances are absolute: true.**
  - `Plant.distance` is `abs(u - u_star) * (N - j)`, which is |exact target − exact boundary| (control.py, whose dataclass comment says so).
  - `report_control` prints it first, and `distance / boundary_value` in brackets.
  - P1.md's six rows span 2.8e-17 to 3.4e-16 absolute, and 3.0e-17 to 4.1e-16 relative, as the correction says.
- **No other doc line carries either label.**
  - `git grep` finds "units of u", and the "(relative)" distances, only in the append-only P1 entry (VALIDATION.md lines 959 and 966-968) and in the new entry that corrects them (lines 1038-1056).
  - README line 77 now reads "of the weight left to draw".
  - CLAUDE.md's ctypes line keeps only P1's measured 5 µs an operand.
  - The remaining "relative" hits are P1's ladder and table headers in quantum_film/pinned, where the bracketed figure is the relative one.
- **The quick budget at 283330c is green.** `--budget quick --require-all`: 11 passed, 0 skipped, 60 s (docs 9, golden 51, pinned 357, fixer 49).

**Verdict: PASS.**
