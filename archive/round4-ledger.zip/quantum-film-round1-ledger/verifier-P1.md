# verifier-P1

## 2026-09-26 04:32Z - verifier-P1 on 857065b: every roll I drew is the authority's, the named control fails as it must, and the merge is clean on three mains; but the hand-off turns a later TieRefusal into a false EnclosureBroken, six faults of the brief's named kind pass every gate, and six round-to-nearest respellings pass the source rule

Measured: every line below except those marked believed. None of it is copied from P1. My clone is
C:/Users/logan/AppData/Local/Temp/verify-p1 (`git rev-parse HEAD` = 857065ba05bb576fc81c4ad7617763cc23297744, clean),
cloned from the lead's repository. Host: Windows 11 22631, i5-12400F, Python 3.12.9, numpy 2.2.6, mpmath 1.3.0 (gmpy).
libcft: the lead's build, loaded only, QF_CFT_ROOT=C:/Users/logan/source/repos/moth-quantum/vendor/cft-fp256 (ABI 0.14,
sha256 6ca569a8e4668706...). Faults were planted only in copies made by `git archive 857065b` (no repository) under
C:/Users/logan/AppData/Local/Temp/verify-p1-work/sab/; merges only in a scratch clone, verify-p1-merge. Scripts and logs are in
verify-p1-work/scripts and verify-p1-work/logs. Main moved twice while I worked (73a79af, then 2df3112 at 04:00Z, then bda92eb
at 04:25Z), and I merged onto all three. Not interrupted.
Believed: only the lines marked so.
For: lead, P1

### Defects, first

**D1. After a draw the certificate hands off, a refusal by the authority at a LATER draw comes back as EnclosureBroken,
not TieRefusal.** The error names a certificate defect that did not happen.
- The cause is sampler.py `_hand_off`, line 233: `if len(order) < j or order != decided[:len(order)]`. Once golden has drawn
  past the hand-off draw j, `order` is longer than `decided`, so the comparison is always unequal. Only `order[:j]` is the
  certificate's.
- Command: `python scripts/refusal.py <clone>` (logs/refusal-857065b.txt). Each case plants an earlier draw 2^-100 below its
  own boundary: the authority decides it, and the certificate hands the roll off there. A later draw is then planted
  2^-240 either side of a boundary, which the authority refuses. On pauli-4x4 the boundaries are exact (the lead's
  kernel); on pauli they are golden's 256-bit trace.
- Result: golden raises TieRefusal and the pinned path raises EnclosureBroken, in **21 of 21** such cases.
  - pauli-4x4: 17, over draw pairs (0,1), (0,4), (2,3), streams verify-p1 0-2, both sides.
  - pauli: 4, over the pair (3,20), streams verify-p1 0-1, both sides.
  - Example: "the authority refused draw 1, after the certificate had decided draws []; draw 0: ...".
- The claim broken is the brief's "the authority's refusals must survive", and sampler.py's point 3 ("its refusals
  (TieRefusal, PrecisionChanged) propagate"). No answer is returned, so nothing wrong is laid.
- It matters in practice because callers that catch `golden.TieRefusal` do not catch this error: P1's own control.ladder
  and measure.py are two of them.
- No gate sees it. P1's refusal tests plant at draw 0 only, where `decided` is empty and `order` is too.
- Believed: it cannot happen at random, since it needs a hand-off (P1 believes about 1 in 10^6 16x16 rolls) followed by a
  refused draw.

**D2. Six faults of exactly the brief's named kind pass EVERY gate: a bound computed under the wrong rounding attribute.**
P1's report says "each certificate step is held to exact arithmetic" and the certificate's docstring says each step's claim
"is held to exact rational arithmetic on wide synthetic boxes". That holds for the faults P1 planted, which change a term
wholesale. It does not hold for a one-ulp wrong direction, for three reasons:
- The accumulations in `decide` and `extend` belong to no step function, and no step test holds them.
- Inside a step, P1's random wide boxes leave the bound slack, and the slack hides a wrong direction.
- The source rule allows every directed function everywhere, so it cannot see a direction at all.

The shipped code is right. I read every directed call in certificate.py (lines 86-257) and the sampler's `bounds64(u)`,
and each points the right way. The gap is in what the gates can see. The six, with the tight input on which each breaks
its own claim (logs/unsound.txt, logs/unsound2.txt):

| fault (file: change) | every gate | on a tight input |
|---|---|---|
| certificate.decide: `b_lo = bd.scan_hi(c_lo)` (lower boundaries scanned up) | passes | 256 tight weights x 200: `locate` certifies a WRONG position for 9 of 50,696 targets placed just above an exact boundary (e.g. 153 for 154) |
| certificate.extend: `s_lo = bd.add_hi(s_lo, sq_lo)` | passes | s_lo 2.8e-17 above the exact sum it bounds below |
| certificate.extend: g0, qf, df accumulated with `bd.add_lo` | passes | qf 7.5e-37 below the exact squared Frobenius norm of Q_lo it bounds above |
| certificate.gram_bound: every node rounded down | passes | F 2.8e-17 below the norm of E for a basis in the box (k = 1, D parallel to q_lo) |
| certificate.inner: radius `r` rounded down | passes | the upper bound of <phi, q> misses the exact greatest by 5.6e-19 (phi in [0, 0.1], q in [1, 1.1]) |
| sampler.roll: `cert.decide(j, idx, *bounds64(u)[::-1], trace)` (u's bounds swapped; outside the source rule's reach) | passes | the target enclosure misses u*S beyond its TAU padding in 569 of 20,000 tight trials |

"Every gate" means all of the following:
- G1, the runner's pinned stage: 130 passed.
- G2, equality with the authority on stream("verify-p1", stock, k): 300 pauli-4x4 and 8 pauli rolls, crystals and draw order.
- G3, exact containment, no slack, on those 300 pauli-4x4 rolls, against the lead's exact kernel (main's
  test_golden_premise.py, reimplemented in my eq.py).
- G4, 31 planted streams: 2^-240 either side of a boundary at draws 0, 2 and 4; 2^-100 either side at draws 0 and 3;
  2^-44 to 2^-48 either side at draws 1 and 4; and pauli draw 5.

The real stocks hide each of these only because their enclosures carry slack: c_lo sits about 1e-14 below each weight.
Nothing in the pinned path keeps that slack larger than a wrong direction's error, and nothing sees it go.

**D3. The source rule passes six respellings of a round-to-nearest conversion.**
- Command: `python scripts/rule_bypass.py <clone>` (logs/rule_bypass.txt). Each candidate is appended to certificate.py's
  source and run through the rule's own `violations()`, as its planted tests are.
- These PASS, and each rounds:
  - item assignment of a Fraction into a float64 array, `z[0] = Fraction(1, 3)`: off by 1.9e-17;
  - slice assignment, `z[:] = Fraction(N, M)`;
  - `np.array(Fraction(1, 3), np.float64)`, with the dtype passed POSITIONALLY (only `dtype=` is refused);
  - the same with the builtin `float` as the positional dtype;
  - `float.fromhex('0x1.999999999999999ap-4')`: fromhex's argument is never checked, and 68 significant bits round;
  - `np.where(c > 0, c, 10000000000000001)`: an integer past 2^53 promoted to float64, off by 1.
- A wrong direction (`bd.add_lo` where `add_hi` is meant) passes by design (D2).
- The rule's own controls (`dtype=`, the literal 0.1) are still refused, and it reads the shipped certificate as clean.
- So the certificate docstring's "a rounding slip spelled some new way is refused too" does not hold. The first two are the
  natural way to write an exact rational into an array.

**D4 (minor). The pinned caches are writable, and a caller that mutates them gets wrong rolls with no refusal.**
- `certificate.enclosure()` and `basis.basis()` are `lru_cache`d, and they return numpy arrays with `writeable` True.
  sampler.py's `__all__` exports both.
- With rows 0 and 5 of the cached pauli-4x4 enclosure swapped in place, 69 of 300 rolls came back unequal to the authority's
  with no refusal, 34 were refused (EnclosureBroken) and 197 were right (logs/cache_mut.txt).
- golden.orbitals returns tuples for exactly this reason: "so no caller can mutate a shared entry".

**D5 (minor). A stream that is not bytes gets a pinned roll where the authority raises.**
- pinned/uniform.py hashes `bytes(stream_bytes)`, and `bytes(5)` is five zero bytes.
- For stream 5, golden raises TypeError and the pinned path returns [3, 5, 8, 11, 15]. For [1, 2, 3], golden raises and the
  pinned path returns [1, 2, 6, 7, 14]. A bytearray is fine on both (logs/misc.txt).

**D6 (minor, for the integrator).**
- `make verify-quick` now runs pinned too. The Makefile's help line, README.md:89 and CLAUDE.md:9 still list the budget
  without it, and still say "~30 s"; I measured 32-41 s.
- P1's own basename check (test_pinned_source_rule.py) duplicates main's registry gate since 2df3112.

### What was asked, item by item

1. **The branch: CONFIRMED.**
   - Six commits (e65e98c, 7226be9, bc57a57, 7df5961, 19cc5ab, 857065b), linear on b0e9ed1.
   - `git diff --stat b0e9ed1 857065b`: 20 files, +3,034 -1.
   - Every commit's `--name-status` touches only quantum_film/pinned/, tests/pinned/ and verify/run.sh; nothing in golden/,
     stocks, fixer, atlas/ or circuits/.
   - verify/run.sh: `pinned` added to BUDGET_QUICK, one need_file line, and the stage pair after fixer and before fixer-cli.
   - `bash verify/run.sh --budget quick`: passed 11, 32 s, pinned "130 passed in 8.28s".
   - `--only pinned,cft`: passed 2. cft names the lead's DLL, sha256 6ca569a8e4668706...
   - Without QF_CFT_ROOT: "pinned SKIP libcft is not built at vendor/cft-fp256 ...", PASSED; with --require-all, FAILED.
   - `python -m pytest -q` (make test): 236 passed.
2. **Equality on my own streams: CONFIRMED** (logs/eq-4x4.txt, logs/eq-16.txt). Draw order is read by my own trace watcher.
   - pauli-4x4, stream("verify-p1", "pauli-4x4", 0..599): 600 of 600 equal in crystals AND draw order, 0 hand-offs.
     3,000 certified draws; widest enclosure 6.03e-14; tightest clearance 5.2e9 widths.
   - On the first 300 of them, against the lead's exact kernel: the draws are equal, and 0 exact targets or boundaries lie
     outside the enclosures, with no slack.
   - pauli, 0..59: 60 of 60 equal, 0 hand-offs. 1,500 certified draws; widest 3.77e-11; tightest clearance 5.2e5 widths.
3. **The certificate's soundness: 24 faults of my own** (logs/sab-all.txt, one copy each; P1's sabotage scripts are in the
   shared scratchpad, which I did not open). Nine pass every gate:
   - six are D2's table;
   - two are sound, so passing is right. The target's products rounded the other way, and u rounded to nearest, missed u*S
     in 0 of 20,000 tight trials each: TAU's directed subtraction steps a whole ulp, which absorbs half an ulp in u;
   - one is NOT DETERMINED: the Gram off-diagonal sum rounded down held on both of my tight inputs.

   The other fifteen are caught:

   | fault | caught by |
   |---|---|
   | TAU added on the low side, subtracted on the high | the target step test (1 test) |
   | TAU = 2^-230 | the TAU pin (1) |
   | F in plain numpy arithmetic | the source rule (1) |
   | the hand-off audit disabled | the two audit tests |
   | locate compares the next boundary | 14 tests; and on my plants it ANSWERS 13 of 31 streams golden refuses |
   | locate's "passed" by lower bounds | the locate step test only (1) |
   | uniforms little-endian, or the separator between stream and index dropped | 15 tests each, equality (0 of 300 equal), exact containment |
   | the total's ends swapped in decide | 7 tests; 1,213 exact values outside; answers where golden refuses |
   | the projection's ends swapped in decide | 6 tests; EnclosureBroken |
   | sqrt(2/M)'s upper bound rounded down | the basis-orbital test (2) |
   | the shim's RDN and RUP numbers swapped | 39 tests; the enclosure's own N/M check |
   | the shim's flag refusal removed | the shim's flag test (1) |
   | P1's "inner radius dropped" and "TAU = 0" | one step test each, and every end-to-end gate passes, as P1 reports |

   The brief's list: the target's attributes swapped (sound, above); TAU direction and scale (caught); F rounded
   down (passes: D2) and in numpy (caught); the audit disabled (caught); off-by-one boundaries (caught); libcft's SHA-256
   against hashlib (caught everywhere).
4. **The control and the refusals: CONFIRMED except D1** (logs/control_check.txt, logs/refusal-857065b.txt).
   - P1's named control reproduces P1's six rows exactly: the same draws, boundaries, distances (2.8e-17 to 3.4e-16) and
     binary64 errors. Hand-off removed DISAGREES on all six; shipped agrees, handed off at the planted draw.
   - On seven streams of mine (verify-p1 pauli-4x4 0-4, pauli 0-1): DISAGREES on 7 of 7 and agrees on 7 of 7.
   - On all eight pauli-4x4 plants, the lead's exact kernel lays the authority's roll and not plain binary64's.
   - My ladder (item 8) shows plain binary64 deciding 1e-14 and 1e-15 as the authority does, so the brief's 1e-14 control
     could not fail, as P1 said.
   - 2^-240 either side of a boundary, with no earlier hand-off:
     - pauli-4x4, every draw 0-4, streams verify-p1 0-2, both sides: TieRefusal from both, 29 of 29;
     - pauli, draws 5 and 24, streams 0-1, both sides: 8 of 8;
     - one pauli-4x4 plant (draw 4, +) was not a valid u: its boundary is the total. Both sides raise ValueError there.
   - 2^-100 (decided by the authority): 8 of 8 handed off and equal to its roll.
   - With an earlier hand-off: D1.
   - PrecisionChanged (logs/precision.txt). A uniform function moves mpmath's precision at draw 1:
     - with no hand-off, golden raises PrecisionChanged and the pinned path returns [6, 11, 12, 13, 15], the exact chain's
       roll. It does not use mpmath, so I read this as by design, not a defect;
     - with a hand-off at draw 3, PrecisionChanged propagates.
   - So the pinned path never returned an answer where golden raised TieRefusal, in 68 planted cases.
5. **The shim: CONFIRMED** (logs/shim_check.txt).
   - Prototypes: all 18 bound functions' argtypes and restype equal my own transcription of cft.h. size_t is 8 bytes and
     every pointer is c_void_p.
   - The audit refuses ABI 0.13 and 1.14, op 25 named "sum", and format 1 named "fp128" (a proxy over the real DLL).
   - Flags refused by name: 1/0, sqrt(-1), 1e300*1e300, inf-inf, 0*inf, an overflowing dot, cospi(inf).
   - Not refused, by IEEE: a quiet-NaN or infinite operand (no flag) and underflow. Only a flagged call can make one inside
     the pinned path.
   - Threads: cft calls and sha256 from a worker raise ThreadRefusal; sampler.roll from a worker refuses by name.
6. **The source rule:** D3.
7. **Timings: CONFIRMED, under load** (logs/timing-*.txt, scripts/timing.py). Interleaved stream by stream in one process,
   neither traced, caches warmed first:
   - pauli, 40 rolls with golden first in each pair: golden median 361 ms and pinned 236 ms, ratio 0.655; CPU means 93 and
     60 ms, ratio 0.647.
   - pauli, 40 rolls with pinned first: ratio 0.653 by wall, 0.698 by CPU.
   - pauli-4x4, 400 rolls: pinned 3.6x slower by wall (9.6 against 2.7 ms). Its CPU ratio is not meaningful: process_time
     ticks at 15.6 ms.
   - Load, sampled every 2 s (logs/load-during-timing.txt): mean 70%, range 49-93%, 8 Python processes from the other
     agents. Wall time is again about 4x CPU time.
   - "Faster than the authority on the 16x16 stock" holds: 0.65x, against P1's 0.62x at 4-17% load.
8. **The precision ladder: CONFIRMED on P1's row** (logs/ladder-pauli-1.txt). pauli seed 1, draw 24, boundary 128 (P1's
   boundary). My own plants, u = B(1 +- d)/(N - j):
   - binary32 parts from 1e-7;
   - binary64 from 1e-16;
   - binary128 from 1e-34;
   - each on the - side only.
   The certified roll equals the authority's on all 32 plants and hands off from 1e-14.
9. **The merge: CLEAN and green on all three mains.** Scratch clone verify-p1-merge; `git merge 857065b` had no conflict;
   the only shared file, verify/run.sh, auto-merged. Each run used QF_CFT_ROOT and `--require-all`.
   - Onto 73a79af (9a014a8): quick budget 11 passed, 0 skipped, 40 s; docs 7 passed (the import rule and the registry);
     one pytest session over tests/: 255 passed.
   - Onto 2df3112 (65013ce): 11 passed; 257 passed (the basename gate included).
   - Onto bda92eb (cb082e8), today's main: 11 passed; docs 9 passed, with 4ff989b's import audit under a PEP 578 hook,
     which enumerates quantum_film/pinned; pinned 130 passed; one pytest session: 310 passed.
   - P1's tests hold against main's golden (trace=, margin(), PrecisionChanged, the basis checks).
10. **Else:** D4, D5 and D6.
    - P1's figures that I reproduced: 130 tests; +3,034 -1; 236 in make test; the control table; 0 hand-offs at random.
    - Its hand-off rate "about once in 10^6" is marked believed, and I did not test it.

### What I did not do

- I fixed nothing, pushed nothing, called no Atlas API and used no amd-arc-box.
- I never opened the shared scratchpad, so P1's p1-work/ scripts (sabotage3.py, stepcatch.py, bypass.py, timing.py) went
  unread and unrun. Every number above comes from my own scripts. The harness kept my backgrounded commands' output under
  the session's tasks/ directory, beside the scratchpad.
- I wrote nothing in the lead's tree or in P1's worktree. The cft stage imported cftmpfr from the lead's vendor/cft-fp256
  in my first runs, before I set PYTHONDONTWRITEBYTECODE. `find vendor/cft-fp256 -newermt "2026-09-25 20:55"` lists
  nothing: its .pyc files date from 12:47 local, and nothing was written.
- I did not run measure.py at P1's scale, nor on another host or CPU, nor an L that is not a power of two (refused by name,
  as P1's test holds).
- Kept: my clone (857065b, clean), the merge clone (branches trial73, trial2df, trialbda; local, unpushed), and
  verify-p1-work/ with scripts/, logs/, the sab/ plant copies and main73/ (git archive 73a79af).

NOT READY: every roll I drew is the authority's and the merge is clean on 73a79af, 2df3112 and bda92eb. But the hand-off turns a later TieRefusal into a false EnclosureBroken (D1, a small fix plus a planted test). And six faults of the brief's own named kind (D2), and six round-to-nearest respellings (D3), pass every gate that P1's report says holds them; each needs a gate, or a stated limit, before merge.

## 2026-09-26 05:38Z - verifier-P1 re-check of 3c29f3a: D1-D5 are fixed as found, my seven certificate faults are all caught, and the merge onto bda92eb is clean and green; but seven new faults pass every gate (two in inner's reductions, five in the orchestration or a new helper), each unsound on a tight input, and five respellings pass the new allowlist

Measured: every line below except those marked believed. My clone C:/Users/logan/AppData/Local/Temp/verify-p1 is at
3c29f3a35bdb4fd69a05a4c3ed1c0410245308f1 (fetched from the lead's repository, branch worktree-agent-acba6146d975d5e26), clean.
Host and libcft are as in my 04:32Z entry (the lead's build, sha256 6ca569a8...). Faults were planted only in `git archive
3c29f3a` copies under verify-p1-work/sab2/, and the merge was made only in the scratch clone verify-p1-merge. Main is bda92eb,
unchanged since 04:25Z. Scripts are in verify-p1-work/scripts (sab2.py, unsound3.py, rule_bypass2.py, refusal.py, eq.py,
control_check.py, timing.py) and logs in verify-p1-work/logs (r2-*, sab2-*). Not interrupted.
Believed: only the lines marked so.
For: lead, P1

### Defects, first

**D7. `inner`'s two reductions over q are held by no gate.**
- check_inner's families where the radius matters are all one-entry (N = 1). Its one multi-entry family (C) is a point,
  where both radius terms are 0.
- So two wrong operands pass it, and the flip gate cannot generate either:
  - B1a: `wmax = w[0]`, the first entry's width, not the widest;
  - B1b: `qabs = magnitudes(q)[1][0]`, the first entry's magnitude, not the largest.
- Both pass every gate: the pinned stage (274 passed), ruff, 300 of 300 pauli-4x4 and 8 of 8 pauli rolls equal in crystals
  and draw order, 0 exact values outside the enclosures on 300 streams, and 31 of 31 planted streams.
- Both are unsound on a two-entry input (logs/r2-unsound3.txt):
  - B1a returns [0.25, 0.25] where the exact range of <phi, q> is [0.25, 0.75];
  - B1b returns [-0.0625, 0.0625] for [0, 1].
- So "every directed call ... held on tight inputs" holds for the calls, not for inner's step as a whole. The docstring says
  "a bound on the wrong side of its exact value shows however it was spelled"; that needs inputs that reach the fault.

**D8. The orchestration is held by its spelling only, and a fault in what it composes passes every gate.**
- The docstring: "Certificate and enclosure only compose steps ... An interval passes from step to step whole, so its two
  ends cannot be swapped between them."
- What the rule does refuse there: bd, np, subscripts, stars and unpacking. I confirmed each.
- What it allows: tuples, float literals, calls to any defined function, and new top-level helpers. The orchestration rule
  does not read a helper.
- Each fault below keeps every text that P1's tests plant into present exactly once (why: "incidental" under Minor).
- Each passes every gate above, ruff included, and each is unsound on a tight input (logs/sab2-kept.txt,
  logs/r2-unsound3.txt):

| fault (in the orchestration unless named) | on a tight input |
|---|---|
| B2b `factors = gram_factors(0.0)`: P1's own "Q^T Q taken for I" (P1.md 01:43Z: every end-to-end gate passed it), re-planted one line up | c's enclosure misses the exact weight by 2.3e-13 (a column with norm^2 = 1 + 2^-40) |
| B2a_kept: the Gram sums reset to (0.0, 0.0, 0.0) after every draw (a missing term: they never accumulate) | the same |
| B4b_kept: u's box collapsed to its lower end, `ub = uniform_box(u)`, `target((lower(ub), lower(ub)), last(b))` | the target misses u*S beyond TAU in 270 of 20,000 trials |
| B4c_kept: q's width dropped before `inner`, `inner(self.e, (lower(q), lower(q)))` | [0.125, 0.125] for an exact [0, 0.625] |
| B6_kept: u's ends swapped by a two-line helper `ends(x)`, called as `target(ends(uniform_box(u)), last(b))` | misses in 569 of 20,000; the rule's violations() is [] |

- So the ends CAN be swapped between steps: by a helper, which holds no directed call and so is no step, and sits outside
  the orchestration, so its subscript is allowed.
- An interval can also be collapsed (`lower` and a tuple), or a step fed a literal.
- Only the rolls see what is composed. P1's own matrix showed they cannot see a fault that stays within the enclosures' slack.
- Caught, for balance:
  - B5, an accumulation split across two step calls, its upper end fed the new square's lower end: the N - j audit
    (EnclosureBroken) and 10 tests;
  - B3a, the column appended before its Gram terms: 29 tests (every roll hands off);
  - B3b, times_positive's operands swapped in enclosure: the orbital test.

**D9. Five respellings pass the new allowlist** (scripts/rule_bypass2.py, logs/r2-rule_bypass.txt). Each is appended to
certificate.py's source and run through the rule's own violations(), as its planted tests are. Each passes, and each rounds:
- R1: a method keyword, `w.max(initial=Fraction(1, 3))`. The rule checks keywords on numpy calls, not on METHODS.
  Off by 1.9e-17.
- R2: a default argument `trace=float.__mul__`, then `trace(x, y)`.
  - A parameter named trace is allowed, and so is any attribute of `float` other than a fromhex call.
  - `np.ndarray.__add__` passes the same way.
  - Off by 2.8e-17.
- R3: an integer name rebound past 2^53 one operator at a time, `k = 94906267`, `k = k * k`, then `np.where(c > 0, c, k)`.
  Off by 1. The rule says "no integer that meets a float can round"; that holds per expression, not per name.
- R4: a NamedTuple field declared `N: int` that holds a float, then `b.N * 3`. Every `.N` or `.M` on a name counts as an
  integer. Off by 5.6e-17.
- R5: R1 with R3's integer, `w.max(initial=k)`. Off by 1.

Inside a step, the tight check sees such a rounding, as P1 says: my R2 planted in `accumulate` fails its check. In a helper or
the orchestration, nothing behavioural looks (D8).

**Minor.**
- `bounds64` is a directed call the rule allows anywhere. The gate that every directed call sits in a checked step reads only
  `bd.` attributes.
- A caller can switch a cached array's write flag back on (numpy lets the owner). The fix stops accidental writes, which is
  what D4 was.
- Incidental catches: four of my first-run plants (B2a, B4b, B4c, B6, as first written) failed only P1's orchestration-rule
  tests. Each had deleted or changed the line those tests plant into, so `SOURCE.count(old) == 1` failed; the rule did not
  see the fault. The same tests will fail on any refactor of those lines. The results above are from anchor-preserving
  versions.

### What was asked, item by item

1. **The two commits: CONFIRMED.**
   - 1c2c2c4 (D1, D5) and 3c29f3a (D2-D4), linear over 857065b.
   - 11 files, +1,171 -496. Only quantum_film/pinned/, tests/pinned/ and one line of verify/run.sh (the pinned stage's
     description).
   - At 3c29f3a:
     - `bash verify/run.sh --budget quick --require-all`: passed 11, pinned "274 passed in 16.28s";
     - `--only pinned,cft`: passed 2;
     - `python -m pytest -q`: 380 passed.
2. **My tools: each now fails where it passed.**
   - D1, refusal.py (logs/r2-refusal-3c29f3a.txt): the 21 later refusals that came back as EnclosureBroken are now
     TieRefusal on both sides, 21 of 21. 66 of 66 valid cases agree; my two invalid plants (u >= 1) raise the same
     ValueError on both.
   - D2: my seven, in their new homes, each fail the pinned stage (logs/sab2-all.txt):
     - A1 lower boundaries scanned up, A2 s_lo accumulated up, A3 the Gram sums accumulated down, A4 gram_bound rounded down,
       A5 inner's radius rounded down: each its step's tight check;
     - A6a uniform_box's ends swapped: its check and P1's swap test;
     - A6b the swap by a subscript in decide: the orchestration rule;
     - A7 the Gram off-diagonal rounded down: gram_terms' check and its flip test.
     Each still passes equality, containment and my planted streams: the step checks are what see them.
   - D3: all six of my first pass's respellings are refused by name.
   - D4:
     - the swap raises "assignment destination is read-only";
     - 9 of 9 cached arrays are read-only;
     - 0 of 100 rolls are unequal afterwards.
   - D5: an int, list, str, None and float stream each raise TypeError on both paths, by name on the pinned side. A bytearray
     and a memoryview give the authority's roll.
3. **P1's claims.**
   - "Every directed call lives in one of 18 steps": CONFIRMED as counted. I counted independently: 69 `bd.` calls in 17
     functions, plus uniform_box's bounds64. "Held on tight inputs": not for inner's reductions (D7).
   - "Certificate and enclosure only compose steps": CONFIRMED as spelled. What they compose is held by the rolls alone (D8).
   - "69 of 69, and 17 of 17": CONFIRMED. The gate's 86 tests are among the 274 that pass at 3c29f3a, and each mutant loads
     and fails its step's check.
   - "The undetermined seventh is caught": CONFIRMED (A7).
   - My faults of the five kinds asked for, beyond the flip gate:

| kind | fault | result |
|---|---|---|
| wrong operand | B1a, B1b (inner's reductions) | pass every gate (D7) |
| wrong operand | B1c times_positive's negative branch takes a_lo | caught: its check, and the orbital test |
| missing term | B2a_kept, B2b (the Gram) | pass every gate (D8) |
| missing term | B2c gram_bound without its D^2 term | caught: its check |
| wrong order | B3a, B3b | caught (above) |
| padding dropped | B4a TAU dropped in target | caught: its check |
| padding dropped | B4b_kept (u's box), B4c_kept (q's width) | pass every gate (D8) |
| accumulation split | B5 | caught: the N - j audit and 10 tests |
| ends swapped by a helper | B6_kept | passes every gate (D8) |

4. **The allowlist: D9.** Five respellings pass it.
5. **The merge onto bda92eb: CLEAN and green.** Scratch merge 3a50a26, no conflict; verify/run.sh auto-merged.
   - `--budget quick --require-all` with QF_CFT_ROOT: passed 11, 46 s; docs 9 passed, pinned 274 passed.
   - One pytest session over tests/: 454 passed.
   - tests/docs/test_atlas_guards.py: 3 passed.
   - My own run of main's import_audit.py over P1's ten modules: all "ok", with no effect under the audit hook.
6. **Else.**
   - Equality at 3c29f3a on my streams (logs/r2-eq-3c29f3a.txt):
     - pauli-4x4, stream("verify-p1", ...) 0..599: 600 of 600 equal, 0 hand-offs;
     - on 300 of them, 0 exact values outside the enclosures;
     - pauli 0..59: 60 of 60 equal.
   - The named control: 13 of 13 as in my first pass. Hand-off removed DISAGREES; shipped agrees, handed off at the planted
     draw.
   - Timing, 30 pauli rolls each way, interleaved, load 1-12%: pinned/golden 0.669 and 0.663 by wall time, 0.663 and 0.668
     by CPU. The restructure costs nothing measurable.
   - D6 (the budget lines and P1's duplicate basename check) remains the lead's, untouched by P1.

### What I did not do

- I fixed nothing, pushed nothing, called no Atlas API and never opened the shared scratchpad.
- I wrote nothing in the lead's tree or in P1's worktree. The runs set PYTHONDONTWRITEBYTECODE, and nothing under the lead's
  vendor/cft-fp256 was written.
- I did not re-run the precision ladder or measure.py; the plain chain is unchanged by these commits.
- Kept: my clone (at 3c29f3a, clean), the merge clone (local branch trial2-bda, unpushed), and verify-p1-work/ with scripts/,
  logs/ and the sab2/ plant copies.

NOT READY: D1-D5 are fixed and the merge is clean, but P1's two new claims overreach again: inner's reductions (D7) and whatever the orchestration or a new helper composes (D8) are held by no gate, and seven unsound faults pass every gate; each needs a gate (multi-entry boxes in check_inner; a closed, named helper set) or a stated limit before merge.

## 2026-09-26 05:40Z - for P1's third round: a closed helper set closes one of D8's five faults; the other four use only lower, a tuple or a float literal, and the end-to-end gates passed them

Measured (logs/sab2-kept.txt, 05:34-05:37Z, at 3c29f3a):
- B6_kept (u's ends swapped by a new two-line helper) is the only D8 fault that adds a top-level function. A closed, named
  helper set closes it.
- The other four add no function. Each uses only what such a set keeps: the existing helper `lower`, a tuple display, or a
  float literal. None needs a subscript, a star, an unpacking, bd or np:
  - B2b: `gram_factors(0.0)`;
  - B2a_kept: `self.g = (0.0, 0.0, 0.0)` after every draw;
  - B4b_kept: `target((lower(ub), lower(ub)), last(b))`;
  - B4c_kept: `inner(self.e, (lower(q), lower(q)))`.
- Each passed all of these, and each is unsound on a tight input (my 05:38Z entry, D8):
  - the pinned stage (274 passed) and ruff (rc 0);
  - 300 of 300 pauli-4x4 and 8 of 8 pauli rolls equal;
  - 0 exact values outside the enclosures on 300 streams;
  - 31 of 31 planted streams.
- So a stated limit that reads "in the orchestration, the rule and the end-to-end gates are what hold" would not be
  accurate for these four. The end-to-end gates did not hold them, as they did not hold P1's own "Q^T Q taken for I"
  (P1.md 01:43Z).
- An accurate limit would say it: a step fed a collapsed interval or a literal by the orchestration is seen only if it moves
  a roll, and within the enclosures' slack it moves none.
Believed: refusing tuple displays and float literals in the orchestration, and holding `lower` to its one call site, would
close all four. `self.g = (0.0, 0.0, 0.0)` in `__init__` would then move into a helper, and an integer 0 in place of 0.0 is
refused at run time by bounds (int64 is not binary64). Not tried.
For: P1, lead

## 2026-09-26 06:24Z - verifier-P1's third pass, 6dcd5a1: D7 and my five D8 faults are closed, R1-R5 are refused, and the merge onto bda92eb is green; but the end-to-end check reads decide's trace, not its decision, so a decision spelled within the rule passes every gate while certifying the wrong site

Measured: every line below. My clone C:/Users/logan/AppData/Local/Temp/verify-p1 is at
6dcd5a16efda71d546568bde390d9f4a575bc902 (one commit over 3c29f3a, fetched from the lead's repository), clean. Faults were
planted only in `git archive 6dcd5a1` copies under verify-p1-work/sab3/. The merge was made only in the scratch clone
verify-p1-merge. Main is bda92eb. Scripts are in verify-p1-work/scripts (sab3.py and sab3_faults.py, probe3.py,
probe_n3b.py), logs in verify-p1-work/logs (r3-*, sab3-*). Not interrupted.
Believed: -
For: lead, P1

### Defect (one)

**D10. The end-to-end check holds decide's trace record, not its certified position.**
- orchestration_problems calls `cert.decide(...)` and reads only what decide passes to `trace`. It ignores decide's return
  value, the position the sampler draws from. It then extends by the plan's site.
- The fault, N3b, is two lines in decide, after the honest trace. It is spelled within the rule, and the rule's violations()
  on it is [] (logs/r3-probe3.txt):
  - `unsound = gram_factors(gram_bound(gram_zero()))`;
  - `found = locate(t, boundaries(weights(select(self.e.norm, idx), select(self.s, idx), unsound)))`.
  So decide returns a position certified on weights that ignore the Gram factor: P1's own "Q^T Q taken for I".
- N3b passes every gate (logs/sab3-n3b-summary.txt):
  - ruff (rc 0) and the pinned stage (346 passed), including the rule, the end-to-end check, the control, the refusals and
    the ladder;
  - 300 of 300 pauli-4x4 and 8 of 8 pauli rolls equal, and 0 exact values outside the enclosures on 300 streams;
  - 31 of 31 planted streams.
- It certifies the wrong site on a tight input (logs/r3-probe_n3b.txt).
  - The input is P1's family G plan 0 at draw 1, with the target planted a quarter of the way into the 1.64e-12 gap between
    N3b's boundary 0 and the exact one.
  - N3b returns position 1, where the exact chain rule's is 0; the shipped decide returns None and hands off.
  - P1's orchestration_problems, run on that same plan and uniform, reports 0 problems for N3b.
  - On P1's own three families it reports 0 problems too. There N3b's returned positions are right on 210 of 210 decides,
    because no family plants a target near a boundary.
- So two statements are false as written:
  - the test's docstring: "at each decide, the boundaries, the target and the certified position" are held;
  - P1.md 06:05Z: "every claim held to the exact chain rule in Fractions".
  What is held is the position decide traces, and nothing holds that it equals the one decide returns.
- certificate.py's limit attributes an orchestration fault's escape to what it "moves ... on the end-to-end check's inputs".
  For decide's certified position that is not the reason: the check does not read it, on any input.
- What would close it, believed and not tried:
  - orchestration_problems holds decide's return: None, or the exact position cleared by TAU, and equal to the traced one;
  - a tight family plants a target inside the Gram factor's reach, as above.
  Or the limit states it: decide's certified position is held only as traced, and a decision that differs from its trace
  is held by the rolls alone.

### Minor (recorded, not blocking)

- R1 respelled with a positional initial, `w.max(None, None, False, Fraction(1, 3))`, passes the rule and rounds (off by
  1.85e-17). Planted in inner's wmax it is caught: every roll hands off, and 28 tests fail. This is inside D9's stated limit.
- certificate.py says of the closed file "anything else is refused". A method added to Located or Enclosure passes the rule
  (violations() is []); the rule's own docstring fixes only Certificate's methods. Calls to such a method are refused unless
  it takes a METHODS name, and then only steps and helpers may call it. Wording only.

### What was asked, item by item

1. **D7: CLOSED.**
   - B1a (`wmax = w[0]`) fails inner's tight check through the new Wm family, and 2 more tests.
   - B1b (`qabs = magnitudes(q)[1][0]`) fails inner's tight check through Qm.
   - The first-entry gate covers inner's two `.max()` reductions.
   - Clearance's builtin `min` and `max` (diagnostics) are not in that gate. Replaced by their first entries they still fail
     check_clearance: 63 and 101 problems (logs/r3-probe3.txt).
2. **D8: my five CLOSED; same-kind faults inside the rule are caught unless they stay out of the trace (D10).**
   - B2a_kept, B2b, B4b_kept, B4c_kept and B6_kept, as I planted them: each fails the rule's
     test_the_certificate_does_only_what_the_allowlist_names. Each fails the end-to-end check too, in families G and Q,
     or G, Q and U. Each still passes the rolls, as before.
   - Within the rule, all caught by the end-to-end check (G and Q), all still passing the rolls:
     - N1, the Gram sums fed `gram_zero()` every draw;
     - N2, `gram_factors(gram_bound(gram_zero()))`.
   - N3b is D10.
3. **D9: R1-R5 CLOSED.**
   - My R1-R5 and my first pass's six D3 respellings are all refused, each for its own reason (logs/r3-rule_bypass.txt).
   - The stated limit is accurate for the rule, the steps and the helpers. It is not accurate for decide's certified position
     (D10).
4. **The merge onto bda92eb: CLEAN and green.** Scratch merge 43f1203, no conflict; verify/run.sh auto-merged.
   - `--budget quick --require-all` with QF_CFT_ROOT: passed 11, 45 s; docs 9 passed, pinned 346 passed.
   - One pytest session over tests/: 526 passed.
   - tests/docs/test_atlas_guards.py: 3 passed.
   - main's import_audit.py over P1's ten modules: all "ok".
- Also, at 6dcd5a1:
  - `--budget quick --require-all`: passed 11;
  - `--only pinned,cft`: passed 2;
  - make test: 452 passed;
  - my equality run: 600 of 600 pauli-4x4 and 60 of 60 pauli rolls equal, with 0 exact values outside on 300 streams;
  - the named control: 13 of 13;
  - the refusals: 66 of 66 valid cases as the authority's.
  No correctness defect in the shipped code.

### What I did not do

- I fixed nothing, pushed nothing, called no Atlas API and never opened the shared scratchpad.
- I wrote nothing in the lead's tree or in P1's worktree.
- Kept: my clone (at 6dcd5a1, clean), the merge clone (local branch trial3-bda, unpushed), and verify-p1-work/.

NOT READY: the shipped code is correct and the merge is green, but P1's report and the orchestration test's docstring say the end-to-end check holds decide's certified position, and it holds only the trace (D10, N3b); a few lines in orchestration_problems, or one stated limit, close it.

## 2026-09-26 06:50Z - verifier-P1's final pass, b7cb207: D10 is closed (the check now holds the decision decide returns), both minors are closed, the docstring and the corrected line are accurate, and the merge onto bda92eb is green; READY

Measured: every line below. My clone C:/Users/logan/AppData/Local/Temp/verify-p1 is at
b7cb207726b4ac105b88191acaed8332bda44cd4 (one commit over 6dcd5a1, fetched from the lead's repository), clean. Faults were
planted only in `git archive b7cb207` copies under verify-p1-work/sab4/. The merge was made only in the scratch clone
verify-p1-merge. Main is bda92eb. Scripts are in verify-p1-work/scripts (sab4.py, sab4_faults.py, probe4.py), logs in
verify-p1-work/logs (r4-*, sab4-*). Not interrupted.
Believed: -
For: lead, P1

### Defects

None by the bar (lead.md 05:39Z, 06:44Z, the latter written at 06:40Z):
- no correctness defect in the shipped code;
- no claim false as stated;
- no fault that passes every gate outside every stated limit.

The shipped code is identical to 6dcd5a1 apart from certificate.py's docstring (an AST comparison of all eight modules,
docstrings aside). At 6dcd5a1 my 600 + 60 rolls, the named control (13 of 13) and the 66 refusal cases all held. At
b7cb207 the unplanted base again gives 300 + 8 equal rolls, 0 exact values outside the enclosures, and 31 of 31 planted
streams.

### Minor (recorded, not blocking)

- **N3m, which I built to evade the ladder, passes every gate, inside P1's stated limit.**
  - It returns the decision certified without the Gram factor only where the Gram bound F is below 2^-40 on an M = 16
    tile. The condition is `holds(factors, Fraction(N, N + 1))`, with 2^40 built one operator at a time from self.M.
  - Spelled with every anchor kept (N3m_kept), it passes the rule, ruff, the pinned stage (359 passed), 300 + 8 equal
    rolls, 0 outside on 300 streams, and 31 of 31 planted streams.
  - It gives 0 problems on P1's families: family G's F is about 2^-36, and Q and U carry no planted targets.
  - On a family like G whose columns are off orthonormal by 2^-44 (F 2.3e-13), laddered with P1's own machinery, it gives
    91 problems and certifies 2 wrong sites (e.g. position 1 where the exact chain rule's is 0). The shipped code gives 0.
  - So the ladder reaches only the Gram bound family G has. This is exactly what certificate.py's limit says: a fault
    passes only if it moves none of the claims above on the end-to-end check's inputs.
  - A laddered family with a small F would narrow it. Believed; not tried in P1's tree.
- A field added to Located (an annotation only) passes the class-shape rule. That rule fixes a class's body to fields,
  not which ones. Located's two-argument construction would then fail on every roll, so it cannot pass silently.
- Carried from 06:24Z: clearance's builtin min and max (diagnostics) are not in the first-entry reduction gate, which
  mutates `.max()` calls. Replaced by their first entries they still fail check_clearance.

### What was asked

1. **D10: CLOSED.** orchestration_problems now holds the position decide RETURNS. I read decision_problems: the returned
   position must equal the traced one; be None, or the exact position with a gap above TAU; be None within TAU of a
   boundary; and not be None where the target clears every boundary by 1e-7. On family G's first three plans decide is
   also asked about targets planted either side of every exact boundary at nine relative distances, from 0 to 1e-6.
   - P1's own figures, recounted with its machinery (logs/r4-probe4.txt):
     - N3b: 317 problems on G, 43 of them wrong sites and 219 returned-not-traced; 0 with the ladder off; refused by the
       rule;
     - N3e: passes the rule, and gives the same 317;
     - N3d: 4,996 problems, caught with the ladder off too.
   - My decision faults, each run through every gate (logs/sab4-all.txt):
     - my N3b as written: the rule refuses it (`found` assigned twice), and family G's check fails it;
     - my own second-name N3e: rule passes; G's check fails it (317);
     - N3h, the unsound decision only where the honest one hands off: rule passes; G's check fails it (317);
     - N3i, the unsound decision traced AND returned: rule passes; G's check fails it (98);
     - N3m_kept: Minor above.
     Each also leaves the rolls, containment and the planted streams untouched, as N3b did. The returned decision's check
     is what sees them.
   - Why the ladder is enough where it reaches: a decision taken by locate is monotone in the target. So any wrong site
     certified at a laddered draw is also certified at that draw's probe 2^-210 from the exact boundary. The check's hits
     bear this out: 43 wrong sites for N3b, all on probes.
2. **The two minors: CLOSED.**
   - Refused by the rule:
     - `w.max(None, None, False, Fraction(1, 3))`: "a method max with more positional arguments than 0";
     - `w.ravel(0)`;
     - a method in Located, and a staticmethod in Enclosure: "body is more than its fields";
     - a statement added to EnclosureBroken.
   - The shipped certificate has no violation.
3. **The texts: ACCURATE.**
   - certificate.py's docstring now names what the check holds: the traced boundaries and target; the returned decision
     with its four conditions; the state after each extend; the ladder on family G.
   - Its limit ("a fault passes only if it is spelled past the rule AND moves none of the claims above on the end-to-end
     check's inputs") matches every result above, N3m's included.
   - P1.md 06:39Z's correction of its 06:05Z line is accurate, and so are its counts (317, 317, N3d, the single-assignment
     refusal).
4. **The merge onto bda92eb: CLEAN and green.** Scratch merge c822b9b; no conflict; verify/run.sh auto-merged.
   - `--budget quick --require-all` with QF_CFT_ROOT: passed 11, 51 s; docs 9 passed, pinned 359 passed.
   - One pytest session over tests/: 539 passed.
   - tests/docs/test_atlas_guards.py: 3 passed.
   - main's import_audit.py over P1's ten modules: all "ok".
   - At b7cb207 alone:
     - `--budget quick --require-all`: 11 passed (pinned 359);
     - `--only pinned,cft`: passed 2;
     - make test: 465 passed.

### What I did not do

- I fixed nothing, pushed nothing, called no Atlas API and never opened the shared scratchpad.
- I wrote nothing in the lead's tree or in P1's worktree.
- D6 remains the lead's, at the merge.
- Kept: my clone (at b7cb207, clean), the merge clone (local branch trial4-bda, unpushed), and verify-p1-work/.

READY TO MERGE: D1-D10 are closed as found, the shipped code is correct, every claim checked is accurate, what passes every gate (N3m) lies inside P1's stated limit, and b7cb207 merges cleanly onto bda92eb with every gate green.
