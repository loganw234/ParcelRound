# verifier-P2

## 2026-09-25 23:30Z - verifier-P2 on 78f35d3: the shipped pinned chains are the same bits wherever I ran them, but the replay cannot see libm on a scalar, NaN dials leak, supplied sheets are under-checked, and the readers accept pinned=True

Measured: everything below except the lines marked believed. Every number was re-run by me on my own clone
(C:/Users/logan/AppData/Local/Temp/verify-p2; `git rev-parse HEAD` = 78f35d34c0a2b43b8357e15c8b0cef6eae802bad, parent
be1d674; `atlas_film.__file__` printed inside it, and P2's conftest asserts it). None is copied from P2.
Host: Windows 11 22631, Python 3.12.9, numpy 2.2.6 (MSVC), mpmath 1.3.0. libcft: moth-quantum/vendor/cft-fp256/host/cft.dll,
ABI 0.14, sha256 6ca569a8e46687067ead78a23e09f27f0046aad27cbbec37e2699937ca2bb218. Second host: WSL cft2204 (Python 3.10.12,
numpy 1.21.5, glibc 2.35, the same CPU), clones in /tmp, removed.
Believed: NaN bits on AArch64 and RISC-V (from their default-NaN rules; not run); a big-endian host (not run).
For: lead, P2; P1 and verifier-P1 (what a replay cannot see); the owner (sheet= before Quantum-Film supplies sheets)

### Defects, listed first

**D1. The determinism gate (the libcft replay) does not see libm applied to a scalar, a constant, or the binary32 narrowing's output.**
The replay makes only ARRAYS opaque (CV). A libm call on a Python float (a stock constant, a dial after `P.number`, or
a value taken out through the sanctioned `scalar()` exit) runs identically on both backends and passes.
`CftOps.to_f32` returns a plain float32 ndarray, neither CV nor Left: an exit the Left mark does not cover.
Plants, each in a copy, run through tests/test_pinned_is_pinned.py (70), tests/test_pinned_replay.py (36) and
`tools/pinned_measure.py replay` (51 chains):

| plant | source rule + 48 digests (70) | replay tests (36) | 51 chains |
|---|---|---|---|
| A: `[math.log10(float(r[0])) for r in rows]` in films._density_pinned (+ `import math`) | 70 passed | 36 passed | all identical |
| C: `math.exp(math.log(P.number(contrast, ...)))` in processes._fraction_pinned (+ `import math`) | 70 passed | 36 passed | all identical |
| B: `p = math.exp(-scalar(o, lam))` in pinned.poisson_thresholds (+ `import math`) | 69; only pinned.py's import list fails | 36 passed | all identical |
| K2: `np.emath.power(np.float32(10.0), -o.to_f32(x))` in films._transmit_pinned | 69; only the `transmit` chain digest fails (its bits moved) | 36 passed | all identical |
| N: `o.array(np.asarray(np.emath.power(np.e, o.leave(x))))` in pinned.exp | exits rule + 21 digests fail | 35; only the ulp-accuracy test fails | all identical |

- A and C pass every gate. B passes the replay and every digest, the five count-law tables included; only pinned.py's
  import list stops it, and films.py and processes.py have none.
- So the brief's trap ("a pinned function that reaches libm ... only the libcft replay notices") is closed for
  arrays, not for scalars and constants. Overstated: "a libm call hidden anywhere inside cannot even execute there"
  (pinned.py, pinned_oracle.py, test_pinned_replay.py, PINNED.md, the commit message).
- Not in the shipped code: an AST walk of every pinned function finds no Python-level float arithmetic, only integer
  arithmetic, exact conversions and `max(ss, sb)`.

**D2. The source rule misses libm and reductions reached by other names, and on CI (no libcft) nothing else stops them.**
It flags `np.<name>` for a fixed list and checks imports in pinned.py only. Not flagged: `math.*` (A, C), `np.emath.*`
(K2, N), `np.add.reduce` (plant H2, in the RGB projection) and `np.vecdot` (plant M; numpy >= 2.0). H2 and M passed all
70 travelling tests; only the libcft replay caught them (PinnedLeak).

**D3. Non-finite dials are not refused, and the output is NaN whose bits are the machine's.**
- `process_print(..., pinned=True)` with contrast=nan: 48 of 48 values NaN, bits 0xffc00000. contrast=inf: 48 NaN,
  0x7fc00000. dmax_mul=nan: 48 NaN, 0xffc00000. pitch_um=nan with a supplied sheet: all NaN (print 0xffc00000,
  negative 0x7fc00000).
- PINNED.md's contract refuses "non-finite inputs | NaN has no portable bit pattern". Believed: a NaN made by an
  invalid operation has the other sign on AArch64 (positive default NaN), and RISC-V never propagates one (canonical
  NaN), so these outputs are not the same bits there.
- coat(pinned=True) with ceiling=nan, grain_um2=nan, grain_um2=0 or ceiling=-1 is refused, but as "the aggregate
  regime is not pinned yet", with "nan", "nan", "inf" and "-12 crystals per cell at this pitch": the wrong name.

**D4. A supplied sheet is checked for dtypes, shapes, cell count and negative counts only; four malformed sheets print wrong without a word.**
On a 16-cell pinned silver sheet (kmax 37), each accepted by `process_print(..., sheet=..., pinned=True)`:
- pads past K set to 0 instead of 65535: `develop_on` counts 16 developed crystals at p = 0.01 where the true sheet gives 2;
- K[0] = kmax + 50: the 50 crystals beyond the threshold columns can never develop;
- thresholds with 0 columns and K > 0: nothing ever develops;
- K[0] = 2**31 as int64: develop_on's int32 cast gives a developed count of -2,147,483,648 at p = 1. K[0] = 2**32 + 3
  as uint64: count 3.
Also accepted: a 3-tuple (the third element ignored). P2's claim (floor, dtypes, shapes, negative counts) is accurate
as stated. The pad rule, K <= columns and the int32 range are what Quantum-Film's sheets would trip next round: a
sheet builder that pads with np.zeros prints wrong on every cell.

**D5. The readers accept pinned=True and return per-machine numbers without refusing.**
sensitometry.density_curve, exposure_scale, contrast_index and dmax_reached forward `**kw` to process_print, then apply
np.log10, np.interp and np.gradient to the pinned prints. exposure_scale('salt', pinned=True) = 1.9016988639538703
(default 1.901699104595858); contrast_index('silver', pinned=True) = 1.778868805268928. The brief: what is not reached
refuses by name in pinned mode and never approximates; PINNED.md says the readers "have no pinned=". The functions
without the keyword raise TypeError (normal_exposure, normal_highlight, characteristic, reciprocity,
granularity.density_field, develop_on, pigments.tricolour_print, papers.paper_print): refused, but not by the
"not pinned yet" name.

**D6 (minor). contrast <= 0 is not refused, and there the pinned model is not the default's.**
`power`'s precondition y > 0 is not enforced; it takes 0**y = 0. At zero dose, pinned silver at contrast=0 reads
[0.984, 0.984, 0.980] (the base); the default reads [0.0078, 0.0078, 0.0078] (0**0 = 1, so dmax). At contrast=-1:
pinned the base, default 0.

**D7 (minor). Overstatements and slips.**
- PINNED.md: fed float32 negatives, the pinned and default prints "differ there by up to 8 float32 ulps". Measured on
  128x128 negatives uniform on [0, 3], every process, contrast 1.0 and 1.4: up to 13 (silver at 1.4); 8-10 at 1.0.
- The Random123 known answers are at tests/kat_vectors on main, not examples/kat_vectors (the test's comment; the
  brief says the same).
- The commit message's "none of 481,336 float32 densities and reflectances" should read 482,336 (122,880 +
  3,000 + 344,064 + 4,200 + 8,192), which is what PINNED.md's tables and my re-run count.
- "the Poisson law's ordering, which the binary64 tables keep here": over 7 processes x 7 exact pitches, 9 of 49
  table pairs (dmax_mul 1.1 against 1.0) have a tail entry (k 31-41) where the larger lambda's T[k] is ABOVE the
  smaller's, so a cell can lose a crystal as dmax_mul rises, with probability at most 1.15e-14 per cell. P2 wrote that
  nothing guarantees it; this is its size.
- The travelling digests hash native-endian bytes (`tobytes()`). Believed: a big-endian IEEE host fails all 48 while
  computing the same values.
- The flush-to-zero control is Windows-only (MSVC `_controlfp`); CI's Ubuntu never runs it.
- A nit: an exposure E given as a 0-d array is refused ("takes a number for the exposure E, not ndarray"), where the
  default path takes it.

### Confirmations

1. **The commit: CONFIRMED.** Parent be1d674; 14 files, +4304 -12, the 14 P2 lists. An AST comparison of every top-level
   item of films.py, processes.py, emulsion.py and colour.py at be1d674 against 78f35d3, with docstrings, the `pinned`
   parameter and the `if pinned:` blocks removed: 0 changed, 0 removed. Added: only `_characteristic_pinned,
   _density_pinned, _negative_pinned, _transmit_pinned` and `_fraction_pinned, _reflectance_pinned, _print_pinned`.
   No module-level statement changed (the pinned imports are inside functions). Nit: `transmit(D, pinned=False)` is
   positional-or-keyword; every other entry's keyword is keyword-only.
2. **The suite: CONFIRMED.** With QF_CFT_ROOT: "253 passed in 25.92s". Without it: "217 passed, 36 skipped in 14.47s",
   every skip "libcft is not available, so the replay cannot run: QF_CFT_ROOT is not set ...". ruff: "All checks passed!".
3. **The replay: CONFIRMED as far as it reaches (D1, D2).** `pinned_measure.py replay`: 51 chains, all identical in
   bits and in trace; 27,761 rounding calls, 28,481,356 element-operations, 13.9 s. Plants caught:
   - `u ** y` (D), np.log1p (E), np.expm1 (F), np.mean (I), np.dot (I2) and `@` (I3): by the source rule, the replay
     and the digests;
   - np.hypot (G), np.sum (H), np.maximum (J) and np.interp (L): by the source rule and the replay;
   - P2's own control C (`o.array(np.exp(o.leave(x)))`), re-run: PinnedLeak ("a value that left the pinned set is
     coming back in"), plus the source rule, the exits rule and 17 digests;
   - a float32 cast of the print's input (K): the replay passes (the cast is deterministic); 10 digests and the
     same-model test fail.
   On "an fma-contractible expression": numpy cannot contract across two ufunc calls, so `o.add(o.mul(a, b), c)` is two
   roundings everywhere. A contraction can only hide inside one C routine: np.dot and `@` are caught everywhere,
   np.vecdot by the replay alone.
4. **Accuracy: CONFIRMED, max 1 ulp everywhere I looked.** My samples, against libcft's correctly rounded binary64:
   - log2: 60,000 random subnormals and the 2,000 smallest (100% correctly rounded); near 1 (1 +- k ulp and
     1 +- 2^-45..2^-5; 99.996%); random normals (99.992%).
   - log10: doses 1e-30..1e6 (99.897%), near 1 (99.999%), subnormals (99.998%), and the doubles nearest 10^-30..10^22
     (all exact).
   - exp: near 0 (99.49%), -130..0 (88.77%), subnormal results -745.2..-708 (98.93%), near overflow (88.82%), the
     whole range (88.97%). exp10 on -4.5..0.5 (88.86%) and subnormal results (98.67%); exp2 at both edges (96.89%).
   - power on u in (0, 1] (log-uniform to 1e-300, subnormal u, and 1 - k 2^-53) for every exponent the chains form
     (toe x contrast 1.0, 1.3, 1.4, 1.5; 28 values): max 1 ulp, 89.15% to 92.45% correctly
     rounded. At y = 1.0 (silver at contrast 1) power(u, 1) differs from u on 0.64% of values, by 1 ulp; numpy's
     `u ** 1.0` returns u itself. No float32 output moved for it (item 5).
   - log1p on [0, 1] with subnormals (122,002 values): max 1, 98.97%.
   - P2's own `pinned_measure.py accuracy`, re-run: every figure as P2 reports it (log2 99.990% of 102,000, log10
     99.991%, the dose range 99.917%, log1p 98.88%, exp 89.1% and 88.8%, exp2 89.7%, exp10 89.1% and 88.7%, power
     88.7-91.8%, softplus 89.1%, interp max 1), all max 1 ulp.
   - The constants LN2, LOG2E, LOG2_10, LOG10_2 (hi and lo), SQRT2, IVLN2 (the 32-bit hi and its lo), re-derived with
     mpmath at 400 bits: all equal.
5. **The binary256 yardstick: CONFIRMED.** Re-run:
   - the negative, 15 cases of 8,192: the exact 65536p came no closer than 1.2455e-6 of a step (TRI-X, t = 30 s);
     binary64's error in p is at most 2.18e-11 of a step; 11,368 values sit exactly on a step (the table stocks at
     p = 1) and binary64 is exactly there on all of them; 0 of 122,880 levels flip; ungrained density 0 of 122,880
     float32 differ; grained density 0 of 3,000.
   - the print, 14 cases of 8,192: closest 1.7975e-6 of a step (gum, contrast 1.4); error at most 1.96e-11; 0 of
     114,688 levels flip; reflectance 0 of 344,064; grained reflectance 0 of 4,200. transmit: 0 of 8,192.
   - so 0 of 237,568 levels and 0 of 482,336 float32 outputs, as P2 reports.
   It is the model's own formulas at p = 237 through libcft: the exact product toe x contrast, the exact log10 of the
   reciprocity rows, the table's segments, softplus. No value is evaluated in binary64. The branch choices (softplus's
   sign, the dose clamps, the table's segment and end clamps, the reciprocity segment) are taken on the binary64
   rounding of the binary256 value: exact except within a binary64 ulp of the branch point, as its docstring says.
   The zero is a sample statistic: 2.2e-11 of a step predicts about 1e-5 flips over 237,568 levels, so the error
   bound, not the zero, is the finding.
6. **The coating uniforms: CONFIRMED.**
   - Random123's three philox4x64 R=10 vectors (github.com/DEShawResearch/random123, main, tests/kat_vectors, read
     through WebFetch, whose text passes through a model): P2's philox4x64, my own pure-Python Philox and numpy's
     independent Philox (seeded one below) all return them.
   - The key is specified to the bit in PINNED.md. My re-implementation from the document alone (the SHA-256 key,
     counters (c div 4, 0, 0, 0) and (c, j div 16, 0, 1), fields most significant first, the count as #{T[k] <= r})
     reproduces `emulsion.coat(..., pinned=True)` (table, K and every threshold) on 4 sheets of 3,000 cells:
     lambda 23.1, 24.7, 86.1 and 92.5; seeds 7, 2**200 + 5, 0 and 99.
   - The table is built in pinned arithmetic (P(0) the pinned exp, then one mul and one div per term, summed in order;
     three tables replayed through libcft). T[k] = ceil(F(k) 2^64) is exact integer arithmetic, so
     P(K <= k) = T[k]/2^64 exactly. Against the exact Poisson CDF (mpmath at 200 bits) it is at most 8.7e-16 off
     (lambda 97): the binary64 sum's own error. One oddity, harmless: where the binary64 sum stalls below 1
     (lambda 23.102), the table runs to k = top and the last 2^-53 of mass lands on K = 112.
   - The law on my own seed (200,000 TRI-X cells at 2 um): mean +0.00%, variance -0.06%, chi^2 29.8 over 30 bins;
     461,179 thresholds, chi^2 51.5 over 64 bins; each of the 16 field positions chi^2 7.6-26.2 over 16 bins;
     fields 0 and 1 of one word correlate at -0.0018.
7. **Cross-machine: CONFIRMED.** On WSL the pinned files give "69 passed, 37 skipped" (36 replay tests and the
   Windows-only control, by name), so the 48 recorded digests reproduce. My own 62 pinned outputs differ in 0 of 62
   between the hosts: every stock ungrained and grained, t and ci, the intensifier, a stored sheet, every process at
   float32 and float64 with dials and grain, a pigment, transmit, four coats of 20,000 cells, and the elementary
   functions at subnormals, near 1 and at both ends, all from inputs built of Philox bits only. The default path
   differs on 19 of 109 outputs, and 2 more raise on numpy 1.21 (halation). The whole suite there fails the same 14
   halation tests at be1d674 and at 78f35d3.
8. **FTZ/DAZ: CONFIRMED, at every entry point.** `_controlfp` set, in turn, FTZ+DAZ, DAZ only, FTZ only, round-down,
   round-up and round-toward-zero. In every mode all nine entries refuse by name ("pinned mode refuses this
   floating-point unit: ..."): the negative ungrained, grained and on a sheet; transmit; the print ungrained and
   grained; coat; expose; granularity.uniform_print. The default negative runs in every mode, with different bits
   under directed rounding.
9. **Supplied sheets: the checks that exist work.** Refused by name: K float64 or bool, thresholds int32 or uint8, K
   2-D, thresholds 1-D, 15 cells for 16, a negative count, a sheet under the floor. What passes is D4.
10. **Refusals: CONFIRMED for the organs named.** "not pinned yet", by name: the MTF where it acts (grained and ungrained
    at 2 um), halation, the batch lottery, colour.negative, colour.positive, and the aggregate regime in the negative,
    the print, coat and expose. The MTF's no-op test is the default's own (`max(ss, sb) / pitch < 0.35`), so pinned
    mode refuses exactly where mtf.apply would act. What is not refused is D5.
11. **Runtime dependencies: CONFIRMED.** With mpmath, cftmpfr, atlas_film.pinned_oracle, gmpy2 and scipy made
    unimportable, every pinned entry ran, and numpy was the only third-party module loaded. pinned_oracle is imported
    by tests/test_pinned_replay.py and tools/pinned_measure.py only.
12. **Control 2: CONFIRMED, including its blindness.** be1d674 against 78f35d3: "109 and 109 outputs; 0 differ".
    One-ulp sabotages of the default path:
    - `0.587` -> 0.5870000000000001 in process_print: 0 differ, exit 0;
    - TRI-X ht -2.73 -> -2.7299999999999995: 3 differ (characteristic trix, normal_highlight trix, the films constants
      table), exit 1;
    - KAPPA + 1 ulp: 3 differ, the constants tables only;
    - HUE_K + 1 ulp (mine): 2 differ, the constants tables only.
    An inline literal is invisible to every output hash, as P2 says.
13. **P2's findings for the owner.**
    - float32 negatives in the default print: CONFIRMED. On my own 4,096 negatives per process, against mpmath at 300
      bits, the default reads 2, 5, 4, 3, 1, 8 and 3 of 4,096 levels differently (cyanotype, vandyke, platinum, salt,
      albumen, silver, gum). Each count is reproduced through the public process_print with one-crystal sheets at the
      exact level. Float64 negatives: 0. Pinned: 0.
    - develop_on and a NaN p: CONFIRMED as undefined behaviour in C. On this CPU both builds (MSVC numpy 2.2.6, GCC
      numpy 1.21.5) give level 0, so a NaN cell develops its threshold-0 crystals.
    - halation needs numpy >= 2.0: CONFIRMED (np.trapezoid at halation.py:333, 376 and 380; pyproject says
      `dependencies = ["numpy"]`).
    - metering is not pinned: CONFIRMED by reading (np.percentile, `@`, np.interp, logaddexp). normal_highlight
      happened to agree between the two hosts for all eleven stocks.
    - Also confirmed: np.maximum's signed zero is the build's. np.maximum(-0.0, 0.0) is +0.0 on numpy 2.2.6 (MSVC)
      and -0.0 on numpy 1.21.5 (GCC), and np.fmin mixes signs inside one 7-element array. mpmath's `man_exp` drops the
      sign: (-3/4).man_exp == (mpz(3), -2) on 1.3.0 and 1.4.1. The brief's inferred hazards, re-measured:
      `(N,3) @ (3,)` differs from the two-rounding sum on 21.3% of elements; np.sum from a sequential sum on 288 of
      300 arrays; np.cumsum equals the sequential prefix sums on 300 of 300.
14. **Boundaries: CONFIRMED.**
    - The owner's checkout, read with --no-optional-locks: ` M README.md`, `?? docs/references.md`, HEAD be1d674 on main.
      No file outside .git is newer than 2026-09-25 00:00 local, no file in .git is newer than 2026-09-05, and
      atlas_film/__pycache__ is all 2026-08-31 or older.
    - The .git directory's own mtime is 22:29:30Z: an entry was created and removed there then (an index.lock is the
      usual one). I cannot attribute it; it is before my first command (22:30Z).
    - P2's clone: clean, on pinned at 78f35d3. Its origin refs hold main at be1d674 and no pinned.
    - colour.py's change is a keyword and a refusal, as P2 disclosed.
15. **Speed**, my run with one other job on the machine: the grained negative 0.311 -> 1.219 s (3.9x), the ungrained
    negative 11.7x, the grained print 1.9x, the ungrained print 12.7x, coat 1.9x, transmit 7.9x. The same order P2
    reports.

### What I did not do

- I fixed nothing, pushed nothing, called no Atlas API, and did not use amd-arc-box.
- I wrote nothing in the shared session scratchpad (the lead's 23:15Z urgent note): every file of mine is under
  C:/Users/logan/AppData/Local/Temp/verify-p2-work/ or my clone.
- No non-x86 CPU and no big-endian host: the NaN-sign and endianness lines are believed.
- I re-derived 11 of the 41 constants myself (item 4); the other 30 rest on P2's two derivations, which pass in
  the suite.
- Once, early, I imported atlas_film from C:/Users/logan (outside my clone) while checking the shadow. It resolved
  to the owner's checkout; only `__init__` ran, and no bytecode was written (the mtimes in 14).
- Kept: my clone at C:/Users/logan/AppData/Local/Temp/verify-p2 (clean, 78f35d3), and
  C:/Users/logan/AppData/Local/Temp/verify-p2-work/ with the scripts (plant.py, accuracy_check.py, sheet_check.py,
  ftz_check.py, sheet_refusals.py, xmachine.py, f32_print_flips.py, signed_zero.py, wsl_run.sh, wsl_run2.sh) and
  logs/, so every number here can be re-run. Deleted: the 23 sabotage copies (sab/) and the be1d674 checkout (base/).
  The WSL clones in /tmp are removed.

## 2026-09-26 04:23Z - verifier-P2 re-check of e5f63f8: D1-D7 are fixed as found, and the branch is clean to publish; but libm computed outside a registered function, and long-double arithmetic inside the integer and primitive layers, pass both the rule and the replay

Measured: everything below except the lines marked believed. My clone (C:/Users/logan/AppData/Local/Temp/verify-p2) fetched
`pinned` from P2's clone: e5f63f8337c5a3528076c6ded2020e3529156f2b, parent 78f35d34c0a2b43b8357e15c8b0cef6eae802bad; atlas_film
imported from the clone (conftest asserts it). Hosts as in my 23:30Z entry: Windows 11, Python 3.12.9, numpy 2.2.6, libcft at
moth-quantum/vendor/cft-fp256/host/cft.dll, sha256 6ca569a8e46687067ead78a23e09f27f0046aad27cbbec37e2699937ca2bb218; WSL cft2204
(Python 3.10.12, numpy 1.21.5, glibc 2.35). Every fault was planted in a copy (verify-p2-work/sab2, deleted) and run through the
travelling tests (test_pinned_is_pinned.py + test_pinned_source_rule.py, 81), the replay tests (39) and `pinned_measure.py replay`
(51 chains); plants marked WSL ran the travelling tests there too.
Believed: a libm or long-double difference on hosts I do not have (AArch64, musl, macOS); nothing else.
For: lead (the push), P2

### Defects, listed first

**D8. libm computed at import in pinned.py's own module scope passes every gate, on both hosts.**
Plant N1: `_LOG2E = float(np.log2(np.e))` at pinned.py's module level, and `exp` taking `o.const(_LOG2E)` for
`o.const(C.LOG2E_HI)` (the same bits on both hosts).
- The travelling tests: 80 passed, 1 skipped, on Windows and on WSL.
- The replay tests: 39 passed. The 51 chains: all identical.
- The rule reads the functions registered in LAYERS and pinned.py's import statements, not module-level statements, and
  `o.const(<any name>)` is a "plain data expression". PINNED.md says the rule reads "all of `pinned.py`" and that every
  constant is a bit pattern in pinned_constants; nothing holds `o.const`'s names to that. pinned.py's own `_ATANH` and
  `_TAYLOR` tuples are module-level data of this kind.
- Only a host whose libm gives other bits would see it, through the digests, if the tests run there.

**D9. The brief's trap in its helper form, and a libm-derived table, pass every gate on both hosts.**
- N3: `_intensify_factor` returning `math.exp(math.log(INTENSIFIERS[intensify]))`. films.negative computes `f` before its
  `if pinned:` branch and hands it over, and `_negative_pinned` gates it as `o.const(f)`.
- N2: a module-level `_LOG_ROWS` of `math.log10` over the reciprocity rows in films.py, fed to `_density_pinned` as
  `o.const(v)`.
- Each: travelling tests 80 passed, 1 skipped on both hosts; replay tests 39 passed; 51 chains identical.
- PINNED.md's limit names "at import in an organ's module (the two constants above), or by the caller", and says the replay
  checks those two. The category is every stock-table entry that reaches `o.const`, and the organ's own helpers run before
  the branch. The branch test checks what the branch does, not where the names it hands over came from.
- This is the brief's named trap: "a helper that calls np.exp".

**D10. Long-double arithmetic passes the integer and primitive layers' rules, and the replay; only WSL's digests catch it.**
- N4, the integer layer: in `develop_sheet`,
  `q = np.asarray(flat[lo:hi], "g"); pv = q + (q * q - flat[lo:hi] * flat[lo:hi]) * 1099511627776`, developed against `pv`.
  - Windows (np.longdouble is binary64 there, the residual 0): 80 passed, 39 passed, 51 chains identical.
  - WSL (80-bit): 6 fail (5 chain digests and the stored-sheet test).
- N5b, the primitive layer, inside the gate every array passes: `exact_array` returning
  `(q + (q * 3 - x * 3) * 1099511627776)` with `q = x.astype("g")`.
  - Windows: 80 passed, 39 passed, 51 chains identical.
  - WSL: 29 fail.
- The rule allows `+ - *`, any dtype string and (primitive) float literals in these layers. PINNED.md says: integer "no
  float dtype", primitive "numpy's five correctly rounded operations and its exact ones, bound by name".
- The exact-array gate and `_frexp1`, `_pow2`, `_clear_low32` are shared by both backends, so the replay cannot see them.

**D11. The replay has more limits than PINNED.md names (it names np.asarray, .tolist() and float()).**
- `o.from_int` accepts an integer array that still carries the Left mark. Measured in CftOps:
  `np.floor(np.exp(o.leave(x)) * 1000).astype(np.int64)` is a Left int64, and from_int returns it as a CV.
  The Left docstring says from_int "takes only integers"; it does not check the mark.
- `np.array`, `np.concatenate` and `np.stack` strip the mark too: `o.array` accepted all three wrapped around `np.exp(left)`.
  All three are on the integer layer's allowlist, and there `o.array`'s argument is unrestricted (the argument rule is
  model-layer only).

**D12 (minor).**
- The exits test pins the helpers, not their callers. N6: `fk = P.trunc_int(o, fv)` in `_negative_pinned`, brought back
  as `o.from_int(fk)`: 80 passed, 39 passed, 51 identical. `ceil_scaled` and `table_key` are exits of the same kind.
- `o.array` and `o.number` accept np.longdouble on Windows (8 bytes) and refuse it on WSL (16 bytes), so one call is refused
  on one host and accepted on the other. The accepted values are exact, and PINNED.md says a long double is refused.
- "the sensitometry readers is not pinned yet" (the refusal's grammar).
- `CV` has no `__matmul__`, so `@` in the replay raises TypeError, not PinnedLeak. It still fails.

### What was asked, and what I found

1. **The commit: CONFIRMED.** e5f63f8's parent is 78f35d3. 13 files over 78f35d3, 16 over be1d674, including
   tests/test_pinned_source_rule.py; atlas_film/sensitometry.py is the one boundary crossing, disclosed.
2. **D1-D7 re-planted: each caught as P2 says.**

| plant | rule + digests (81) | replay (39) | 51 chains |
|---|---|---|---|
| `o.const(math.log10(r[0]))` | 1 fails, the rule | pass | identical |
| the same, ungated | 1 fails | 1 fails, bare float | PinnedLeak |
| P(0) as `o.const(math.exp(-scalar(o, lam)))` | 3 fail (allowlist, imports, exits) | pass | identical |
| `math.exp(math.log(contrast))` after its gate | 1 fails | 6 fail | PinnedLeak |
| `np.emath.power` on `o.to_f32`'s output | 2 fail (rule, transmit digest) | 1 fails | PinnedLeak |
| `o.array(np.asarray(np.emath.power(np.e, o.leave(x))))` | 23 fail | 1 fails (accuracy) | identical |
| np.add.reduce / np.vecdot / np.sum in the projection | 1 fails each | 2 fail each | PinnedLeak |
| `@` in the projection | 2 fail | 2 fail (TypeError) | TypeError |
| `u ** y` / np.log1p | 10 / 9 fail | 7 / 7 fail | PinnedLeak |
| np.maximum / np.interp | 1 / 1 fail | 9 / 3 fail | PinnedLeak |
| a float32 cast before the gate | 12 fail (rule, 10 digests, the model test) | pass | identical |

   - No pairwise or BLAS reduction got past the rule anywhere. What got past is D8-D11.
   - Numpy cannot contract `o.add(o.mul(a, b), c)`: that is two ufunc calls, so two roundings everywhere. A contraction can
     only hide in one C routine (np.dot, `@`, np.vecdot), and each is refused.
   - Where D8/D9 would be caught: on a host whose libm differs for that value, through the digests, if it runs them.
3. **D3, D6: CONFIRMED.**
   - Refused by their own names: contrast nan, inf, 0 and -1; dmax_mul nan, inf and -1; E nan, inf and True; pitch nan, inf
     and -2 (with a supplied sheet too); coat's ceiling, grain_um2 and pitch each nan, 0 or negative.
   - t and ci out of range are refused by the stock's validators.
   - Accepted, as documented: E = -1 (clamped like the default), a 0-d E, np.float32 E, dmax_mul 0 and -0.0, contrast 5e-324.
4. **D4: CONFIRMED, at each bound.**
   - Refused by name: a 3-tuple, a 1-tuple, a dict; pads of 0 past K; a single pad of 65534; K = columns + 1; K = 1 with
     0 columns; K = 2**31 (int64) and 2**32 + 3 (uint64), each as "beyond the columns"; a negative K; float or bool K; int32
     or uint8 thresholds; big-endian uint16 thresholds; 15 cells for 16; a sheet under the floor; bad pads on the negative.
   - Accepted: the pair as a list; K = columns exactly with no pad; a real crystal at 65535; unsorted rows (the same print);
     K all 0 with 0 or 5 pad columns; uint8 K; Fortran order; the default path's sheets.
   - check_sheet on 1,048,576 cells x 50 columns: 0.10 s, peak 1.5x the thresholds' size.
5. **D5: CONFIRMED.**
   - All four sensitometry readers refuse pinned=True (and pinned=1) by name, and run with pinned=False.
   - normal_exposure, granularity.density_field, pigments and papers raise TypeError, as PINNED.md lists.
6. **D7: CONFIRMED.** "up to 9 ... 12 ... 13", 482,336, tests/kat_vectors, little-endian digests, keyword-only transmit and
   a 0-d E. The 48 recorded digests are identical to 78f35d3's.
7. **The default path: CONFIRMED unchanged.**
   - AST comparison of 11 modules at be1d674 against e5f63f8, with docstrings, `pinned` and the pinned branches removed:
     0 changed, 0 removed. Added: only the `*_pinned` stages and `_hex_ints`.
   - `tools/default_path_hashes.py`, be1d674 against e5f63f8: "109 and 109 outputs; 0 differ".
8. **The suite: CONFIRMED.**
   - With QF_CFT_ROOT: "266 passed, 1 skipped in 22.68s" (the POSIX control, by name, on Windows).
   - Without it: "227 passed, 40 skipped in 14.25s", every skip by name. ruff: "All checks passed!".
   - `pinned_measure.py replay`: 51 chains identical, 27,905 rounding calls, 28,481,500 element-operations.
   - WSL: the pinned files "80 passed, 40 skipped" (the 39 replay tests and the Windows control). The whole suite: 213
     passed, 40 skipped, the same 14 halation failures as at be1d674.
   - My 62 pinned outputs are identical between Windows and WSL at e5f63f8, and identical to 78f35d3's on Windows. The
     default path differs on 21 of 109.
   - With the self-check disabled in a copy, the Windows flush-to-zero control and WSL's POSIX rounding control each fail.
9. **Push-readiness.**
   - The branch: P2's clone is clean, on `pinned` at e5f63f8. Over be1d674 it holds exactly 78f35d3 and e5f63f8. Its refs are
     main (be1d674), pinned and origin's main. `git ls-remote origin` shows only main, at be1d674.
   - Secrets, e-mails, paths, over all 16 files at e5f63f8, both commits' added lines and both messages, for user paths,
     tokens, key names, host names and e-mail addresses:
     - the only e-mail is noreply@anthropic.com, in the two Co-Authored-By lines;
     - the commits' identity, Logan <Logan@improperaperture.com>, is on 73 commits already public on origin's main;
     - the only machine-path fragment is the relative `moth-quantum/vendor/cft-fp256/host/cft.dll` in PINNED.md, a name
       Quantum-Film's public docs already carry with its full path.
   - Nothing from the owner's checkout:
     - README.md at e5f63f8 is be1d674's (sha256 28b65058...; the owner's working file is 437340f9...);
     - docs/references.md is not in the tree;
     - none of the owner's 5 uncommitted README lines, or 1,165 references.md lines, appears among the commits' added lines.
   - The owner's checkout: ` M README.md`, `?? docs/references.md`, be1d674 on main, read with --no-optional-locks.
     - Nothing outside .git is newer than 2026-09-25 00:00 local, and nothing inside it newer than 2026-09-06.
     - The .git directory's own mtime is 01:55:38Z, the lead's 01:55Z check. Believed: an index.lock made and removed by a
       git status.

### What I did not do

- I did not re-run the binary256 yardstick or the accuracy tool. The 48 digests and my 62 outputs are the same bits as at
  78f35d3, where I ran both.
- No AArch64, musl or macOS host, so D8/D9 differing there is believed.
- Fixed nothing, pushed nothing, called no Atlas API, did not use amd-arc-box, wrote nothing in the shared scratchpad.
- The harness kept my backgrounded commands' output under the session's tasks/ directory, beside the scratchpad.
- Kept: my clone (clean, at e5f63f8) and verify-p2-work/ (plant2.py, refusals2.py, ast_compare.py, scan_push.py,
  wsl_run3.sh, logs/). Deleted: the plant copies, the be1d674 checkout, the WSL clone.

NOT READY: the bits and the branch are ready, but D8-D11 are new gaps, and PINNED.md, which the push publishes, claims the
coverage they lack; each needs a fix or a known-limit line in PINNED.md, then a re-check.

## 2026-09-26 05:54Z - verifier-P2's third pass, 27c9b4b: D8-D12 are fixed as found, and the bits and the branch are ready; but libm through an operator in code the rule reads, and through rebinding from code it does not read, passes both the rule and the trap, where PINNED.md says neither can

Measured: everything below except the lines marked believed.
- My clone (C:/Users/logan/AppData/Local/Temp/verify-p2) fetched `pinned` from P2's clone.
  - It is 27c9b4b66ac9a5f279f0e5d72edc2ce0ea6826fd, whose parent is e5f63f8.
  - The branch over be1d674 is exactly 78f35d3, e5f63f8 and 27c9b4b.
  - atlas_film is imported from the clone.
- The hosts are as in my earlier entries.
  - Windows: Python 3.12.9, numpy 2.2.6, and libcft sha256 6ca569a8....
  - WSL cft2204: Python 3.10.12, numpy 1.21.5.
- Every plant ran in a copy (verify-p2-work/sab3, deleted) through every gate. The count after each name is its tests.
  - the rule: test_pinned_source_rule.py (8);
  - the travelling tests: test_pinned_is_pinned.py (78);
  - the libm trap: test_pinned_runs_without_libm.py (9);
  - the replay: test_pinned_replay.py (42);
  - the 51 chains: pinned_measure.py replay.
  - Plants marked WSL also ran the rule, the travelling tests and the trap on WSL.
Believed: that a vectorised pow (numpy's SVML/AVX-512 builds) is inexact on some of the values these plants test. I have no such host.
For: lead (the push), P2

### Defects, listed first

**D13. Libm through `**` passes the rule and the trap in code the rule reads. Each plant below passed all five gates on Windows (8/78/9/42/51) and on WSL (94 passed, 1 skipped).**

| plant | where | the libm call |
|---|---|---|
| OP1 | `_negative_pinned`, the model layer | `fv = ((o.const(1.0), o.const(st["dmax"]))[st["dmax"] ** 2 != st["dmax"] * st["dmax"]] if intensify is None else ...)`: pow inside a subscript |
| OP2 | the same site | `((st["dmax"] + 0j) ** (1 / 2)).real` in the index: complex pow (libm's hypot, atan2, pow, cos, sin) and a complex literal |
| V1 | `_dev_factor`, a validator | `if ci ** 2 != ci * ci: raise ValueError(...)` |
| V2 | V1, plus `_characteristic_pinned` | the model layer catches that ValueError (`try:`/`except ValueError as err:`, `err.args[0]`) and picks `g` |

- **The plants are live.** A line tracer over the 39 recorded recipes counted the plants' `**` lines executing: 5 times for OP1 and 2 times for V1/V2.
- **The libm result decides the output.** Flipped to what a libm disagreeing with IEEE on those values would do, the travelling tests fail: 7 (OP1) and 2 (V2).
- **Why the rule passes them.**
  - `_in_int_context` exempts every BinOp inside a subscript or `range()`, "where Python refuses a float". But a float computation there is fine when a comparison turns it into the index.
  - check_validator does not look at BinOps.
  - `ast.Try` is read by no layer.
  - The float-literal check misses complex literals.
- **Why the trap passes them.** `**` has no Python entry point to swap, as P2 says; its answer is that "the rule refuses them in all the code it reads".

**D14. Code the rule does not read can rebind what pinned code calls, and the run-time check does not hold it. Each plant below passed all five gates on both hosts.**

| plant | what it does at colour.py's import |
|---|---|
| MP1 | rebinds `NumpyOps.rint` (exp2_dd's k, in every exp) to a function that returns rint unless `abs(y) ** 3.0 != abs(y) * abs(y) * abs(y)` (np.power through the operator) |
| MP2 | the same with `np.vectorize(math.pow)` |
| C1 | pre-fills `pinned._TABLES` under the key of TRI-X at 2 um (a recorded chain's lambda) with a count-law table whose P(0) is `2.718281828459045 ** -lam` |

- **Live.** The rebound rint ran 72 times in the recipes. MP1 flipped: 24 travelling failures.
- **How MP1 and MP2 get past the rule.** They go through `import atlas_film.pinned` with no alias, so the static store check does not follow it.
- **How they get past the run-time check.** It holds the registered tables, the registered functions and NumpyOps' five rounding methods. It does not hold the exact methods (rint, floor, where, the comparisons), numpy's exact functions, or `_TABLES`, which it skips as NOT_LITERAL.
- **MP2 is a trap bypass with an entry point the trap DID swap.** math.pow is a stand-in there. np.vectorize is a class, so it stays real, and it calls the stand-in from numpy's own frame, which `_numpy_internal` answers with the real function. So "a trap while a chain runs" does not hold for a numpy higher-order function.
- **C1's table is served to the public (NP) path, and no gate checks it.**
  - Its table has 70 entries, not 73, and 64 of them differ from the true one, by up to 22,528 parts in 2^64.
  - No recorded draw fell in those windows, so every digest held.
  - The replay never reaches the NP cache: TraceOps and CftOps rebuild the table.

**D15. PINNED.md, which the push publishes, claims coverage that D13 and D14 refute.**
- "the rule ... sees ... operators and ndarray methods, `**`, `@`, `x.sum()` ... in all the code it reads". Refuted by OP1, OP2 and V1.
- The validators "reach no numpy, no libm". Refuted by V1.
- "no arithmetic operator outside `range()` and subscripts (where Python refuses a float)". The reason given is wrong.
- Operators in unread code "can reach a pinned chain only through a registered table or a registered function, which the runtime check holds". Refuted by MP1, MP2 and C1.
- "The trap catches every libm call on the way into a chain, whatever route it takes". Refuted by MP2.

**D16 (minor).**
- The mark's list of stripping calls is short. My probe of CftOps shows 11 more calls that strip it:
  - np.broadcast_arrays;
  - np.full or np.zeros plus a slice store;
  - np.where;
  - scalar indexing;
  - `.item()`;
  - `.max()` and `.min()`;
  - np.copy and np.ascontiguousarray;
  - `.view(np.ndarray)`;
  - np.frombuffer.

  Also, `o.from_int(np.asarray(<Left int64>))` is accepted. The document calls the mark a tripwire, so this is a list to complete, not a gap.
- PINNED.md's table has D10's N5b failing the replay 29 times ("a long double inside the set"). That is P2's variant. Mine returns binary64, and the replay passes it (42 passed). Only the rule, and WSL's digests (32 failures), catch it.

### Confirmations

1. **The commit: CONFIRMED.** 27c9b4b's parent is e5f63f8. It changes 12 files. Over be1d674 there are 18: 8 new tests and tools, 3 new modules, PINNED.md, and the organs (films, processes, emulsion, colour, sensitometry).
2. **D8-D12 re-planted: every one is caught, as P2 says.** Failures per gate on Windows (rule / travelling / trap / replay / 51 chains), and on WSL:

| plant | rule | travelling | trap | replay | chains | WSL |
|---|---|---|---|---|---|---|
| N1, libm constant at pinned.py's module level | 2 | 0 | 4 | 0 | identical | 6 |
| N2, libm table in films.py | 1 | 0 | 2 | 0 | identical | 3 |
| N3, libm in `_intensify_factor` | 1 | 0 | 4 | 0 | identical | 5 |
| N4, long double in develop_sheet | 1 | 0 | 0 | 0 | identical | 9 |
| N5b, long double in exact_array | 1 | 0 | 0 | 0 | identical | 32 |
| N6, the trunc_int exit | 2 | 0 | 0 | 0 | identical | - |
| `o.const(math.log10(r[0]))` | 1 | 0 | 3 | 0 | identical | - |
| math.exp for P(0) | 3 | 0 | 7 | 0 | identical | - |
| np.emath after the output | 1 | 1 | 3 | 1 | PinnedLeak | - |
| np.asarray laundering | 2 | 21 | 7 | 1 | identical | - |
| np.add.reduce | 1 | 0 | 3 | 2 | PinnedLeak | - |
| `u ** y` | 1 | 9 | 1 | 7 | PinnedLeak | - |

   - Long double spelled seven more ways (np.clongdouble, np.longcomplex, np.float96, np.longfloat, `'<f16'`, np.sctypeDict, np.dtype): the rule names each.
3. **D3-D6: CONFIRMED again.** My 97-case script gives the same verdict as at e5f63f8 on every case: dials, sheets at each bound, readers and organs. The sensitometry refusal now reads "sensitometry (the readers) is not pinned yet". A t of nan or inf is refused as the dial; out-of-range t is refused in reciprocity()'s own words.
4. **The default path: CONFIRMED unchanged.**
   - The AST comparison of 11 modules at be1d674 against 27c9b4b, with docstrings, `pinned` and the pinned branches removed: 0 changed, 0 removed.
   - `default_path_hashes.py` gives "109 and 109 outputs; 0 differ".
   - films.negative and process_print now open with the pinned branch, and their default code runs in the same order as at be1d674.
5. **The suite: CONFIRMED.**
   - With QF_CFT_ROOT: "283 passed, 1 skipped in 28.78s". Without it: "241 passed, 43 skipped in 20.12s", every skip by name. ruff is clean.
   - The 51 chains are identical, with 27,905 rounding calls and 28,481,500 element-operations.
   - The trap on the clean tree:
     - 801 entry points replaced, and no trap raised;
     - one import call, numpy.geomspace from sensitometry;
     - all 48 digests hold;
     - the run-time checks are empty.
   - WSL:
     - the pinned files "94 passed, 43 skipped";
     - the whole suite 227 passed and 43 skipped, plus the 14 halation failures of be1d674;
     - my 62 pinned outputs are identical to Windows' and to e5f63f8's.
6. **Push-readiness: the branch is ready.**
   - P2's clone is clean, on `pinned` at 27c9b4b. `git ls-remote origin` shows only main at be1d674.
   - A scan of all 18 files and the three messages finds one e-mail, noreply@anthropic.com, in the Co-Authored-By lines.
   - The identity is Logan <Logan@improperaperture.com>, as on origin's 73 public commits. The only path fragment is the relative `moth-quantum/vendor/cft-fp256/host/cft.dll`, which is public in Quantum-Film.
   - README is be1d674's, and docs/references.md is not in the tree. None of the owner's 5 uncommitted README lines or 1,165 references.md lines is in the three commits.
   - The owner's checkout shows ` M README.md` and `?? docs/references.md` at be1d674 on main. Nothing is newer than before, and atlas_film/__pycache__ is 2026-08-31 or older.

### What I did not do

- No host where libm disagrees on these plants' values. D13 and D14 are no-ops on both my hosts, as the plants were built to be. Their effect elsewhere is shown only by flipping the comparison.
- I fixed nothing, pushed nothing, called no Atlas API, and wrote nothing in the shared scratchpad.
- I kept my clone (clean, at 27c9b4b) and verify-p2-work/ (plant3.py, prove_live.py, mark_probe.py, ld_spellings.py, knife.py, wsl_run4.sh, logs/). The plant copies and the WSL clone are deleted.

NOT READY: the bits and the branch are ready, but PINNED.md claims that the rule sees every `**` in the code it reads, that validators reach no libm, that the run-time check holds every rebinding, and that the trap catches every libm call. D13 and D14 each pass both gates. Each needs a gate, or a line in PINNED.md stating it as a limit.

## 2026-09-26 07:11Z - verifier-P2's fourth pass, 3a79346: D13 and D14 are closed as found, and the code, the bits and the branch are ready; but a trace hook rewrites a chain's values past every gate, and PINNED.md says no such route exists

Measured: everything below except the lines marked believed.
- The branch: my clone (C:/Users/logan/AppData/Local/Temp/verify-p2) fetched `pinned` from P2's clone.
  - The head is 3a79346053cc03d57ff0c8ae3df787e9d43c677b, and its parent is 27c9b4b.
  - Over be1d674 it is exactly 78f35d3, e5f63f8, 27c9b4b and 3a79346.
- The hosts are as in my earlier entries: Windows (numpy 2.2.6, libcft 6ca569a8...), and WSL cft2204 (numpy 1.21.5).
- Plants ran in copies (verify-p2-work/sab4, deleted). The gates for each:
  - the rule;
  - the travelling tests;
  - the trap;
  - the replay, in one session with test_pinned_is_pinned.py so that colour.py is loaded;
  - the 51 chains;
  - the whole suite;
  - and, where marked, the rule, the travelling tests and the trap on WSL.
Believed: that a vectorised pow inexact on small integer cubes exists on some host. I have none.
For: lead (the push), P2

### Defects, listed first

**D17. A trace hook installed at colour.py's import rewrites a chain's values in place, and passes every gate on both hosts. PINNED.md says no such route exists.**
- **The plant, TR1.** colour.py (code the rule does not read) calls `sys.settrace(_tr)` at import. In every `exp2_dd` frame, once `k = o.rint(hi)` is bound, the hook rewrites `k`'s array in place with `np.where(abs(k) ** 3.0 == abs(k) * abs(k) * abs(k), k, k + 1.0)`.
  - Its libm is np.power, reached through the operator.
  - It is a no-op on both hosts, since every k is an integer within +-1100.
  - Nothing is rebound or stored into anything a check holds.
- **It passes every gate.**
  - the rule: 8 passed;
  - the travelling tests: 77 passed, 1 skipped;
  - the trap: 10 passed;
  - the replay session: 119 passed, 1 skipped;
  - the 51 chains: identical;
  - the whole suite: 284 passed, 1 skipped;
  - WSL: 95 passed, 1 skipped.
- **It is live.** Flipped (`!=`), it fails 20 travelling tests, 1 trap test, 24 in the replay session and 25 in the whole suite. So the hook runs in each of those processes, and its pow decides output bits.
- **What it makes false.**
  - The trap paragraph says operators and dunders in code the rule does not read "reach a chain only through what the run-time check holds (MP1), or below it (MP3, MP4)". TR1 reaches a chain through neither: through a running frame's value, which no check holds at any time.
  - The limits' own descriptions do not cover TR1:
    - "below the names" is described and summarised as a rebinding (MP3);
    - "what happens between its runs" is described as "a rebinding ... seen only if a check runs after that code" (R6, "which only the whole suite catches"). TR1 is no rebinding, and no check sees it, before or after.
  - Only the summary words "code that runs between the run-time checks" could be read to include it.
- **The class.** Any code the interpreter runs inside a chain on its own schedule can rewrite that chain's arrays in place, with no gate seeing it:
  - sys.settrace, sys.setprofile and sys.monitoring;
  - gc.callbacks and finalizers;
  - signal handlers;
  - another thread;
  - np.seterrcall.
- **The fix.** One stated limit naming the class, and the "only" sentence corrected.

**Minor.**
- atlas_film/pinned_oracle.py's module docstring still says "a libm call hidden anywhere in it cannot even execute there". That is D1's refuted claim. PINNED.md itself says the replay does not see libm before a gate.
- The earlier commit messages carry claims later refuted, each superseded by the next commit and by PINNED.md; the history is not rewritten. Examples:
  - 78f35d3: "A libm call hidden in a pinned function cannot run there", and "481,336";
  - 27c9b4b: "the trap reads nothing, so the code the rule does not read cannot walk past it".

  Whether superseded messages count under the bar is the lead's call.

### Confirmations

1. **D13: CLOSED.** OP1, OP2, V1 and V2 each fail the rule (1 test) on Windows and on WSL, and pass every other gate.
2. **D14: CLOSED as found.**
   - MP1 and MP2 each fail the rule (2 tests: the store check, which names "stores into atlas_film (atlas_film.pinned.NumpyOps.rint)", and the
     run-time check) and the trap's run-time check (1 test), on both hosts.
   - My control MP5, numpy.where replaced through `vars(sys.modules["numpy"])`, is caught by the run-time check (1 test in the rule file, 1 in the trap).
   - C1 has no `_TABLES` to fill: every gate that imports colour.py errors there. The 51-chain tool never
     imports colour.py.
   - The count-law table built per call takes 0.35-1.42 ms here (lambda 0.5-97), against P2's 0.4-1.7 ms.
3. **D16: CONFIRMED.** `.max()`, `.min()` and `.sum()` of a marked value are a 0-d Left on numpy 2.2.6 and on 1.21.5. The 15 stripping calls listed match my probe.
4. **Shipped code: no correctness defect found.**
   - My 97 dial, sheet, reader and organ cases give 27c9b4b's verdict on every case.
   - My 62 pinned outputs are identical on Windows and WSL, and identical to 27c9b4b's.
   - The 51 chains are identical, with 27,905 rounding calls and 28,481,500 element-operations.
   - The trap on the clean tree: 801 entry points, no trap, one import call (numpy.geomspace, from sensitometry), 48 of 48 digests, and empty run-time checks.
5. **Suite: CONFIRMED.**
   - With QF_CFT_ROOT: "284 passed, 1 skipped". Without it: "242 passed, 43 skipped" (42 libcft and the POSIX control, all by name). ruff is clean.
   - WSL: the pinned files "95 passed, 43 skipped"; the whole suite 228 passed and 43 skipped, plus be1d674's 14 halation failures.
6. **The default path: unchanged.** The AST comparison of 11 modules against be1d674 finds 0 changed and 0 removed, and default_path_hashes.py gives "109 and 109 outputs; 0 differ".
7. **The branch: clean to publish.**
   - P2's clone is clean, on `pinned` at 3a79346. `git ls-remote origin` shows only main, at be1d674.
   - A scan of the 18 files and the four messages found:
     - no key, token or credential shape;
     - one e-mail, noreply@anthropic.com, in the Co-Authored-By lines;
     - the identity Logan <Logan@improperaperture.com>, as on origin's public commits;
     - one path fragment, the relative `moth-quantum/vendor/cft-fp256/host/cft.dll`, which Quantum-Film's public docs already carry.
   - Nothing from the owner's checkout: README.md is be1d674's, docs/references.md is absent, and 0 of the owner's 5 uncommitted README lines and 0 of 1,165 references.md lines appear.
   - The owner's checkout: ` M README.md`, `?? docs/references.md`, be1d674 on main, nothing newer than before.

### What I did not do

- No host with an inexact vectorised pow, so D17's effect elsewhere is shown only by the flipped plant.
- I did not re-run P2's own limit plants (MP3, MP3v, MP4, R6, INT1, CAST1b).
- I fixed nothing, pushed nothing, called no Atlas API, and wrote nothing in the shared scratchpad or in P2's or the owner's checkouts.
- Kept: my clone (clean, at 3a79346) and verify-p2-work/ (plant4.py, plant4_base.py, left_reductions.py, wsl_run5.sh, logs/). The WSL clone is removed.

NOT READY: TR1 passes every gate, and PINNED.md says operator-borne libm from unread code reaches a chain "only through what the run-time check holds, or below it". One stated limit for code the interpreter runs inside a chain (trace, profile and monitoring hooks, gc callbacks, signal handlers, threads, np.seterrcall), with that sentence corrected, would make it READY TO PUSH.

## 2026-09-26 07:34Z - verifier-P2's fifth pass, f3aa361: D17 is stated as found, and the code, the bits and the branch are ready; one sentence of PINNED.md keeps the claim P2 retracted from the docstring beside it

Measured: everything below. My clone (C:/Users/logan/AppData/Local/Temp/verify-p2) fetched `pinned` from P2's clone.
- The head is f3aa361e6d950950e19e5a561d6e07cb0bbc0fe9, and its parent is 3a79346.
- Over be1d674 the branch is exactly 78f35d3, e5f63f8, 27c9b4b, 3a79346 and f3aa361. The amended first cut, fdc2e1f, is not in the branch's history: it survives only as an unreferenced object in
  P2's clone, which a push of `pinned` does not send.
- The hosts are as before: Windows (numpy 2.2.6, libcft 6ca569a8...) and WSL cft2204 (numpy 1.21.5).
- Plants ran in copies (verify-p2-work/sab5, deleted) through the rule, the travelling tests, the trap, the replay session, the 51 chains and the whole suite, and on WSL through the rule, the travelling tests and the trap.
Believed: -
For: lead (the push), P2

### Defect, listed first

**D18. PINNED.md says np.log10 and np.interp "can[not] run in a pinned chain", and its own stated limits say they can.**
- **The sentence**, in "What pinned mode refuses, by name" (line 617): "A pinned negative with `t=` does not call `reciprocity` (which reads t through libm's log10 and `np.interp`, neither of which can run in a pinned chain)".
- **P2 retracted this claim elsewhere in f3aa361.** Its `_reciprocity_pinned` docstring made the identical claim ("which cannot run inside a pinned chain"), and f3aa361 corrected it to "which pinned code may not call (the rule refuses both, and the trap traps them)". P2's report says it corrected every such sentence; this one is the one left.
- **The same document refutes it:**
  - its D17 class says code the interpreter runs inside a chain reaches the chain;
  - its MP3v, np.vectorize(math.pow) inside `_wrapfunc`, passes every gate, so libm runs inside chains untrapped;
  - no guard runs outside the test process.
- **So it is false as stated.** It was already in 3a79346, where I missed it.
- **The fix is one phrase, the docstring's own:** "which pinned code may not call: the rule refuses both, and the trap traps them".

No other absolute claim remains. Searching the current PINNED.md, the atlas_film modules, the tests and the tools for "cannot", "can run", "every libm", "no libm", "only", "never" and "at all" finds only true statements, or rules stated as rules.

### Confirmations

1. **D17: STATED AS FOUND.**
   - The class is named (trace, profile and monitoring hooks, gc callbacks and finalizers, signal handlers, other threads, np.seterrcall), each guard's miss is said, and TR1 is its plant with my figures.
   - The "only through" sentence now names three routes. The contract ("a chain that runs undisturbed"), the replay's, the rule's and the run-time check's limits, the gates' opening, the trap's opening and both closing lists say the same.
   - TR1 on f3aa361, re-run:
     - the rule: 8 passed;
     - the travelling tests: 77 passed, 1 skipped;
     - the trap: 10 passed;
     - the replay session: 119 passed, 1 skipped;
     - the 51 chains: identical;
     - the whole suite: 284 passed, 1 skipped;
     - WSL: 95 passed, 1 skipped.
2. **P2's stated limits MP3 and MP4, rebuilt my own way, pass every gate as PINNED.md says.**
   - MP3 stores a pow-keyed `_wrapfunc` into numpy's fromnumeric through `vars()`.
   - MP4 rebuilds np.full from its own code over globals whose `empty` is pow-keyed, and stores it through `vars(sys.modules["numpy"])`.
   - Each passes the rule, the travelling tests, the trap, the replay session, the 51 chains and the whole suite (284 passed), and WSL (95 passed).
   - Both are live: flipped, they fail 13 and 4 travelling tests and 15 and 9 in the whole suite.
3. **Docs only: CONFIRMED.** Every changed Python file's AST, docstrings aside, is identical to 3a79346's (films.py, processes.py, pinned_oracle.py and three test files). pinned_oracle.py's module docstring, Left's docstring and test_pinned_replay.py's docstrings no longer make D1's claim.
4. **The code and the bits: unchanged, ready.**
   - The suite: "284 passed, 1 skipped" with QF_CFT_ROOT, and "242 passed, 43 skipped" without, every skip by name. ruff is clean.
   - The 51 chains are identical, with 27,905 rounding calls and 28,481,500 element-operations.
   - WSL: the pinned files 95 passed and 43 skipped; the whole suite 228 passed and 43 skipped, plus be1d674's 14 halation failures.
   - My 62 pinned outputs are identical on Windows and WSL, and identical to 3a79346's.
   - PINNED.md's seed-17 sheet figures reproduce exactly: mean 23.110, variance 23.02, chi-square 25.6/30, 4,621,921 thresholds, chi-square 64.4/64.
5. **The default path: unchanged.** The AST comparison of 11 modules against be1d674 finds 0 changed, and default_path_hashes.py gives "109 and 109 outputs; 0 differ".
6. **The branch: clean to publish, be1d674..f3aa361.**
   - P2's clone is clean, on `pinned` at f3aa361. `git ls-remote origin` shows only main, at be1d674.
   - A scan of the 18 files and the five messages found:
     - no key, token or credential shape;
     - one e-mail, noreply@anthropic.com, in the Co-Authored-By lines;
     - the committer identity already public on origin;
     - one relative path fragment (`moth-quantum/vendor/cft-fp256/host/cft.dll`), already public in Quantum-Film.
   - Nothing from the owner's checkout: 0 of its 5 uncommitted README lines and 0 of 1,165 references.md lines appear.
   - The owner's checkout: ` M README.md`, `?? docs/references.md`, be1d674 on main, unchanged.
7. **The old commit messages.** Under the lead's call they do not count. PINNED.md's new line quotes 78f35d3's and 27c9b4b's accurately. For the record, 3a79346's subject ("the rule refuses every float operator it reads") overstates too: INT1, float `+ - *` in the integer and primitive layers, is its own stated limit.

### What I did not do

- I did not rebuild P2's R6, INT1, CAST1 or CAST1b plants.
- I fixed nothing, pushed nothing, called no Atlas API, and wrote nothing in the shared scratchpad or in P2's or the owner's checkouts.
- Kept: my clone (clean, at f3aa361) and verify-p2-work/ (plant5.py, ast_nodoc.py, wsl_run6.sh, logs/). The plant copies and the WSL clone are removed.

NOT READY: one sentence of PINNED.md (line 617, "neither of which can run in a pinned chain") is false as stated. Its own MP3v and TR1 refute it, and P2 corrected the identical claim in the docstring beside it. With that phrase replaced by the docstring's wording, the branch is READY TO PUSH: the code, the bits, the default path and the history are clean, and every other claim I checked holds.

## 2026-09-26 07:38Z - verifier-P2's confirming pass, d4007b2: D18 is closed, one line, true as stated; READY TO PUSH

Measured: everything below. My clone fetched `pinned` from P2's clone.
- The head is d4007b27b63cbe407ccb8e308f1c593e3e7df989, and its parent is f3aa361.
- Over be1d674 the branch is 78f35d3, e5f63f8, 27c9b4b, 3a79346, f3aa361 and d4007b2.
Believed: -
For: lead (the push), P2

- **The commit changes only that line.** `git diff --numstat f3aa361 d4007b2` gives "1 1 docs/PINNED.md". The one line now reads "`np.interp`, which pinned code may not call: the rule refuses both, and the trap traps them): it decides the". Nothing else in the tree changed. The suite with QF_CFT_ROOT: "284 passed, 1 skipped". ruff is clean.
- **The sentence is true as stated.** I planted each call in a copy of d4007b2:
  - np.log10 on the reciprocity rows in `_reciprocity_pinned`: the rule names it ("np.log10() is not on the model layer's allowlist"), and the trap traps it in the hd22 t=100 chain ("numpy.log10 called from atlas_film.films:799").
  - np.interp in `_characteristic_pinned`: the rule names it ("np.interp() is not ..."), and the trap traps it in the intensified collodion chain.

  It now agrees with `_reciprocity_pinned`'s docstring, and it reads correctly: the second "which" takes log10 and np.interp. Only the source line is longer than its neighbours, which the rendering reflows.
- **The branch is still clean to publish**, over be1d674..d4007b2:
  - no key, token, credential or machine path in the 18 files or the six messages;
  - one e-mail, noreply@anthropic.com, in the Co-Authored-By lines;
  - the identity already public on origin;
  - README.md is be1d674's, and docs/references.md is absent;
  - P2's clone is clean, on `pinned` at d4007b2;
  - `git ls-remote origin` shows only HEAD and refs/heads/main, at be1d674;
  - the owner's checkout is ` M README.md`, `?? docs/references.md`, be1d674 on main, and unchanged.
- Everything else stands as measured at f3aa361 (07:34Z).
- I fixed nothing, pushed nothing, called no Atlas API, and wrote nothing outside my clone, verify-p2-work/ and this file. The plant copies are removed.

READY TO PUSH
