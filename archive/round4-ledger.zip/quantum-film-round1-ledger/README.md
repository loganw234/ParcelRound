# The round ledger: Quantum-Film round 1

Scaffolding for a parcel round, not history. It is in no repository and
outside every worktree. At the end of the round the lead folds anything
durable into Quantum-Film's docs/VALIDATION.md (and atlas-film's own records),
archives this directory beside the round's case study in ParcelRound, and
deletes the working copy.

It exists because **a brief is written once, at dispatch, and cannot be
updated.** Anything learned while the parcels are running otherwise reaches
them never: it arrives in a final report, after the sibling who needed it has
finished.

## How to use it

Reach it by its absolute path:

    C:\Users\logan\source\repos\quantum-film-ledger\round1

In Git Bash that is `/c/Users/logan/source/repos/quantum-film-ledger/round1`.

**One file per author, append only.** Yours is `<your-name>.md`: `P1.md`,
`verifier-P0.md`, `lead.md`. Read every file in the directory; write only to
your own. Never edit anyone else's, and never edit an entry you already wrote:
append a correction underneath instead.

**Read at three moments.** These are the floor, not the mechanism;
`urgent/` below is the rest of it.
1. Once, before starting anything.
2. Again before designing anything that touches a file your brief called
   shared or forbidden.
3. Again before writing your final report.

**Write when this clears the bar:** *would it have changed another parcel's
work, or the lead's?* Three things do:
1. **Environment and setup:** what the tree needs before it builds, what your
   base commit actually turned out to be, a tool that is not where it looks.
2. **A brief that turned out wrong:** the moment you find it, not in your
   report. A sibling may be acting on the same wrong premise right now.
3. **A finding about shared code:** behaviour in a function another parcel
   owns, an upstream defect, a constraint that will bind someone else.

**Do not write** progress, plans, or anything only your own parcel cares
about. A ledger full of status is one nobody reads.

**Mark what you measured.** Every entry says which claims were *measured* and
which are *believed*. Other agents build on these, and an unverified claim
propagates faster than a verified one.

**Stamp times from the clock, not from memory.** Run `date -u +%H:%MZ` and
paste its output. In ParcelRound's round 2 every author guessed ahead by
minutes to hours.

## `urgent/`: the push channel

The three read moments are a polling schedule, and its latency is its
interval. `urgent/` is the way past that. **Arm a watcher on it before you
start anything**, persistently, inline rather than from a script file:

```bash
U=/c/Users/logan/source/repos/quantum-film-ledger/round1/urgent; mkdir -p "$U"
seen=$(ls "$U" 2>/dev/null | sort)
while true; do
  cur=$(ls "$U" 2>/dev/null | sort)
  comm -13 <(echo "$seen") <(echo "$cur") | while read -r f; do
    head -1 "$U/$f"; grep -m1 '^For:' "$U/$f" 2>/dev/null || true
  done
  seen=$cur; sleep 20
done
```

- **The watch is latency reduction, not the mechanism.** A dead watcher looks
  exactly like a quiet directory. If yours is gone, re-arm it **and do a full
  read**.
- **The bar for `urgent/` is "stop what you are doing and read this"**, and
  it is mostly the lead's.
- **Escalating to the lead is what the channel is for too.** If your brief is
  wrong, or you are in the wrong place, put it here rather than in your
  final report. An escalation that turns out to be your own misreading costs
  nothing.
- **One file per message, renamed into place.** Compose it elsewhere and `mv`
  it in, named `<who>-<short-slug>.md`. The first line is the headline, and
  it needs a `For:` line, because the watcher prints only those two.
- **Verifiers watch the lead's file only.**

## Entry format

    ## <date time from `date -u`> - <one-line headline>

    Measured: ...
    Believed: ...
    For: <who this is likely to matter to, or "anyone">
