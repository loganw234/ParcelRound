# lead

## 2026-09-25 20:05Z - the round's facts, as the lead knows them at dispatch

Measured:
- Quantum-Film main is 775b5ed (pushed; git ls-remote agrees). make verify:
  9 passed, atlas skipped by name. make verify-quick: 19.1 s.
- The lead's built libcft: /c/Users/logan/source/repos/moth-quantum/vendor/cft-fp256/host/cft.dll
  (submodule 7d7285d; ABI 0.14). The Python binding is vendor/cft-fp256/bindings/python/cftmpfr
  (ctypes); set QF_CFT_ROOT=C:/Users/logan/source/repos/moth-quantum/vendor/cft-fp256.
  A git worktree of Quantum-Film has the submodule UNINITIALISED: use this copy; do not build.
- libcft transcendentals cost ~0.4 ms per element at binary64 (measured 2026-09-25 in WASM,
  native believed similar): build tables once, never per element.
- Git Bash traps on this desktop: MSYS rewrites slash-leading args (MSYS_NO_PATHCONV=1);
  long heredocs with backslashes are mangled (write a script file, then run it);
  Windows Python cannot see Git Bash's /tmp (use a Windows path).
- Third-party pytest plugins must stay off (PYTEST_DISABLE_PLUGIN_AUTOLOAD=1); the
  runner's pytest-stage.sh sets it.
Believed: nothing else.
For: anyone

## 2026-09-25 20:15Z - the owner confirmed P2's scope: libcft is the oracle; binary256 is the precision yardstick

Measured: nothing new; this is a decision.
Believed: -
The owner confirmed the design direction in P2's brief: pinned binary64 primitives at
numpy speed, and cft-fp256's libcft as the oracle that replays the same operation
sequence bit for bit. Running programs on the U50 is out of scope. A binary256
evaluation through libcft is the yardstick for whether binary64 is precise enough,
measured in output units (16-bit threshold steps; float32 ulps). The brief now says so.
For: P2, verifier-P2

## 2026-09-25 20:51Z - verifier-P0 read in full; P1-P3 are held until its defects are fixed on main

Measured: an untracked clone, moth-quantum/qf-verify-p0/ (made 13:34 local, pristine at 775b5ed,
submodule uninitialised), sat inside the lead's tree; verifier-P0's "what I did not do" does not
list it. It is removed. The lead's own watch on this directory was armed only at 20:48Z, after the
owner noticed it missing; everything written before then (urgent/ at 20:43Z included) was read in
full at 20:48-20:50Z.
Believed: -
Every defect in verifier-P0 is accepted for triage; the lead confirms each before fixing it. The
briefs are corrected before dispatch: P3's for 8a, P1's for 7e, 11a and 11c.
For: anyone; verifier-P0 especially

## 2026-09-25 20:53Z - P2 dispatched ahead of P0's fixes: none of verifier-P0's findings touch its inputs

Measured: atlas-film-round1 is on pinned at be1d674, clean; the owner's checkout is as it was
(README.md modified, docs/references.md untracked, be1d674). briefs/P2.md as dispatched: sha256
05be2bee24889120...; it gained two lines before dispatch, both measured by verifier-P0: libcft's native cost
(cos 0.211 ms, exp 0.110 ms per element at binary64) and mpmath's process-global precision.
Believed: nothing in verifier-P0 bears on P2. Its findings are all in Quantum-Film's seams (the
runner, the fixer, the law and margin gates, the Atlas attribution), and P2 works in atlas-film,
reading only the lead's libcft build. P1 and P3 branch from Quantum-Film main and wait for the fixes.
From here briefs/P2.md is frozen; anything P2 needs to know arrives in this file or in urgent/.
For: P2, verifier-P2

## 2026-09-25 22:28Z - P0's defects fixed at b0e9ed1 (pushed); P1 and P3 dispatched from it

Measured:
- Quantum-Film main is b0e9ed1c0d8906da9320ac043abecc10d68e2594; git ls-remote agrees.
  bash verify/run.sh --require-all: 12 passed, 0 skipped (cft and the live atlas smoke ran), 33 s.
  --budget quick: 10 passed, 28.6 s, with P2 running on the same desktop.
- Every verifier-P0 defect was planted in a scratch copy of the fixed tree and refused; the
  table is in docs/VALIDATION.md (the verifier's entry). Three more found by the lead on the way:
  - under MSYS_NO_PATHCONV=1, the runner's git -C /c/... failed silently: every run "nogit" and
    never dirty, so a dirty tree could pass the --resume guard. git now runs inside the tree.
  - the client compared host but not scheme: http://api.mothquantum.com would have sent the
    key in clear. Now compared; tests/client/ holds both refusals offline.
  - tools/atlas_smoke.py (the lead's) called Atlas on import: the eighth unguarded script,
    found by the new gate tests/docs/test_atlas_guards.py on its first run.
- P2.md 21:52Z was read at 22:25Z: the lead's watch expired at its 30-minute limit at ~21:18Z
  and was re-armed at 22:25Z with its shadow kept, so the entry arrived on the first pass.
- Briefs as dispatched: P1 sha256 1010536b78d389e0..., P3 sha256 5f36d74955229f8e.... Both at b0e9ed1. P1's carries
  7e (no skip inside a stage), 11a (the cft stage honours QF_CFT_ROOT), 11c (no threads), the
  trace= hook, and P2's replay-laundering and man_exp findings. P3's carries 8a (its run is the
  first of the shelf's law on Atlas; score against golden, not atlas_tile_compare's box),
  commitment v2, fixer.text, Python ints, the forbidden-layout count, and the QASM committed.
Believed: -
From here briefs/P1.md and briefs/P3.md are frozen.
For: P1, P3, verifier-P0, verifier-P1, verifier-P3

## 2026-09-25 22:35Z - the owner cleared pushing atlas-film's pinned branch, when ready

Measured: nothing new; this is a decision. The owner: "You are clear to push when ready".
Believed: -
"Ready" is the lead's reading: after verifier-P2 has reported, and each defect it finds is fixed
and re-checked or recorded as a known limit. Only the branch pinned goes to origin; atlas-film's
main is not touched, and the owner's checkout never is.
For: verifier-P2, anyone

## 2026-09-25 22:52Z - P3's two findings accepted; both land in P0's files at P3's merge

Measured (the lead, reading b0e9ed1): client.run_job POSTs, then polls
/api/v1/jobs/{id}/status (save=False) before GET .../result. So with P3's finding (a completed
job's status carries the whole result), run_job cannot run a device roll: the result reaches the
process before any commitment could be published. docs/records/2026-09-25/atlas/ holds status
responses from 17:33Z; P3 cites the one for job 9e04918d.
Believed: -
- The timing rule becomes: form and commit the commitment after the POST and before the job's
  FIRST status call. P3's tool already does that. fixer.py's comment, ATLAS.md and run_job's
  docstring will say so at P3's merge. Until then, nobody forms a device roll through run_job.
- 51 rotations and 102 cx for pauli-4x4 (four exact zeros skipped): ROADMAP.md, givens.py's
  docstring and VALIDATION.md's newest entry say 55 and 110, the generic (M - N)N bound. They are
  corrected at P3's merge with the count verifier-P3 confirms (VALIDATION.md by a new entry; it
  is append-only).
- For verifier-P3: the skip is an exact-zero test on float values (P3: every entry examined is
  <= 6.5e-17 or >= 0.25). Whether the rotation count can differ on another machine, and what
  the kernel error is with the four rotations kept instead, are worth a line.
For: P3, verifier-P3, verifier-P0

## 2026-09-25 23:03Z - verifier-P0's re-verification read; its four new defects and five minor ones are the lead's to fix next

Measured: nothing new yet.
Believed: -
To be fixed on main, each with the fault planted and refused before commit:
- 1: the premise gate gets references that share no code with sample(). For pauli-4x4, K is
  rational (entries k/16), so every chain-rule weight and boundary is an exact Fraction. For the
  16x16 stock, an independent chain rule in the test at 512 bits, plus a closed-form check of the
  basis at 512 bits (the verifier's item 1 noted the 16x16 span had no independent gate).
- 2: orbitals() refuses, and so does not cache, a basis whose precision moved while it was built.
- 3: guards gate: a script under research/ or tools/ that imports an Atlas client in any form must
  refuse import. A library module under quantum_film/ may not call Atlas at import, with dotted,
  relative and star imports, nested blocks, class bodies, decorators and defaults all read.
- 4: --resume refuses an environment that differs from the run's: QF_CFT_ROOT, the DLL's hash,
  python and package versions, and whether an Atlas key is set.
- Minor: all stages skipped is FAILED; a tree that is not its own git toplevel is "nogit";
  pytest-stage clears PYTEST_ADDOPTS; check() holds a golden roll's authority and code to exactly
  what lay() writes;  refuses a non-integer seed by name.
- CLAUDE.md's "not pinned by hash" is corrected: the builds differ in three PE fields only.
For P1: pauli-4x4's exact Fraction boundaries will be importable from the new test as a reference.
For: verifier-P0, P1, P3, verifier-P1, verifier-P3

Correction to the entry above (23:04Z): its minor-fixes line lost two words to the shell. It reads: the fixer's lay command refuses a non-integer seed by name.
For: verifier-P0

## 2026-09-25 23:18Z - the re-check's defects fixed at 5fe9741 (pushed); P1's correction to its own control accepted

Measured:
- Quantum-Film main is 5fe97411de9014f358bacb9a9eeb885004704d13; git ls-remote agrees.
  bash verify/run.sh --require-all: 12 passed, 0 skipped, 30.6 s. docs/VALIDATION.md's newest
  entry has each fix, and the fault planted against it in a scratch copy.
- The premise gate now measures against code the authority does not share. Exact Fractions on
  pauli-4x4 give 2^-252.4 (20 rolls); an independent 512-bit chain rule on the 16x16 stock gives
  2^-249.2. Four of verifier-P0's six binary64 slips are caught by it; the other two are inert on
  today's shelf, and a new source rule (no binary64 in golden) catches all six.
- tests/golden/test_golden_premise.py has exact_draws(stream) (pauli-4x4, Fractions) and
  independent_draws(stream, L, r2) (512 bits). P1 may import them by path as references; they are
  test code, not the authority.
Believed: -
- P1's finding (23:17Z) is right, and it is the lead's error. The brief's "about 1e-14 (relative)"
  names where P1's certificate starts to hand off, not where binary64 starts to err, so the control
  as briefed could not fail. P1's plant inside binary64's own error at the boundary (3e-17 to 4e-16
  relative, found per stream) is the control. verifier-P1 should hold P1 to that, not to the
  brief's number.
For: P1, verifier-P0, verifier-P1

## 2026-09-25 23:27Z - a usage limit is expected within minutes; agents may stop mid-task, and will be resumed

Measured: nothing new. The owner: a usage limit will pause work for about 30 minutes; agents are to
run until they stop, then be resumed.
Believed: -
In flight: P1 (the pinned sampler), verifier-P2, verifier-P3, and verifier-P0's third pass.
Nothing will be merged or pushed until each is resumed and has reported.
On resume, each agent:
- does a full read of this ledger, its own file included, to see what it already recorded;
- checks its tree (git status, git log) before trusting its memory of what it had done;
- re-arms its watch (P1 on urgent/, verifiers on lead.md);
- continues, and says in its report where it was interrupted.
For: P1, verifier-P0, verifier-P2, verifier-P3

## 2026-09-25 23:30Z - verifier-P2 read; atlas-film's pinned branch is NOT ready to push

Measured: nothing new by the lead; verifier-P2.md (23:30Z) has the numbers.
Believed: -
The chains verifier-P2 ran give the same bits everywhere, but its defects stand between 78f35d3 and
the owner's push:
- D1, the replay is blind to libm on scalars;
- D2, the source rule misses math.*, np.emath.*, np.add.reduce and np.vecdot;
- D3, non-finite dials are not refused;
- D4, supplied sheets are under-checked, which Quantum-Film's sheets next round depend on;
- D5, the sensitometry readers accept pinned=True.
Plan, after the usage pause: P2 is resumed to fix D1-D5 and the minors, with each fault planted and
refused. verifier-P2 re-checks. Only then does the pinned branch go to origin.
For: P2, verifier-P2

## 2026-09-26 00:40Z - main's runner runs under %TEMP% again (900b9e5); the third pass's other defects are being fixed

Measured: 900b9e5ef68050535cbc679f8e5a8371be3051b2 is main; git ls-remote agrees. A clone under
%TEMP% runs from its /c/... path and from its /tmp/... path, and an export nested inside another
repository still runs as nogit. The toplevel test is now git rev-parse --show-cdup, which needs no
path spelling.
Believed: -
For verifier-P3: main's front door is usable for your merge check from 900b9e5. P3's branch itself
(34c759e) carries b0e9ed1's runner, which never had this defect.
Being fixed next, in one commit:
- an exact L = 6 reference beside the 16x16 one;
- the mirror near-tie plant;
- import is inert: every module refuses import, or runs only an allowlist of pure calls at import;
- the binding and tool versions in the resume fingerprint;
- a content check on the basis before caching;
- `fixer lay` refuses an unknown stock by name.
For: verifier-P3, verifier-P0, P1

## 2026-09-26 00:52Z - main is 73a79af: the third pass's defects and verifier-P3's fixer findings are fixed; P1 and P3 need no change for them

Measured: 73a79af2632a87d1d711548c9939274ba21e9f49 is main; git ls-remote agrees.
run.sh --require-all at 1a92c62: 12 passed, 0 skipped. docs/VALIDATION.md's two newest entries have
every fix and the fault planted against it.
What reaches the parcels' merges, checked against their branches by the lead (bc57a57 and 34c759e):
- Import is inert: every module refuses import, or calls only pure modules at import. Every new
  module on both branches passes. The rule refuses only their base's old research scripts, which main
  has since guarded.
- The fixer knows occurrences (1..shots) and refuses unknown source fields; P3's rolls carry only
  known ones. A device roll may lay any crystal count.
- The premise gate has an exact L = 6 reference; P1 may read exact_draws(stream, L=6, r2=1) too.
- A mirror near-tie plant, 2^-240 below a boundary, must be refused. P1's control plants on one
  side only, and would profit from the other.
Believed: -
The owner's instruction (00:5xZ): once P1, P2 and P3 finish, no further agents. The lead pauses and
documents where the round stands, and waits for the owner. Verifiers for P1, and re-checks of P2's
and P3's fixes, wait for that word.
For: P1, P2, P3

## 2026-09-26 01:56Z - THE ROUND IS PAUSED at the owner's word: where everything stands, what is owed, and what was missed

Measured (the lead, 01:55Z):
- Quantum-Film main is 73a79af, local and remote alike, and clean. run.sh --require-all at 1a92c62:
  12 passed, 0 skipped; --budget quick at 73a79af: PASSED.
- P1: branch worktree-agent-acba6146d975d5e26 at 857065b (on b0e9ed1), clean. It merges onto main
  cleanly (git merge-tree). P1 reported its merged tree passes ruff, tests/pinned and tests/docs
  (135 passed), with main's import rule.
- P3: branch worktree-agent-ab2e8468056a7cea0 at 961b385 (on b0e9ed1), clean. It merges onto main
  cleanly. It used 1 of its 6 Atlas jobs.
- P2: atlas-film-round1 on pinned at e5f63f8 (78f35d3 + e5f63f8), clean, NOT on origin. The owner's
  checkout is as it was (README.md modified, docs/references.md untracked, be1d674).
- ParcelRound main is b7818cf, local and remote; CASE-STUDY-4.md is current to 17:52 local.
- No agent is running. No verifier was dispatched after the owner's word.
Believed: -

### Owed, in the order the lead would take them on the owner's word
1. **verifier-P2 re-checks e5f63f8**, P2's fixes for D1-D7. After it, and only then, atlas-film's
   pinned branch is pushed to origin: the owner cleared that "when ready". Only the branch; never
   atlas-film's main or the owner's checkout.
2. **verifier-P3 re-checks 961b385**, P3's fixes, then P3 merges onto main. At that merge the lead
   also lands:
   - 51 rotations and 102 cx for pauli-4x4, replacing 55 and 110 (ROADMAP.md, givens.py's docstring,
     a new VALIDATION.md entry);
   - the status-carries-the-result rule in ATLAS.md and in client.run_job's docstring;
   - README: the shelf's law has run on Atlas (job 8586f1cc), with its scores and circuit hash;
   - circuits/__init__.py's docstring (givens_line is held by test_givens_line.py);
   - a DECODE version constant, so "quantum_film.atlas.decode/v1" has one home (P3's suggestion).
3. **verifier-P1**, first dispatch: P1 has had no verifier. Then P1 merges. At that merge:
   - ROUND1.md: "for that draw" becomes "for that roll";
   - CLAUDE.md: an outputs gate cannot see a fault in an enclosure; test basenames must be unique
     across tests/; ctypes .data, not .data_as;
   - DETERMINISM.md: the pinned path, equal by construction. The binary32 "2 of 40" is the 64x64
     prototype's; on the shelf, plain formats parted on 0 random rolls;
   - README: the pinned path exists;
   - a registry-style gate for duplicate test basenames (P1's test_uniform.py broke `make test`).
4. **verifier-P0, a fourth pass**, over 900b9e5, 1a92c62 and 73a79af, which no verifier has checked.
5. **Round end**: METHOD.md's lessons with the owner, the ledger archived beside the case study, the
   worktrees and merged branches removed.

### Next round, not this one
- Commitment v3 binding `kind`, and anchor evidence that is not only the local clock: push the
  commitment before the first status call, or put its hash in the job request.
- A bundle format for device rolls (1,995 files for one job).
- Pinning libcft's DLL by a hash with its three PE timestamp and checksum fields zeroed.
- The plan's round 2:
  - Quantum-Film's development adapter (a layout into atlas-film's (K, thr) sheet, through P2's
    checked sheet= path);
  - Speckle's authority;
  - colour, the Pauli tripack;
  - hardware on IBM's Open Plan (the owner's account).
- Moth Hack deliverables: #9 is this repository; #10 is a notebook, not started.

### Time-bound
- The Atlas key expires about 17:25Z on 2026-09-26, about 15.5 hours from this entry. Any further
  Atlas run needs it or a new key.
- The hackathon's virtual build window is 26 September to 2 October. The submit link and deadline
  hour were unknown at 13:21Z on 2026-09-25; the owner is asking on Moth's Discord.

### What the lead missed, or got wrong, this round (each in the case study with its time)
- Its own ledger watch, unarmed until the owner noticed (13:48), and lapsed at the tool's 30-minute
  cap more than once; the kept snapshot meant no entry was lost.
- P0 credited the Atlas run to the wrong circuit and law, in five documents (8a).
- Gates the lead wrote to answer a verifier, that could not fail:
  - the premise gate compared the authority with itself;
  - the guards gate and golden's source rule named spellings, and were walked past;
  - the first allowlist would have refused both parcels' pure constructors, caught against their
    branches before either merged.
- A regression the lead introduced: the runner refused every clone under %TEMP% (5fe9741 to 900b9e5).
- P1's brief named a control, 1e-14 from a boundary, that could not fail.
- The briefs did not warn that every agent shares the lead's scratchpad, which holds the Atlas key.
- One ledger entry lost two words to an unquoted heredoc (corrected by an appended line); the case
  study's first afternoon times came from memory (corrected to stamps).
For: the owner, anyone resuming the round

## 2026-09-26 03:58Z - resumed at the owner's word ("Continue work"); four checks dispatched at once

Measured: nothing was written to the ledger during the pause (01:56Z to 03:56Z). Every branch head is
as the 01:56Z entry records: main 73a79af (local = remote), P1 857065b, P3 961b385, P2 e5f63f8.
The lead's watch was re-armed first, at 03:56Z.
Believed: -
Dispatched together, from the 01:56Z entry's list:
- verifier-P2 re-checks e5f63f8, ending READY TO PUSH or NOT READY;
- verifier-P3 re-checks 961b385 and its merge onto 73a79af, ending READY TO MERGE or NOT READY;
- verifier-P1, first dispatch, on 857065b and its merge, ending READY TO MERGE or NOT READY;
- verifier-P0, a fourth pass over 900b9e5, 1a92c62 and 73a79af.
The lead meanwhile lands on main only what needs no parcel: run_job's docstring and ATLAS.md on the
status call; a DECODE constant; a gate for duplicate test basenames (P1's suggestion).
For: verifier-P0, verifier-P1, verifier-P2, verifier-P3

## 2026-09-26 04:25Z - P3 MERGED (63a831e, integrated at bda92eb, pushed); P2 not ready (D8-D12), resumed; verifier-P0's fourth pass fixed (4ff989b)

Measured:
- main is bda92eb; git ls-remote agrees. The merged tree: run.sh --require-all 12 passed, 0
  skipped; all 1,995 P3 rolls pass main's fixer; one pytest session over tests/: 180 passed.
- 4ff989b (verifier-P0's fourth pass): imports are checked by BEHAVIOUR. Every module is imported
  under a PEP 578 audit hook in a child process (tests/docs/import_audit.py). 19 import clean, 15
  refuse, 0 effects. Nine planted effects are each stopped and named. P1's and P3's new modules have no
  effect at import. Also: the basis holds three kernel entries to the closed form; the resume
  fingerprint has the import path, the packages and the machine; fixed_at parses as a real time.
- verifier-P2 (04:23Z): NOT READY. D1-D7 fixed and the branch clean, but D8-D11 (libm at module
  level or before the pinned branch, long double, replay marks stripped) pass both gates, and
  PINNED.md claims them covered. P2 resumed to close or state each.
Believed: -
Next: verifier-P1's report, then P1's merge. P2's fixes, then verifier-P2's re-check, then the push.
For: P1, P2, verifier-P1, verifier-P2

## 2026-09-26 04:31Z - the lead's watch is now a background script (the owner's word); two watches racing raised false "REWRITTEN" alarms, and no ledger file was touched

Measured: at 04:28-04:30Z the expiring Monitor and the new script ran together, sharing one
snapshot's temporary files. Each moved the other's copy into the wrong file, and the snapshot's
P1.md came to hold urgent/lead-shared-scratchpad.md's 1,106 bytes. The real ledger was never
written by either: every file's size and latest entry were checked by hand at 04:30Z, and all match
what was read before. The Monitor was stopped, the snapshot rebuilt from the ledger (diff -rq
identical), and the script given per-run temporary files.
Believed: -
The owner, going to bed, asked for a watch that needs no consent: a background script that polls
every 20 s and exits on the first change or after 25 quiet minutes, relaunched by the lead each time.
For: anyone reading this ledger's watch-related entries

## 2026-09-26 04:34Z - verifier-P1: NOT READY; P1 resumed on D1-D5; D6 is the lead's at P1's merge

Measured: nothing new by the lead; verifier-P1.md (04:32Z) has the numbers.
Believed: -
- P1's arithmetic holds as verified: 600 + 60 rolls equal in crystals and draw order, 68 planted
  refusals never answered, the shim's 18 prototypes, 0.65x under load. The merge onto bda92eb is clean
  and green (quick budget with --require-all 11 passed; one session over tests/ 310 passed).
- Before the merge, P1 fixes:
  - D1: after a hand-off, a later refusal comes back as EnclosureBroken, from a prefix comparison;
  - D2: six one-ulp wrong-direction faults pass every gate, since the accumulations have no step test
    and wide boxes hide the slack. They are to be held on tight inputs;
  - D3: six round-to-nearest respellings pass the source rule;
  - D4: writable caches;
  - D5: a non-bytes stream.
- The lead's at the merge (D6): the Makefile, README and CLAUDE.md budget lines and timing, and P1's
  basename check, which duplicates main's registry gate since 2df3112.
For: P1, verifier-P1

## 2026-09-26 05:39Z - verifier-P1's re-check: NOT READY again; P1's third round is scoped to CONVERGE (close the structural gaps, state the spelling limit)

Measured: nothing new by the lead; verifier-P1.md (05:38Z) has the numbers.
Believed: a rule that reads spellings can always be walked past by a spelling it does not list:
Quantum-Film's guards gate twice, golden's source rule, P2's rule, and now P1's twice. What holds
is behaviour: tight exact checks inside the steps, and audit hooks and libm traps at the edges.
Decision:
- P1 CLOSES D7 (multi-entry tight boxes in check_inner) and D8 (a closed, named helper set for the
  orchestration, each helper with its own exact test; any other top-level function refused).
- P1 closes the five named respellings of D9 where cheap, and STATES the limit: the rule reads
  spellings; inside a step the tight check sees any rounding; in the orchestration, the rule and
  the end-to-end gates are what hold.
- verifier-P1's next pass judges READY if what is left is stated accurately, the standard it
  offered itself ("a gate, or a stated limit").
For: P1, verifier-P1

## 2026-09-26 05:54Z - verifier-P2's third pass: NOT READY; P2's next round is scoped to CONVERGE, as P1's is

Measured: nothing new by the lead; verifier-P2.md (05:54Z) has the numbers.
Believed: -
- D8-D12 are fixed as found. The bits and the branch are ready: digests hold on both hosts, the default
  path is unchanged, and no secret, e-mail or machine path is in any of the three commits.
- It is NOT READY because PINNED.md, which the push publishes, claims coverage refuted by:
  - D13: libm through  in a subscript or a validator;
  - D14: rebinding pinned code's exact methods from another module at import, np.vectorize calling a
    trapped function from numpy's frame, and a pre-filled count-law cache.
- P2 closes D13's structural holes (float BinOps in index contexts, validators, try, complex literals).
  It holds what it can of D14 (the exact methods, a _TABLES fingerprint) and states the rest as
  limits. PINNED.md is rewritten to claim exactly what the gates hold.
- verifier-P2's next pass judges READY on accurate stated limits, its own offered standard.
For: P2, verifier-P2

Correction to the entry above (05:55Z): its D13 line lost the operator to the shell. It reads: libm through the ** operator in a subscript or a validator.
For: P2, verifier-P2

## 2026-09-26 06:35Z - verifier-P1's third pass accepted: D10 is the one thing left; P1 is resumed on it

Measured: nothing new by the lead; verifier-P1.md (06:24Z) has the numbers.
Believed: -
- Closed in 6dcd5a1: D7, all five D8 faults, and R1-R5. The merge onto bda92eb is green (526 in one
  session). The shipped code is correct.
- Open, and narrow: D10. The end-to-end check reads decide's trace, not the position decide returns,
  so N3b (a decision certified without the Gram factor, traced honestly) passes every gate. P1 was
  resumed at 06:25Z to hold the returned position and the hand-off decision against the exact chain
  rule's, plant N3b, and correct the docstring and its report.
- Recorded, not blocking: a positional `initial` in max(...), and a method added to Located or
  Enclosure. P1 closes them if cheap, or states them.
The lead answered the 06:24Z report by resuming P1 at 06:25Z, but wrote this entry only at 06:35Z.
Verifiers watch this file, so the lead's answer belongs here first.
For: verifier-P1, P1

## 2026-09-26 06:44Z - P1's D10 fix (b7cb207) goes to verifier-P1 for its final pass; READY by the stated bar, then the merge

Measured: P1's branch head is b7cb207, one commit over 6dcd5a1, as P1.md 06:39Z says.
Believed: -
- verifier-P1 is resumed on b7cb207 and its merge onto main (bda92eb). The bar is the one in the
  05:39Z entry. NOT READY only for: a correctness defect in the shipped code; a claim false as stated;
  a fault that passes EVERY gate and is outside every limit P1 has stated. READY otherwise.
- On READY the lead merges P1 onto main (--no-ff) and lands D6 with it: the Makefile, README and
  CLAUDE.md budget lines and timing; P1's basename check removed (main's registry gate has held it
  since 2df3112); ROUND1.md "for that roll"; the DETERMINISM.md and README pinned-path lines; a
  VALIDATION.md entry. The full suite runs on the merged tree before the push.
- Two minors were closed as well: positional arguments are capped at a method's arity, and every
  class in the certificate must match its registered shape.
For: verifier-P1, P1

Correction to the entry above (06:40Z): it was written at 06:40Z by the clock. Its heading's 06:44Z was the lead's estimate, not a reading. The message to verifier-P1 cites it as "lead.md 06:44Z"; it is this entry.
For: verifier-P1, P1

## 2026-09-26 06:47Z - P2's D13-D16 round (3a79346) goes to verifier-P2; READY TO PUSH by the stated bar, then the push

Measured: atlas-film-round1's pinned head is 3a79346 (parent 27c9b4b), and the tree is clean, as P2.md 06:45Z says.
Believed: -
- verifier-P2 is resumed on 3a79346. Its bar is the 05:54Z entry's. It says NOT READY only for:
  - a correctness defect in the pinned mode's shipped code;
  - a claim in PINNED.md (which the push publishes) or in the commits that is false as stated;
  - a fault that passes EVERY gate and is outside every limit PINNED.md states.

  Otherwise it says READY TO PUSH.
- On READY TO PUSH the lead pushes atlas-film's `pinned` branch only, from atlas-film-round1, and checks it with
  git ls-remote. It never pushes atlas-film's main or touches the owner's checkout.
- P2 states new limits alongside the closures. MP3, MP3v, MP4 and R6 are below the names the run-time check holds.
  INT1 and CAST1b are operand types in the integer and primitive layers. Each has its plant, shown live by a tracer.
For: verifier-P2, P2

## 2026-09-26 06:51Z - verifier-P1: READY TO MERGE; P1 merges now, with D6 and the docs

Measured (the lead, on a trial merge in its own worktree, scratchpad lead/p1-merge):
- a389653 merges b7cb207 onto bda92eb (--no-ff) with no conflict; verify/run.sh auto-merged.
- 04fe2fe, the lead's integration on top, is D6 plus the docs. It covers:
  - the Makefile, README and CLAUDE.md budget lines, with `pinned` and ~55 s;
  - P1's basename check removed (main's registry gate holds it);
  - ROUND1.md: the roll is handed off whole;
  - DETERMINISM.md: the pinned path, its checks and its gap;
  - README: the pinned path, and the binary32 figure's 32x32 research tile. P1's report said 64x64; VALIDATION.md's
    2026-09-25 entry says 32x32 with 128 crystals;
  - ROADMAP: P1 merged;
  - CLAUDE.md: equality cannot see a faulty certificate.
- Results at 04fe2fe:
  - run.sh --require-all: 13 passed, 0 skipped, 51 s;
  - one pytest session over tests/: 537 passed. That is 539 less P1's two duplicate basename tests;
  - quick budget at a389653: 11 passed, 56 s, with verifier-P1 running beside it.
Believed: -
- main fast-forwards to 04fe2fe. A VALIDATION.md entry follows, and then the push.
- Recorded as open, not blocking: verifier-P1's N3m. It is a decision fault that fires only where the Gram bound is below
  2^-40, and it passes every gate because family G's bound is about 2^-36. It lies inside certificate.py's stated
  limit. A laddered family with a smaller bound would narrow it (believed, not tried).
For: P1, verifier-P1

## 2026-09-26 06:53Z - P1 MERGED and pushed (main 709055b); verifier-P0 makes a fifth and final pass over the lead's commits since 73a79af

Measured:
- main is 709055b, local and remote alike (git ls-remote). It is a389653 (the merge), 04fe2fe (the integration) and
  709055b (VALIDATION.md's entry), fast-forwarded from the trial branch.
- At 709055b, from the lead's tree with the in-tree libcft: --budget quick --require-all passed 11 in 47 s.
- At 04fe2fe: run.sh --require-all passed 13 of 13, the cft and live Atlas stages included (the Atlas stage makes GETs
  only). One pytest session over tests/ passed 537.
Believed: -
- verifier-P0 is resumed for a fifth, final pass. It covers the lead's own commits that no verifier has checked as the
  lead's: 2df3112, 4ff989b, bda92eb, 04fe2fe and 709055b. The parcels' code had its own verifiers. The lead's parts of
  the merges have not, and neither have the docs' claims about the parcels.
- P2: verifier-P2 is checking 3a79346 (06:47Z entry). The push follows READY TO PUSH.
For: verifier-P0, P1, verifier-P1

## 2026-09-26 07:13Z - verifier-P0 (07:09Z): one false claim, the lead's, corrected at 283330c (pushed); verifier-P2 (07:11Z): D17, one stated limit; P2 resumed on a docs-only round

Measured:
- main is 283330c, local = remote. Quick budget with --require-all: 11 passed.
- P1's measuring script (its p1-work/format_error.py) prints "(boundary - target) / (N - j), i.e. in units of u". There
  u is the uniform the target is drawn from, not a unit roundoff.
- quantum_film/pinned/measure.py's report_control prints the absolute distance first, and the distance relative to the
  boundary's value in brackets.
Believed: -
- verifier-P0's fifth pass: NOT READY on VALIDATION.md's "in units of u". The claim is the lead's, copied from P1's
  label without its definition.
  - It is corrected by an appended entry (283330c). The entry says what the figures are, a fraction of the weight left
    to draw, and gives them in unit roundoffs, about 7.7, 15.3 and 13.5.
  - The same entry corrects a second mislabel the lead found in that table: the control's "(relative)" figures are
    absolute distances.
  - The README's "relative" now reads "of the weight left to draw", and CLAUDE.md's unmeasured 2 us is gone.
  - verifier-P0 is asked to confirm the correction, and only that.
- verifier-P2's fourth pass: the code, the bits and the branch are ready. It is NOT READY on D17: TR1, a trace hook
  installed at colour.py's import, rewrites exp2_dd's k in place and passes every gate. PINNED.md says unread code
  reaches a chain "only through what the run-time check holds, or below it".
- P2 is resumed on a docs-only round, with no new gate:
  1. State the limit as a CLASS: code the interpreter runs inside a chain that pinned code did not call. That covers:
     - trace, profile and monitoring hooks;
     - gc callbacks and finalizers;
     - signal handlers;
     - other threads;
     - np.seterrcall.
     TR1 is its plant.
  2. Correct the "only through" sentence.
  3. Fix pinned_oracle.py's docstring, which still makes D1's refuted claim.
  4. The lead's call on the old commit messages: they stay, as history, like this ledger. PINNED.md gains one line: the
     branch's earlier commit messages carry claims that later commits refuted, and PINNED.md at the head is what is
     claimed.
  A tripwire at chain entry (sys.gettrace and the rest) goes on the next round's list, not this one.
- The push follows verifier-P2's READY TO PUSH.
For: P2, verifier-P2, verifier-P0

## 2026-09-26 07:18Z - verifier-P0: PASS at 283330c; the lead's P0 is verified, five passes in all

Measured: nothing new by the lead; verifier-P0.md (07:17Z) has the numbers.
- It re-ran P1's script on 283330c's code and reproduced P1.md's figures.
- The correction's conversions are right, and so are the control's absolute and relative spans.
- No other doc line carries either label.
- The quick budget passes 11 with --require-all.
Believed: -
- The P0 verifier's passes found, in turn:
  - 21 defects;
  - 4 new, three of them in the fixes' own gates;
  - 5, one a regression;
  - 5, the import allowlist walked past;
  - 1 claim false as stated, a label copied without its definition.
  Each was closed as found. No verifier pass is owed on main.
- Owed now: verifier-P2's pass on P2's docs-only round, then atlas-film's `pinned` push. Then the case study and the
  morning summary for the owner.
For: verifier-P0, the owner

## 2026-09-26 07:22Z - P2's docs-only round (f3aa361) goes to verifier-P2; READY TO PUSH by the stated bar, then the push

Measured: atlas-film-round1's `pinned` head is f3aa361. Its parent is 3a79346, and the tree is clean.
f3aa361 changes seven files: PINNED.md; docstrings and comments in films.py, processes.py and pinned_oracle.py; and three
test modules' docstrings. P2 reports the AST unchanged apart from docstrings.
Believed: -
- verifier-P2 is resumed on f3aa361 under the same bar (05:54Z and 06:47Z). It is NOT READY only for:
  - a correctness defect;
  - a claim false as stated;
  - a fault that passes every gate outside every stated limit.
  Otherwise it is READY TO PUSH.
- P2 amended its own commit once, before anyone had seen it, for atlas-film's lowercase subject style; fdc2e1f was the
  first cut. The branch as verified at 3a79346 is unchanged beneath it.
For: verifier-P2, P2

## 2026-09-26 07:34Z - verifier-P2 (07:34Z): D18, one phrase of PINNED.md; P2 replaces it with the docstring's own wording, then a confirming pass, then the push

Measured: atlas-film-round1's docs/PINNED.md line 617 reads "... `np.interp`, neither of which can run in a pinned
chain): it decides the ...".
Believed: -
- verifier-P2's fifth pass confirms that D17 is stated as found, the change is docs only, and the code, the bits, the
  default path and the branch are clean to publish. It found one claim false as stated (D18): line 617 says np.log10
  and np.interp "neither of which can run in a pinned chain". PINNED.md's own MP3v and TR1 refute it, and P2 had
  already corrected the same claim in the docstring beside it.
- P2 is resumed to replace that phrase, and only that, with the docstring's wording, "which pinned code may not call:
  the rule refuses both, and the trap traps them", in one commit. verifier-P2 then confirms that commit, and only that
  change, and the push follows READY TO PUSH.
For: P2, verifier-P2

## 2026-09-26 07:36Z - P2's D18 fix (d4007b2) goes to verifier-P2 for a confirming pass on that change only

Measured: atlas-film-round1's `pinned` head is d4007b2, whose parent is f3aa361, and the tree is clean. `git show
d4007b2` changes one line of docs/PINNED.md, from "neither of which can run in a pinned chain" to "which pinned code
may not call: the rule refuses both, and the trap traps them".
Believed: -
- verifier-P2 confirms d4007b2 against its 07:34Z finding and the bar. On READY TO PUSH the lead pushes `pinned`
  (be1d674..d4007b2) to atlas-film's origin, that branch only, and checks it with git ls-remote.
For: verifier-P2, P2

## 2026-09-26 07:38Z - verifier-P2: READY TO PUSH at d4007b2; the lead pushes atlas-film's `pinned` branch, and only it, under the owner's word

Measured, before the push:
- atlas-film-round1 is clean, on `pinned` at d4007b2.
- `git ls-remote origin` shows main at be1d674 and no other branch.
Believed: -
- The owner's word, 2026-09-25 22:35Z: "You are clear to push when ready". "Ready" is verifier-P2's READY TO PUSH (07:38Z).
- The push is `git push origin pinned` from atlas-film-round1, and nothing else. It does not touch main or the owner's
  checkout, and opens no pull request: whether and when `pinned` merges is the owner's call.
For: P2, verifier-P2, the owner

## 2026-09-26 07:39Z - atlas-film's `pinned` is PUSHED (d4007b2); round 1's parcels are all landed and verified

Measured:
- `git push origin pinned:refs/heads/pinned` from atlas-film-round1 created the new branch `pinned`.
- `git ls-remote origin` now shows main at be1d674, unchanged, and pinned at
  d4007b27b63cbe407ccb8e308f1c593e3e7df989.
- No pull request was opened.
Believed: -
Where round 1 stands:
- Quantum-Film main is 283330c, local and remote, after verifier-P0's PASS (07:17Z). It holds:
  - P0, verified in five passes;
  - P3 (63a831e, integrated at bda92eb);
  - P1 (a389653, integrated at 04fe2fe, with VALIDATION entries at 709055b and 283330c).
- atlas-film's pinned branch is on origin at d4007b2, after verifier-P2's READY TO PUSH (07:38Z). Merging it into
  atlas-film's main is the owner's call.
- Every parcel is landed and verified, and no agent has work owed. Agents may stop their watches.
Left for the owner (the lead does not do these):
- METHOD.md's lessons, from CASE-STUDY-4's observations;
- the ledger archived beside the case study;
- the worktrees, the merged branches, atlas-film-round1 and the verifiers' clones under %TEMP% removed;
- whether `pinned` merges into atlas-film's main.
Next round, not this one (from this ledger's entries):
- commitment v3 binding `kind`, with anchor evidence beyond the local clock;
- a bundle format for device rolls;
- the libcft DLL pinned by a hash with its PE timestamp and checksum fields zeroed;
- verifier-P1's N3m: a laddered family with a Gram bound below 2^-40;
- a tripwire at chain entry for P2's D17 class (sys.gettrace and the rest);
- P2's operand-type limits, INT1 and CAST1b;
- verifier-P3's minors: --score's exit code has no test, and fixed_at has no upper bound;
- round 2 in the plan: the development adapter through P2's sheet= path, Speckle's authority, colour, and IBM hardware
  (an account the owner creates);
- Moth Hack's #10 notebook.
Time-bound: the Atlas key expires about 17:25Z today. The build window is 26 September to 2 October.
For: the owner, P1, P2, P3, every verifier

## 2026-09-26 07:40Z - the lead's watch stops: no agent is running

Measured: P1 and P2 both report their watches stopped, and no verifier has one running. The lead stopped its own at 07:40Z.
Believed: -
The case study is pushed at ae77abc. Nothing more is written to this ledger until the owner picks up the round-end items in the 07:39Z entry.
For: the owner
