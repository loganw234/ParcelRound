"""Plant a wrong code commit in a copy's platform record.  Usage: python plant_platform.py <copy root> <day> <commit>"""
import json
import pathlib
import sys

root, day, commit = pathlib.Path(sys.argv[1]), sys.argv[2], sys.argv[3]
assert "qf-verify-p0-work" in str(root), root
p = root / f"docs/records/{day}/p3/circuit-ed767c01bd4b851d.platform.json"
raw = p.read_text(encoding="ascii")
rec = json.loads(raw)
old = rec["made_by"]["code_commit"]
rec["made_by"]["code_commit"] = commit
p.write_text(json.dumps(rec, sort_keys=True, indent=1, ensure_ascii=True) + ("\n" if raw.endswith("\n") else ""),
             encoding="ascii", newline="\n")
print(f"{day}: made_by.code_commit {old[:9]} -> {commit[:9]}")
