"""Plant one fault in a copy's quantum_film/develop.py.  Usage: python plant_develop.py <copy root> <fault>
These are the verifier's own, distinct from the lead's eight (VALIDATION.md, e7935ef)."""
import pathlib
import sys

NL = chr(10)
FAULTS = {
    # the offsets' axes swapped: a layer shifted by (ox, oy) instead of (oy, ox)
    "offsets-swapped": ("columns[((ty * L + r + oy) % H) * W + (tx * L + c + ox) % W]",
                        "columns[((ty * L + r + ox) % H) * W + (tx * L + c + oy) % W]"),
    # the thresholds' stream drops the layer: every layer's tile (ty, tx) reuses the same thresholds
    "thresholds-no-layer": ('parts = ("threshold", *print_stream, d, ty, tx)',
                            'parts = ("threshold", *print_stream, ty, tx)'),
    # a Sattolo walk in place of Fisher-Yates: still a permutation, but only cyclic ones
    "sattolo": ('j = _below(("shuffle", *print_stream), i, i + 1)',
                'j = _below(("shuffle", *print_stream), i, i)'),
    # the mean K a fraction off: M + 1 sites in the denominator
    "mean-k-off": ('return Fraction(layers * law["N"], law["M"])',
                   'return Fraction(layers * law["N"], law["M"] + 1)'),
    # device shots ordered by layout before job (a different canonical order)
    "device-order": ('keyed = sorted(((r["source"]["job_id"], tuple(r["crystals"]), int(r["source"].get("occurrences", 1)))',
                     'keyed = sorted(((tuple(r["crystals"]), r["source"]["job_id"], int(r["source"].get("occurrences", 1)))'),
    # the shadow check reads the package's parent, not the package: any copy beside another checkout passes
    "shadow-parent": ("if not where.is_relative_to(ATLAS_ROOT.resolve()):",
                      "if not where.parent.parent.is_relative_to(ATLAS_ROOT.resolve().parent):"),
}
root, fault = pathlib.Path(sys.argv[1]), sys.argv[2]
assert "qf-verify-p0-work" in str(root), root
p = root / "quantum_film/develop.py"
s = p.read_text(encoding="utf-8")
old, new = FAULTS[fault]
assert s.count(old) == 1, (fault, s.count(old))
if fault == "device-order":
    s = s.replace(old, new).replace("return [list(lay) for _job, lay, n in keyed for _ in range(n)]",
                                    "return [list(lay) for lay, _job, n in keyed for _ in range(n)]")
else:
    s = s.replace(old, new)
p.write_text(s, encoding="utf-8", newline=NL)
print("planted", fault)
