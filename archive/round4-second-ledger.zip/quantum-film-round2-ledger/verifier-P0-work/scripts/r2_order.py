"""Round 2's five Atlas runs, from git's history and the committed records alone:
for each job, the commit that first adds its commitment line, the commit that first adds its result, and the
first status call's own timestamp (the "at" the client records), all in UTC."""
import datetime
import json
import pathlib
import subprocess

ROOT = pathlib.Path(r"C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/fresh6")
R = ROOT / "docs/records/2026-09-26/p3"


def git(*a):
    return subprocess.run(["git", *a], cwd=ROOT, capture_output=True, text=True, check=True).stdout


def utc(iso):
    return datetime.datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone(datetime.timezone.utc)


def first_commit_adding(path, needle=None):
    """The oldest commit in which `path` exists (and, if given, contains `needle`)."""
    for line in git("log", "--reverse", "--format=%H %cI", "--", path).splitlines():
        h, when = line.split()
        if needle is None:
            return h[:7], utc(when)
        try:
            body = git("show", f"{h}:{path}")
        except subprocess.CalledProcessError:
            continue
        if needle in body:
            return h[:7], utc(when)
    return None, None


lines = [json.loads(ln) for ln in (R / "commitments.jsonl").read_text(encoding="utf-8").splitlines() if ln.strip()]
print(f"commitments.jsonl: {len(lines)} lines; keys {sorted(lines[0])}")
for c in lines:
    job = c["job_id"][:8]
    ch, ct = first_commit_adding("docs/records/2026-09-26/p3/commitments.jsonl", c["commitment"])
    rh, rt = first_commit_adding(f"docs/records/2026-09-26/p3/atlas-{job}-result.json")
    st = json.loads((R / f"atlas-{job}-status.json").read_text(encoding="utf-8"))
    at = st.get("at") or st.get("taken_at") or st.get("fetched_at")
    at_utc = utc(at) if isinstance(at, str) else None
    ok = ct is not None and rt is not None and ct < rt and (at_utc is None or ct <= at_utc)
    print(f"job {job}: commitment commit {ch} {ct:%H:%M:%SZ} | first status call at "
          f"{at_utc:%H:%M:%S.%fZ}" if at_utc else f"job {job}: commitment commit {ch} {ct} | status record has no time")
    print(f"           result commit {rh} {rt:%H:%M:%SZ} | commitment before status call and result: {ok}")
