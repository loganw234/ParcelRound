"""tiling_sk.py's variants: how strong must bunching be to lift S(k) above 1 above the tile's scale?
Same geometry (256 x 256 cells, 16 x 16 tiles, 91 layers, a random offset per layer, the record's radial S(k)).
Each tile holds exactly 25 distinct crystals inside a b x b block; the block sits at a random place in each tile
('random') or at the same place in every tile ('fixed'). k = 16 is the tile's scale; k < 16 is above it."""
import numpy as np

L, T, LAYERS, N = 16, 16, 91, 25
side = L * T
ky, kx = np.meshgrid(np.fft.fftfreq(side) * side, np.fft.fftfreq(side) * side, indexing="ij")
KR = np.rint(np.hypot(kx, ky)).astype(int)


def radial_s(K):
    f = K.astype(np.float64)
    P = np.abs(np.fft.fft2(f - f.mean())) ** 2 / (f.size * f.mean())
    return np.array([P[KR == k].mean() for k in range(1, side // 2)])


for b, where in ((6, "fixed"), (10, "random"), (12, "random"), (16, "random")):
    rng = np.random.default_rng(20260926)
    K = np.zeros((side, side), np.int64)
    for _d in range(LAYERS):
        oy, ox = rng.integers(0, L, 2)
        for ty in range(T):
            for tx in range(T):
                r0, c0 = (rng.integers(0, L - b + 1, 2) if where == "random" else (5, 5))
                block = [(r0 + i) * L + (c0 + j) for i in range(b) for j in range(b)]
                for s in rng.choice(block, N, replace=False):
                    r, c = divmod(int(s), L)
                    K[(ty * L + r + oy) % side, (tx * L + c + ox) % side] += 1
    S = radial_s(K)
    print(f"{b:2d} x {b:<2d} block, {where:6s}: S at k = 1, 2, 4, 8, 12, 15: "
          + ", ".join(f"{S[k - 1]:.3f}" for k in (1, 2, 4, 8, 12, 15))
          + f"; max over k = 1..15: {S[:15].max():.3f}")
