"""Round 2's Atlas figures, recomputed from the committed records alone through the shipped decoder and the golden
kernel: each run's scores, and all six runs pooled (the 2026-09-25 run 8586f1cc and the five of 2026-09-26)."""
import itertools
import json
import math
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(r"C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/fresh6")
sys.path.insert(0, str(ROOT))
import numpy as np  # noqa: E402

from quantum_film.atlas.decode import layouts  # noqa: E402
from quantum_film.golden import fermi  # noqa: E402

assert "fresh6" in fermi.__file__
RUNS = [("2026-09-25", "8586f1cc")] + [("2026-09-26", j) for j in ("579df87d", "d017540c", "5831ff5e", "3673f9fe", "933138bc")]
K = np.array([[float(v) for v in row] for row in fermi.kernel(4, 1, prec=128)])
M = 16
dets = {y: np.linalg.det(K[np.ix_(y, y)]) for y in itertools.combinations(range(M), 5)}
forbidden = {y for y, d in dets.items() if abs(d) < 1e-9}


def scores(lay):
    shots = sum(lay.values())
    z1 = []
    for q in range(M):
        m = sum(c for y, c in lay.items() if q in y) / shots
        z1.append((m - K[q, q]) / math.sqrt(K[q, q] * (1 - K[q, q]) / shots))
    z2 = []
    for i, j in itertools.combinations(range(M), 2):
        ex = K[i, i] * K[j, j] - K[i, j] ** 2
        m = sum(c for y, c in lay.items() if i in y and j in y) / shots
        z2.append((m - ex) / math.sqrt(ex * (1 - ex) / shots))
    return (shots, len(lay), max(map(abs, z1)), sum(z * z for z in z1), max(map(abs, z2)), sum(z * z for z in z2),
            sum(c for y, c in lay.items() if y in forbidden), sorted({len(y) for y in lay}))


pooled = {}
rolls_total = 0
for day, job in RUNS:
    rec = json.loads((ROOT / f"docs/records/{day}/p3/atlas-{job}-result.json").read_text(encoding="utf-8"))
    body = rec["response"]["result"]
    lay = layouts(body)
    for y, c in lay.items():
        pooled[y] = pooled.get(y, 0) + c
    s = scores(lay)
    xx, yy = body["observables"]["0,1"]["XX"], body["observables"]["0,1"]["YY"]
    rolls = len(list((ROOT / f"docs/records/{day}/p3/rolls-{job}").glob("*.json")))
    rolls_total += rolls
    print(f"{job}: shots {s[0]}, distinct {s[1]:,}, crystals/layout {s[7]}; one-site {s[2]:.2f}, {s[3]:.1f}; "
          f"pairs {s[4]:.2f}, {s[5]:.1f}; forbidden {s[6]}; XX {xx:+.4f}, YY {yy:+.4f}; roll files {rolls}")
s = scores(pooled)
allowed = sum(1 for d in dets.values() if abs(d) >= 1e-9)
print(f"POOLED: shots {s[0]:,}; distinct {s[1]:,} of {allowed:,} allowed; one-site {s[2]:.2f}, {s[3]:.1f}; "
      f"pairs {s[4]:.2f}, {s[5]:.1f}; forbidden {s[6]}; device roll files in all six runs: {rolls_total:,}")
new5 = sum(len(list((ROOT / f"docs/records/{d}/p3/rolls-{j}").glob("*.json"))) for d, j in RUNS[1:])
print(f"roll files in the five new runs: {new5:,}")
