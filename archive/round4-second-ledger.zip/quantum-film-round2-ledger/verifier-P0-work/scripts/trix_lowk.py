"""STOCKS.md: atlas-film's coating is 'a Poisson count per cell, whose S(k) is about 1 at every k'; the trix record reads
0.238 at k = 1. Coat the same sheet with atlas-film's pinned coat at seeds 1..12 (seed 1 must reproduce the record),
and compute the record's own radial S(k) (tools/first_prints.py's radial_s, copied here verbatim)."""
import json
import pathlib
import sys

ROOT = pathlib.Path(r"C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/fresh6")
sys.path.insert(0, str(ROOT))
import numpy as np  # noqa: E402

from quantum_film import develop  # noqa: E402


def radial_s(K):
    f = K.astype(np.float64)
    side = f.shape[0]
    P = np.abs(np.fft.fft2(f - f.mean())) ** 2 / (f.size * f.mean())
    ky, kx = np.meshgrid(np.fft.fftfreq(side) * side, np.fft.fftfreq(f.shape[1]) * f.shape[1], indexing="ij")
    kr = np.rint(np.hypot(kx, ky)).astype(int)
    return [round(float(P[kr == k].mean()), 4) for k in range(1, side // 2)], int((kr == 1).sum())


films, processes, emulsion = develop.atlas()
name, dmax, a, _kappa, _floor = develop.borrowed("pauli")
pitch = develop.pitch_um("pauli", 91)
rec = json.loads((ROOT / "docs/prints/trix.json").read_text(encoding="ascii"))
lows = []
for seed in range(1, 13):
    K, _thr = emulsion.coat(256 * 256, dmax, a, pitch, seed, pinned=True)
    S, n1 = radial_s(np.asarray(K).reshape(256, 256))
    if seed == 1:
        print(f"seed 1 reproduces the record's K digest: {develop.digest(K) == rec['digests']['K']}; "
              f"S(k=1) {S[0]} (record {rec['structure_factor']['S'][0]}); modes in the k = 1 bin: {n1}")
    lows.append(S[0])
    print(f"seed {seed:2d}: S at k = 1..4: {S[:4]}; mean S over k = 16..90: {np.mean(S[15:90]):.3f}")
print(f"S(k=1) over 12 seeds: mean {np.mean(lows):.3f}, min {min(lows)}, max {max(lows)}")
tw = json.loads((ROOT / "docs/prints/poisson.json").read_text(encoding="ascii"))["structure_factor"]["S"]
pa = json.loads((ROOT / "docs/prints/pauli.json").read_text(encoding="ascii"))["structure_factor"]["S"]
for lo, hi in ((16, 45), (16, 90)):
    print(f"k = {lo}..{hi}: pauli {min(pa[lo-1:hi]):.3f}-{max(pa[lo-1:hi]):.3f}; poisson twin "
          f"{min(tw[lo-1:hi]):.3f}-{max(tw[lo-1:hi]):.3f}; trix {min(rec['structure_factor']['S'][lo-1:hi]):.3f}-"
          f"{max(rec['structure_factor']['S'][lo-1:hi]):.3f}")
