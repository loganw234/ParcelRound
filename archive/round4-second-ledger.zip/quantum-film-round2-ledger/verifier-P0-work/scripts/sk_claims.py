"""The S(k) prose in VALIDATION.md (2026-09-26) and README.md, read against the print records' own structure_factor.
S[k-1] is the radial bin k (k in units of 2 pi / side), as tools/first_prints.py writes it."""
import json
import pathlib

P = pathlib.Path(r"C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/fresh6/docs/prints")
S = {n: json.loads((P / f"{n}.json").read_text(encoding="ascii"))["structure_factor"]["S"]
     for n in ("pauli", "poisson", "trix", "atlas-pauli-4x4", "golden-pauli-4x4")}
print("VALIDATION's table columns, from the records:")
for n in ("pauli", "poisson", "trix"):
    print(f"  {n:8s}", " ".join(f"k={k}:{S[n][k - 1]:.3f}" for k in (8, 16, 24, 32, 48, 64)))


def band(n, lo, hi, a=None, b=None):
    v = S[n][lo - 1:hi]
    out = f"  {n:8s} k = {lo}..{hi} ({len(v)} bins): {min(v):.3f} (k={lo + v.index(min(v))})" \
          f" - {max(v):.3f} (k={lo + v.index(max(v))})"
    if a is not None:
        outside = [lo + i for i, x in enumerate(v) if not a <= x <= b]
        out += f"; {len(outside)} bins outside [{a}, {b}]"
        above = [lo + i for i, x in enumerate(v) if x > b]
        out += f", {len(above)} above {b}"
    print(out)


print("VALIDATION line 1173: pauli 'between k = 16 and k = 90 ... 0.29-0.72':")
band("pauli", 16, 90, 0.29, 0.72)
print("  pauli at k = 70, 80, 85, 90:", [round(S["pauli"][k - 1], 3) for k in (70, 80, 85, 90)])
print("  mean of pauli over k = 81..90:", round(sum(S["pauli"][80:90]) / 10, 3))
band("pauli", 16, 64, 0.29, 0.72)
print("README lines 52-54, 'between a Pauli tile's scale and its Fermi scale' (k = 16..45):")
band("pauli", 16, 45, 0.29, 0.71)
band("poisson", 16, 45, 0.80, 0.96)
band("trix", 16, 45)
band("trix", 16, 90)
print("Twin vs pauli over 16..45: pauli max", round(max(S["pauli"][15:45]), 3), "< twin min",
      round(min(S["poisson"][15:45]), 3), ":", max(S["pauli"][15:45]) < min(S["poisson"][15:45]))
print("Below the tile scale, twin k = 1..8:", [round(x, 3) for x in S["poisson"][:8]])
print("4x4 pair at k = 8, 16, 32:", [round(S["atlas-pauli-4x4"][k - 1], 3) for k in (8, 16, 32)],
      [round(S["golden-pauli-4x4"][k - 1], 3) for k in (8, 16, 32)])
