"""'The Atlas-laid sheet and its exact twin trace the same curve' (README; VALIDATION 2026-09-26 gives k = 8, 16, 32).
Every bin of the two records' S(k), against the noise of a bin: a bin's mean of n independent periodogram values
(each about exponential with mean S) has sd about S / sqrt(n), with n = half the bin's modes (a real field).
A second exact sheet (golden rolls on other seeds, laid by develop.sheet on the same print stream) is the null."""
import json
import pathlib
import sys

ROOT = pathlib.Path(r"C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/fresh6")
sys.path.insert(0, str(ROOT))
import numpy as np  # noqa: E402

from quantum_film import develop  # noqa: E402
from quantum_film.golden import fermi  # noqa: E402
from quantum_film.golden.uniform import stream  # noqa: E402
from quantum_film.stocks import params  # noqa: E402

side = 116
ky, kx = np.meshgrid(np.fft.fftfreq(side) * side, np.fft.fftfreq(side) * side, indexing="ij")
kr = np.rint(np.hypot(kx, ky)).astype(int)
modes = np.array([(kr == k).sum() for k in range(1, side // 2)])


def radial_s(K):
    f = K.astype(np.float64)
    P = np.abs(np.fft.fft2(f - f.mean())) ** 2 / (f.size * f.mean())
    return np.array([P[kr == k].mean() for k in range(1, side // 2)])


def zs(a, b):
    sd = np.sqrt((a ** 2 + b ** 2) / (modes / 2))
    return (a - b) / sd


A = np.array(json.loads((ROOT / "docs/prints/atlas-pauli-4x4.json").read_text("ascii"))["structure_factor"]["S"])
G = np.array(json.loads((ROOT / "docs/prints/golden-pauli-4x4.json").read_text("ascii"))["structure_factor"]["S"])
z = zs(A, G)
print(f"atlas vs golden, {len(z)} bins: sum z^2 {np.sum(z ** 2):.1f}; max |z| {np.abs(z).max():.2f} at k = "
      f"{1 + int(np.abs(z).argmax())}; z at k = 8, 16, 32: {z[7]:.2f}, {z[15]:.2f}, {z[31]:.2f}")
for lo, hi in ((1, 8), (9, 16), (17, 29), (30, 45), (46, 57)):
    print(f"  mean S over k = {lo}..{hi}: atlas {A[lo - 1:hi].mean():.3f}, golden {G[lo - 1:hi].mean():.3f}")

law = params("pauli-4x4")
n = 29 * 29 * 29
lay = [list(fermi.sample(law["L"], law["fermi_r2"], stream("roll", "pauli-4x4", 100000 + i))) for i in range(n)]
K, _thr, _hw = develop.sheet(lay, "pauli-4x4", (29, 29), 29, ("print", "golden-pauli-4x4"))
G2 = radial_s(np.asarray(K).reshape(side, side))
z2 = zs(G2, G)
print(f"null, a second golden sheet vs the golden record: sum z^2 {np.sum(z2 ** 2):.1f}; max |z| "
      f"{np.abs(z2).max():.2f}; S at k = 8, 16, 32: {G2[7]:.3f}, {G2[15]:.3f}, {G2[31]:.3f}")
