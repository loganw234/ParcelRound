"""05011bd's corrected S(k) sentences, against the print records (S[k-1] is radial bin k, units of 2 pi / side).
Run with the clone's root as argv[1]."""
import json
import pathlib
import sys

import numpy as np

P = pathlib.Path(sys.argv[1]) / "docs" / "prints"
S = {n: np.array(json.loads((P / f"{n}.json").read_text(encoding="ascii"))["structure_factor"]["S"])
     for n in ("pauli", "poisson", "trix")}
for n in ("pauli", "poisson", "trix"):
    v = S[n][15:45]
    print(f"{n:8s} k = 16..45 ({len(v)} bins): min {v.min():.4f}, max {v.max():.4f}, mean {v.mean():.4f}")
print("every pauli bin below every twin bin, k = 16..45:", S["pauli"][15:45].max() < S["poisson"][15:45].min())
print(f"pauli max over k = 16..90: {S['pauli'][15:90].max():.3f} at k = {16 + int(S['pauli'][15:90].argmax())}")
lo = S["pauli"][:15], S["poisson"][:15]
print("below the tile scale, k = 1..15: pauli max", round(float(lo[0].max()), 3), "; twin max", round(float(lo[1].max()), 3),
      "; pauli below the twin in", int((lo[0] < lo[1]).sum()), "of 15 bins")
print("twin k = 9..15:", [round(float(x), 3) for x in S["poisson"][8:15]])
side = 256
f = np.fft.fftfreq(side) * side
ky, kx = np.meshgrid(f, f, indexing="ij")
kr = np.rint(np.hypot(kx, ky)).astype(int)
print("modes in the k = 1 bin of a 256 sheet:", int((kr == 1).sum()),
      [(int(a), int(b)) for a, b in zip(ky[kr == 1], kx[kr == 1])])
