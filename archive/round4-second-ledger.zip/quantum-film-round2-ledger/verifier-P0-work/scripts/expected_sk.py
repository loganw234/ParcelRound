"""The LAW's expected S(k) on the prints' sheets (256 x 256 cells, 16 x 16 tiles, independent tiles, a random offset
per layer), so the prose can be judged against the law as well as against one record's noisy bins.
For a fixed-count tile law with covariance C(x, y) of the occupations, and a uniform one-site density (row norms
N/M), E[F(q)] = 0 at every q != 0 and the expected structure factor per crystal is
    S(q) = (1/N) sum_{x,y} C(x, y) exp(i q.(x - y)).
Pauli (a projection DPP, kernel K): C = diag(K) - |K|^2. The Poisson twin (N of M uniformly, no replacement):
S(q) = (1 - p)(M - F(q))/(M - 1), F(q) = |sum_x exp(i q.x)|^2 / M. Radially averaged as tools/first_prints.py does."""
import sys

sys.path.insert(0, r"C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/fresh6")
import numpy as np  # noqa: E402

from quantum_film.golden import fermi  # noqa: E402
from quantum_film.stocks import params  # noqa: E402

side, L = 256, 16
law = params("pauli")
M, N = law["M"], law["N"]
K = np.array([[float(v) for v in row] for row in fermi.kernel(L, law["fermi_r2"], prec=80)])
assert np.allclose(np.diag(K), N / M, atol=1e-12), "the one-site density is uniform"
xs = np.array([(i // L, i % L) for i in range(M)])
# W[d] = sum over x - y = d of |K_xy|^2, on displacements -15..15 in each axis
W = np.zeros((2 * L - 1, 2 * L - 1))
for x in range(M):
    d = xs[x] - xs + (L - 1)
    np.add.at(W, (d[:, 0], d[:, 1]), K[x] ** 2)
f = np.fft.fftfreq(side) * side
ky, kx = np.meshgrid(f, f, indexing="ij")
kr = np.rint(np.hypot(kx, ky)).astype(int)
qy, qx = 2 * np.pi * ky / side, 2 * np.pi * kx / side
ds = np.arange(-(L - 1), L)
phase_y = np.exp(1j * np.multiply.outer(qy, ds))          # (side, side, 31)
phase_x = np.exp(1j * np.multiply.outer(qx, ds))
Wq = np.einsum("abi,abj,ij->ab", phase_y, phase_x, W).real
S_pauli = 1.0 - Wq / N
D = np.abs(np.exp(1j * np.multiply.outer(qy, np.arange(L))).sum(-1)) ** 2 \
    * np.abs(np.exp(1j * np.multiply.outer(qx, np.arange(L))).sum(-1)) ** 2
p = N / M
S_twin = (1 - p) * (M - D / M) / (M - 1)
bins = range(1, side // 2)
P = np.array([S_pauli[kr == k].mean() for k in bins])
T = np.array([S_twin[kr == k].mean() for k in bins])
kF = np.sqrt(N / np.pi) * side / L
print(f"k_F = {kF:.2f}, 2 k_F = {2 * kF:.1f} (units of 2 pi / {side})")
print("expected pauli S at k = 8, 16, 24, 32, 48, 64, 80, 90:", [round(P[k - 1], 3) for k in (8, 16, 24, 32, 48, 64, 80, 90)])
print("expected twin  S at k = 8, 16, 24, 32, 48, 64:", [round(T[k - 1], 3) for k in (8, 16, 24, 32, 48, 64)])
for name, S, lo, hi in (("pauli", P, 16, 90), ("pauli", P, 16, 45), ("pauli", P, 16, 64), ("twin", T, 16, 45)):
    v = S[lo - 1:hi]
    print(f"expected {name} over k = {lo}..{hi}: {v.min():.3f} (k={lo + int(v.argmin())}) - {v.max():.3f} "
          f"(k={lo + int(v.argmax())}); bins above 0.72: {int((v > 0.72).sum())}")
print(f"twin's ceiling (1 - p) M / (M - 1) = {(1 - p) * M / (M - 1):.4f}; expected twin at k = 1, 2, 4: "
      f"{[round(T[k - 1], 4) for k in (1, 2, 4)]}; pauli at k = 1, 2, 4: {[round(P[k - 1], 4) for k in (1, 2, 4)]}")
