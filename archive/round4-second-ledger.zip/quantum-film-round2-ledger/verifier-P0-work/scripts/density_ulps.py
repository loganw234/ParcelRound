"""DETERMINISM (e7935ef): the pitch makes the borrowed stock's lambda_K equal the sheet's mean K 'to one rounding in a
correctly rounded square root'; VALIDATION: 'one ulp was measured'; the test's bound is 4 x 2^-52 relative.
Measure the identity's error at every allowed layer count up to 1,000, with atlas-film's own operation order
(emulsion.coat: area = pitch ** 2; lam_k = ceiling * area / (kappa * grain)) and with the test's."""
import math
import sys
from fractions import Fraction

sys.path.insert(0, r"C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/fresh6")
from quantum_film import develop  # noqa: E402

for stock in ("pauli-4x4", "pauli", "poisson"):
    name, dmax, a, kappa, _floor = develop.borrowed(stock)
    worst_atlas = worst_test = (-1.0, 0)
    n = exact = 0
    for layers in range(1, 1001):
        try:
            pitch = develop.pitch_um(stock, layers)
        except develop.SheetRefused:
            continue
        n += 1
        k = develop.mean_k(stock, layers)
        lam_atlas = float(dmax) * (float(pitch) ** 2) / (kappa * float(a))
        lam_test = dmax * pitch * pitch / (kappa * a)
        # the error in units of 2^-52 relative, measured exactly against the Fraction
        e_atlas = float(abs(Fraction(lam_atlas) - k) / k) / 2.0 ** -52
        e_test = float(abs(Fraction(lam_test) - k) / k) / 2.0 ** -52
        exact += e_atlas == 0
        worst_atlas = max(worst_atlas, (e_atlas, layers))
        worst_test = max(worst_test, (e_test, layers))
        ulps = abs(lam_atlas - float(k)) / math.ulp(float(k))
        if layers in (29, 91):
            print(f"  {stock} at {layers} layers: lambda_K {lam_atlas!r} vs mean K {float(k)!r}, {ulps:.0f} ulp")
    print(f"{stock}: {n} allowed layer counts in 1..1000; lambda_K == mean K exactly at {exact}; worst relative error "
          f"{worst_atlas[0]:.2f} x 2^-52 (atlas-film's order, {worst_atlas[1]} layers), {worst_test[0]:.2f} x 2^-52 "
          f"(the test's order, {worst_test[1]} layers)")
