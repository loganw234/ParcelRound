"""How unusual is 933138bc under the exact law? 20,000 multinomial replicates of 4,096 shots from det(K_Y) over the
4,368 layouts; the one-site sum of squared z's (16 sites) and the pairs' (120 pairs), as tools/pauli_atlas_run.py scores."""
import itertools
import math
import sys

sys.path.insert(0, r"C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/fresh6")
import numpy as np  # noqa: E402

from quantum_film.golden import fermi  # noqa: E402

K = np.array([[float(v) for v in row] for row in fermi.kernel(4, 1, prec=128)])
M, n, R = 16, 4096, 20000
lays = list(itertools.combinations(range(M), 5))
P = np.clip(np.array([np.linalg.det(K[np.ix_(y, y)]) for y in lays]), 0, None)
P /= P.sum()
pairs = list(itertools.combinations(range(M), 2))
A1 = np.zeros((len(lays), M))
A2 = np.zeros((len(lays), len(pairs)))
pidx = {p: i for i, p in enumerate(pairs)}
for r, y in enumerate(lays):
    A1[r, list(y)] = 1
    for p in itertools.combinations(y, 2):
        A2[r, pidx[p]] = 1
one = np.diag(K)
two = np.array([K[i, i] * K[j, j] - K[i, j] ** 2 for i, j in pairs])
rng = np.random.default_rng(933138)
c = rng.multinomial(n, P, size=R).astype(float)
s1 = (((c @ A1) - n * one) ** 2 / (n * one * (1 - one))).sum(axis=1)
s2 = (((c @ A2) - n * two) ** 2 / (n * two * (1 - two))).sum(axis=1)
print(f"null, {R} runs of {n} shots: one-site sum mean {s1.mean():.2f}, sd {s1.std():.2f}; "
      f"P(>= 34.0) = {(s1 >= 34.0).mean():.4f}")
print(f"                          pairs sum mean {s2.mean():.1f}, sd {s2.std():.1f}; P(>= 181.2) = {(s2 >= 181.2).mean():.4f}")
p1 = (s1 >= 34.0).mean()
print(f"chance that at least one of six runs reaches one-site 34.0: {1 - (1 - p1) ** 6:.3f}")
