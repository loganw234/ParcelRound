"""STOCKS.md / README: a sheet laid from tiles of FIXED crystal count suppresses S(k) above the tile's scale (k below
the tile's wavenumber) for ANY law. An independent check with the prints' geometry: 256 x 256 cells, 16 x 16 tiles,
91 layers, each layer's grid shifted by a random offset, and the record's radial S(k). Three within-tile laws:
  uniform-fixed:   25 distinct sites uniformly (the Poisson twin's law);
  clustered-fixed: 25 distinct sites inside a random 6 x 6 block (a strongly clustered law);
  poisson-count:   a Poisson(25) number of distinct sites, uniformly: the count is NOT fixed (the contrast)."""
import numpy as np

rng = np.random.default_rng(20260926)
L, T, LAYERS, N = 16, 16, 91, 25
side = L * T


def radial_s(K):
    f = K.astype(np.float64)
    P = np.abs(np.fft.fft2(f - f.mean())) ** 2 / (f.size * f.mean())
    ky, kx = np.meshgrid(np.fft.fftfreq(side) * side, np.fft.fftfreq(side) * side, indexing="ij")
    kr = np.rint(np.hypot(kx, ky)).astype(int)
    return np.array([P[kr == k].mean() for k in range(1, side // 2)])


def tile_sites(law):
    if law == "uniform-fixed":
        return rng.choice(L * L, N, replace=False)
    if law == "clustered-fixed":
        r0, c0 = rng.integers(0, L - 6, 2)
        block = [(r0 + i) * L + (c0 + j) for i in range(6) for j in range(6)]
        return rng.choice(block, N, replace=False)
    n = min(int(rng.poisson(N)), L * L)
    return rng.choice(L * L, n, replace=False)


for law in ("uniform-fixed", "clustered-fixed", "poisson-count"):
    K = np.zeros((side, side), np.int64)
    for _d in range(LAYERS):
        oy, ox = rng.integers(0, L, 2)
        for ty in range(T):
            for tx in range(T):
                for s in tile_sites(law):
                    r, c = divmod(int(s), L)
                    K[(ty * L + r + oy) % side, (tx * L + c + ox) % side] += 1
    S = radial_s(K)
    print(f"{law:16s} mean K {K.mean():.3f}; S at k = 1, 2, 4, 8, 12: " + ", ".join(f"{S[k-1]:.3f}" for k in (1, 2, 4, 8, 12))
          + f"; mean S over k = 1..8: {S[:8].mean():.3f}; over k = 20..40: {S[19:40].mean():.3f}")
