"""curve_4x4.py's one null sheet gave sum z^2 = 30 against the golden record, where atlas vs golden gave 63.6 and the
naive noise model expects about 57. So measure the noise: 12 exact 116 x 116 pauli-4x4 sheets (golden rolls on seeds
far from the prints', each laid by develop.sheet on its own print stream), their mean curve and per-bin variance, and
where the Atlas record and the golden record sit against them."""
import json
import pathlib
import sys
from multiprocessing import Pool

ROOT = pathlib.Path(r"C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/fresh6")
sys.path.insert(0, str(ROOT))
import numpy as np  # noqa: E402

side, n = 116, 29 * 29 * 29
ky, kx = np.meshgrid(np.fft.fftfreq(side) * side, np.fft.fftfreq(side) * side, indexing="ij")
kr = np.rint(np.hypot(kx, ky)).astype(int)
modes = np.array([(kr == k).sum() for k in range(1, side // 2)])


def radial_s(K):
    f = K.astype(np.float64)
    P = np.abs(np.fft.fft2(f - f.mean())) ** 2 / (f.size * f.mean())
    return np.array([P[kr == k].mean() for k in range(1, side // 2)])


def roll(seed):
    from quantum_film.golden import fermi
    from quantum_film.golden.uniform import stream
    return list(fermi.sample(4, 1, stream("roll", "pauli-4x4", seed)))


def main():
    from quantum_film import develop
    from quantum_film.stocks import params
    law = params("pauli-4x4")
    assert (law["L"], law["fermi_r2"]) == (4, 1), law
    sheets = []
    with Pool(10) as pool:
        for i in range(12):
            lay = pool.map(roll, [300000 + 30000 * i + j for j in range(n)], chunksize=256)
            K, _t, _hw = develop.sheet(lay, "pauli-4x4", (29, 29), 29, ("print", f"verifier-null-{i}"))
            sheets.append(radial_s(np.asarray(K).reshape(side, side)))
    S = np.array(sheets)
    m, v = S.mean(axis=0), S.var(axis=0, ddof=1)
    naive = m ** 2 / (modes / 2)
    print(f"12 exact sheets: per-bin variance / naive S^2/(modes/2), median over 57 bins {np.median(v / naive):.2f}, "
          f"mean {np.mean(v / naive):.2f}")
    c = np.mean(v / naive)
    var = c * naive

    def stat(x):
        return float(np.sum((x - m) ** 2 / (var * (1 + 1 / 12))))

    A = np.array(json.loads((ROOT / "docs/prints/atlas-pauli-4x4.json").read_text("ascii"))["structure_factor"]["S"])
    G = np.array(json.loads((ROOT / "docs/prints/golden-pauli-4x4.json").read_text("ascii"))["structure_factor"]["S"])
    loo = []
    for i in range(12):
        rest = np.delete(S, i, axis=0)
        mi = rest.mean(axis=0)
        loo.append(float(np.sum((S[i] - mi) ** 2 / (var * (1 + 1 / 11)))))
    print(f"sum over 57 bins of (S - mean)^2 / var: atlas record {stat(A):.1f}; golden record {stat(G):.1f}; "
          f"each null sheet against the other 11: {sorted(round(x, 1) for x in loo)}")
    for lo, hi in ((1, 8), (9, 16), (17, 29), (30, 45), (46, 57)):
        sl = slice(lo - 1, hi)
        print(f"  k = {lo}..{hi}: mean S atlas {A[sl].mean():.3f}, golden {G[sl].mean():.3f}, "
              f"null {m[sl].mean():.3f} (sheets {S[:, sl].mean(axis=1).min():.3f}-{S[:, sl].mean(axis=1).max():.3f})")


if __name__ == "__main__":
    main()
