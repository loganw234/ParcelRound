"""first_prints.py lays 'golden rolls' of the determinantal stocks with the pinned sampler ('the authority's roll by
construction'). Spot-check that on the prints' own streams: golden.fermi.sample (mpmath, 256 bits) against
quantum_film.pinned.sampler.sample, seed for seed, at both ends of each print's seed range and a few between.
Needs QF_CFT_ROOT (the lead's built libcft, read only)."""
import sys
import time

sys.path.insert(0, r"C:/Users/logan/AppData/Local/Temp/qf-verify-p0-work/fresh6")
from quantum_film.golden import fermi  # noqa: E402
from quantum_film.golden.uniform import stream  # noqa: E402
from quantum_film.pinned import sampler  # noqa: E402
from quantum_film.stocks import params  # noqa: E402

for stock, seeds in (("pauli-4x4", [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12195, 24388, 24389]),
                     ("pauli", [1, 2, 3, 4, 5, 11648, 23295, 23296])):
    law = params(stock)
    same = 0
    t0 = time.time()
    for seed in seeds:
        s = stream("roll", stock, seed)
        g = list(fermi.sample(law["L"], law["fermi_r2"], s))
        p = list(sampler.sample(law["L"], law["fermi_r2"], s))
        if g == p:
            same += 1
        else:
            print(f"  {stock} seed {seed}: golden {g} pinned {p}")
    print(f"{stock}: {same} of {len(seeds)} print-stream rolls identical, golden vs pinned ({time.time() - t0:.0f} s)")
