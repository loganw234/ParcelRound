"""STOCKS.md at 05011bd: atlas-film's coating is 'a Poisson count per cell, whose S(k) is 1 at every k in law';
VALIDATION.md at 05011bd: 'TRI-X's lowest bin (0.238 at k = 1) holds two modes'. The k = 1 bin of a 256 sheet
holds 8 modes, 4 independent (a real field). Coat the record's sheet at seeds 1..48 with atlas-film's pinned coat
and look at S at k = 1..4 across seeds: in law each is a mean of n independent exponentials of mean 1."""
import math
import pathlib
import sys

ROOT = pathlib.Path(sys.argv[1])
sys.path.insert(0, str(ROOT))
import numpy as np  # noqa: E402

from quantum_film import develop  # noqa: E402

side = 256
f = np.fft.fftfreq(side) * side
ky, kx = np.meshgrid(f, f, indexing="ij")
kr = np.rint(np.hypot(kx, ky)).astype(int)
films, processes, emulsion = develop.atlas()
name, dmax, a, _kappa, _floor = develop.borrowed("pauli")
pitch = develop.pitch_um("pauli", 91)
rows = []
NS = int(sys.argv[2]) if len(sys.argv) > 2 else 48
for seed in range(1, NS + 1):
    K, _thr = emulsion.coat(side * side, dmax, a, pitch, seed, pinned=True)
    x = np.asarray(K, dtype=np.float64).reshape(side, side)
    P = np.abs(np.fft.fft2(x - x.mean())) ** 2 / (x.size * x.mean())
    rows.append([P[kr == k].mean() for k in (1, 2, 3, 4)])
R = np.array(rows)
print(f"seed 1: S(k=1) = {R[0, 0]:.4f}")
for j, k in enumerate((1, 2, 3, 4)):
    n = int((kr == k).sum()) // 2
    print(f"k = {k}: {n} independent modes; over {NS} seeds mean {R[:, j].mean():.3f}, sd {R[:, j].std(ddof=1):.3f} "
          f"(law: mean 1, sd {1 / math.sqrt(n):.3f}); min {R[:, j].min():.3f}, max {R[:, j].max():.3f}")
x = 0.2382 * 4
p4 = 1 - math.exp(-x) * (1 + x + x * x / 2 + x ** 3 / 6)
x2 = 0.2382 * 2
p2 = 1 - math.exp(-x2) * (1 + x2)
print(f"P(S(k=1) <= 0.2382) in law: {p4:.4f} with 4 independent modes, {p2:.4f} if it were 2; "
      f"seeds at or below it here: {int((R[:, 0] <= 0.2382).sum())} of {NS}")
