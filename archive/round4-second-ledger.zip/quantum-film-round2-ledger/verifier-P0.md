## 2026-09-26 13:23Z - the one pass over round 2 at e7935ef: NOT READY, on two S(k) sentences false as stated; the code, the records, the gates and the prints hold

Measured (the verifier; a fresh clone of origin/main at e7935ef with both submodules, atlas-film d4007b2 and
cft-fp256 7d7285d, in %TEMP%/qf-verify-p0-work/fresh6; QF_CFT_ROOT = the lead's built vendor/cft-fp256, read only;
no Atlas call):
- run.sh at e7935ef: 13 passed, atlas skipped by name, 69 s (run 20260926-054551-30423-e7935ef). One pytest
  session over tests/: 601 passed in 85 s.
- tools/first_prints.py --check: all five "the same bits", rc 0, the tree clean after (pauli 823 s).
- The five runs' per-run and pooled figures, recomputed from the result files by my own reader, equal
  VALIDATION's.
- The prints' S(k) prose against their records and against the laws' expected S(k): D1 and D2.
Believed: D2's counterexample is a law I made up, not one on the shelf. The shelf's laws are suppressed as the
docs say, but a bunched stock (Speckle is planned) need not be.

**Verdict: NOT READY.** Two claims are false as stated, both prose: VALIDATION.md's "0.29-0.72" out to k = 90
(D1), and "suppresses S(k) above the tile's scale for ANY law" in STOCKS.md and VALIDATION.md (D2). Each is a
doc fix. I found no correctness defect, and no fault outside a stated limit that passes every gate.

### Defects: claims false as stated

**D1.** VALIDATION.md, the 2026-09-26 entry, lines 1172-1173: "Between the tile's scale (k = 16) and about twice
Pauli's Fermi scale (k = 90), Pauli's count carries 0.29-0.72 of random placement's noise power."
- The record: pauli.json's own S over k = 16..90 runs from 0.279 (k = 17) to 1.131 (k = 90). 35 of the 75 bins
  exceed 0.72, and the mean over k = 81..90 is 1.001.
- The law: Pauli's expected S on this sheet (from the golden kernel, S(q) = 1 - (1/N) sum |K_xy|^2
  exp(iq.(x - y)); scripts/expected_sk.py) rises from 0.301 at k = 16 to 0.824 at 64 and 0.975 at 90
  (2 k_F = 90.3). 36 of the 75 bins exceed 0.72. A Fermi sea's S reaches 1 at 2 k_F, so no band that ends there
  can stop at 0.72.
- 0.29-0.72 is the table's columns k = 16..64, read as the band to k = 90. The README's sentence names the right
  band, the tile scale to the Fermi scale (m2).
- After e7935ef (outside this pass, unverified): 5ebbb82's VALIDATION entry names "Pauli's 0.29-0.72" as the
  source of the demo's "about 30 to 70 percent". The caption itself (site/story.js line 35) names the
  tile-to-Fermi band, where the law gives 0.30-0.64.

**D2.** STOCKS.md lines 36-37 ("That alone suppresses S(k) above the tile's scale for ANY law"), and
VALIDATION.md lines 1113-1114, where the spike "found" it.
- What is true: a fixed count sends S(k) to 0 as k -> 0 for every law. To leading order
  S(q) = q.Cov(D).q / N, where D is a tile's dipole moment (the sum of its crystals' positions). How far above
  the tile's scale the suppression reaches depends on the law, through that variance.
- A control with the prints' geometry: 256 x 256 cells, 16 x 16 tiles, 91 layers, a random offset per layer and
  first_prints' radial_s, with 25 distinct crystals in every tile (scripts/tiling_sk.py and tiling_sk2.py). S at
  k = 1, 2, 4, 8, 12, where k = 16 is the tile's scale:
  - uniform, the twin's law: 0.021, 0.036, 0.256, 0.454, 0.891, suppressed;
  - inside a 6 x 6 block at a random place in each tile: 0.164, 0.427, 1.598, 4.443, 11.668;
  - a 10 x 10 block: 0.081, 0.327, 0.905, 3.605, 3.744;
  - a 12 x 12 block: 0.019, 0.130, 0.576, 1.846, 1.866;
  - a 6 x 6 block at the same place in every tile: at most 0.142 over k = 1..15, suppressed;
  - a Poisson(25) count placed uniformly (the contrast): 1.190, 0.981, 1.038, 1.118, 0.872.
- So a bunched law whose clusters land anywhere in a tile is enhanced several-fold between one and four tiles'
  scale. That is the band STOCKS.md says the tiling alone suppresses.
- It matters for Speckle, which is planned and whose "crystals bunch". STOCKS.md's reading rule rests on this
  premise, and for such a sheet the premise is false.
- The evidence for "ANY law" was one law, the uniform twin (0.024 at the lowest k), beside Pauli's.

### Minor

- **m1.** A Sattolo walk planted in develop.shuffled (it gives only cyclic permutations) passes all 14 develop
  tests and every stage.
  - `first_prints.py --check --only atlas-pauli-4x4` catches it in 3 s ("DIFFERENT BITS").
  - But --check is in no stage, and the develop test checks only that the shuffle returns a permutation.
  - --check is stated as a check, not a gate. The 3-second atlas print alone could be a gate.
- **m2.** README lines 52-54 give "0.29-0.71" for Pauli and "0.80-0.96" for the twin, from the tile scale to the
  Fermi scale.
  - These are the tabulated bins. They hold for the laws' expectations, 0.301-0.644 and 0.889-0.905. The twin's
    ceiling is (1 - p) M/(M - 1) = 0.906.
  - They do not hold for the record's every bin: 0.279-0.642, and the twin's 0.657-1.122 with 8 of 30 bins
    outside. A bin carries about S/sqrt(modes/2) of noise.
  - The comparison holds more strongly than it says: over k = 16..45 Pauli's largest bin, 0.642, is below the
    twin's smallest, 0.657.
- **m3.** DETERMINISM says lambda_K equals the mean K "to one rounding in a correctly rounded square root". The
  identity carries several roundings: the product and quotient before the root, and atlas-film's own after it.
  At every allowed layer count up to 1,000 (scripts/density_ulps.py):
  - the identity holds within 1.99 x 2^-52 relative, inside the test's 4 x 2^-52;
  - it is exact at 117 of 282 counts for pauli-4x4, and at 356 of 904 for pauli and for poisson.
- **m4.** The spike's figures (11,776 rolls in 233 s; 0.024 against 0.016) come from scratch work. Nothing in the
  tree reproduces them.
- **m5.** README's "1.24 um across" is the 256-cell prints' pitch (1.240431). The 4x4 prints' pitch is 1.252639.
- **m6.** golden-pauli-4x4's rolls also come from the pinned sampler, so its --check needs QF_CFT_ROOT. The
  table says "(pinned sampler)" only on pauli's row.
- **m7.** TRI-X's k = 1 bin reads 0.238, and that bin holds 2 independent modes.
  - Seed 1 reproduces the record's K digest.
  - Over seeds 1..12, S(k = 1) runs from 0.22 to 1.42, while the mean over k = 16..90 runs from 0.98 to 1.01.
  - "About 1 at every k" holds in law.
- **m8.** 933138bc is the outlier of the six runs: one-site chi^2 34.0 on 16, and pairs 181.2 on 120. Under the
  exact law at 4,096 shots (20,000 replicates):
  - P(one-site >= 34.0) = 0.0094, and P(pairs >= 181.2) = 0.0086;
  - the chance of such a run in six is 5.5%.

  That is chance, not a finding. I note it because the pooled figure leans on this run.

### Confirmed

1. **The five runs** (08cf10f..dce9ad2).
   - The history is linear, and each job's commitment commit comes before its result commit.
   - Each commitment commit's time is the server's submitted_at second (11:46:31, 11:47:56, 11:49:22, 11:50:42
     and 11:51:53Z), and each job completed 2 s later.
   - The status records carry no client call time. So "before the first status call" rests on the tool and the
     local clock, as documented.
   - Per run (one-site max|z| and chi^2; pairs max|z| and chi^2):

     | job | one-site max\|z\| | one-site chi^2 | pairs max\|z\| | pairs chi^2 |
     |---|---|---|---|---|
     | 579df87d | 2.53 | 19.9 | 2.73 | 138.5 |
     | d017540c | 1.72 | 9.8 | 2.14 | 84.1 |
     | 5831ff5e | 2.33 | 19.1 | 2.52 | 147.2 |
     | 3673f9fe | 2.66 | 24.6 | 2.84 | 131.7 |
     | 933138bc | 3.14 | 34.0 | 3.11 | 181.2 |

     The XX and YY figures match too.
   - Pooled: 24,576 shots, 3,004 of the 3,008 allowed layouts seen, one-site 2.15 and 17.1, pairs 2.64 and
     128.0, and 0 forbidden.
   - There are 10,076 new roll files, 12,071 in all.
   - `--score`, offline: 6 runs, ALL CHECKS HOLD.
2. **757c9a1.**
   - Unplanted, 6 of 6 runs pass.
   - A foreign commit planted in the 2026-09-26 platform record fails all five runs.
   - The other directory's commit planted in the one-run 2026-09-25 record fails that run. The check is exactly
     as strict for a one-run directory.
3. **a228cf5.**
   - The submodule is at d4007b2, and its files' digest is frozen.
   - A real copy of atlas_film imported first is refused as AtlasFilmShadowed. With develop imported first, the
     vendored copy wins over a shadow on sys.path.
   - With the submodule deinitialised, develop skips by name. --only develop then FAILS ("no stage ran"), and so
     does --require-all.
   - The density identity is 9.0625 against 9.062500000000002 (1 ulp) at 29 layers, and exact for pauli at 91.
     The rest is in m3.
   - The honesty floor and the exact regime are refused by name.
   - All 14 tests are in the quick budget.
   - My plants, distinct from the lead's eight:
     - offsets swapped, and thresholds without the layer: each failed FROZEN;
     - mean K off: 3 failed and 5 errored;
     - the device order: failed its test;
     - the Sattolo walk: passed (m1).
   - In WSL (Ubuntu 22.04, Python 3.10.12, numpy 1.21.5, mpmath 1.4.1), tests/develop passed 14, FROZEN
     included. That is the same bits on a second OS and interpreter, on the same CPU.
4. **e7935ef.**
   - Every table figure equals its record: cells, layers, pitch, mean K, rolls, digests,
     E = 0x1.3a7550d6f4737p-3, the S(k) table, the twin's 0.019 at k = 1, and the 4x4 pair at k = 8, 16 and 32.
   - The captions of the gallery and of structure.png (145 um, 318 um, the tile-scale lines) match.
   - "Golden rolls": on the prints' own streams, the pinned sampler's rolls equal golden.fermi.sample's.
     - pauli-4x4: 13 of 13 (seeds 1-10, 12195, 24388, 24389);
     - pauli: 8 of 8 (seeds 1-5, 11648, 23295, 23296).
   - "Trace the same curve" holds (scripts/curve_4x4_null.py):
     - The Atlas sheet against 12 exact 116 x 116 sheets gives sum (S - mean)^2/var = 62.9 over 57 bins.
     - Each exact sheet against the other 11 gives 37.3-75.0.
     - The band means agree within the exact sheets' spread.
   - ROADMAP: about 5.78 million crystals a square millimetre, and about 231,000 pauli rolls.
   - DETERMINISM's new section matches develop.py: integers and SHA-256 up to the sheet, then pinned mode.

**Before the drop** (API ECONNRESET; the lead's 12:50Z entry), I had:
- read round 2's lead.md;
- made the fresh clone at e7935ef with both submodules;
- checked the five runs' git order;
- recomputed the per-run and pooled figures;
- planted 757c9a1's platform faults;
- read develop.py and counted tests/develop's 14 tests;
- started the front door, which finished before the drop as run 20260926-054551-30423-e7935ef.

On resume the clone was at e7935ef and clean, with its submodules as checked out, and my work directory was as I
left it.

**Housekeeping.**
- Nothing was written in the lead's tree or the shared scratchpad, and no Atlas call was made. The lead's DLL
  was only read, through QF_CFT_ROOT.
- The copies are deleted: sab6 (atlas-film deinitialised), sab6s (the Sattolo plant), and the WSL clone
  /tmp/qf-verify-p0-wsl6.
- fresh6 and my scripts stay under qf-verify-p0-work/: scripts/, plant_develop.py and plant_platform.py.
- The commits after e7935ef (ec65c44, 7e6f60d and 5ebbb82) are outside this pass, except where D1 reaches them.

For: the lead, the owner

## 2026-09-26 13:37Z - the corrections at 05011bd: PASS; one sentence repeats an error of mine (the k = 1 bin's modes)

Measured (a fresh clone of origin/main at 05011bd, in qf-verify-p0-work/fresh7; nothing on main after it; atlas-film
d4007b2; QF_CFT_ROOT = the lead's DLL, read only; no Atlas call):
- The quick budget at 05011bd: 12 passed, 0 failed, 0 skipped (run 20260926-063139-34761-05011bd). develop: 15
  passed in 3.3 s.
- My Sattolo plant, in a copy:
  - test_the_atlas_prints_sheet_is_its_records_own fails (1 failed, 14 passed);
  - `run.sh --only develop` FAILED.
- The records are unchanged since e7935ef. Over k = 16..45 (scripts/sk_claims2.py):

  | sheet | min | max | mean |
  |---|---|---|---|
  | Pauli | 0.2786 | 0.6425 | 0.4722 |
  | the twin | 0.6571 | 1.1222 | 0.8918 |
  | TRI-X | 0.7983 | 1.1675 | 0.9972 |

  - Every Pauli bin is below every twin bin.
  - Pauli reaches 1.131 at k = 90.
  - k_F = 16 sqrt(8) = 45.25: pauli's r2 is 8.
- TRI-X's coat at seeds 1..600 (scripts/trix_lowk2.py): the mean S at k = 1, 2, 3, 4 is 0.981, 1.013, 0.992 and
  0.989.
Believed: -

**Verdict: PASS.** Each corrected sentence below is true as stated, against the records and my scripts. That
covers README, STOCKS.md, DETERMINISM.md, site/story.js (the caption and the plot's band), site/widgets.js and
VALIDATION.md's correction entry. The exception is n1. It is false as stated, but it is a detail of a note, it came
from my own entry, and it changes no conclusion. So I list it as minor, as I did m2 and m5.

**D1.** README gives:
- the band as k = 16 to 45;
- Pauli: 0.47 on average and at most 0.64;
- the twin 0.89 and TRI-X 1.00;
- every Pauli bin below every twin bin;
- the law's 0.30-0.64, which is my expected_sk.py's 0.301-0.644.

The demo:
- the story's caption says "roughly 30 to 65 percent" (the records give 28-64, the law 30-64);
- the story's band runs from 1/16 to 45/256;
- the widgets caption says 0.28-0.64, 0.47 against 0.89.

**D2.** STOCKS.md's points hold:
- a fixed count sends S(k) to 0 as k goes to 0, for every law;
- the twin's suppression reaches about the tile's scale (0.019 at k = 1; the law stays at or below 0.906
  everywhere);
- 1.6 to 11.7 is my control, at k = 4 to 12;
- atlas-film's coat is 1 at every k in law (the 600 seeds above).

**No other sentence in the docs or the site makes D1's or D2's claim.**
- The only ones left are VALIDATION.md's own entries, at lines 1113-1114, 1172-1173 and 1209. The file's rule
  keeps them: it is append-only, and none of the 16 commits that touched it removed a line. The appended
  correction names each one.
- tools/print_figures.py marks only the tile scales on structure.png, with no band.

**m3 and m5.**
- m3: the density identity holds within 2 x 2^-52 relative up to 1,000 layers, and exactly at about 40% of the
  counts (117 of 282; 356 of 904).
- m5: 1.24-1.25 um is right. widgets' 1.24 is the 256-cell pair's pitch.

**Minor**
- **n1.** VALIDATION.md's correction says "TRI-X's lowest bin (0.238 at k = 1) holds two modes". That is false, and
  the error is mine.
  - My 13:23Z m7 said 2 independent modes. The k = 1 bin of a 256-cell sheet holds 8 modes, 4 independent: the
    four axis and four diagonal neighbours, since rint(sqrt 2) = 1.
  - In law, such a bin reads 0.238 or less with probability 0.016. 10 of the 600 seeds did.
  - "About 1 at every k" still holds in law. This corrects my m7.
- **n2.** README says "Below the tile scale both are suppressed ... That comes from the fixed count per tile, not
  from the quantum law."
  - That is true of the suppression itself.
  - But its depth there is the law's too. Pauli lies below the twin in all 15 bins k = 1..15 of the records. The
    law puts it at about 0.40 of the twin: 0.0070 against 0.0172 at k = 1.

**Housekeeping.**
- The copy sab7s is deleted. fresh7 and my scripts remain under qf-verify-p0-work/.
- Nothing was written in the lead's tree or the shared scratchpad.

For: the lead, the owner
