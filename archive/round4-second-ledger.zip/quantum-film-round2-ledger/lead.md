## 2026-09-26 12:39Z - round 2's P0 is on main at e7935ef (pushed): five more Atlas runs, the develop seam, the first prints; verifier-P0 makes the one pass

Measured (the lead):
- main is e7935ef, local and remote alike.
- run.sh --require-all at the tree committed as e7935ef: 14 passed, 0 skipped, 72 s. The atlas stage made GETs only.
- The quick budget at e7935ef: 12 passed.
- One pytest session over tests/: 601 passed.
- tools/pauli_atlas_run.py --score: six runs audited, ALL CHECKS HOLD.
- tools/first_prints.py --check: all five prints re-develop to the same bits.
Believed: -
The owner's words:
- run all five remaining Atlas jobs before the key expires;
- vendor atlas-film as a submodule at d4007b2;
- round 2 is "lead only, fast", with one verifier pass;
- save the prints as images and show some in the README.
The commits since 145fd75:
- 08cf10f..dce9ad2: five Atlas runs by P3's tool, on a branch, each commitment committed before the job's first
  status call;
- 757c9a1: test_p3_records.py's platform check for runs that share a QASM file;
- 9b3b2c2: VALIDATION.md on those runs;
- a228cf5: quantum_film/develop.py, tests/develop, the develop stage, and vendor/atlas-film;
- e7935ef: docs/prints/, tools/first_prints.py and tools/print_figures.py, and the docs.
For: verifier-P0

## 2026-09-26 12:50Z - verifier-P0 was cut off by a dropped connection (API ECONNRESET) mid-pass; resumed

Measured: its last words were that it had counted tests/develop's 14 tests and was starting the front door at e7935ef.
Nothing had been written to this ledger. main is still e7935ef, and the lead's tree is clean.
Believed: -
It is resumed with round 1's rule: check your tree, say where you stopped, and continue.
For: verifier-P0

## 2026-09-26 13:16Z - after e7935ef, at the owner's request: the web demo, the video's source and the poster (ec65c44, 7e6f60d, 5ebbb82)

Measured: main is 5ebbb82, pushed. The quick budget at ec65c44 passed 12. Pages run 36244571651 deployed site/ with
conclusion success, and https://loganw234.github.io/Quantum-Film/ renders with no console errors.
Believed: -
- These commits come after e7935ef, the commit verifier-P0 is checking, and are outside its brief. They are
  presentation: site/ (the story, the A|B sliders, the tile toy), tools/site_data.py, tools/poster.py,
  tests/docs/test_site.py, .github/workflows/pages.yml, and the README and VALIDATION lines.
- The owner's words: publish via a GitHub Actions workflow; save the images and show some in the README.
For: verifier-P0, the owner

## 2026-09-26 13:29Z - verifier-P0 (13:23Z): D1 and D2 corrected at 05011bd (pushed), with the minors and a gate for the shuffle; a confirming pass

Measured:
- The lead's own reading of the records, k = 16..45:
  - Pauli 0.279-0.642, mean 0.472;
  - the twin 0.657-1.122, mean 0.892;
  - TRI-X 0.798-1.167, mean 0.997.
  - Pauli's maximum over k = 16..90 is 1.131.
  These are the verifier's figures.
- tests/develop: 15 passed. A Sattolo shuffle planted in develop.shuffled fails the new Atlas-sheet test, and
  develop.py was restored byte for byte.
- The quick budget passes 12. Pages is redeploying.
Believed: -
- D1:
  - VALIDATION.md gets an appended correction;
  - README's band figures are now the records' band, with the law's 0.30-0.64 beside them;
  - the story's caption says "roughly 30 to 65 percent", and its plot band ends at k_F, not 2 k_F;
  - the demo's prints caption says 0.28-0.64.
- D2:
  - STOCKS.md now says a fixed count sends S to 0 as k goes to 0 for every law, how far that reaches depends on
    the law, and a bunched law can be enhanced;
  - README's "every tiled stock" is now "both";
  - VALIDATION.md gets an appended correction.
- The minors:
  - m1 is a gate (the Atlas sheet against its record);
  - m3 and m5 are corrected in DETERMINISM.md and README;
  - m4, m6, m7 and m8 are recorded in VALIDATION.md;
  - m2 is answered with the band's records and the law's expectation.
For: verifier-P0

## 2026-09-26 13:38Z - verifier-P0: PASS (13:37Z); round 2's P0 is verified, and its two minors are fixed at 4ff684f (pushed)

Measured: main is 4ff684f, local and remote alike.
Believed: -
- The one pass found D1 and D2, both prose, and eight minors. The confirming pass found n1 and n2.
- Fixed at 4ff684f:
  - n1: TRI-X's lowest bin holds eight modes, four of them independent, not two. The error came first from the
    verifier's own entry, and VALIDATION.md now has a correction line.
  - n2: README now says Pauli still sits below its twin below the tile scale, at about 0.4 of it in law.
- The demo and the poster (ec65c44..5ebbb82) have had no verifier pass beyond the lines D1 reached. The owner asked
  for them as presentation. tests/docs/test_site.py holds their data to the records.
- No agent is running. The lead's watch stops here.
For: the owner, verifier-P0
