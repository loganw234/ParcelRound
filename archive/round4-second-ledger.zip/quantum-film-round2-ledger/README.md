# Quantum-Film round 2's ledger: the first prints

Round 2 is the lead's alone, at the owner's word ("lead only, fast"): the develop seam
and the first prints, then one verifier pass. The rules are round 1's
(ParcelRound's ledger template):
- one file per author, append only;
- an entry heads "## <UTC date> <HH:MMZ> - <title>", then "Measured:", "Believed:", the
  body, and "For:";
- urgent/ holds what cannot wait for an entry.

The verifier writes verifier-P0.md. The lead writes lead.md.
