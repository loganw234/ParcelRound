# Round 6 - verifier-P2

Append only. Each heading's time is taken from `date`.

## 2026-10-02 22:30:52 -0700 - verifier-P2 starts on the copy at 40df983 (parent 1dc5ed4), on Opus 5.5

Measured:
- My system prompt names the model I run as: Claude Opus 5.5.
- The copy at <scratch>/r6-vcopy-P2/ is detached at 40df9835a4dc91382b72a8ac4e2169e1a4f6de55, parent 1dc5ed4, clean, with no remote and no branch.
- `git show --stat HEAD` there: METHOD.md only, 147 insertions and 10 deletions.
- Read so far, in R2's order: the ledger README, lead.md, briefs/_verifier.md, briefs/_common.md, briefs/P2.md. Not yet read: P2.md (the parcel's file) and the other verifiers' files.

Believed: nothing yet about the work.

For: the lead

## 2026-10-02 22:43:52 -0700 - my own view of P2's copy, formed before reading P2.md: two wrong answers, two restates

Measured (all at 40df983, in the copy or in my own clone of it under <scratch>/r6-vP2/work):
- Scope holds. The diff changes METHOD.md only: 15 hunks (at -U0), 147 insertions, 10 deletions. Everything up to and including "## 4. The ledger", and everything from "## 5. Gates and negative controls" on, hashes the same at 1dc5ed4 and 40df983. The words removed are only the decision procedure's "`urgent/`;" and the archive-or-throw-away sentence the brief retires.
- R2's paragraph, "Verifiers watch the lead's channel only.", hashes the same at 1dc5ed4 and 40df983.
- Gate in the copy: 10 of 10; `--control`: 48 of 48. The copy's tree stayed clean.
- Two sentences misstate their source or the scope:
  1. METHOD.md:414 says "5 of 28 watched parcel entries" carried typed stamps. CASE-STUDY-3.md:353-354 says "5 of 38".
  2. METHOD.md:648-649 ends the archive paragraph "and since it is published, no brief or entry in it holds the owner's personal data". That is CS5#3 (CASE-STUDY-5.md:351-353), pending at ADOPTION.md:124, widened from "no brief" to "no brief or entry", with no incident cited. The commit message says the opposite: "Not written: the privacy rule for ledgers (CS5#3, pending)".
- Two more claim more than is true:
  3. METHOD.md:340-342: "cft-fp256's later parcel briefs, which carry the rules in place of a README, say only "append only"". The survey says that in its row on reading the ledger at three moments (archive/round6-practice-survey.md:139, one brief cited, S56 b/S1:77-80), and its own CS3#2 row records the stamp rule in "every later cft brief" (line 46).
  4. The commit message says "146 lines added"; its diff has 147.
- Every other added claim I read at its source and it holds: CS3:330-337, 353-362, 366-368, 780-785, the timeline's 13:29, 17:23 and 18:57; CS4's 13:43, 14:18 (15:25), ~16:25, 16:30-17:08, 21:28-21:31, 23:25-23:35, 05:39-05:40, obs 2, 3, 12, 17 and 32; CS5:419-441; the survey's B6, B7, B15 and departures rows; cft-fp256's docs/VALIDATION.md:16507 at `4190a47` (the owner's words are exact).
- Faults built in my clone (each restored after): a minute of another event, a phrase opening many items, a wrong status, and a heading that exists while the rule sits in section 7 each pass, inside their stated limits. A cft-fp256 line number made wrong passes ("not that the line is right at it"); a survey row that does not exist, as a link's text, passes ("as a link's text"). An observation number or a section mark of the wrong item passes, and no "What it cannot see" line states it: only the threat model's content sentence covers it. Caught: a time no record holds, "[sic]", "section 9", an address, a line number with no commit.

Believed:
- 1 and 2 are wrong answers under the send-back rule; 3 and 4 are restates. P2's own file is not read yet; I read it next, to check its claims against this view.

For: the lead

## 2026-10-02 22:48:08 -0700 - verifier-P2 reports NOT READY on 40df983: two wrong answers (a count, a pending item adopted), two restates

Measured, after reading P2.md whole (its 21:59:08 design, the 22:00:32 correction, the 22:28:32 report):
- **The copy differs from the text P2's file gives in two places, and only there.** A script compared each of the design's 16 blocks with the copy's section 4. Every other difference is one P2's 22:00:32 or 22:28:32 entry discloses: P4's link form, "does not reach the agents who rely on that carrier", "so that", and B15's evidence and "neither the archive nor the working copy". The two it does not disclose are my findings 1 and 2:
  - block G (P2.md:179) has "5 of 38", and P2's 22:28:32 entry reasons from "33 of 38". The copy's METHOD.md:414 has "5 of 28";
  - block P (P2.md:325-336) ends "not a channel.", and P2.md:394 lists CS5#3 under "Not written". The copy's METHOD.md:648-649 adds the privacy clause.
- **P2's counts match a text one line shorter than the copy's.** P2's file gives 146 insertions and METHOD.md at 948 lines (P2.md:452, 456); the copy has 147 insertions and 949 lines. The clause is that line, so finding 4 goes wherever finding 2 goes.
- **P2's other claims hold where I could check them**: 15 hunks, all inside section 4; R2's paragraph byte for byte; every cited time and observation read at its source; the VALIDATION.md lines 16507, 15635, 15834, 16160 and 16352 at `4190a47`; the gate at 10 of 10 and 48 of 48. P2's file, its commit message and the diff are clean under the gate's own privacy patterns.
- **The quoted passages hold.** Counted by my own script: loganw.dev's 29 patterns, as loganw.dev runs them, match once each, and HonestFramework's 6 passages are each present once. loganw.dev's three METHOD.md patterns read the same at `43c36a2` as in the gate.
- **S1 to S3 keep the purposes of the rules they relax:**
  - the entry comes first, so the ledger stays the record;
  - the brief says to escalate and wait;
  - a verifier gets only the lead's messages;
  - the read moments stay the floor;
  - the test and the record of how the lead learned stand in for a watch;
  - R4 keeps the cross-parcel view.
- **HonestFramework's paraphrase stays true in substance.** That is WITH-PARCELROUND.md:35 at 65447fd: a correction is in the ledger before any message carries it.

Verdict: NOT READY.
1. Wrong answer: METHOD.md:414. It says "5 of 28"; CASE-STUDY-3.md:353-354 says "5 of 38".
2. Wrong answer: METHOD.md:648-649 adopts CS5#3, which is pending at ADOPTION.md:124. It widens CS5#3 to "brief or entry", and cites no incident.
3. Restate: METHOD.md:340-342 ("say only "append only"") claims more than the survey. Its rows 139, 46 and 118 scope the words to reading the ledger, and record the stamp rule in every later cft-fp256 brief. cft-fp256's Data/runs is not in my reach, so this rests on the survey's own rows.
4. Restate: the commit message says "146 lines added" and "Not written: ... CS5#3". The copy has 147, and the clause.
- Known limit, the gate's, not P2's. An observation number or a section mark that names another item passes. The docstring's "What it cannot see" states that concession for minutes and phrases only. The threat model's content sentence covers it. Each of P2's own citations is right at its source.

Background processes: none of mine. Every command ran in the foreground and has finished.

Believed:
- Findings 1 and 2 have the shape of planted faults: each differs from P2's own record of its text. I report both as real, as the brief says.

For: the lead
