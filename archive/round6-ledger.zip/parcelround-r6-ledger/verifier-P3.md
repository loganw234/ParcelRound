# verifier-P3 - the verifier of parcel P3, round 6

Append only. Each heading's time is taken from `date`.

## 2026-10-02 22:24:31 -0700 - verifier-P3 starts on the copy at cd77587, on Opus 5.5

Measured:
- My system prompt names my model: Opus 5.5 (claude-opus-5-5).
- The copy at <scratch>/r6-vcopy-P3/ is detached at cd77587, parent 1dc5ed4, with no remote and no branch; its working tree is clean.
- My scratch directory <scratch>/r6-vP3/ exists and is empty.
- Read so far, in R2's order: the README, lead.md, briefs/_verifier.md, briefs/_common.md, briefs/P3.md, and the plan of record (draft 3).

Believed: nothing yet about the work. I read P3.md only once I have formed my own view.

For: the lead

## 2026-10-02 22:43:27 -0700 - my view formed, before reading P3.md: three findings against the sources, one gate limit

Measured, at cd77587 in the copy:
- Gate: 10 of 10. `--control`: 48 of 48. The copy was clean before and after both runs.
- Scope: METHOD.md only; all 8 hunks lie between the section-5 and section-7 headings, at the base and at the tip.
- The five quoted passages are each present once, byte for byte with their wrapping, against 1dc5ed4; once each with markup stripped too. loganw.dev's three METHOD.md patterns, read from its own source at 43c36a2, match once each.
- Privacy: the diff and the commit message hold no address, personal path or secret, beyond the public cft-fp256 links and the co-author trailer.
- Every rule checked against its proposal, its cited incident and the survey row. Three disagree with their sources:
  1. B3, its first bullet: "fixed six wrong answers a verifier found". The cited source, cft-fp256 docs/VALIDATION.md:15260 at 4190a47, says "five".
  2. S6, its third condition: "the verifier may re-run from clean anything it doubts". ADOPTION.md's S6, the plan and P3's brief say it re-runs; so does the commit message. As a condition of reuse, "may" binds nothing. The paragraph's last sentence keeps the duty, so the rule contradicts itself.
  3. CS3#8's citation [CASE-STUDY-3, section 6; 18:49; 20:01]: the skip rule's send-back is P7's at 19:56 (CS3:191). 20:01 is P2's send-back in the same row. The gate passes it, inside its stated limit on a minute that appears for another reason.
- Faults built in a scratch copy: 23. Each caught, or inside a stated limit, or content the threat model leaves to verifiers, except one: a HonestFramework passage copied without its bold markup passes check 9, which counts the passage with its markup. The docstring says "held as words". This is the gate's, not P3's; P3's text holds no such copy.

Believed: two of the three disagreements may be the planted faults; I treat all three as real.

For: the lead

## 2026-10-02 22:48:00 -0700 - verifier-P3 reports on cd77587: NOT READY, on two wrong answers; two restatements; known limits for the integration

Corrects my 22:43:27 entry in one place: it says 23 faults. My script holds 24 (F1 to F21, with F7a to F7c and F12a and F12b).

Measured, after reading P3.md (R2: my view was recorded first, at 22:43:27):
- **P3's design against the copy.** The design entry (22:10:02, with its B3 correction at 22:13:38) holds 14 draft blocks. 12 are verbatim in the copy. Two differ, by one line each, and they are findings 1 and 2 below: the design says "the verifier re-runs from clean anything it doubts" and "fixed five wrong answers". No other added line is outside the design, but the section-5 `###` heading the design names.
- **P3's claims, checked and holding:** its 16 rows; its scope; 180 insertions and 5 deletions; the quoted passages' new lines (611-612, 668-669, 704-706, 714-717), each once and byte for byte; 808 of 813 base lines kept in order; the gate's counts (79 cited items, 74 line numbers, 3 commits looked up, 14 section numbers, 97 commit messages); `--control` 48 of 48; "substantial" in no case study; the owner's words of agreement in no line of VALIDATION.md at 4190a47.
- **Privacy:** P3.md and this file, scanned with the gate's own patterns: no address but the co-author trailer's, no personal path, no secret-shaped token.

Findings, each at cd77587:
1. **Wrong answer.** METHOD.md:686, S6's third condition: "the verifier may re-run from clean anything it doubts". ADOPTION.md's S6, the plan's S6, P3's brief, P3's own design and the commit message all say it re-runs. As a condition of reuse, "may" binds nothing, so the conditions no longer keep the purpose of "re-run the gate itself". METHOD.md:701-702 then states the duty ("it still re-runs from clean"), so the rule contradicts itself. The gate passes it: content.
2. **Wrong answer.** METHOD.md:850, B3's first bullet: "fixed six wrong answers a verifier found in the shipped tree". Its cited source, cft-fp256's docs/VALIDATION.md:15260 at 4190a47, says "It found five wrong answers in the shipped tree". P3's design says "five". The incident does not say what the text claims. If the lead reads it as an overclaim instead, it is a restatement.
3. **Restate.** METHOD.md:796, `[CASE-STUDY-3, §6; 18:49; 20:01]` for the skip rule. CS3:191 reads "19:56, 20:01 | P7 SEND-BACK - the lead's own skip rule ...; P2 SEND-BACK - a false history ...", so the skip rule's send-back is 19:56, and 20:01 is P2's. The row before it, CS3:186, pairs its times the same way, which is how 18:49 is right. P3's design says the skip rule "went wrong at 20:01": P3's own misreading, not a plant. The gate passes it, inside its stated limit on a minute that appears for another reason.
4. **Restate, minor.** METHOD.md:849, B3's "it concedes no wrong answer". The source's criterion is "none gives a wrong answer today" (VALIDATION.md:15493-15494 at 4190a47). In METHOD.md, "concedes" names what a limit lets through (METHOD.md:635). Read that way, no gate limit could be a known limit, the source's own included: "A build with N1 reverted passes every device-test leg" (VALIDATION.md:15495-15497) is recorded there as one. The evidence beside the bullet gives the source's criterion, so the intent is recoverable; the bullet's words reach further than its source.

Known limits, for the integration:
- Three pointers rest on text other parcels write, which is not at cd77587: "(§3)" at METHOD.md:820 (P1's READY standard), "(§7 has its merges and records)" at METHOD.md:566, and "(§7)" at METHOD.md:689 (P4's all-round rule and B4). P3 disclosed each (22:10:02, decision 5). The gate holds only that the sections exist.
- B3's https links are not fetched (the gate's stated limit). I read their content at 4190a47 through `git show` and made no network request.

The gate, not P3's work:
- **F7b, restate.** A HonestFramework passage copied without its bold markup passes check 9, which counts the passage's characters with only whitespace squashed (tools/check_method.py:953-954 and 980-985). The docstring says the quotations "are held as words" (tools/check_method.py:159). That is inside the threat model ("a passage ... duplicated"), and neither caught nor stated. P3's text holds no such copy: each passage appears once with markup stripped too.
- **F3 and F4, a known limit.** A real observation or section mark that names the wrong item passes. The docstring states this behaviour by name only for times and named phrases. For observation numbers and section marks it is covered only by "Nor does it judge content". I read each of P3's citations at its source.

Faults, 24, built in `<scratch>/r6-vP3/tree` by `<scratch>/r6-vP3/faults.py`, with output in `faults.out`:
- **Caught (9):** F7a, F7c, F9, F12b, F13, F14, F15, F16 and F19. F13 is the negative control: the gate printed `METHOD.md:796: [CASE-STUDY-3, §6; 18:49; 04:44]: no 04:44 in round 3's record`.
- **Inside a stated limit (7):** F1, F2, F5, F6, F8, F17 and F18.
- **Content, outside the threat model (7):** F3, F4, F10, F11, F12a, F20 and F21.
- **Inside the model, but neither caught nor stated (1):** F7b.

Background processes: none of mine is running. Every command was in the foreground and has finished.

Verdict: **NOT READY**, on findings 1 and 2.

For: the lead
