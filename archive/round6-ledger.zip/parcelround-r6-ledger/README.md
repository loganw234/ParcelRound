# The round ledger (ParcelRound, round 6)

The round's record, while it runs and after it. At the round's end it is
archived with its timestamps as `archive/round6-ledger.zip` in ParcelRound.
The ledger is the round's record (ADOPTION.md, B15), so **everything here
will be published**: no secret, and no personal data, in any file.

Your dispatch message gives its absolute path, as
`<repos>/parcelround-r6-ledger/`.

**No absolute paths, here or in any commit.** A path names the owner's
machine. Name a place relative to `<repos>` or `<scratch>`, which your
dispatch message defines; ParcelRound's gate (check 10) fails on an absolute
personal path, in history too.

## The rules

**One file per author, append only.** Yours is named in your brief: `lead.md`,
`P1.md`, `verifier-P1.md` and so on.
- Read every file here, and write only to your own.
- Never edit an entry. Correct one by appending a new entry that says which
  entry it corrects.

**Stamps come from the clock, never from memory** (CS3#2). Write every
heading with `date`:

    printf '\n## %s - <headline>\n\nMeasured: ...\nBelieved: ...\nFor: ...\n' "$(date '+%Y-%m-%d %H:%M:%S %z')" >> <your-file>.md

**Read the whole directory at three moments**. They are the floor, whatever
else carries news (R5):
1. before you start;
2. before you design anything that touches a section or file your brief
   calls shared or forbidden;
3. before you write your report.

**Write an entry when it would change another agent's work, or the lead's.**
Three kinds of thing pass that test:
- environment facts;
- a brief that turned out wrong, written the moment you find it;
- a finding about shared text.

Mark which claims you **measured** and which you only **believe**.

**Escalation** (S1). Write the question in your own file first, then message
the lead and wait for its answer. If your runtime cannot message, stop, and
make the question your report. Never hold a problem for your final report.

**The lead's messages.** Every message the lead sends you is in `lead.md`
first, and its decisions are there before they reach you (CS4#12).

**Verifiers** read only `lead.md` and this README until they have formed their
own view of the work (R2). After that, they read the parcel's file to check its
claims.

**Your scratch directory** is named in your brief. Work only there, outside
your worktree.

**If a pause is announced**, write an entry saying exactly where you are
before you stop (CS4#11).

**Before you report**, stop every background process of your own: watches,
servers, long runs (CS5#10). Say in your report that you did.

## Entry format

    ## <date time zone> - <one-line headline>

    Measured: ...
    Believed: ...
    For: <who this is likely to matter to, or "anyone">
