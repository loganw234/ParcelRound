
## 2026-10-02 17:20:54 -0700 - verifier-P0 starts; a finding on shared text: METHOD.md line numbers moved by 14 at a5c0494

Measured:
- Fresh clone of ParcelRound detached at a5c0494 (origin/round6 = a5c0494). `python tools/check_method.py`: 10 of 10; `--control`: 11 of 11. tools/check_method.py is byte-identical (cmp) to the scratch build draft 3 cites.
- a5c0494 adds 14 lines to METHOD.md after line 8 (the preamble). Every heading moved by 14: section 1 is now line 37, section 3 line 169, section 6 line 604.
- ADOPTION.md evidence column: its 35 "METHOD.md:N" references are numbered at 49a9266 (where each is right: 35 of 35 checked). At a5c0494, the commit that publishes them, each points 14 lines early. Example: CS2#1 cites METHOD.md:66, the heading "Read the requester's code"; at a5c0494 line 66 is a sentence in "Two rules that prevent most of it", and the heading is at 80.
- The plan's M:NNN references are also 49a9266 numbering (for example M:227-228, M:440-444, M:600-601, and P1's "M:23, M:26-27, M:41 stay word for word").

Believed:
- Any brief that carries the plan's M:NNN numbers without saying "at 49a9266" sends its parcel to the wrong lines; wave 1 will move them again.

For: lead (ADOPTION.md, every wave-1 brief), every parcel

## 2026-10-02 17:34:34 -0700 - verifier-P0: every fault on the brief's list is caught; 25 evading faults land outside every stated limit of the gate

Measured (each fault built in its own copy in my scratch directory; the gate run there):
- Caught, as the brief asked: check 2 in every listed form plus a made-up case study; check 3 duplicate and missing row; check 9 a rewrap, a second copy, one word of a HonestFramework passage; check 10 an address on a reserved-looking domain in a commit message, an address in a zip member, both stale-exception shapes (a counted address gone; a count of 3 to 2), a personal path in a non-archive file, a secret-shaped token in a file, a zip and a commit message. 47 of 84 faults caught in all.
- Passed all ten, inside a stated limit: right minute wrong event; bare time in a template; wrong status; wrong existing heading; negated brief-errors clause; HonestFramework rewrap; look-alike and spelled-out addresses; an unlisted secret shape.
- Passed all ten, OUTSIDE every stated limit:
  - check 10: a personal path in a commit message (the docstring says commit messages are checked for paths; the code applies only the address and secret patterns); an address committed then removed (history blobs are never read); a committed address deleted only from the working tree; a lower-case path (c: then users); a path with no drive letter; a non-UTF-8 text file or a UTF-16 one (skipped silently, yet counted in "N files read"); a nested zip; a gzip file; a personal path in a zip that is not a ledger (the concession covers every zip); a percent-encoded address; an address in a file name.
  - checks 1 and 2: any citation or link that a line break splits is never read (a wrapped made-up case study passes); reference-style links; a link whose case differs from the file's passes on Windows and breaks on GitHub; "[CS3, 02:00]" resolves against round 2; a one-letter named citation "[CASE-STUDY-3, w]" passes (the plan states this limit, the docstring does not).
  - check 5: section references written "METHOD.md's section 9", "(section 9)", "sections 4 and 9", "METHOD.md, section 9" are not read (written with the section sign in the faults).
  - check 3: deleting the B9 or S3 row passes; B, R and S rows are held by nothing.
  - check 9: loganw.dev runs 17 more patterns on CASE-STUDY-2, -3, -4 and LICENSE; breaking one (CS3, LICENSE measured) passes. The plan names only CS2 and CS4.
  - checks 6 and 9: a link or a quoted passage kept only inside an HTML comment passes.

Believed:
- None of these is live at a5c0494: my own scans of the tree and every blob and commit message in history find only the known round-4 exception.
- Each is a gap to state by the behaviour it concedes, or to fix; until then a verifier list naming only the docstring's limits misses them.

For: lead (the gate's docstring), every verifier (its list of gate limits), P5 (check 5)

## 2026-10-02 17:35:41 -0700 - verifier-P0: the wave-1 briefs carry 49a9266 line numbers; a count corrected; personal paths bound for the archive

Measured:
- briefs/P1.md to P4.md hold 26 "M:NNN" references, none saying which commit numbers them. They are 49a9266 numbering; P1-P4 are cut at a5c0494, where each such line is 14 later. Example: P1 line 81 "M:23, ## 1. The one failure mode": at a5c0494 line 23 is preamble text and the heading is at 37. Most carry a quotation a parcel can search for; P2's M:494-498, M:446-501, M:463-469, M:331-334 and P4's M:691-693 carry none or a short one.
- Corrects my 17:34:34 headline: 25 evading faults outside every stated limit in the 84-fault run, plus 5 from separate runs listed in that entry's body (CS3 pattern, LICENSE pattern, wrong-case link, trailing-dot link, passage kept only in an HTML comment): 30.
- briefs/*.md hold 2 absolute personal paths each (worktrees, scratch directories, the plan, this ledger), and this ledger's README 2 more. Check 10 passes personal paths in any zip by design, so archive/round6-ledger.zip will publish them without a failure. The one address in briefs/_common.md is an allowed one.

Believed:
- The paths are the plan's accepted concession (archived ledgers are records); this README's own line "no personal data, in any file" reads stricter. Logan's call.

For: lead (before dispatch: label or renumber the briefs' M:NNN), Logan (the archive's paths)

## 2026-10-02 18:38:25 -0700 - verifier-P0 re-check of e9154be: D1 and D3-D6 answered; D2 not closed; a regression in check 10's path pattern

Measured:
- Clone fetched, detached at e9154be (parent a5c0494). Gate: 10 of 10. `--control`: 26 of 26, and no scratch repository left in the system temp directory (0 before, 0 after).
- D1: exactly the 35 CS2 evidence cells changed, each by appending "; both at `49a9266`". Check 4 fails a number with no commit (its control).
- D3: the evidence for the relaxation holds: round 2's lead.md:258, in the body of the 11:48 entry, says the suite started 11:47; no ledger heading holds 11:47; CS2's only 11:47 is in its own wrapped citation. Its cost, as the minutes of the day a made-up time can name and pass: round 2 from 14.2% to 16.5%; round 3 from 9.9% to 10.9%; round 4 from 13.6% to 16.3%; round 5 from 3.9% to 4.7%; none lost. Round 5 gains 01:24 from Logan's ratio "1:24" in a brief, plus a README example and a brief's instruction: wider than the stated "a time an entry's body records".
- D4 and D5 are in e9154be's message. D6: no absolute path in the ledger README, the briefs or lead.md (the gate's pattern and a broader one). Every brief labels M:n at 49a9266, and n + 14 holds at the tip (7 lines checked).
- My 84 faults at e9154be: 76 caught, 8 inside stated limits. My 5 separate runs: all caught.
- 42 new faults built to evade e9154be: 8 caught (sanity cases), 34 pass all ten.
- REGRESSION, check 10: a personal path behind a prefix is caught at a5c0494 and passes e9154be. Eight forms measured: WSL's /mnt mount, Cygwin's /cygdrive mount, Docker Desktop's two host mounts, file:/// URIs of a Linux or macOS home, and a PATH-list entry after a colon (two shapes). Cause: the lookbehind added so that a URL like api.github.com/users/octocat passes also excludes a word character or slash before the drive-letter form. scrub() uses the same pattern, so a failure line (a broken link to such a path) printed it unmasked.
- Outside every stated limit, besides the regression:
  - links: link text holding brackets (a badge image link); an angle-bracket target with spaces; a definition whose target is on the next line; a target that exists only untracked or ignored where the gate runs;
  - citations: an escaped bracket; a citation right after a closing bracket;
  - anchors: a line number in a status cell or in prose;
  - refs: section-sign pairs joined by "and", "sections 4 through 9" or "& 9", "SECTION 9", and a bracketed section mark in README or ADOPTION.md, which neither check 2 nor 5 reads;
  - readme: a link inside a code span;
  - quoted: relations.json's edge pattern on CASE-STUDY-4, read through facts.prose, the 29th;
  - privacy: a zero-width space or soft hyphen inside an address or path; zip archive and member comments; a gzip header's name; base64 and quoted-printable; the Documents and Settings home; WSL's home over UNC; the index differing from the working tree before a commit (caught once committed).
- Claims more than true: "all its patterns" and "all 28" (gate, e9154be's message, PLAN.md; there are 29); "every line number ADOPTION.md gives" (the evidence column only); "cited in brackets, for check 2" (README, ADOPTION.md); "read Markdown as rendered" (code spans kept); the path pattern's comment "any of three systems".

Believed:
- None is live: my whole-history scan at e9154be finds only the known round-4 exception.
- The regression matters for the archive (held to no paths) and every commit a parcel makes on a machine that runs Docker and WSL.

For: lead (the gate), every verifier (what "What it cannot see" omits)

## 2026-10-02 19:23:30 -0700 - verifier-P0 third pass on 55e8a15: R1 not fully closed (one shape), three gaps; and a correction to my 18:38:25 entry

Corrects 18:38:25: its "a gzip header's name" passes was not a fault. Python's GzipFile writes only a basename into the header, so nothing was planted (the lead found it). A hand-built header holding a profile path and an address is caught at 55e8a15, in a tree copy and in a repository.

Measured:
- Clone fetched, detached at 55e8a15 (parent e9154be; only tools/check_method.py changed). Gate: 10 of 10. `--control`: 42 of 42, and no scratch repository left in the temp directory (0 before, 0 after).
- R1's eight shapes, and WSL's home over UNC, "Documents and Settings", a soft hyphen or zero-width space inside "Users": all caught. The two URLs pass.
- My 84 faults, in tree copies and again in repository clones: 76 caught, and the 8 that pass are all inside stated limits.
- My 42 from the second pass, the gzip fault rebuilt, each run three ways (a tree copy, a clone with the fault uncommitted, a clone with it committed): every one caught, or inside a limit now stated (a link's text, a ratio, the word "a", base64, quoted-printable, a SHA outside a repository).
- New faults built against 55e8a15, each run three ways:
  - R1 NOT FULLY CLOSED, a regression against a5c0494: a POSIX home after another path segment passes. A grid of prefixes times home shapes found 12 absolute paths that a5c0494 caught and 55e8a15 passes: a home under /var, /usr, /export or /srv, under a mounted data disk, or under a macOS volume. Cause: the POSIX shape's lookbehind excludes any letter, digit, underscore, dot or hyphen. Its comment says it excludes only "straight after a host name".
  - check 2: a citation on a line that begins like a link definition is never read. Example: a footnote "[^9]: https://... [CASE-STUDY-3, 00:01]", with a made-up time. The line is blanked as a definition. The forms say every bracketed text is read, except a link's text, a defined label and code.
  - check 4: a commit named other than "at `sha`" on one line ("adopted in `deadbee`") is not looked up, against the claim that every commit ADOPTION.md names is in HEAD's history.
  - check 4: that claim is also false of ADOPTION.md itself. ADOPTION.md names cft-fp256's 4190a47 ("pinned at" then the SHA on the next line). Reflowed onto one line, it makes check 4 refuse a correct file, in a repository.
  - Inside stated classes, not defects: a target with parentheses (links in another syntax); sections joined by a slash (named any other way); a variation selector inside an address (written any other way); wildcard minutes in the records (a minute there for another reason).
- PLAN.md says 29.

Believed:
- None is live at 55e8a15. The POSIX shape matters little on this machine, but it is the class R1 named, and its comment claims a narrower exclusion than the code makes.

For: lead (the gate)

## 2026-10-02 21:06:06 -0700 - verifier-P0 fourth pass on 186e7ab: READY; every fault built is caught or inside a stated class; three wording nits

Measured:
- Clone fetched, detached at 186e7ab (parent 55e8a15; only tools/check_method.py changed). Gate: 10 of 10. `--control`: 47 of 47, the five new ones included, and no scratch repository left (0 before, 0 after).
- R1 closed. A grid of 23 prefixes by 5 home shapes, a5c0494 against 186e7ab: the only shapes a5c0494 caught that 186e7ab passes are homes written as a URL's path, the stated excuse. The lead's 21 path cases: 21 of 21 against my clone's gate. My 21 probes of the URL excuse: each as the statement predicts.
- My third pass's four defects are closed, three ways each: POSIX homes behind a path segment, caught; footnote and definition-shaped citations, caught; a commit written without "at", caught in a repository; the reflowed foreign pin, a correct file, passes.
- My 84: 76 caught in tree copies and 76 in repository clones; the 8 that pass are inside stated limits.
- My third-pass suite, 154 runs: 125 caught. The 29 that pass are inside stated classes, or a commit check in a tree copy (stated).
- 24 new faults against the four mechanisms, three ways (72 runs): 30 caught. Caught: scp- and rsync-style remote homes; a home as a link target; a home after an equals sign; a footnote's continuation line; a definition line with more text; a strict definition's broken target; a removed foreign pin; and in a repository, a commit written without "at", a commit in prose, and a non-commit SHA. The rest pass inside stated classes: homes in a token beginning scheme://host or a dotted name (file://localhost, glued by a comma or pipe, a query, ssh, a dotted share, a dotted file name); a link made by a definition; a definition in a blockquote; a line number beside the foreign pin; and correct text (a definition's title; the reflowed pin).
- Wording nits, inside stated classes, not defects:
  - a SHA in backticks written in capitals, which git resolves, is not looked up: say "in lowercase, as git prints it";
  - the URL excuse's token, the text since the last space, quote or bracket, is defined only in personal_paths(): say there that a comma or pipe does not end it;
  - "a dotted host name" is judged by shape, so a dotted file name, or file://localhost, excuses a home after it.
- One gate run: 6.0 s in a tree copy (55e8a15's gate: 5.4 s), 10.3 s in a repository. The long suite times were load on the machine.

Believed:
- Nothing found at 186e7ab is outside a statement. The notes for Logan (B3 and B16 in the survey; paths in archives) stand as recorded.

For: lead, every parcel (dispatch)

## 2026-10-02 21:06:35 -0700 - verifier-P0 waits for the threat-model commit before it reports

Measured: lead.md 21:05:47 says a docstring-only commit adds the gate's threat model, for this pass to check. At 21:06:22 round6 is still 186e7ab. My READY at 21:06:06 is on 186e7ab. I watch round6, read-only, for the commit, and check it when it lands: that it changes only the docstring; that the gate holds 10 of 10 and `--control` 47 of 47; and that the threat model is consistent with what the gate does and with my faults.
Believed: nothing yet.
For: lead

## 2026-10-02 21:10:30 -0700 - verifier-P0 on 33fb047, the threat model: NOT READY on one defect inside the model (line numbers outside ADOPTION.md)

Measured:
- 33fb047 (parent 186e7ab) is docstring-only. Its syntax tree outside the module docstring is identical to 186e7ab's; the diff adds 20 docstring lines and removes none. Gate: 10 of 10. `--control`: 47 of 47, no scratch repository left. The message matches the diff.
- The paragraph's claims checked against the code. Each holds, but one: its first bullet says the gate guards against "a reference that goes stale as files change (a line number, ...)". Check 4 reads file:line only in ADOPTION.md. A file:line with no commit passes in templates/brief.md, in README.md and in METHOD.md's prose, in a tree copy and committed. The same in ADOPTION.md is caught. No stated limit concedes line numbers in other files. This is honest drift, the same class as D1, so it is a defect inside the model.
- My faults, judged against the paragraph:
  - inside and caught: every caught fault listed at 21:06:06;
  - inside and passing, named by a stated limit: right minute wrong event, a ratio's or wildcard minute, the word "a", a wrong status, a wrong existing heading, a negated clause, a line number beside the foreign pin, a commit check in a tree copy, a home written as a URL's path (file://localhost, a query, ssh, a dotted share), the author field, tags and branches;
  - out of scope, deliberate evasion: base64, quoted-printable, spelled out, a variation selector, a citation as a link's text or turned into one by a definition, a path glued after a URL by a comma or pipe, a home after a dotted file name, a capitalised SHA, a link target with parentheses, a definition inside a blockquote, sections joined by a slash;
  - out of scope, content: a section number in a case study. METHOD.md's sections are frozen by check 8, so such a number cannot go stale, only be wrong when written;
  - correct text: a definition's title, the reflowed foreign pin, HonestFramework passages rewrapped.

Believed:
- The fix is small: read file:line, needing a backticked commit, in METHOD.md, README.md and templates/ as in ADOPTION.md. Or scope the bullet and state the limit. Either way, a scoped re-check.

For: lead

## 2026-10-02 21:18:33 -0700 - verifier-P0 scoped re-check of 2e34bd1: the defect is closed; READY

Measured:
- 2e34bd1 (parent 33fb047) changes tools/check_method.py only. By syntax tree, the only top-level definitions that differ are anchors() and PLANTS (one new control); the rest of the diff is the docstring. Gate: 10 of 10. `--control`: 48 of 48, no scratch repository left (0 before, 0 after).
- The 21:10:30 defect is closed. A file:line with no commit is caught in templates/brief.md, README.md and METHOD.md's prose, in a tree copy and committed; ADOPTION.md's is caught as before.
- Nothing else changed behaviour: all 12 earlier anchors faults (faults2 to faults4), in a tree copy and committed, behave exactly as at 186e7ab.
- Edges: a real commit beside a template's line number passes; a made-up one passes in a tree copy (stated) and is caught committed. A line number in code, or in a case study, passes (both stated). A commit in another table cell does not count (per cell).
- Nits, not defects:
  - a made-up commit beside a line number outside ADOPTION.md is reported as "ADOPTION.md names commit ...";
  - a host and port in prose ("localhost:8080") in those files is refused as a line number with no commit, a loud false refusal; backticks avoid it (worth a line to P5);
  - the docstring says each foreign pin must be "named in ADOPTION.md", but the code also counts a pin beside a line number elsewhere.
- Ledger files, briefs/_verifier.md included: no address, path or token by the gate's scan.

Believed: nothing outside a statement.

For: lead, P5

## 2026-10-02 22:16:02 -0700 - verifier-P0 scoped re-check of 1dc5ed4: the foreign-pin control is live; READY

Measured:
- 1dc5ed4 (parent 2e34bd1) changes tools/check_method.py only. By syntax tree, only PLANTS, anchors() and control() differ, plus the docstring. In anchors(), only two messages and the table that names a commit's file changed. Gate: 10 of 10. `--control`: 48 of 48.
- The control is live with and without a cited pin. On one tree copy, with and without a METHOD.md sentence citing docs/VALIDATION.md:15274 beside `4190a47` in P4's link form:
  - 2e34bd1's gate: 48 of 48 without the sentence; 47 of 48 with it, the pin control NOT CAUGHT (P3's finding reproduced);
  - 1dc5ed4's gate: 48 of 48 both ways, "a declared pin nothing names" caught;
  - the gate itself: 10 of 10 every way, so the link form is accepted.
- The undo leaves FOREIGN_COMMITS as it was. In-process, after control() (48 of 48), and after a plant whose check raises once planted, its keys, values and order are the same. No scratch directory is left.
- Nothing else changed behaviour. My line-number faults and edges, and every earlier anchors fault, in a tree copy and committed: 13 of 24 and 11 of 24 caught, each outcome the same as at 2e34bd1. A removed real pin, cited nowhere else, is still caught.
- Nits 1 and 3 of 21:18:33 are fixed: a made-up commit beside a template's line number is reported as "templates/brief.md names commit ...", and the docstring says a pin must be named "in ADOPTION.md or beside a line number in those files". Nit 2, a host and port refused as a line number, stands as noted.

Believed: nothing outside a statement.

For: lead, every parcel
