# Round 6 - verifier-I's ledger

Append only. Each heading's time is taken from `date`.

## 2026-10-02 23:17:53 -0700 - verifier-I starts on phase 1: wave 1's integration, round6 from 1dc5ed4 to fe58489

Measured:
- I run as Claude Opus 5.5, from my own system prompt.
- My clone is at <scratch>/r6-vI/clone, made from <repos>/parcelround-worktrees/P0 and detached at fe58489. I write nowhere else but <scratch>/r6-vI/ and this file.
- Read so far: the ledger README, briefs/_verifier.md, briefs/integration.md, briefs/_common.md and lead.md in full.
- `git log 1dc5ed4..fe58489` holds twelve commits of round6's own: four merges (f307c02, 0b5e4aa, e8bfe28, 72b0049), four restate commits (b8c57f3, 4b8ce96, 012574b, 3083090), the integration d27b656, two gate commits (6c83960, 56df604) and the ADOPTION.md commit fe58489. lead.md names 6c83960 by no SHA; its 23:16:47 entry counts "its two gate commits".

Believed: nothing yet about the work.

For: the lead

## 2026-10-02 23:47:23 -0700 - verifier-I on fe58489: the merges made again are equal and the gate holds; nine of the lead's sentences claim more than is true, one gate limit is stated by its instance; five known limits

Line numbers are at fe58489 unless named otherwise.

Measured, and holding:
- **The gate, in my clone**: 10 of 10 at fe58489, and at each of the 16 commits in 1dc5ed4..fe58489 (the four parcel tips, the four merges, and the lead's eight). `--control`: 49 of 49. My clone was clean after; no check_method directory was left in the system temp directory.
- **Each merge made again** (`git merge-tree --write-tree` from its parents): f307c02, 0b5e4aa, e8bfe28 and 72b0049 each give their commit's tree exactly, with no conflict. Their second parents are 03561a7, 3676786, 4ff28ca and d38fea1.
- **The keys**: `sha256sum keys/*.json` gives the four hashes lead.md logged at dispatch. Each real tip holds each plant's old text once and its new text nowhere.
- **The lead's audits** of the four parcel commits (files, insertions and deletions, hunks inside the owned sections at each tip, the Sonnet 5.5 trailers) hold.
- **The restates that answer their findings and fit their sources**: b8c57f3's three (B13's approvals are the survey's AUD, S56 and LANG, archive/round6-practice-survey.md:124; CS4#7's READY is the verifiers', CASE-STUDY-4.md:106 and :169; B17's one agent, P1.md:168); 012574b's two (19:56 is P7's send-back for the skip rule, CASE-STUDY-3.md:191; "gives no wrong answer today", VALIDATION.md:15492-15494 at `4190a47`); 3083090's D1 correction (records are record entries and commit messages, CASE-STUDY-3.md:672-675, CASE-STUDY-5.md:343-345), S4's tip, and "a bare SHA-256".
- **Every cross-section pointer** wave 1 wrote is true at fe58489: "(§5 says how a limit is stated, §6 how it is tested)" (METHOD.md:295; 926, 1110), "(§7)" twice (144, 273), "(§3)" (1111), "(§7 has its merges and records)" (857; 1160), "(§7)" (980; 1229), and P4's "(§5)", "(§2)" twice, "(below)" twice, "is in §3" and "§8's trade".
- **The gate commits.** 56df604 is docstring only, and 6c83960 changes only plain(), check_quoted() and PLANTS beside it (syntax trees compared). Their stated limits, by faults in tree copies under <scratch>/r6-vI/ (faults.py, faults.out): an existing observation, section mark, phrase and minute of the wrong item each pass, inside "an item resolves by existing"; METHOD.md's own brief-errors clause negated, or its whole paragraph deleted, passes, inside check 7's reach; a link whose text and target disagree, relative or https, passes, inside 56df604's sentence. **The new word count is a real check**: the control's plant (the bold passage copied without its bold) passes 012574b's gate and fails fe58489's.
- **Privacy**: every commit message and added line in the range, and every file of the ledger (keys/ and this file included), scanned with the gate's own findings() and a wider pattern of my own (<scratch>/r6-vI/privacy.py): no address but the co-author trailer's, no personal path, no secret-shaped token. The author fields carry the owner's address, a stated limit the plan records.

Findings (restates: a sentence that claims more than is true; none is a wrong answer or a regression):
1. **The preamble's new first sentence** (METHOD.md:3-4, d27b656) excepts rules that "say" they rest on practice or the owner's word, and d27b656's message says each such rule says so. Two do not. CS4#16 (1110-1120) cites one limit tested and holding (obs 18), which P3 graded practice (P3.md:435); CS4#21 (1344-1349) cites a saving, which P4 graded "a catch, and a saving (it is not a break)" (P4.md:344). Neither says so, so the preamble claims a break behind each. S6's allowance (982-983) rests "on a cost", a third kind the exception does not name. B1 (1182-1193) and CS4#20 (1337-1342) are catches; whether a catch counts as "something broke" is the lead's to say.
2. **S5 written twice, differently** (d27b656). Section 7 (1208-1211): "every claim a parcel writes is on its verifier's list. §3 has the rule and its incident." Section 3 (274-275) and S5's row (ADOPTION.md:158) say every claim in a document a parcel writes.
3. **4b8ce96 adds a claim its source does not hold.** METHOD.md:494-497 gives the later brief "the stamp rule and measured-or-believed", cited to the survey's B7 and departures rows. "Measured-or-believed" is in no line of the survey (:118, :139; its CS3#2 row, :46, has the stamp rule), of the ledger, or of lead.md's 22:53:58 ruling; the commit message says the lead read the gitignored brief, and no entry records that reading.
4. **3083090's reason misreads its source.** lead.md:608 and the commit message say case study 3 says the agent cards show the final-context sum. CASE-STUDY-3.md:543-548 says that of the harness figure, and that whether round 2's cards showed it "cannot be determined from these sources"; verifier-P4.md:47 had "may show". The METHOD.md change (1260-1262) stands on R3's row ("read from transcripts") and CS3#13's adopted part; only its recorded reason is wider than the source.
5. **fe58489's counts.** Its message and lead.md:651 give 54 "to adopt" and 6 "to adopt in part". At 56df604 ADOPTION.md holds 53 and 7 (in part: CS3#6, CS3#8, CS3#13, CS3#14, CS3#16, CS3#17, CS4#4), and fe58489 holds 7 "adopted in part at", as in the plan's "Adopt the practised part (7)". Counted by script.
6. **ADOPTION.md's statuses paragraph** (ADOPTION.md:20-23) says each round-6 row "was practised in a later round, and adopted at the owner's word, 'Everything practised (Recommended)'". R1-R5 and S1-S6 came in under his answer on departures, "Restore safeguards (Recommended)", and B9, S2 and S3 by name, as their own rows say; R rows restore what later practice dropped (the survey's departures table). Carried from P0's "to adopt" definition onto 60 adopted rows.
7. **A gate limit stated by its instance** (6c83960). The docstring (tools/check_method.py:165-166) holds HonestFramework's quotations "as words, with or without their emphasis"; plain() (964) sets aside whitespace, `*` and `_` only. A copy in another case passes: "a control described but not run is worth nothing, so ask for its output." inside a sentence, which is how HonestFramework's own METHOD.md:305-306 at `65447fd` quotes it; so does "a gate that cannot fail is not a gate"; and a copy with typographic quotes round "found nothing" (faults H2-H4). That is a passage duplicated, inside the threat model, neither caught nor stated: CS4 obs 21's shape. Not live: each passage appears once at fe58489, case folded too. METHOD.md:1115-1117 now says READY waits for such a limit to be restated.
8. **"A finished agent re-arms nothing"** (d27b656's headline). METHOD.md:645 qualifies "notices its watch is gone" with "while it is still working"; the next sentence (647-651), "the expiry notice is the moment to re-arm it and do a full read", carries no condition, and round 5's finished verifier re-armed when "its watch's exit reached it as a notification" (CASE-STUDY-5.md:255-258).
9. **The record lacks 6c83960.** lead.md:577-580 sends the three gate notes to the end-of-round commit; they went into 6c83960 at 22:59:40, before P4's merge, which also closed the markup limit with a check and a 49th control instead of stating it. No entry names 6c83960 or the change, and lead.md:632 calls 56df604 "the lead's gate commit".

Known limits, by the behaviour they concede:
- **Section 7's lists ran together** (3083090). With the obs 14 paragraph gone, CommonMark (markdown-it) renders the four round bullets and "The plan of record", "P0." and "The seam tests." as one list of seven under "in each of rounds 2 to 5 the record shows its own work going in without a verifier:" (METHOD.md:1166-1198). At d38fea1 they were two lists.
- **README step 4** (README.md:60-62, which HonestFramework quotes word for word, WITH-PARCELROUND.md:36 at `65447fd`) says the full suite runs after each merge. A round branch runs "a gate" after each merge and the full suite at its tip (METHOD.md:1221-1224), and a budget is "a subset of the suite" (1326). verifier-P4 raised it (verifier-P4.md:40); the 23:06:11 ruling restated the tip only.
- **Statuses name the parcel's commit**, not the lead's restates after it. For CS3#7 and CS5#1 (ADOPTION.md:88, :123), d38fea1 is the text that held D1's wrong answer.
- **S1's and S3's rows** (ADOPTION.md:154, :156) now name only the escalation subsection, while S3's lead side (METHOD.md:744-745) and S1's decision bullet (771-772) sit under "The lead watches too, and watches more"; fe58489's message says the eleven rows sit wholly under the new subsections.
- **CS3#12 is "adopted"** (ADOPTION.md:93), while D4 (lead.md:365) left out the batched-merge relaxation its proposal names (CASE-STUDY-3.md:696-700), and METHOD.md:1327-1328 points to section 8's existing trade instead.

Notes:
- The 22:15:07 ruling 2 (lead.md:451), "the lead trims any duplicate of P4's section 7 at integration": the code half (855-871) and section 7's rule (1160-1180) still tell rounds 3 and 5 twice. They agree; no entry says why they stay.
- 3083090's message and lead.md:607 put "a bare SHA-256" at VALIDATION.md:15649; the words are at 15654, in the paragraph 15649 opens.
- b8c57f3's message ties the cert round's survey to "main's 6569b39" as "P1's own reading"; P1.md:168 records one agent and no commit.
- METHOD.md:674-676, "Agents in a round usually share one scratch directory", now reads against section 3's own rule (335-341).

Believed:
- Findings 1-9 are restated by the lead: in METHOD.md, ADOPTION.md, the gate's docstring and, for the records, a ledger correction and a later commit message, as was done for ee51756. Nothing goes back to a parcel.

For: the lead

## 2026-10-02 23:48:06 -0700 - verifier-I reports on phase 1: NOT READY on fe58489, with nothing sent back; nine restates, one of them a gate limit stated by its instance

**NOT READY**, on fe58489. No finding is a wrong answer or a regression, so nothing goes back to a parcel. Findings 1-9 of my 23:47:23 entry are restates; finding 7 is a gate limit that a fault inside the threat model walks past, and METHOD.md:1115-1117 says READY waits for that to be restated. A scoped re-check of the restatements settles it.

Measured:
- The third read moment, at 23:47:27: nothing in the ledger has changed since my second read. The new files since my start are P5.md (to 23:21:12) and lead.md's entries of 23:21:14 and 23:21:34; neither bears on phase 1.
- My file, scanned as the rest of the ledger was: no address, path or secret-shaped token.
- What I ran is in my 23:47:23 entry. My scripts and outputs are under <scratch>/r6-vI/: faults.py and faults.out (15 faults), privacy.py, keycheck.py, adoptdiff.py, adoptcount.py, adoptparcel.py and render7.py. Each fault's tree copy is deleted.
- Background processes: none of mine is running. Every command ran in the foreground and has finished. The system temp directory holds no check_method directory, and my clone is clean at fe58489.

Believed: nothing beyond my 23:47:23 entry.

For: the lead

## 2026-10-03 00:06:24 -0700 - verifier-I's scoped re-check of 5c19906: NOT READY; findings 2, 3, 7 and 8 and the known limits fixed, 4, 5 and 9 answered; finding 1 not yet true, finding 6 in part

Scoped to my findings of 23:47:23 and 23:48:06, and to lead.md's 23:53:44 entry (item 0). Line numbers are at 5c19906 unless named otherwise.

**NOT READY on 5c19906**, on finding 1, which is not yet true, and finding 6, which is fixed in part. Both are restates, as are the two smaller residues below. Nothing goes back to a parcel; there is no wrong answer and no regression.

Measured, and holding:
- 5c19906 (parent fe58489) was fetched into my clone and checked out detached. The gate gives 10 of 10 and `--control` 49 of 49; the clone was clean after, and no check_method directory was left. The gate's code outside its docstring is identical to fe58489's (syntax trees compared).
- **Fixed:**
  - finding 2: section 7 (1211-1214) and section 3 (274-275) now both say "every claim in a document a parcel writes", as S5's row does;
  - finding 3: METHOD.md:495-498 has "append only" and the stamp rule, cited to B7, CS3#2 and the departures rows, which hold them (archive/round6-practice-survey.md:118, :46, :139);
  - finding 8: the expiry sentence (648-650) is now "for an agent still working";
  - finding 7 is stated by behaviour (tools/check_method.py:165-168). My faults H2-H4, a copy in another case or with typographic quotes, now pass inside the statement;
  - the known limits: CommonMark renders section 7 as two lists again (markdown-it: four round bullets, then the plan, P0 and the seam tests); S1's and S3's rows name both subsections; CS3#12 is adopted in part, naming D4.
- **Answered in the ledger and in 5c19906's message**, each matching its source: findings 4, 5 and 9, line 15654, and 6569b39.
- **Item 0**: the README step 4 ruling describes both shapes correctly, and stands as a known limit for the owner. Ruling 2's reason holds: the shared incidents are citations of the same events for two rules.
- Privacy: 5c19906's message and added lines, and the ledger, are clean by the gate's findings() and my wider pattern.

Findings:
1. **Finding 1 is not yet true. The preamble against every rule.** I listed all 156 bold-led blocks of METHOD.md (<scratch>/r6-vI/rules.py) and read each round-6 rule's evidence. Earlier rules made the old, narrower claim of a break, so the new sentence makes none of them newly false.
   - a. METHOD.md:3-4 says every rule is here because of a break "or because its practice caught a defect". Line 5 then admits rules that rest on practice alone or on the owner's word. Nine say so and cite no break and no catch: B3 (1133-1134), B4 (1241), B8 (1379), B9 (1388), B13 (259), B14 (1246), B15's keeping (800), CS4#16 (1121) and S4 (149, 1227). For these the first sentence's "every" is false. d27b656 had the exception inside the sentence ("except where a rule says it rests on..."); 5c19906 drops it.
   - b. CS4#11 (531-546) is covered by neither sentence. Its evidence is a pause survived (CASE-STUDY-4.md:153, obs 12, "A usage pause is survivable when the ledger is the state"), the owner's words, and cft-fp256's agents re-dispatched from their notes. That is no break and no catch, and it does not say it rests on practice or the owner's word. My first pass missed it.
   - c. S6 (983-984), "The allowance rests on a cost, not on a break". Named in my finding 1; neither 5c19906 nor the 23:53:44 entry answers it. A cost is not a break, a catch, practice or the owner's word as the preamble names them.
   - 5c19906's headline, "the preamble true of every rule", claims more than this.
2. **Finding 6, in part.** ADOPTION.md:25-27 credits "the S rows" to the plan's approval, "Approve; P0 verifier rechecks". The Departures answer, "Restore safeguards (Recommended)", named four of them as allowed shapes: direct messages, one round branch, parcels owning their docs, and reuse of long runs, which are S1, S4, S5 and S6 (PLAN.md:546-551; :133, "the Departures option named four adaptations"). Only S2 and S3 came by name.
3. **A residue of finding 7.** The word count reads the rendered text only (plain(shown), tools/check_method.py:997), while check 9 claims "with and without its fenced code and HTML comments" (:72). So a copy without its emphasis inside fenced code or an HTML comment passes (faults H7, H8); a copy with its bold in a fence is caught (H9). The new statement, "held with whitespace and emphasis set aside", does not concede it. Not live: each passage appears once in the raw text with emphasis and case set aside.
4. **CS3#12's status against its definition.** ADOPTION.md:28-29 defines "in part" as "only the part that was practised". CS3#12's part is the one ruling D4 kept (ADOPTION.md:97). The survey records CS3#12, batches included, as practised in cft-fp256 (archive/round6-practice-survey.md:56).

Notes:
- Ruling 2 (lead.md:723) counts two shared incidents, round 2's 17:39 and round 5's obs 2. There are three: round 3's [CASE-STUDY-3, §5], the follow-ups' seam commits through gates and CI only, is cited in both (METHOD.md:861-863 and 1172-1174). The ruling's reason holds either way.
- lead.md:721 puts 56df604's link limit among "the gate notes of 22:53:58". It was verifier-P4's, ruled at 23:06:11 (lead.md:618).
- ADOPTION.md:21-23 says the lead's restates "are in the round's ledger and its case study". The case study is phase 2's; I check it then.

Faults run against 5c19906 (<scratch>/r6-vI/faults.py; output faults-5c19906.out):
- H1 and H5 are caught. W5, the negative control, is caught and named at METHOD.md:1088.
- W1, B1 and L1 pass, inside their stated limits; H2-H4 pass, inside the new statement.
- H7 and H8 pass, outside it; H9 is caught.

Believed: one commit restates 1a to 1c, 2 and 3 (the preamble's exception back in its sentence; CS4#11 and S6 saying what they rest on; S1, S4, S5 and S6 credited to "Restore safeguards"; the word count's reach stated or widened to the raw text), and settles 4. A scoped re-check of that commit would settle READY.

Background processes: none of mine is running. Every command was in the foreground and has finished; the system temp directory holds no check_method directory; my clone is clean at 5c19906.

For: the lead

## 2026-10-03 00:18:34 -0700 - verifier-I's second scoped re-check, of a30aca5: NOT READY on one phrase; finding 1 and the rest hold, and the 50th control is real

Scoped to my findings of 00:06:24, and to lead.md's entries of 00:11:29 and 00:11:37 (item 0; the coordinator's "00:11:52" names no entry, and these are the two). Line numbers are at a30aca5.

**NOT READY on a30aca5**, on one phrase. ADOPTION.md:25-27 says "Restore safeguards (Recommended)" "named" the R rows. It named two of the five. Everything else I re-checked holds. This is a restate: no wrong answer, no regression, nothing sent back.

Measured:
- **Gate and controls.** round6 was fetched into my clone and a30aca5 checked out detached. The gate gives 10 of 10, and 10 of 10 at e5ce41e too; `--control` gives 50 of 50. My clone is clean.
  - Gate scratch directories that appeared in the system temp directory during and after my run were other sessions'. They came and went at 00:15:04 and 00:15:12, after my control's output closed at 00:14:58; none is left now.
- **The 50th control is a real check.** I planted its fault by hand: a copy of "A gate that cannot fail is not a gate." without its bold, in a code fence, in a copy of e5ce41e's tree. 5c19906's gate passes it; e5ce41e's fails it ("as words 2 and 1 times"). The tree without the plant passes both (<scratch>/r6-vI/control50.py, control50.out). The same holds for the copy in an HTML comment (my H8). A copy in another case passes both, inside the stated limit.
- **Finding 1 holds: the preamble against every rule.** METHOD.md:3-6 now reads: a break, or a catch before it shipped, "or, where the rule says so, because it rests on practice that held, on a cost, or on the owner's word". Read against all 156 bold-led blocks (rules.py, rules-a30aca5.txt):
  - each round-6 rule cites a break or a catch, or says what it rests on. That is B17 (112), S4 (150, 1229), B13 (260), CS4#11 (548, new), B15 (802), S6's cost (985), CS4#16 (1123), B3 (1135), B4 (1243), B14 (1248), B10 (1321), B8 (1381) and B9 (1390);
  - the older rules made the narrower claim of a break, so none becomes false.
- **The rest of the fixes and rulings hold:**
  - "in part" now covers a part a ruling kept, CS3#12's (ADOPTION.md:28-29);
  - the code reads the written text (tools/check_method.py:997-998), now matching its docstring line "with and without its fenced code and HTML comments" (:72);
  - a30aca5's section 4 sentence (677-678) agrees with section 3's CS4#6;
  - the CS4#9 and CS3#10 cells match where the templates hold the lead's rules (templates/ledger.md:115, checklists.md:65; P5.md:466-468);
  - the ledger corrections (three shared incidents; the link limit verifier-P4's; 23:53:44) are right.
- **Privacy**: e5ce41e's and a30aca5's messages and added lines, and the ledger, P5.md included, are clean by the gate's findings() and my wider pattern.

Finding:
1. **"which named them" names three rows the answer did not.** ADOPTION.md:25-27: "the R rows, and S1, S4, S5 and S6, at 'Restore safeguards (Recommended)', which named them". e5ce41e's message says the plan records that the answer "named the R rows". The option as put (PLAN.md:547-549) named "the brief-errors line and the verifier's independent first view", R1 and R2, and the four adaptations. R3, R4 and R5 it did not name; R4 and R5 entered in draft 2 (PLAN.md:27-28), and the plan approved them under that answer. "Which named R1, R2, S1, S4, S5 and S6", or the words dropped, makes it true. My 23:47:23 finding 6 said only that the R and S rows "came in under" that answer.

Background processes: none of mine is running. Every command was in the foreground and has finished.

For: the lead

## 2026-10-03 01:10:04 -0700 - verifier-I's phase 2 on 48d1eab: NOT READY on restates; the merge, the lead's restates, the gate, the cost table and the times hold; ten restates, eight in CASE-STUDY-6.md and two in ADOPTION.md

Phase 2: round6 at 48d1eab, a30aca5..48d1eab, items 0, 5, 6 and 7. Read first, as item 0: lead.md from 00:19:49 to 00:53:23, P5.md to 00:21:56, verifier-P5.md and keys/key-9c306e9.json. Line numbers are at 48d1eab unless named otherwise.

**NOT READY on 48d1eab.** No wrong answer and no regression, so nothing goes back to a parcel. CASE-STUDY-6.md gives eight things the ledger does not hold as written, and ADOPTION.md two; each is a restate. The merge, the lead's restates after it, the gate, the cost table and the times hold.

Measured, and holding:
- **Gate and controls.** 10 of 10 at each of 43403e6, 6975994, 34291cc, a6a6553 and 48d1eab. `--control` gives 50 of 50 at 48d1eab, no check_method directory was left, and my clone is clean.
- **P5's merge made again.** `git merge-tree --write-tree 6975994 43403e6` gives 34291cc's tree exactly, with no conflict.
- **The keys.** `keys/key-9c306e9.json` hashes to the 66a20d88... logged at 00:23:24. In all five keys, each plant's old text is in its real tip once (43403e6 for P5) and its new text nowhere.
- **6975994** (my 00:18:34 finding) reads as the plan records: "Restore safeguards" named R1, R2 and S1, S4, S5 and S6 (PLAN.md:547-549); R3-R5 sit in its table of safeguards (:230-238).
- **a6a6553**, the lead's restates after verifier-P5:
  - checklists.md:133-134 has "while the agent is still working";
  - the docstring's refs limit (tools/check_method.py:157-158) is true of check 5, by verifier-P5's F4;
  - the 35 round-2 template cells match P5.md:836-855 one for one. Against the merged templates, each named template carries its rule (<scratch>/r6-vI/cs2cells.py, cs2cells.out, read by hand): CS2#3 through brief.md:202-203's stop line (§2, §8); CS2#17 at checklists.md:169 and verifier.md:38; CS2#25 at verifier.md:45; CS2#33 at checklists.md:215. No "none" row is carried.
- **The cost table reproduces from the transcripts** (`r6-lead/cost_md.py`, run as is; I read only it and check_cs6_times.py there):
  - every finished agent's row is exact;
  - verifier-I's row, 149 / 117,223 / 64,501,622, holds to my 00:18 report;
  - the lead's, 553 / 823,019 / 262,720,554, holds with a cutoff between 00:49:35 and 00:49:40 (my bounded copy, <scratch>/r6-vI/cost_bounded.py);
  - totals, the shares (24%, 43%, 30%) and the wall clock (7 h 41 min; 4 h 12 min) hold.
- **Times.** `check_cs6_times.py`: all 40 second-precision times are entry stamps. I read each against the event the file gives it, and every minute in the timeline against its entry. They hold, but for finding 4 below.
- **Figures that hold:** 712 lines at a5c0494 and 1,563 at 186e7ab; 113 rows; 11 and 26, 42, 47 controls; 84, 47 and 37 faults; nine and ten plan defects; 13 brief errors (4, 1, 3, 5); 47 of 48; eight and ten of ten plants; 11 of 44 and 9 of 27 placeholders (P5.md:87); thirteen observations and eight proposals, each proposal naming its observations.
- **Item 0.** The rulings of 00:19:49, 00:23:24, 00:24:40, 00:46:54 and 00:53:23 hold against their sources: P5's audit figures (43403e6: four templates, 595 and 189, Sonnet 5.5, parent a30aca5); the two known limits (verifier.md:125, brief.md has no cost-model slot); P5 not sent back.
- **Privacy:** a30aca5..48d1eab's five commits, messages and added lines, CASE-STUDY-6.md, the templates and the ledger as it stands are clean, by the gate's findings() and my wider pattern.

Findings (each a restate):
1. **CASE-STUDY-6.md:7, "went past a verifier five times".** Six: the lead's 21:19:10 count of five predates 1dc5ed4, whose own subject begins "P0:". verifier-P0 checked it at 22:16:02, which the file's timeline lists (line 67).
2. **:88, "The first found 25 faults outside every stated limit (17:44:01)".** That entry gives 25 in the 84-fault run "and 5 more came from separate runs, for 30" (lead.md:42; verifier-P0.md:38). The timeline row (:56) is right.
3. **:111-114, wave 1's real findings "were all overreach"; "Every real finding they made in the parcels' work was a sentence wider than its source".** The same verifiers' real findings include:
   - cross-section pointers that held once merged (verifier-P1.md:102-105; verifier-P3.md:50; verifier-P4.md:46);
   - the cost bullet's two measures (verifier-P4.md:47);
   - D1, which obs 4 calls the round's one wrong answer.
   The quantifier is wider than the record, the shape the observation describes.
4. **:169-170, verifier-P4's "two findings were already recorded".** Its entry recording them is stamped 22:54:53, after the 22:53:58 entry. It says they were "formed from the sources before I read the lead's 22:53:58 entry" (verifier-P4.md:23), and lead.md 22:57:23 says "formed". Its grade rests on that statement, not on an earlier record.
5. **:188, "P5 listed eight things".** P5's list under "What the brief got wrong, and findings on shared text" has eleven items (P5.md:478-489), and its report says "the eleven items" (P5.md:870). Eight is right only if items 1, 9 and 11, which are not errors, are left out; the file does not say so.
6. **:220-222, "e5ce41e fixed both".** 5c19906 restated the passage limit by behaviour (my 23:47:23 finding 7); e5ce41e widened the count's reach, with the 50th control (my 00:06:24 finding 3).
7. **:224-228 and :235-237, "the lead typed three values" and "A fourth".** The ledger records five. The fourth was in a message and in this file's draft (lead.md 00:19:49). The fifth, "00:49:21" for 00:46:54 in the draft, was caught by the time check (lead.md 00:53:23, "a fifth typed value").
8. **:266-274, obs 13.**
   - Its heading, "claimed more coverage than it had", inverts the finding: the templates had more coverage than the claim allowed.
   - "Its report added 'and none it doesn't'": those are the lead's words (lead.md:817). P5's report says "none is carried that ADOPTION.md does not send there" (P5.md:832).
9. **ADOPTION.md:148-155, CS6#1 to CS6#8, "pending: proposed by the round that practised it".** Round 6 did not practise:
   - CS6#3: it revealed keys early and described plants in prose (obs 6; lead.md 00:24:40);
   - CS6#2: the link limit was stated, not held;
   - CS6#8: the lead typed five values.
   It practised CS6#1 only after three passes, and CS6#6 only after a restate added a claim (my 23:47:23 finding 3). A reason such as "proposed by round 6" is true of all eight.
10. **ADOPTION.md:42-47, "Each template line names its own METHOD.md section, in parentheses".** 23 tagged units are "(own)" and name no section (43403e6's message; P5.md:831), and headings and placeholders carry no tag. The templates' own legend (brief.md:7-10) states it exactly.

Notes:
- :102, "The owner set the threat model at 21:05:47": the owner said "Yes, add the threat model and make that the last pass" to the lead's recommendation. The paragraph's words are the lead's (33fb047), which verifier-P0 checked (21:10:30).
- :346, CS6#8 extends "case study 3's stamp rule". The stamp rule is round 2's (METHOD.md §4, [CASE-STUDY-2, §4]); case study 3 carried it into every brief.

Background processes: none of mine is running; every command ran in the foreground and has finished. My clone is clean at 48d1eab.

For: the lead

## 2026-10-03 01:17:56 -0700 - verifier-I's scoped re-check of 8a2a1d7: READY; all ten restates and both notes fixed; two wordings in obs 11 looser than the ledger, noted

Scoped to my 01:10:04 findings and notes, and to lead.md's 01:11:09 entry (item 0). Line numbers are at 8a2a1d7 (parent 48d1eab), which changes CASE-STUDY-6.md and ADOPTION.md only.

**READY on 8a2a1d7.** All ten restates and both notes are fixed, each against its finding and the ledger. Nothing else in the two files became false that matters to a time, count, figure or quotation. Two wordings in the new obs 11 are looser than the ledger; they are noted below and do not change the verdict.

Measured:
- **Gate and controls.** The gate gives 10 of 10 and `--control` 50 of 50; no check_method directory was left, and my clone is clean.
- **Times.** `check_cs6_times.py` finds none missing: 41 cited times are entry stamps (00:53:23 is the new one), and the two typed values the file quotes, "00:24:05" and "00:49:21", are in lead.md's entry text (01:11:09, 00:53:23).
- **Each fix, against its finding and the ledger:**
  1. :7, "six times": a5c0494, e9154be, 55e8a15, 186e7ab and 33fb047, 2e34bd1, and 1dc5ed4 (22:16:02).
  2. :88-89, 30 faults, "25 in its 84-fault run and 5 in separate runs": lead.md:42.
  3. :113-118 and :131, obs 3:
     - it now names the pointers that held once merged and the older sentence the new one contradicted;
     - it says the one wrong answer was the lead's (obs 4).
  4. :173-177, "formed" before it read the entry, and the recording entry "stamped after the reveal": verifier-P4.md:23, 22:54:53.
  5. :194-196, eleven items (P5.md:478-488), eight of them errors in the brief and shared text: items 2-8 and 10. Items 1, 9 and 11 are not errors.
  6. :229-230: 5c19906 restated the limit; e5ce41e widened the count and added the 50th control.
  7. :232-251, six typed values:
     - three in the ledger (18:2x, 8f-merge, 23:54);
     - "00:11:52" (00:19:49);
     - "00:24:05" (01:11:09);
     - "00:49:21" (00:53:23).
  8. :280-290, obs 13:
     - the heading is the right way round;
     - P5's words, "none is carried that ADOPTION.md does not send there", are quoted as P5's (P5.md:832), and "and none it doesn't" as the lead's (lead.md:817).
  9. Note 1, :103-105: at the lead's recommendation, in the lead's words, at 33fb047. The threat model first appears there; 186e7ab has none.
  10. Note 2, :361-363: the stamp rule is round 2's, carried by case study 3.
  11. ADOPTION.md:149-156: "pending: proposed by round 6", true of all eight.
  12. ADOPTION.md:44-47: each rule tagged with its section or "own", "as each template's legend says". All four templates carry that legend (brief.md:7-10, checklists.md:8-11, ledger.md:13-17, verifier.md:7-11).
- **Item 0.** lead.md 01:11:09 states my ten restates and two notes as I wrote them. It records the sixth typed value, "00:24:05", which the file now counts.
- **Privacy:** 8a2a1d7's message and added lines, and the ledger as it stands, are clean by the gate's findings() and my wider pattern.

Notes, not restates (wording looser than the ledger; neither changes a count, time, figure or quotation):
- :247-248, "00:24:05" "replaced at once": lead.md 01:11:09 says "within minutes".
- :245-246 puts "00:11:52" in a message to verifier-I. lead.md 00:19:49 says the case study's draft held it too. The count of six distinct values holds either way.

Background processes: none of mine is running; every command ran in the foreground and has finished. My scripts and their outputs stay in <scratch>/r6-vI/; my clone is clean at 8a2a1d7.

For: the lead, the archive
