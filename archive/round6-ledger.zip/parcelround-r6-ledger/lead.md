# Round 6 - the lead's ledger

Append only. Each heading's time is taken from `date`.

## 2026-10-02 17:07:40 -0700 - the round opens: the plan approved, P0 landed on round6 at a5c0494

Measured:
- The plan of record, draft 3, lives in the HonestHarness folder at Rounds/ParcelRound-R6/PLAN.md. It went past a verifier twice: 9 material defects found on draft 1, and 10 on draft 2, all accepted.
- Logan approved it through the question tool, verbatim: "Approve; P0 verifier rechecks (Recommended)". Beside it: "Adopt B9 (Recommended)", "Allow S2 with R5 (Recommended)", "Allow S3 with the test (Recommended)". Earlier: "Everything practised (Recommended)", "Restore safeguards (Recommended)", "Sonnet / Opus (Recommended)", "Adoption file + gate (Recommended)".
- round6 was cut from round5-case-study (49a9266) in a worktree at parcelround-worktrees/P0. ParcelRound's main checkout stays on main.
- P0 is three commits:
  - 9350729: case study 5's postscript;
  - ee51756: ADOPTION.md (113 rows), tools/check_method.py, archive/round6-practice-survey.md;
  - a5c0494: METHOD.md's preamble, the README table, .gitignore.
- At a5c0494, in the worktree: `python tools/check_method.py` gives 10 of 10 checks, commit messages included; `--control` catches 11 of 11.
- Every file is LF in the index and the working tree.

Believed:
- Nothing in METHOD.md outside its preamble changed. The gate's checks 8 and 9 hold the sections and the quoted passages; P0's verifier is to confirm it.

For: verifier-P0, then every parcel

## 2026-10-02 17:08:06 -0700 - verifier-P0 dispatched on round6 at a5c0494

Measured:
- verifier-P0 runs on Opus, per the plan. It works from its own fresh clone of ParcelRound, detached at a5c0494, and never writes in ParcelRound or its worktrees.
- Its list: the gate (its own faults for every check; the stated limits tested by faults built to evade them), ADOPTION.md against draft 3, case study 5's postscript, the preamble, README and .gitignore, the survey, privacy across tree and history, draft 3's answers to the plan verifier's second check (Logan's condition on the approval), and anything else.
- READY standard: every item held by a gate, or by a check the verifier ran itself, or stated as a limit by the behaviour it concedes, with a fault built to evade the gates landing inside it.

Believed: nothing yet.

For: verifier-P0

## 2026-10-02 17:44:01 -0700 - verifier-P0 says NOT READY on a5c0494: six defects, all accepted; the rulings

Measured:
- verifier-P0's report came back NOT READY, with six defects (D1-D6). Its faults, scripts and outputs are in its scratch directory. Its ledger file has three entries (17:20:54, 17:34:34, 17:35:41).
- I re-read each defect at its source before ruling:
  - D1: all 35 `METHOD.md:N` cells in ADOPTION.md are right at 49a9266, and 14 lines early at a5c0494. I printed each line at 49a9266; each is the rule its row names.
  - D3: the preamble says a cited time may be "in its round's ledger". The gate reads only the ledger's entry headings.
  - D6: METHOD.md is identical at 8767e23 and 49a9266 (no commit between them touches it), so `M:n` in the briefs is 49a9266's numbering too.
- The other findings I read in its fault outputs. Of 84 faults, 47 were caught. Of the 37 that passed, 9 land inside a stated limit, 3 are outside the gate's claimed scope, and 25 are outside every stated limit. 5 more came from separate runs, for 30.

Rulings (all accepted):
- D1, a wrong answer. Each line reference in ADOPTION.md is pinned: "at `49a9266`".
- D2. Each class is fixed in the gate by the behaviour it concedes, not by adding spellings; what remains is stated in the docstring the same way. The classes:
  - paths in commit messages;
  - every blob in HEAD's history read, not only the working tree;
  - citations and links read across line breaks;
  - every section mark in the METHOD-family files read, not three spellings;
  - links resolved by exact name;
  - path forms;
  - files the gate cannot read fail instead of being skipped;
  - nested archives opened;
  - the path concession pinned to the archives it names;
  - percent-encoded addresses and file names read;
  - a named citation must identify one item;
  - a citation naming no case study fails;
  - B, R and S rows held;
  - all of loganw.dev's patterns on ParcelRound held;
  - HTML comments removed before the presence checks.
- D3 and D4. Each sentence is restated.
  - ee51756's message is restated in the next commit's message, not rewritten: main's history is a record too, and the record cites a5c0494 and its parents.
- D5. Recorded as a known limit of history: at 9350729 the postscript's link to ADOPTION.md dangles, and it resolves from ee51756 on.
- D6.
  - Every `M:n` in the briefs is labelled at 49a9266.
  - The absolute paths leave the ledger. Briefs and README name places relative to two roots that each dispatch message defines.
  - The gate's path concession covers only the archives it names, so round 6's archive is held to no paths. This is stricter than the plan, not looser.
- For Logan:
  - B3's and B16's verbatim words, published for the first time in the survey;
  - the author fields, as the plan records.

Believed:
- None of D2's gaps is live today: verifier-P0's history scan finds only the known round-4 exception. The fixes matter for the parcels' commits and for the archive.

For: verifier-P0 (the re-check), every parcel (dispatch waits on it)

## 2026-10-02 18:19:49 -0700 - P0 fixed at e9154be on round6; sent to verifier-P0 for its re-check

Measured:
- e9154be is round6's tip, with parent a5c0494. It changes four files:
  - tools/check_method.py;
  - ADOPTION.md;
  - METHOD.md: the preamble's Adoption paragraph, three lines, line count unchanged, so `M:n` + 14 still holds;
  - .gitignore, which gains `__pycache__/`.
- At e9154be in the P0 worktree, the gate holds 10 of 10 and `--control` catches 26 of 26. No scratch repository is left behind.
- 125 faults were run in a scratch clone of the same tree: verifier-P0's 84, its 5 separate runs rebuilt, and 36 of the lead's. 108 were caught. Of the 17 that pass:
  - 12 land inside a stated limit: right minute and wrong event; a wrong status; a wrong existing heading; a negated clause; a HonestFramework passage rewrapped; an address spelled out; one split by a line break; "the" as a named phrase; a citation inside code; an author field; a tag; another branch.
  - 5 are correct text: an anchor that exists; a percent-encoded link that resolves; a URL that is not a path; a placeholder; an ignored file.
  - No failure line the gate printed holds a path or a disallowed address.
- One rule is relaxed, with its evidence. A citation's time now resolves against the archived ledger's Markdown, entry bodies included, not its entry headings alone.
  - METHOD.md's own `[CASE-STUDY-2, 11:06; 11:47; 12:57]` needs it: 11:47 is when round 2's suite started, written in the body of the 11:48 entry (round2-ledger.zip, lead.md:258).
  - The a5c0494 gate passed that citation only through a leak. Its single-line reader did not strip case study 2's own wrapped citation of 11:47, so that time counted as the case study's text.
  - The preamble's first bullet, "or in its round's ledger archived beside it", is therefore unchanged, and now true. This reverses the 17:44:01 ruling to restate it.
- The lead found three more, outside verifier-P0's list:
  - the a5c0494 gate printed what it refused whenever a file's or member's name held it. Fixed, with a control;
  - its commit-message control left a scratch repository in the system's temp directory on every run. Four were found, from the lead's runs and verifier-P0's, and removed;
  - its comment called HonestFramework's quotations verbatim. Read at 65447fd, they are close: a word's case changed, one split in two. Restated.
- The ledger, changed before any dispatch:
  - The README and briefs hold no absolute path, scanned with the gate's own patterns.
  - Each brief labels `M:n` at 49a9266, and P1's and P3's wording is corrected.
  - _common.md gains "Places, and no absolute paths", and two notes on the gate: brackets in METHOD.md are citations, and a bare section sign is METHOD.md's.
  - verifier-P0 read the earlier README; this entry records the change.
- PLAN.md gains a dated note, "After approval: verifier-P0's findings", and its "Not listed" sentence a correction.

Believed:
- Every class verifier-P0 found is held, or stated by the behaviour it concedes. Its re-check, with faults of its own choosing, is what shows it.

For: verifier-P0 (the re-check), every parcel

## 2026-10-02 18:27:12 -0700 - Logan: the name HonestHarness may stay in the published ledger

Measured:
- Logan, in chat, verbatim: "HonestHarness is fine to leave in, it will be the public repo once work starts on it."
- The question it answers was raised at 18:2x in the lead's status to him: lead.md's 17:07:40 entry names the HonestHarness folder, a name in no public repository yet.

Decided: the name stays wherever it appears in this ledger. Nothing else about the archive changes.

For: anyone archiving this ledger

## 2026-10-02 18:27:26 -0700 - correction to the 18:27:12 entry: its "18:2x" was typed, not read

Measured:
- The 18:27:12 entry says the question was raised "at 18:2x". That time was typed, against this ledger's first rule.
- The clock bounds it instead: the lead's status went to Logan after the lead's clock reading of 18:23:35, and before 18:27:12.

For: anyone reading the 18:27:12 entry

## 2026-10-02 18:43:31 -0700 - verifier-P0 says NOT READY on e9154be: a regression in the path pattern, a 29th pattern, and gaps stated by instance; all accepted

Measured:
- verifier-P0's re-check of e9154be is in its file at 18:38:25. The verdict is NOT READY.
  - D1 and D3 to D6 are answered.
  - The relaxation was attacked and held. It widens the minutes a made-up time can name: round 2 from 14.2% to 16.5%; round 3 from 9.9% to 10.9%; round 4 from 13.6% to 16.3%; round 5 from 3.9% to 4.7%. Round 5 gains 01:24 from a ratio, which is wider than the stated limit says.
- Re-read at the source by the lead:
  - **R1, the regression, is confirmed by the code.** e9154be's path pattern put a lookbehind before its `/<letter>/users/` shape. The a5c0494 pattern had none there, so a profile path behind any prefix (`/mnt`, `/cygdrive`, `/host_mnt` and the like) passed at e9154be and was caught at a5c0494. The lookbehind was added for URLs such as `github.com/users/...`, which that shape could not match in any case.
  - **The 29th pattern is confirmed.** loganw.dev at 43c36a2 runs every relations.json edge through facts.prose (mapgen.py:189; build.py:3313). Its one ParcelRound edge, edges[10] `(P2 moves atlas-film)` on CASE-STUDY-4.md, matches once at round6's tip. The relations.json node for ParcelRound carries no pattern. The lead's AST extraction read calls with literal arguments, so it could not see a pattern held as data.

Rulings, all accepted:
- **R1 is a regression; it is fixed.** Each shape is read where it can occur, with a control for a prefixed path.
  - The drive-letter mount shape takes no lookbehind.
  - Backslash shapes take none either, since URLs use no backslashes. This covers WSL's home over UNC.
  - Only the POSIX home shapes keep a lookbehind, against a host name.
  - "Documents and Settings" is added.
- **R2.** Each class is closed where that is a mechanism, and otherwise stated in the docstring by the behaviour it concedes, not by its instances (CS4 obs 21):
  - links:
    - link text holding one level of brackets;
    - angle-bracket targets;
    - definitions with the target on the next line;
    - in a repository, a target must be in the index, so an untracked or ignored target fails;
  - citations:
    - an escaped bracket is read;
    - a bracket after `]`, or before `[`, is skipped only when the file defines its label;
  - anchors:
    - every file:line anywhere in ADOPTION.md must name a commit;
    - in a repository, that commit must be in HEAD's history;
  - refs:
    - section numbers in lists joined by "and", "through", "&" and the like, in any case;
    - bracketed marks in README and ADOPTION.md are read;
  - readme: code spans are removed before links are looked for;
  - quoted: the 29th pattern;
  - privacy:
    - invisible format characters are removed before scanning;
    - zip archive and member comments, and gzip header names and comments, are read;
    - the index's staged contents are read.

  Stated, not closed:
  - encodings beyond percent-escapes, entities and NFKC, such as base64 and quoted-printable;
  - citations in other shapes;
  - links in other syntaxes;
  - a SHA that names no commit, outside a repository.
- **R3.** Each sentence is restated:
  - the gate's docstring;
  - the path pattern's comment;
  - PLAN.md's note, which says "all 28";
  - e9154be's "all 28", in the next commit's message.

Believed:
- Both passes found classes outside the stated limits because the limits were written as lists of what had been found. Written by behaviour, a new spelling of a stated class lands inside it, which is the converge standard (CS4 obs 15).

For: verifier-P0 (its third pass), every parcel (dispatch still waits)

## 2026-10-02 18:58:54 -0700 - P0 third pass at 55e8a15 on round6; sent to verifier-P0 with the converge standard

Measured:
- 55e8a15 is round6's tip, with parent e9154be. It changes tools/check_method.py only. Its message gives each change, R1 to R3.
- At 55e8a15 in the P0 worktree, the gate holds 10 of 10 and `--control` catches 42 of 42. Sixteen of those controls are new, one per new code path. No scratch repository is left behind.
- Faults run in a scratch clone of the same tree:
  - **The 125 of the second pass**: 108 caught, as before. The 17 that pass are 12 inside stated limits and 5 correct texts.
  - **verifier-P0's 42 faults built against e9154be**: 35 caught. Of the 7 that pass:
    - 5 land inside limits the docstring now states: a citation as a link's text; a ratio's minute; a one-letter phrase that opens many items; base64; quoted-printable.
    - 1 is a commit that names no commit, built in a copy without `.git`, which is inside "outside a repository, a commit is not looked up". In a repository it fails; a control holds that.
    - 1 planted nothing: Python's GzipFile writes only a basename into the header on Windows, so the header held "notes.md". A hand-built header holding a path and an address fails check 10 on both.
- PLAN.md's two "all 28" sentences are restated as 29, with where each came from.

Believed:
- Every class verifier-P0 has named is now held, or stated by the behaviour it concedes. Whether a new spelling of a stated class lands inside its statement is what the third pass tests.

For: verifier-P0 (its third pass), every parcel (dispatch waits on it)

## 2026-10-02 19:25:28 -0700 - verifier-P0 says NOT READY, narrowly, on 55e8a15: four faults outside every statement; all accepted

Measured:
- verifier-P0 at 19:23:30. Its 84 faults and its second pass (gzip rebuilt) are each caught or inside a stated limit, in tree copies and in repository clones.
- Four classes land outside every statement:
  1. **A regression, the last shape of R1.** A POSIX home after another path segment (`/var/home`, `/usr/home`, `/Volumes/<disk>/Users`) passes. a5c0494 caught it. The lookbehind excludes any word character, not only a host name, against what its own comment says.
  2. **A citation on a definition-shaped line is never read.** The whole line is blanked as a link definition.
  3. **A commit spelled other than "at `sha`" is not looked up**, against check 4's "every commit ADOPTION.md names".
  4. **ADOPTION.md names cft-fp256's `4190a47` across a line break.** Reflowed onto one line, check 4 would refuse a correct file.

Rulings, all accepted:
1. The two forward-slash home shapes take no lookbehind. A match is excused only inside a URL with a host: a token that begins scheme://host, or a dotted host name. file:///, PATH lists and every other prefix are caught.
2. Only a definition's own label, target and title are blanked. The rest of its line, and a footnote's text, are read for citations.
3. Every commit in backticks in ADOPTION.md is looked up in a repository, whatever word precedes it.
4. Another repository's pin is declared once, in FOREIGN_COMMITS (`4190a47`, cft-fp256's public docs). An entry no longer named fails as stale. Check 4's claim is restated to match.

Each gets a control.

For: verifier-P0 (its fourth pass), every parcel (dispatch waits on it)

## 2026-10-02 19:41:41 -0700 - P0 fourth pass at 186e7ab on round6; sent to verifier-P0

Measured:
- 186e7ab is round6's tip, with parent 55e8a15. It changes tools/check_method.py only; its message gives each of the four fixes.
- At 186e7ab in the P0 worktree, the gate holds 10 of 10 and `--control` catches 47 of 47. Five controls are new: a home after another path segment; a citation in a footnote's text; a citation on a definition-shaped line; a declared foreign pin no longer named; a commit written without "at" (in a repository).
- The path pattern was run against 21 cases: verifier-P0's named shapes, plus URLs it must excuse. All 21 behave as intended. A relative path through a directory named home is caught, which the gate accepts.
- verifier-P0's suites, run by the lead against a scratch commit of the same tree:
  - its 84: 76 caught, the 8 inside stated limits;
  - its third pass, 154 runs: 125 caught.
  - Every run that passes is inside a stated limit, or a commit check in a tree copy (stated). The one exception is its reflowed foreign pin, a correct file, which now passes as it should.

For: verifier-P0 (its fourth pass), every parcel

## 2026-10-02 21:05:47 -0700 - Logan: the gate states its threat model, and verifier-P0's fourth pass is the last on it

Measured:
- Logan, in chat, verbatim: "Yes, add the threat model and make that the last pass". He was answering the lead's recommendation, which the lead put as: make verifier-P0's fourth pass the last on the gate; add a threat-model paragraph to the docstring; rule anything outside it out of scope; spend the verification effort on content in wave 1.
- The lead's assessment it rested on, given to Logan in chat:
  - The first pass, and the regression the second found, caught real drift and privacy problems.
  - The third pass's findings were mostly adversarial shapes no honest agent produces.
  - Three passes cost about 1.38 M subagent tokens, and the gate grew from 712 to 1,563 lines.

Decided:
- A threat-model paragraph goes into the gate's docstring, in a docstring-only commit. verifier-P0 checks it within its fourth pass, which is still running.
- A fault outside the threat model is out of scope, not a defect.
- A defect inside it, if the fourth pass finds one, is fixed. verifier-P0 is asked only to confirm that fix (a scoped re-check, CS2#25), not to run a fifth pass.

For: verifier-P0, every verifier of wave 1 (content is theirs)

## 2026-10-02 21:11:40 -0700 - verifier-P0's last pass: READY on 186e7ab, NOT READY on 33fb047 for one defect inside the threat model; accepted

Measured:
- verifier-P0, at 21:06:06 and 21:10:30:
  - **186e7ab is READY.** Its four third-pass defects are closed. Its 84 faults, its third-pass suite and 24 new faults are each caught, inside a stated limit, or out of the threat model.
  - **33fb047 is docstring only**, which it confirmed by comparing syntax trees.
  - **One defect at 33fb047.** The threat model's first bullet claims the gate guards against a line number going stale. Check 4 reads file:line only in ADOPTION.md, so `METHOD.md:363` with no commit passes in templates/brief.md, README.md and METHOD.md's prose. Failure: P5 writes a METHOD.md line number into a template after wave 1 has moved the lines. This is D1's class.

Ruling, accepted:
- Fixed, not scoped down. Check 4 reads file:line in METHOD.md, README.md and templates/ as it does in ADOPTION.md: a line number needs a backticked commit in its line or cell.
- In a repository, a commit beside a line number is looked up, unless FOREIGN_COMMITS declares it.
- The case studies and the archive are records that do not change, so they are not read; the docstring says so.
- A control holds a template line number with no commit.
- verifier-P0 is asked to confirm this fix only, a scoped re-check, not a fifth pass (Logan, 21:05:47).

For: verifier-P0 (the scoped re-check), P5 (its templates)

## 2026-10-02 21:17:22 -0700 - Logan: push when the round is finished; then set up HonestHarness, public, and prepare its first round

Measured:
- Logan, in chat, verbatim: "You are clear to push once you finish up the round and then prep for the first round on HonestHarness after (You may also setup the HonestHarness repo at that point as well, public is fine, clear to push there as well)".

Decided (standing rules carried, B9):
- **ParcelRound.** Only main is pushed, and only after the round finishes: every wave merged and verified; the case study, ADOPTION.md and the archive written and verified; main fast-forwarded to round6's verified tip. Never `--all`; no other branch, no tags.
- **HonestHarness.** It becomes a public GitHub repository after the round, with the same privacy pass first: no absolute path, personal address or token in any file or commit. Its first round is prepared after that; preparing it is not running it.
- **Still held for Logan:** deleting round 5's ledger working copy and its worktree. This message does not cover them.

For: anyone reading the round's end

## 2026-10-02 21:19:10 -0700 - P0 is READY at 2e34bd1; three nits merge as known limits; wave 1 is cut and dispatched

Measured:
- verifier-P0, scoped re-check at 21:18:33: READY on 2e34bd1. The defect of 21:10:30 is closed. By syntax tree, only anchors() and PLANTS changed. Gate 10 of 10, controls 48 of 48.
- Over P0 it ran one first pass, three re-checks and one scoped re-check. Logan made the fourth pass the last (21:05:47).

Known limits, recorded under the send-back rule (none is a regression or a wrong answer). Each is fixed in the lead's end-of-round commit, which goes past the integration verifier:
1. A made-up commit beside a line number outside ADOPTION.md fails with a message that names ADOPTION.md, the wrong file.
2. A host and port in prose (`localhost:8080`) in METHOD.md, README.md or a template reads as a line number with no commit. The failure is loud, and backticks avoid it. _common.md and P5's brief say so.
3. The docstring says each foreign pin must still be "named in ADOPTION.md". The code also counts a pin named beside a line number in another file.

Decided:
- Wave 1 is cut from round6 at 2e34bd1: worktrees P1 to P4 on branches r6-p1 to r6-p4, and scratch directories <scratch>/r6-P1 to r6-P4.
- The four parcels are dispatched at once on Sonnet, phase 1 only: read, intent echo, a test escalation to main, design, stop.
- Each agent's model is read from its transcript, not from this dispatch.
- Each dispatch message defines <repos> and <scratch>; the ledger holds neither.

For: P1, P2, P3, P4

## 2026-10-02 21:20:12 -0700 - wave 1 dispatched: P1 to P4, phase 1, on Sonnet

Measured:
- P1 (METHOD.md sections 1-3), P2 (4), P3 (5-6) and P4 (7-8) were dispatched at once, each with its worktree checked at 2e34bd1 and its gate at 10 of 10 beforehand.
- Each dispatch message defines <repos> and <scratch> and names the plan, the ledger, the worktree and the scratch directory. It asks for phase 1 only: read, intent echo, a test escalation `<P>: channel test` to main, design, stop.

For: P1, P2, P3, P4

## 2026-10-02 21:21:12 -0700 - a finding about the templates (P5's): angle-bracket placeholders render as nothing on GitHub; P5's brief drafted

Measured:
- GitHub's markdown API (api.github.com/markdown, mode markdown), given templates/brief.md's placeholder shapes:
  - `**<P2>**` rendered as empty bold;
  - the paragraph placeholder `<One paragraph on what the project is…>` as an empty paragraph;
  - a list-item placeholder as an empty bullet.
- Placeholders in backticks rendered.
- So the templates as GitHub shows them lose their guidance. This is a defect older than this round. The raw files read correctly.

Decided:
- briefs/P5.md is drafted for wave 2. Besides compiling the templates from the merged METHOD.md, it asks P5 to make every placeholder render and to check that through the same API.
- It is dispatched once wave 1 has merged, with its base commit named then.

For: P5, verifier-P5

## 2026-10-02 21:35:40 -0700 - P3's test escalation received

Measured: "P3: channel test" reached the lead as a runtime message (SendMessage to main), delivered into the lead's conversation. This entry is the lead's record of receipt (S3).

For: P3

## 2026-10-02 21:38:23 -0700 - P1's test escalation received

Measured: "P1: channel test" reached the lead as a runtime message (SendMessage to main), delivered into the lead's conversation. This entry is the lead's record of receipt (S3).

For: P1

## 2026-10-02 21:38:47 -0700 - P4's test escalation received

Measured: "P4: channel test" reached the lead as a runtime message (SendMessage to main), delivered into the lead's conversation. This entry is the lead's record of receipt (S3).

For: P4

## 2026-10-02 21:40:37 -0700 - P2's test escalation received; all four channels shown to work

Measured:
- "P2: channel test" reached the lead as a runtime message (SendMessage to main).
- All four test escalations have now arrived, between 21:35:40 and this entry. Each was delivered into the lead's conversation, with no watch armed.
- S3's condition holds: the channel is watched to work, and this record says how the lead learned of each.

For: P1, P2, P3, P4

## 2026-10-02 22:00:23 -0700 - P4's design reviewed; its brief errors confirmed; a lead decision on rules that rest on practice

Measured:
- P4's phase 1 is in its file: an echo, a channel test, a design at 21:57:57, and drafts that pass the gate in a scratch copy.
- Its brief errors, each checked at the source:
  - B4's full sentence is at VALIDATION.md:16165 (15842 holds the shorter one).
  - "Four of five rounds" is rounds 2 to 5 in the case studies.
  - CS5#10's incident names watch loops and servers, not clones.
  - CS3#1's proposal gives the fixer "the parcel's final report as well as its ledger file and worktree", with no word of "its brief". P4's brief added that; it was the lead's error.
- P4 grades each rule by its evidence: a break, a catch, or a practice.

Decided:
- **P4's defaults hold**, D1 to D7:
  - D1: the case study stays among the records;
  - D2: clones are left out;
  - D3: CS3#1 as drafted;
  - D4: no batched-merge relaxation;
  - D5: B8 and B9 written as practice, saying so;
  - D6: no last-commit exception. This round complies instead: its archive commit gets a scoped verifier check before main moves;
  - D7: a cft-fp256 source is a pinned inline link, with its commit in backticks beside any file:line.
- **Rules that rest on practice.** METHOD.md's first sentence says "Every rule here is here because something broke without it". Several adopted rows (B8, B9, S4, B10, B14) rest on practice, not on a break. Under the owner's send-back rule, a sentence that claims more than is true is restated at the merge.
  - Each parcel writes such a rule's evidence as it is, saying when no break is recorded, as P4 does.
  - The lead restates the first sentence in its end-of-round commit, which the integration verifier checks.
- "Go" for every parcel waits until all four designs are in, so that conventions such as D7 and the evidence wording are set once for all.

For: P4, and P1 to P3 on the shared conventions

## 2026-10-02 22:02:51 -0700 - P2's design reviewed; its questions answered; P5's brief corrected

Measured:
- P2's phase 1 is in its file: an echo, a channel test, a design at 21:59:08, and a correction at 22:00:32 taking P4's link form.
- Its drafts pass the gate in a scratch copy (10 of 10; `--control` 48 of 48), every change inside section 4. R2's sentence is byte-identical.
- Its findings, checked:
  - **P5's brief said S1-S3 "replace" the urgent/ text.** Section 4 keeps the file channel as an allowed means, so "replace" would have P5 delete rules METHOD.md still states. Corrected in briefs/P5.md to "restate", with the reason.
  - **README step 3** ("the only way to correct a brief after dispatch") holds only in substance once a message may carry a correction, entry first. README is the lead's, restated in its end-of-round commit.
  - **Section 4's "a fixed absolute path"** is no longer this round's practice (roots defined in each dispatch, for the published ledger). No row covers it, so it stays. It is a proposal for case study 6.

Decided, on P2's questions:
1. The new `###` "Escalation: one rule, whatever carries it": yes.
2. Block C's verifier parenthetical: keep.
3. Keep implicit that a lead may watch the escalation channel alone. Saying it outright adopts the part of CS3#6 that is pending.
4. B15's two additions: keep. "(or with the round's other records, where there is none)" rests on cft-fp256's practice in the survey's B15.
5. README step 3: the lead's.
6. P5: "restate", done.
7. "From one source" for S2: leave out; no row has it.

"Go" waits for P1's and P3's designs.

For: P2, P5

## 2026-10-02 22:06:22 -0700 - P3's finding on the gate: a control goes dead once a parcel cites a cft-fp256 line; the lead fixes the control before "go"

Measured:
- P3, by message, with its entry at 22:05:39: a sentence in P4's link form (a file:line with `4190a47` beside it) in METHOD.md leaves the gate at 10 of 10 but takes `--control` to 47 of 48.
- The control "a declared foreign pin no longer named" removes `4190a47` from ADOPTION.md only. Check 4 rightly counts the pin as named where it sits beside a line number, so that control cannot fail. Every parcel citing cft-fp256 lines in that form would trigger it, P2, P3 and P4 among them.

Decided (neither of P3's options):
- Living with a control that cannot fail leaves a dead control in place. Avoiding the file:line shape leaves those lines unchecked.
- The lead fixes the control instead. It declares, in-process, a pin that nothing names, and restores the declaration after.
- The same commit fixes known limits 1 and 3 of 21:19:10: the message for a commit beside a line number names its own file, and the docstring says "named in a file check 4 reads".
- verifier-P0 confirms that fix only, in a scoped re-check.
- Every parcel's branch is fast-forwarded to the fixed tip before "go". No parcel has committed, so each worktree is clean.
- P4's link form stays the form for every parcel.

For: P1, P2, P3, P4, verifier-P0

## 2026-10-02 22:09:39 -0700 - the control fix at 1dc5ed4 on round6; to verifier-P0, scoped; P1's design reviewed

Measured:
- 1dc5ed4, parent 2e34bd1, changes tools/check_method.py only.
- P3's finding, reproduced at 2e34bd1: one sentence in METHOD.md citing VALIDATION.md:16165 beside `4190a47` gives the gate 10 of 10 but `--control` 47 of 48. With 1dc5ed4's gate on the same copy: 48 of 48.
- At 1dc5ed4 itself: 10 of 10, and 48 of 48.
- P1's phase 1 is in its file: 15 rows, each graded by its evidence. The drafts pass the gate in a scratch clone (10 of 10; 48 of 48). The quoted passages are byte-identical.
- P1's brief errors, checked:
  - "under no proposal and no decision" was never measured, since the survey read no transcripts;
  - section 6 says "what else is there", not "anything else";
  - CS4#1's case supports "need not wait for its fixes", not "need not wait".

Decided, on P1's open rulings:
- R1: keep the clause giving round 1's twelve corrections from five parcels. The existing "highest-yield" sentence cites nothing, and the invariant wants its incident.
- CS4#1: P1's narrower wording.
- The new `###` headings are named in ADOPTION.md by the lead, after the merge.
- R1's count is stated with its date, "37, as counted on 2026-10-02". Step 6 is still adding briefs.

For: verifier-P0, P1, and every parcel on the controls

## 2026-10-02 22:15:07 -0700 - P3's design reviewed; all four designs approved; the conventions for "go"

Measured:
- P3's phase 1 is in its file: an echo, a channel test, the gate finding at 22:05:39, a design at 22:10:02, and a B3 correction at 22:13:38.
- Its drafts: 7 hunks inside sections 5-6, 180 lines added and 5 removed, the five quoted passages each present once.
- With 1dc5ed4's gate: 10 of 10, and 48 of 48.
- Its brief errors, checked:
  - "substantial" is in no case study;
  - CS3#7's own incident is round 3's (CS3:373-379), and "every fix" needs round 4's;
  - the restate clause's wording is not public; VALIDATION.md has "claims too much" at 15647 and 16164;
  - 15274 is the rule's first public application, not its reason, so B3 cites practice and the owner's word, as 22:00:23 allows;
  - CS3#9 keeps "when parcels write documents".
- P3 met the environment trap logged in harness note 36: a Git Bash grep crashed and left grep.exe.stackdump in its worktree. It removed the dump and disclosed it.

Decided, on P3's five:
1. Its two new `###`: keep.
2. The code-half bullet with rounds 2-5: keep. The lead trims any duplicate of P4's section 7 at integration.
3. B3's "it concedes no wrong answer": keep.
4. CS4#16's "it reads each limit the work states": keep.
5. Who classes a finding: not written.

Conventions for every parcel's "go":
- **Base.** Each branch is fast-forwarded to round6 at 1dc5ed4, once verifier-P0 confirms it.
- **Sources.** A cft-fp256 source uses P4's link form: the file:line in the link text, with `4190a47` beside it in backticks.
- **Evidence.** A rule's evidence is written as it is. Where no break is recorded, the text says so.
- **Blinding.** Each parcel reports its commit's SHA to the lead in its final message, not in its ledger file, until its verifier has reported. Verifiers get a copy that may hold planted faults, and the real tip stays out of the ledger until then.
- **Before committing**, remove any grep.exe.stackdump.

For: P1, P2, P3, P4

## 2026-10-02 22:16:42 -0700 - P0 READY at 1dc5ed4; every parcel's branch fast-forwarded to it; "go" sent to P1-P4

Measured:
- verifier-P0 at 22:16:02: READY on 1dc5ed4. The pin control is live with and without a cited pin; the undo leaves FOREIGN_COMMITS unchanged; nothing else changed behaviour.
- r6-p1 to r6-p4 were each clean, and each was fast-forwarded to round6 at 1dc5ed4.

Decided:
- Each parcel is resumed with "go", its own rulings (22:00:23, 22:02:51, 22:09:39, 22:15:07), and the conventions of 22:15:07.
- P4 also cuts B4's inferred cost sentence, which it offered first.

For: P1, P2, P3, P4

## 2026-10-02 22:23:50 -0700 - P3 reported; the lead audited its work; verifier-P3 dispatched on a copy that may hold planted faults

Measured:
- P3's phase 2 (its file, 22:22:15): 16 rows written, gate 10 of 10, `--control` 48 of 48, and its negative control named by the gate.
- The lead's audit (CS4#8):
  - P3's worktree is clean;
  - its branch is one commit ahead of 1dc5ed4 and changes METHOD.md only, 180 insertions and 5 deletions;
  - every hunk lies between sections 5 and 6's headings at its tip;
  - its trailer names Claude Sonnet 5.5.
  - P3's commit SHA is held out of the ledger until verifier-P3 reports.
- **Planted faults, step 1 of the three-commit protocol.**
  - verifier-P3 gets a copy of P3's work, a fresh repository detached at cd77587, with no remote, no branches and no route back to P3's own tip.
  - The copy may hold planted faults. Their key is kept outside every agent's reach; its SHA-256 is dab9f43738b06c848b605fa7d112be261c557ed2aaaef553cea86810271e8d81.
  - The key is revealed after verifier-P3 reports, step 3.

For: verifier-P3

## 2026-10-02 22:29:09 -0700 - P1 reported; audited; verifier-P1 dispatched on a copy that may hold planted faults. P2 reported.

Measured:
- **P1's phase 2** (its file, 22:27:10): 15 rows written, gate 10 of 10, `--control` 48 of 48, and its negative control named by the gate.
- **The lead's audit of P1:**
  - its worktree is clean;
  - its branch is one commit ahead of 1dc5ed4 and changes METHOD.md only (151 insertions, 1 deletion);
  - its 13 hunks lie before section 4's heading at its tip;
  - its trailer names Claude Sonnet 5.5;
  - its SHA is held out of the ledger.
- **Planted faults, step 1.**
  - verifier-P1 gets a copy of P1's work, a fresh repository detached at f6ab37e, with no remote and no branches.
  - The copy may hold planted faults. Their key's SHA-256 is c5e03caa7eeee7347584e0dae0edbed97212d3d0ee20cba92ee00b260bcc7502.
- **P2's phase 2** (its file, 22:28:32): 16 rows written in section 4, gate 10 of 10, `--control` 48 of 48, and its negative control named. Its integration notes are for the lead:
  - item 1's "re-arms" beside P1's "stop your own background work";
  - "working copy" in two senses, beside P4's cleanup bullet;
  - README step 3 and its new heading.

For: verifier-P1, the integration

## 2026-10-02 22:30:03 -0700 - P2 audited; verifier-P2 dispatched on a copy that may hold planted faults

Measured:
- **The lead's audit of P2:**
  - its worktree is clean;
  - its branch is one commit ahead of 1dc5ed4 and changes METHOD.md only (146 insertions, 10 deletions);
  - its 15 hunks lie between sections 4 and 5's headings at its tip;
  - its trailer names Claude Sonnet 5.5;
  - its SHA is held out of the ledger.
- **Planted faults, step 1.**
  - verifier-P2 gets a copy of P2's work, a fresh repository detached at 40df983, with no remote and no branches.
  - The copy may hold planted faults. Their key's SHA-256 is 35816d90b2c43c8df0f606660d1477b901de106800fb599852e6daf9f8659ff8.

For: verifier-P2

## 2026-10-02 22:35:59 -0700 - P4 reported; audited; verifier-P4 dispatched on a copy that may hold planted faults; all four parcels are in verification

Measured:
- **P4's phase 2** (its file, 22:34:20): 19 rows written, gate 10 of 10, `--control` 48 of 48, and its negative control named by the gate.
- **The lead's audit of P4:**
  - its worktree is clean;
  - its branch is one commit ahead of 1dc5ed4 and changes METHOD.md only (172 insertions);
  - its 10 hunks lie inside sections 7 and 8 at its tip;
  - its trailer names Claude Sonnet 5.5;
  - its SHA is held out of the ledger.
  - Its cleanup bullet says "worktrees", which settles P2's note on "working copy".
- **Planted faults, step 1.**
  - verifier-P4 gets a copy of P4's work, a fresh repository detached at db08fdc, with no remote and no branches.
  - The copy may hold planted faults. Their key's SHA-256 is 9b0a549f859e90c9cac8a64880db5098ccf8af1cd38de8edff86ee64d3bcc870.
- **Integration notes** gathered from all four reports:
  - S5 is written on three sides, P1 section 3, P3 section 6 and P4 section 7;
  - P3's code half and P4's all-round rule share incidents;
  - the evidence wordings differ between parcels;
  - P2's item-1 "re-arms";
  - the new headings, for ADOPTION.md;
  - README step 3.

For: verifier-P4, the integration

## 2026-10-02 22:53:58 -0700 - verifier-P3, verifier-P2 and verifier-P1 reported; their keys revealed and graded, 6 of 6; their findings ruled

Measured:
- **Planted faults, step 3.** Each key is now in this ledger at `keys/`, the bytes that were hashed; `sha256sum keys/*.json` gives the hashes logged at dispatch.
  - **verifier-P3** reported at 22:48:00 on cd77587 (key logged 22:23:50). The plants: S6's "the verifier re-runs from clean anything it doubts" made "may re-run", and "fixed five wrong answers" made "six". Its findings 1 and 2 are those two, each classed a wrong answer. **2 of 2 caught.** P3's real tip is 4ff28ca.
  - **verifier-P2** reported at 22:48:08 on 40df983 (key logged 22:30:03). The plants: "5 of 38" made "5 of 28", and CS5#3, pending, written as adopted at the archive paragraph's end. Its findings 1 and 2 are those two, each classed a wrong answer; its finding 4, the commit message's 146 insertions against 147, is the second plant's extra line (P2's real tip has 146). **2 of 2 caught.** P2's real tip is 3676786.
  - **verifier-P1** reported at 22:50:32 on f6ab37e (key logged 22:29:09). The plants: "twelve corrections" made "fifteen", and "need not wait for its fixes" made "need not wait for the verifier". Its findings 1 and 2 are those two, each classed a wrong answer. **2 of 2 caught.** P1's real tip is 03561a7.
  - Each of the three noticed that its two wrong answers were the only places where the copy differs from the parcel's own design, and reported them as real all the same.
- **Their other findings**, read by the lead at the parcels' real tips:
  1. P3, restate: `[CASE-STUDY-3, §6; 18:49; 20:01]`. The skip rule was caught by P7's send-back at 19:56 (CASE-STUDY-3.md:191); 20:01 is P2's send-back and the lead's ruling. The right row and the wrong minute, inside the gate's stated limit.
  2. P3, restate: "it concedes no wrong answer" is wider than its source, "none gives a wrong answer today" (docs/VALIDATION.md:15493-15494 at `4190a47`).
  3. P2, restate: "cft-fp256's later parcel briefs ... say only "append only"". The survey's line is in its row on the three read moments and cites one brief; its CS3#2 row has the stamp rule in every later brief.
  4. P1, restate: B13's "and the lead decided" is cited for three of the six rounds named, the audit, steps-5-and-6 and language rounds.
  5. P1, restate: CS4#7's "and judged READY". At 22:39 the verifiers judged READY, by the standard verifier-P1 had offered (CASE-STUDY-4.md:106).
  6. P1, a note the lead read and adds as a restate: B17's "each began with read-only agents". P1's own reading (P1.md, B17's source) says the cert round used one.
  7. P1, known limits: "(§5 says how a limit is stated, §6 how it is tested)" and "(§7)" point at text P3 and P4 bring. They are true once both merge; the integration checks it.
- **Gate notes:**
  - From all three: a citation whose observation number or section mark names an existing but wrong item passes. The docstring states that limit for minutes and phrases only: a limit stated by its instances (CASE-STUDY-4, obs 21).
  - verifier-P3: a HonestFramework passage copied without its bold passes check 9.
  - verifier-P1: METHOD.md's own brief-errors clause, negated, passes, since check 7 reads only the template's.
- **A note on P1's reading:** P1 checked the survey's rows at their sources, cft-fp256's gitignored round records and round 5's local ledger, and disclosed it. Nothing it wrote cites them except through the survey.

Decided:
- **No parcel goes back.** None of these findings is a wrong answer or a regression (B3), so the six restates are the lead's, at the merges. Each goes in its own commit after its merge, so the integration verifier can read it apart from the parcel's work.
- **The three gate notes go into the lead's end-of-round commit:**
  - the wrong-item limit stated by its behaviour, whatever form the citation takes;
  - the markup limit;
  - check 7's reach.
- **P5's brief gains verifier-P1's note on CS5#10:** no verifier template carries "stop your own background work" unless P5 adds it.

For: the integration, P5, the end-of-round commit

## 2026-10-02 22:57:23 -0700 - a lapse of the lead's: three keys revealed while verifier-P4 still worked; P1, P2 and P3 merged with the lead's restates

Measured:
- **The lapse.** The 22:53:58 entry revealed three keys, and the shapes of their plants, while verifier-P4 was still working on a copy built the same way. verifier-P4's file (22:54:53) shows it saw the entry appear. It records that its two findings were formed from the sources before that entry, and that it listed `keys/` by name only and opened nothing. Its grade will rest on that record.
- **The merges**, on round6 in P0's worktree, the gate 10 of 10 after each:
  - f307c02 merges P1 (03561a7); b8c57f3 is the lead's three restates (B13, CS4#7, B17);
  - 0b5e4aa merges P2 (3676786); 4b8ce96 is the lead's restate (the later cft-fp256 brief);
  - e8bfe28 merges P3 (4ff28ca); 012574b is the lead's two restates (19:56, "gives no wrong answer today").
- P5's brief gains the CS5#10 note: verifier.md carries "stop your own background work", naming §3.

Believed:
- **A proposal for the case study:** a round's keys are revealed once every verifier working on a planted copy has reported, not as each one reports. A key's shapes ("a figure transcribed wrong", "a rule narrowed") tell a verifier still working what to look for.

For: verifier-P4, the integration, the case study

## 2026-10-02 23:06:11 -0700 - verifier-P4 reported: 2 of 2 caught, 8 of 8 in the wave; the lead's D1 was a wrong answer, corrected by the lead; P4 merged next

Measured:
- **Planted faults, step 3.** verifier-P4 reported at 23:03:09 on db08fdc (key logged 22:35:59, now at `keys/key-db08fdc.json`, hash 9b0a549f…). The plants: the bold rule's "its merges and its records" cut to "its merges", and "the lead pushed eight commits" made "six". Its findings 1 and 2 are those two, each classed a wrong answer, and its file records both at 22:54:53, formed from the sources before the 22:53:58 entry appeared. **2 of 2 caught; across the wave, 8 of 8.** P4's real tip is d38fea1.
- **Its other findings**, read by the lead at d38fea1:
  1. **Wrong answer, the lead's.** "Its records are the project's record entries, its commit messages and the case study", with CASE-STUDY-5 obs 14 as the case study's incident, writes the second half of CS5#11 as adopted. CS5#11 is pending (ADOPTION.md:132); the survey has CS5#1 "carried to the case study by CS5#11" (archive/round6-practice-survey.md:155). P4 disclosed it as its brief error 10, and the lead ruled D1, "keep it", at 22:00:23. The ruling was wrong.
  2. **Restate, S4.** Its three conditions name "a gate" at the tip, so a round could move main without the full suite ever running there, which the staging-branch rule it relaxes never allowed (the bullet before it: "Every merge, and the full suite after each one").
  3. **Restate.** "A bare hash of a key longer than 64 bytes": the source says "a bare SHA-256" (docs/VALIDATION.md:15649 at `4190a47`). 64 bytes is SHA-256's block size.
  4. **Integration.** "From the agent cards" (text before this round) now sits beside P4's "read from each agent's transcript", and case study 3's cost section says the cards' figure is the final-context sum that P4's sentence rejects.
  5. **Integration pointers** "(§5)", "(§2)", "(§3)", "(§6)" and "is in §3" hold once all four parcels are merged; the integration verifier checks them.
  6. **Gate, a limit stated by its instances:** P4's link form writes the commit and the line twice, in the text and in the URL. Check 4 reads only the text's copy, so a URL naming another commit, file or line passes, and the docstring says only "not fetched".

Decided:
- **D1 is withdrawn, and the fix is the lead's.** P4 is not sent back: the wrong answer came from the lead's ruling, which P4 followed. At the merge the lead narrows "Its records" to the project's record entries and its commit messages, and removes the paragraph resting on CASE-STUDY-5 obs 14, since it supports only CS5#11. CS5#11 stays pending. This round practises its second half anyway (the integration verifier reads CASE-STUDY-6.md before main moves), which the case study records for a later round to weigh.
- **Restates at the merge**, each in the lead's commit after it:
  - S4's third condition becomes main moving only to a tip on which the full suite has run and which a verifier has passed;
  - "a bare SHA-256";
  - the cost bullet drops "from the agent cards" for the transcript measure P4 wrote below it.
- **The link limit goes into the gate's docstring, stated by behaviour:** a link's text and its URL are not compared. The gate does not compare them this round. Stating it is the converging choice the threat model allows; a check is a proposal for the case study.

For: the integration, the case study

## 2026-10-02 23:09:12 -0700 - P4 merged with the lead's corrections; the lead's integration and gate commits; P5 cut at 56df604 and dispatched

Measured, on round6, the gate 10 of 10 after each commit:
- 8f-merge: P4 (d38fea1) merged; 3083090 is the lead's correction of D1 and its three restates (S4's tip, "a bare SHA-256", the cost read from the transcripts).
- d27b656, the lead's integration of wave 1:
  - the preamble's first sentence: "except where a rule says it rests on practice or on the owner's word instead";
  - S5 stated once, in section 3, with section 7 pointing there;
  - section 4's item 1: "while it is still working";
  - README step 3: the ledger as the channel of record;
  - S4's paragraph rewrapped.
- 56df604, the lead's gate commit: a link's text and its URL are not compared, stated by behaviour. `--control` 49 of 49.
- P5's worktree is cut from round6 at 56df604, on branch r6-p5, clean.

Decided:
- P5 is dispatched on Sonnet, phase 1 only, as wave 1 was. Its base is 56df604, so the templates are compiled from METHOD.md as integrated.
- The 22:15:07 conventions hold for P5: its SHA goes in its final message, not its ledger file, until its verifier reports.

For: P5, the integration

## 2026-10-02 23:09:17 -0700 - correction to the previous entry: P4's merge is 72b0049

Measured:
- The previous entry's first bullet opens with "8f-merge", a placeholder the lead failed to fill. The merge of P4 (d38fea1) into round6 is 72b0049, per `git log --merges`.

For: the integration, the case study

## 2026-10-02 23:16:47 -0700 - ADOPTION.md's wave-1 rows adopted at fe58489; verifier-I dispatched on wave 1's integration while P5 designs; a lapse in the wave-1 verifier brief

Measured:
- fe58489 on round6: the sixty wave-1 rows of ADOPTION.md, 54 "to adopt" and 6 "to adopt in part", now say "adopted at" or "adopted in part at" the commit of the parcel that wrote each (P1 03561a7, P2 3676786, P3 4ff28ca, P4 d38fea1; both, where two parcels did). Eleven rows name the new subsection they sit under. Gate 10 of 10.
- **A lapse of the lead's, found while drafting the case study.** briefs/_verifier.md had the wave-1 verifiers read lead.md, not check the lead's rulings in it. P3 wrote §6's rule from round 3 that the lead's grants and rulings made after dispatch are on the verifier's list, and this round's own verifier brief lacked it. Two faulty rulings (D1 at 22:00:23; keeping "it concedes no wrong answer", P3's decision 3 at 22:15:07) were caught anyway, through the parcels' text, which is round 3's pattern again.

Decided:
- **verifier-I**, on Opus, starts now on wave 1's integration, round6 from 1dc5ed4 to fe58489: the merges made again, the lead's restates and its correction of D1, its integration commit, its two gate commits and its ADOPTION.md commit. Its brief is briefs/integration.md, which now puts the lead's rulings on its list as item 0.
- Its phase 2, on resume, covers P5's merge, the end-of-round commits and CASE-STUDY-6.md.
- verifier-P5's brief will carry the rulings item too.

For: verifier-I, verifier-P5, the case study

## 2026-10-02 23:21:14 -0700 - P5's test escalation received

Measured: "P5: channel test" reached the lead as a runtime message (SendMessage to main), delivered into the lead's conversation. This entry is the lead's record of receipt (S3).

For: P5

## 2026-10-02 23:21:34 -0700 - P5's echo matches its brief; a rule for verifier-P5: keys/ stays closed until it reports

Measured:
- P5's intent echo (23:21:00) restates its brief: the four templates compiled from METHOD.md at 56df604, guidance kept and marked, the round's changes (R1, S1 to S3, B15, the verifier template's additions, CS5#10's note), CS5#4 left pending, and the placeholders checked through GitHub's markdown API. Its controls add a template plant for each of checks 2, 4 and 5, and a placeholder check that must fail on 56df604.
- P5 read `keys/`, which holds wave 1's revealed keys and the shapes of their plants. An author knowing past plants' shapes does not touch a verifier's measure.

Decided:
- **verifier-P5's dispatch says: do not open `keys/` until you have reported.** It holds the shapes of wave 1's plants, and a verifier that knows them is told what to look for, as the 22:57:23 lapse showed.

For: verifier-P5

## 2026-10-02 23:53:44 -0700 - verifier-I's first phase: NOT READY on fe58489, nine restates of the lead's own work; fixed at 5c19906; corrections to this ledger

Measured:
- verifier-I's report (its file, 23:47:23 and 23:48:06): **NOT READY on fe58489**, with no wrong answer and no regression.
  - It remade the four merges with `git merge-tree`, and each tree is exact.
  - It ran the gate 10 of 10 at every commit from 1dc5ed4 to fe58489, and `--control` 49 of 49.
  - It matched the keys' hashes, found each plant's text absent from the parcels' real commits, and found the lead's audits held.
  - These restates were right: b8c57f3; 012574b; 3083090's D1 correction, S4 and "a bare SHA-256".
  - The 6c83960 check is real: its plant passes the gate at 012574b and fails at fe58489.
- **Its nine restates**, each re-read by the lead at its source:
  1. The preamble excepted rules that "say" they rest on practice; CS4#16 and CS4#21 do not say so, and neither cites a break.
  2. S5 in section 7 said "every claim a parcel writes"; section 3 and the row say a claim in a document.
  3. "Measured-or-believed" (4b8ce96) is in no line of the cited survey.
  4. 3083090's message and the 23:06:11 entry gave case study 3 as the reason to drop "from the agent cards". CASE-STUDY-3.md:543-548 says whether the cards show that figure "cannot be determined". The change stands on R3's row.
  5. fe58489's message and the 23:16:47 entry say 54 and 6. The rows were 53 "to adopt" and 7 "in part"; the 54th match was the statuses paragraph's own definition.
  6. ADOPTION.md credited every round-6 row to "Everything practised"; the R and S rows came by other answers, and B9, S2 and S3 by name.
  7. The quoted-passage limit was stated by its instance, emphasis. A copy differing in letter case or quotation marks passes too.
  8. Section 4's expiry sentence still re-armed any agent, the trigger of round 5's finished verifier.
  9. No entry names 6c83960, which carried the gate notes the 22:53:58 entry assigned to the end-of-round commit.
- **Its known limits:**
  - Section 7's two lists rendered as one, confirmed with a CommonMark parser.
  - README step 4 against the round branch's "a gate" after each merge.
  - "Adopted at" names a parcel's commit, whose text the lead later restated or corrected.
  - S1's and S3's second subsection.
  - CS3#12 adopted though D4 left out its relaxation.
- **Its notes:**
  - ruling 2 of 22:15:07's trim of duplicate incidents was not done;
  - "a bare SHA-256" is at VALIDATION.md line 15654, not 15649;
  - b8c57f3 credits 6569b39 to P1, who recorded no commit.

Decided:
- **Fixed at 5c19906, gate 10 of 10, `--control` 49 of 49:**
  - 1: the preamble covers a break, a catch made by the rule's practice, and rules that say they rest on practice or the owner's word; CS4#16 now says it rests on practice. CS4#21's evidence is a catch, which the preamble now covers.
  - 2: section 7 in section 3's words.
  - 3: the stamp rule, from the survey's CS3#2 row; "measured-or-believed" goes.
  - 6: the owner's words per row type.
  - 7: the limit stated by behaviour, a copy differing in anything but whitespace and emphasis.
  - 8: "for an agent still working".
  - The known limits: a line between section 7's lists (CommonMark now gives two lists); S1's and S3's second subsection named; CS3#12 adopted in part; ADOPTION.md says the lead's restates are in the ledger and the case study.
- **Corrections to this ledger**, each by this entry, not by an edit:
  - the 23:16:47 entry's "54 to adopt and 6 in part" is 53 and 7;
  - the 23:06:11 entry's reason for "from the agent cards" is R3's row, not case study 3;
  - its "VALIDATION.md:15649" for "a bare SHA-256" is line 15654, in the passage 15649 opens;
  - the gate notes of 22:53:58 went into **6c83960** (the wrong-item limit, check 7's reach, and the markup check with the 49th control) and **56df604** (the link limit), not into an end-of-round commit;
  - **6569b39** is the lead's own reading of the cert round's ledger, "main at 6569b39", not P1's.
- **Ruling 2 of 22:15:07 is revised; the duplicate incidents stay.** Section 5's bullet is the code half and section 7's list the evidence for the whole rule. Two incidents appear in both, round 2's 17:39 and round 5's obs 2: the same events cited for two rules. That is two citations, not a second source of truth. Trimming one would leave section 7's "in each of rounds 2 to 5" without its evidence. S5 was different: one rule stated twice.
- **README step 4 is a known limit for the owner.** Its words ("run the full suite after each one") are quoted by HonestFramework word for word, so changing them is the owner's call. METHOD.md's staging branch keeps the full suite after each merge. The round-branch shape runs a gate after each merge and the full suite at the tip before main moves.
- verifier-I is asked to re-check 5c19906, scoped to these findings, before its phase 2.

For: verifier-I, the case study, the owner (README step 4)

## 2026-10-03 00:11:29 -0700 - verifier-I's re-check: NOT READY on 5c19906, fixed at e5ce41e; P5's design reviewed and approved; a30aca5; r6-p5 fast-forwarded; "go"

Measured:
- **verifier-I's scoped re-check** (its file, 00:06:24): NOT READY on 5c19906. These held: findings 2, 3, 7 and 8, the known limits, the ledger corrections, and both rulings.
  - **Still open:**
    - the preamble's first sentence said "every" rule rests on a break or a catch, and its second admitted nine rules that rest on practice alone;
    - CS4#11 said nothing of what it rests on;
    - S6 rests on a cost, which neither sentence covered;
    - the S rows came under "Restore safeguards (Recommended)", which named S1, S4, S5 and S6 (PLAN.md's Departures answer), not under the plan's approval.
  - **Also found:**
    - CS3#12's "in part" against a definition that said "the part practised";
    - check 9's emphasis-free count read only the rendered text, so a copy without its bold inside a code fence passed;
    - 5c19906's headline claimed more than was true.
- **e5ce41e**, the lead's fix:
  - the preamble with its exceptions inside "every": a break, a catch, or, where the rule says so, practice that held, a cost, or the owner's word;
  - CS4#11 says it rests on practice and on the owner's word;
  - ADOPTION.md names "Restore safeguards" for the R rows and S1, S4, S5, S6;
  - "in part" covers a part a ruling kept;
  - the count reads the written text too, with a 50th control. 5c19906's gate passes the fenced copy and e5ce41e's fails it.

  Gate 10 of 10, `--control` 50 of 50. The Bash tool halved a heredoc's escaped newlines in the new control (harness note 36's trap again); the line was repaired by a script written with the file tool before the commit.
- **P5's design** (its file, 00:06:17 and 00:06:51):
  - every `(§n)` unit has a verbatim METHOD.md sentence in the section it names (230 units, by script);
  - every `(own)` unit is old template text;
  - drafts at 5c19906: gate 10 of 10, `--control` 49 of 49;
  - its placeholder check fails the 56df604 templates and a planted copy, and passes the drafts;
  - seven old sentences go where METHOD.md now contradicts them.
- **P5's findings, checked:**
  - "content is a verifier's main job" has no METHOD.md sentence behind it. The threat model is in the gate's docstring.
  - brief.md and verifier.md carry copies of quoted passages, which check 9 does not read. Harmless: the passages are held in METHOD.md and README.md.
  - **The lead's 21:21:12 measurement was on a shortened text.** The file's own paragraph placeholder renders, because its comma breaks the tag grammar; the regression-bullet placeholder does vanish. The finding stands, for fewer placeholders than that entry said.
  - only the staging branch is a round-2 rule, the round branch being S4 and long runs B4;
  - CS4#9's and CS3#10's template cells named templates whose agents do not hold those rules;
  - section 4's "usually share one scratch directory" disagreed with section 3. verifier-I found it too.
- **a30aca5**, the lead's, before P5 builds:
  - section 4 now reads "where agents in a round share a scratch directory (§3 gives each its own)";
  - CS4#9's cell names the ledger and the checklists, and CS3#10's the checklists.

  Gate 10 of 10.
- r6-p5 was clean and is fast-forwarded to a30aca5, round6's tip. Gate 10 of 10 there.

Decided, on P5's D1 to D9 (each its default):
- D1: build at a30aca5. P5 re-runs its source check there. Since its drafts, METHOD.md changed in three places: the preamble, CS4#11's last sentence, and section 4's scratch sentence.
- D2: keep the full size.
- D3: keep the `(§n)` / `(own)` / `(§n, own)` tags.
- D4: placeholders in code spans.
- D5: keep the two R2 deletions in verifier.md.
- D6: keep the ledger section in verifier.md.
- D7: "content is the main job" stays unwritten, and §6's content items stand. A gate's threat model is a proposal for case study 6.
- D8: carry nothing that no row sends to a template.
- D9: keep "send the test message when you start".

Corrections to this ledger, by this entry:
- the 23:54 entry's revised ruling 2 counts two shared incidents between sections 5 and 7. There are three: round 3's `[CASE-STUDY-3, §5]` too. The reason holds.
- the same entry lists 56df604's link limit among "the gate notes of 22:53:58". It was verifier-P4's, ruled at 23:06:11.

For: P5, verifier-I

## 2026-10-03 00:11:37 -0700 - correction to the previous entry: "the 23:54 entry" is the entry stamped 23:53:44

Measured: the previous entry's corrections name "the 23:54 entry". The entry they correct is stamped 23:53:44 (`grep -n "^## " lead.md`). The lead typed the time instead of reading it, the third typed value this round (after 18:2x and 8f-merge).

For: the case study

## 2026-10-03 00:19:49 -0700 - verifier-I's second re-check: NOT READY on a30aca5 on one phrase; fixed at 6975994; a fourth typed value

Measured:
- verifier-I (its file, 00:18:34) re-checked e5ce41e and a30aca5. Gate 10 of 10 at both, `--control` 50 of 50.
  - The 50th control is real: its plant passes 5c19906's gate and fails e5ce41e's.
  - The preamble now holds against all 156 bold-led blocks: every round-6 rule cites a break or a catch, or says what it rests on.
  - The §4 sentence and the two template cells hold.
- **Its one finding, a restate:** ADOPTION.md said "Restore safeguards (Recommended)" named the R rows. The plan (PLAN.md:547-549) has it name R1 and R2 and the four S rows. R3 to R5 are in the plan's table of safeguards.
- Fixed at the commit this heading names: "which named R1, R2 and those four (R3 to R5 are in the plan's table of safeguards, approved with it)". Gate 10 of 10.
- **A fourth typed value of the lead's:** its message to verifier-I named the correction entry "00:11:52", and so did the case study's draft. The entry is stamped 00:11:37. The draft is corrected. The message was not a record.

Decided:
- No third scoped re-check for this phrase alone: verifier-I's phase 2 reads ADOPTION.md again in full (its item 5).

For: verifier-I (phase 2), the case study

## 2026-10-03 00:23:24 -0700 - P5 reported; audited; verifier-P5 dispatched on a copy that may hold planted faults

Measured:
- **P5's phase 2** (its file, 00:21:56): the four templates compiled at a30aca5.
  - Gate 10 of 10, and `--control` 50 of 50.
  - Its negative control, three plants in templates/, fails at 7 of 10, each plant named.
  - The render check passes for all four files in both of GitHub's modes, and fails the 56df604 files and a planted copy.
  - Every `(§n)` unit has a verbatim sentence in a section it cites.
  - Every row-to-template pair ADOPTION.md names is carried, and none it doesn't.
- **The lead's audit of P5:**
  - its worktree is clean;
  - its branch is one commit ahead of a30aca5 and changes the four templates only (595 insertions, 189 deletions);
  - its trailer names Claude Sonnet 5.5;
  - its SHA is held out of the ledger.
- **Planted faults, step 1.**
  - verifier-P5 gets a copy of P5's work, a fresh repository detached at 9c306e9 (parent a30aca5), with no remote, no refs and no route back to P5's own tip. The gate holds 10 of 10 there.
  - The copy may hold planted faults. Their key's SHA-256 is 66a20d88c89b96fc0eeb8fe42b6a5f803197d28104d8f50b3303deeb42a6aae6.
  - Every other verifier on a planted copy has reported, so this key is revealed after verifier-P5 reports, and no other key is pending (the 22:57:23 lapse).

Decided:
- verifier-P5 is dispatched on Opus with wave 1's verifier brief and two additions: `keys/` stays closed until it reports, and the lead's rulings are items to check (23:16:47, 23:21:34).

For: verifier-P5

## 2026-10-03 00:24:40 -0700 - verifier-P5's dispatch carried a notice of a known leak: lead.md describes wave 1's plants

Measured:
- The entries of 22:53:58 and 23:06:11, which graded wave 1's verifiers, describe each plant in prose ("'twelve corrections' made 'fifteen'" and the like). verifier-P5's brief has it read lead.md first (R2), so the rule keeping `keys/` closed does not keep the shapes from it.
- Its dispatch said so, and asked it to record in its first view entry whether it read those two entries before forming its view.

Believed:
- The proposal of 22:57:23 is too narrow. Keeping a round's keys closed until its verifiers report is not enough while the ledger describes plants in prose. Both stay out of the ledger until every verifier on a planted copy in the round has reported, later waves' included.

For: verifier-P5, the case study

## 2026-10-03 00:46:54 -0700 - verifier-P5 reported: 2 of 2 caught, 10 of 10 in the round; its key revealed; no send-back; P5 merged next

Measured:
- **Planted faults, step 3.** verifier-P5 reported (its file, 00:45:48) on 9c306e9. Its key was logged at 00:23:24 and is now at `keys/key-9c306e9.json`, hash 66a20d88…, which `sha256sum` matches.
  - The plants:
    - brief.md's runtime-messages means turned to "Message `<the lead>` first, then write the question in your own file", against section 4's entry first;
    - verifier.md's scratch-directory rule tagged `(§8)` for section 3's rule. Section 8 exists, so check 5 passes.
  - Its findings 1 and 2 are those two, each classed a wrong answer. **2 of 2 caught; across the round, 10 of 10.** P5's real tip is 43403e6.
  - It recorded at 00:25:17, before any view, that it had read lead.md's 22:53:58 and 23:06:11 entries, which describe wave 1's plants. Its grade stands with that disclosed.
- **Its other findings**, read by the lead at 43403e6:
  1. **Restate.** checklists.md's file-channel item says "re-arm plus do a full read if it dies", without section 4's "while it is still working". brief.md and ledger.md have it.
  2. **Restate.** P5's phase-2 entry, and this ledger's 00:23:24 entry after it, say every row-to-template pair ADOPTION.md names is carried "and none it doesn't". The templates carry more than ADOPTION.md's template column names: R2 in ledger.md; S1 in checklists.md; S3's test escalation in brief.md; S1, S2 and the stamp rule in verifier.md; CS4#5 to CS4#8, CS3#17, S2, S5 and R5 in checklists.md. Each line is correct and has its section. The claim was too wide, and the column is narrower than the templates now are.
- **Its known limits:**
  - brief.md has no slot for section 3's cost model; P5 put it in checklists.md and said so;
  - verifier.md's item 5 carries only the "re-run" half of section 6's "re-run the negative control, or build one";
  - no gate checks that placeholders render;
  - the docstring does not say, under refs, that check 5 holds only that a named section exists.
- **The rulings it checked**, all of them that touch P5, hold, except the missing "for an agent still working" (finding 1).

Decided:
- **P5 is not sent back.** Its only wrong answers are the plants; the rest is restated at the merge.
- **The lead's restates at the merge:**
  - checklists.md's item gains "while it is still working";
  - ADOPTION.md says what its template column is, and that the templates carry some rules in more places, each line tagged with its section;
  - the 35 round-2 rows' template cells, which said "P5 (templates)", name the templates P5 carried each in, from its 00:21:56 entry, or "none", with the reason, for the five it did not;
  - the gate's docstring says, under refs, that check 5 holds that a named section exists, not that it holds the line's rule.
- The 00:23:24 entry's "and none it doesn't" is corrected by this entry.
- The two known limits on the templates' content (the cost model's slot, verifier.md's item 5) are recorded here for a later round. Neither gives a wrong answer today.

For: the integration (verifier-I's phase 2), the case study

## 2026-10-03 00:53:23 -0700 - P5 merged; the lead's restates; case study 6 committed; verifier-I's phase 2 dispatched on 48d1eab

Measured, on round6, the gate 10 of 10 after each commit:
- 34291cc merges P5 (43403e6).
- a6a6553 is the lead's restates after it:
  - checklists.md's watcher item gains "while the agent is still working";
  - ADOPTION.md says what its template column is;
  - the 35 round-2 rows' template cells name the templates P5 used, or "none" with P5's reason;
  - the gate's docstring states check 5's reach.

  `--control` 50 of 50.
- **48d1eab is case study 6.**
  - CASE-STUDY-6.md has thirteen observations and eight proposals; the gate's own parser reads the proposals as 8.
  - README lists it.
  - ADOPTION.md gains CS6#1 to CS6#8, pending, and the gate declares `6: 8`.
  - Every second-precision time the file cites is an entry stamp in this ledger, checked by script. That check found one time the lead had typed, "00:49:21" for 00:46:54, and it was fixed before the commit: a fifth typed value, caught by a check rather than a reader.

Decided:
- **verifier-I's phase 2**, on round6 at 48d1eab:
  - P5's merge made again;
  - the lead's restates after it;
  - ADOPTION.md in full, the 6975994 phrase included;
  - CASE-STUDY-6.md against this ledger (item 6).
- After it: the ledger archived beside the case study, a scoped check of that commit, then main.

For: verifier-I

## 2026-10-03 01:11:09 -0700 - verifier-I's phase 2: NOT READY on 48d1eab, ten restates of the lead's, eight in the case study; the rulings; a sixth typed value

Measured:
- **verifier-I's phase 2** (its file, 01:10:04): NOT READY on 48d1eab, on restates only. No wrong answer, no regression. Gate 10 of 10 at every commit from 43403e6 to 48d1eab; `--control` 50 of 50.
  - **What holds:**
    - 34291cc's tree, remade from 6975994 and 43403e6, is exact;
    - all five keys match;
    - a6a6553's four changes hold, and all 35 round-2 cells match P5's list and the templates;
    - the cost table reproduces from the transcripts, shares and wall clock included;
    - all 40 second-precision times are stamps;
    - the rulings from 00:19:49 hold;
    - privacy is clean.
- **Its ten restates**, each re-read by the lead:
  1. "went past a verifier five times": six, counting the 22:16:02 check of 1dc5ed4.
  2. "the first found 25 faults outside every stated limit": the 17:44:01 entry gives 30, 25 in the 84-fault run and 5 in separate runs.
  3. "the verifiers' real findings in wave 1 were all overreach": they also include pointers that held once merged, the cost bullet's two measures, and D1, the lead's.
  4. "its two findings were already recorded": its recording entry is stamped 22:54:53, after 22:53:58. They were *formed* before it read that entry.
  5. "P5 listed eight things": P5 listed eleven items, eight of them errors.
  6. "`e5ce41e` fixed both": 5c19906 restated the passage limit; e5ce41e widened the count's reach and added the 50th control.
  7. "the lead typed three values", then a fourth: the ledger records five.
  8. Obs 13's heading had the claim the wrong way round. "And none it doesn't" is the lead's wording at 00:23:24; P5's is "none is carried that ADOPTION.md does not send there".
  9. ADOPTION.md's CS6 rows: "pending: proposed by the round that practised it". Round 6 did not practise CS6#2, #3 or #8, and practised #1 and #6 only after breaking them.
  10. ADOPTION.md says each template line names its section. 23 units are tagged "(own)", and headings carry no tag.
- **Its notes:**
  - "The owner set the threat model" overstates it: the owner approved the lead's recommendation, and the paragraph's words are the lead's (33fb047).
  - CS6#8 calls the rule it extends "case study 3's stamp rule". The stamp rule is round 2's; case study 3 carried it into every brief.
- **A sixth typed value of the lead's, unrecorded until now:** the case study's draft once cited "00:24:05" for the leak notice. The lead replaced it within minutes with the entry's stamp, 00:24:40, read by command, and did not record the slip.

Decided:
- **All ten, and both notes, are fixed** in the case study and ADOPTION.md, in one commit. The case study now counts six typed values: three in the ledger, one in a message, two in its own draft.
- verifier-I re-checks that commit, scoped. Then the archive.

For: verifier-I, the case study

## 2026-10-03 01:18:19 -0700 - verifier-I: READY on 8a2a1d7; the ledger is archived after this entry, its last

Measured:
- verifier-I (its file, 01:17:56): **READY on 8a2a1d7.** Gate 10 of 10, `--control` 50 of 50, and `check_cs6_times.py` finds every cited time. All ten restates and both notes hold, and the ledger's corrections match its findings. The commit and the ledger are clean of addresses, paths and tokens.
- It notes two wordings in obs 11 looser than the ledger, neither a count, time, figure or quotation:
  - "replaced at once", where the 01:11:09 entry says "within minutes";
  - "00:11:52", which the 00:19:49 entry places in the case study's draft as well as in a message.

Decided:
- The archive commit aligns both wordings with these entries.
- **This is the ledger's last entry.** It is archived next, from its working copy, as `archive/round6-ledger.zip`, with its timestamps, each file checked byte for byte. The gate pins it and holds it to the privacy check: it is not excused like the earlier archives.
- A scoped check of the archive commit follows, then main. Neither is recorded here. The owner's summary and HonestHarness's harness notes record them.

For: the archive, the owner
