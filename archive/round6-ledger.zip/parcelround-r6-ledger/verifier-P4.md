# Round 6 - verifier-P4

Append only. Each heading's time is taken from `date`.

## 2026-10-02 22:36:43 -0700 - verifier-P4 starts on the copy at db08fdc (parent 1dc5ed4), on Opus 5.5

Measured:
- My system prompt names the model I run as: Claude Opus 5.5 (claude-opus-5-5).
- The copy at <scratch>/r6-vcopy-P4/ is detached at db08fdc94fb3232d2231352c957ea938f053996c, parent 1dc5ed4, clean, with no remote and no branch.
- `git show --stat HEAD` there: METHOD.md only, 172 insertions and 0 deletions. Its trailer names Claude Sonnet 5.5.
- My scratch directory <scratch>/r6-vP4/ exists and is empty.
- Read so far, in R2's order: the ledger README, lead.md, briefs/_verifier.md, briefs/_common.md, briefs/P4.md, and the plan of record (draft 3). Not yet read: P4.md (the parcel's file), until I have formed my own view.

Believed: nothing yet about the work.

For: the lead

## 2026-10-02 22:54:53 -0700 - verifier-P4: gate and control re-run; two findings formed before the lead's 22:53:58 entry; keys/ not opened

Measured:
- In the copy at db08fdc: `python tools/check_method.py` gives 10 of 10; `--control` gives 48 of 48; the working tree is clean after both.
- The diff against 1dc5ed4: METHOD.md only, 172 insertions, 0 deletions; every hunk below the line `## 7. What the lead keeps`.
- Two findings, each formed from the sources before I read the lead's 22:53:58 entry (it appeared while I worked):
  1. METHOD.md:712 says round 5's lead "pushed six commits of its own with only its own gate". CASE-STUDY-5.md:114-115 and :79 say eight, and round 5's archived lead.md (22:01:36) lists eight SHAs.
  2. METHOD.md:694-696: the rule's bold sentence binds "The lead's seam commits and fixes (§5) and its merges", not its records; "Its records are ..." follows with nothing in the rule to refer to. The commit message says "its merges and its records go past a verifier".
- keys/ appeared in the ledger at 22:53. I listed its file names only (three keys, none for db08fdc) and opened none.

Believed: nothing yet on the rest; the content check continues.

For: the lead

## 2026-10-02 23:03:09 -0700 - verifier-P4 reports NOT READY on db08fdc: two wrong answers (a count; the records left out of the rule), a pending part adopted under the lead's D1, two restates, known limits

Measured (every file:line at db08fdc unless named otherwise):

Findings:
1. **Wrong answer: a count.** METHOD.md:712 says round 5's lead "pushed six commits of its own with only its own gate". CASE-STUDY-5.md:114-115 says eight, :79 says "eight of its own commits reached main with no verifier", and round 5's archived lead.md (entry 22:01:36) lists eight SHAs. The gate passes it (content; a changed count passes, fault K2).
2. **Wrong answer: the records half is not in the rule.** METHOD.md:694-696, the bold rule, binds "The lead's seam commits and fixes (§5) and its merges". Records, P4's half of CS3#7 and CS5#1 (ADOPTION.md:87, :122; CASE-STUDY-3.md:674 "and so do its records"; CASE-STUDY-5.md:343-345), are not in it. :696-697 defines "Its records" and :716 says "Records need that reader", but no rule sentence binds them, which is the brief's named trap (a lead reading only section 7). The commit message's first section-7 bullet says "its merges and its records go past a verifier", which the text does not say. It lands inside check 4's stated limit (headings exist, not that the rule is under them): striking the definition too still gives 10 of 10 (fault K4). P3's pointer "(§7 has its merges and records)" (briefs/integration.md, item 4) depends on it.
3. **A pending part adopted, under the lead's D1.** METHOD.md:696-697 puts "the case study" among the records, with CS5 obs 14 as the incident (:716-719). The case study's check before main moves is CS5#11's second half, pending at ADOPTION.md:132; the survey says CS5#1 is "carried to the case study by CS5#11" (archive/round6-practice-survey.md:155); CS3#7 and CS5#1 define records as record entries and commit messages (CASE-STUDY-3.md:674-675; CASE-STUDY-5.md:111-113). P4 disclosed it (P4.md, its brief error 10) and the lead ruled D1 "keep it" (lead.md 22:00:23). By the round's definition it is an item the scope excludes; the remedy is the lead's: record CS5#11's second half as adopted in part, with its practice (CASE-STUDY-3.md:10-20, CASE-STUDY-5.md:96-97, this round's plan), or narrow "Its records".
4. **Restate: S4's conditions name "a gate", not the suite.** METHOD.md:761-765: "Three conditions keep what the staging branch is for: a gate runs after each merge ... main moves only to a tip that has passed that gate and a verifier." The staging branch ran the suite at each staging commit (:753-755), and CS3#12 (:867-869) runs budgets after each merge. Input: every merge into the round branch runs a budget checked against its diff, each merge is re-made, main moves to the tip; all three conditions hold and the full suite never ran, which M:694-699 never allowed (S6's row, ADOPTION.md:158, presupposes a full suite at the tip). And round 3's own end (main moved on `VERDICT: FAIL (1 stage)`, CASE-STUDY-3.md:439-442) meets CS3#12's "write down why" (:869-870) but not S4's "passed that gate". README step 4, which HonestFramework quotes word for word (WITH-PARCELROUND.md:36 at 65447fd), stays true in substance only if "a gate" is the full suite. Otherwise S4 keeps M:694-699's purpose: the sentence stands whole, main moves only to a verified tip, each merge is gated and re-made.
5. **Restate: a domain widened.** METHOD.md:727 "a bare hash of a key longer than 64 bytes"; docs/VALIDATION.md:15654 at 4190a47 says "a bare SHA-256". 64 bytes is SHA-256's block, so "hash" is wider than the record.

Known limits:
- Gate: a citation whose observation number or section mark names an existing but wrong item passes (faults C1-C3); the docstring states the class for minutes and phrases only. Already in the lead's 22:53:58 gate notes.
- Gate: P4's link form (every parcel's, lead.md 22:15:07) writes the commit and line twice. Check 4 reads only the text's; a URL naming another commit (L7) or line (L8) passes. The docstring says only "not fetched".
- Integration: METHOD.md:694 "(§5)" while §5 still says "where it is more than a line" (:564-565); :697 "Not only P0 (§2)"; :747 "(§3)"; :751 "(§6)"; :797 "is in §3". Each holds only once P1's or P3's text merges.
- The cost bullet keeps "from the agent cards" (:801) beside "read from each agent's transcript" (:805-806); CASE-STUDY-3.md:546-548 says the cards may show the final-context figure the new sentence rejects. Which governs is unstated; the brief said keep M:704-707.

Held, checked by me: M:786-790 stands whole at :963-967, with its exception at :968-976 and "Resuming the same agent stays the default". Scope: METHOD.md only, 172 insertions, 0 deletions, every hunk below `## 7.`; no heading changed. Every other citation and figure in P4's text matches its source; the four VALIDATION.md lines (15649, 16164, 16165, 16437 at 4190a47) and B14's nine entries hold; B4's quotation is verbatim. All 29 loganw.dev patterns and 6 HonestFramework passages match once. Privacy: the gate's own patterns and a broader grep find nothing in the diff, the commit message or P4.md (the author field is a stated limit).

What I ran: the gate (10 of 10) and `--control` (48 of 48) in the copy; 22 faults in a scratch clone at <scratch>/r6-vP4/ (faults.py, output faults-run2.txt): 7 caught (the parcel's negative control re-run among them, named at METHOD.md:842), 15 passing, each inside a stated limit or content, with C1-C3 and L7-L8 as above.

Anything else: the copy differs from P4's own design (P4.md, 21:57:57) in exactly findings 1 and 2; both lines were edited after wrapping (:694 is 58 characters with room for "past"; :712 is 69 with room for "of"). I report both as real. I did not check that 4190a47 is reachable on GitHub.

Background processes: none started; nothing of mine is running.

Believed: nothing beyond the above.

For: the lead, the integration
