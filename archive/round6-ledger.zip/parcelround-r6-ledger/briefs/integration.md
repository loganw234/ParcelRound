# verifier-I: the integration and the lead's records

Read `_verifier.md` first. Everything there applies here, except what this
brief changes. Your dispatch message names round6's tip, the roots `<repos>`
and `<scratch>`, and your scratch directory.

You verify the lead's own work in round 6: everything on round6 after `1dc5ed4`
that no parcel wrote, and the merges that brought the parcels' work in. METHOD.md
§7 says why: the lead is the one author in a round that nobody disconfirms by
default, and its seam commits, fixes, merges and records go past a verifier
before main moves.

**Places:**
- **The work:** round6's commits after `1dc5ed4`, in a fresh clone you make
  yourself in your scratch directory: `git clone <repos>/parcelround-worktrees/P0`,
  then check out the tip your dispatch names. Never touch P0's worktree.
- **The parcels' own commits:** P1 `03561a7`, P2 `3676786`, P3 `4ff28ca`, P4 and
  P5 as the ledger names them. Each was verified on its own by its verifier.
  Their reports are in the ledger (`verifier-P1.md` …), and the lead's rulings
  on them in `lead.md`.
- **The ledger**, read in full: it is the record CASE-STUDY-6.md is checked
  against.

## Two phases

- **Phase 1, now:** wave 1. P1 to P4's merges, the lead's restates and
  corrections after them, its integration commit, its gate commits and
  its ADOPTION.md commit: round6 from `1dc5ed4` to the tip your dispatch
  names. Items 1 to 4 and 7 below, and item 5 for ADOPTION.md.
- **Phase 2, when the lead resumes you:** P5's merge, the lead's
  end-of-round commits and CASE-STUDY-6.md. Item 6, and the rest of
  item 5.

Report at the end of each phase.

## What you check

0. **The lead's rulings after dispatch**, in `lead.md`, are items to check,
   not only reading: each against the rows and sources it touches. Round
   3's lesson, which this round adopted into §6, and which this round's
   own wave-1 verifier brief missed (lead.md, the entry that dispatches
   you).
1. **Each merge, made again.** For each merge commit, rebuild it from its
   parents with `git merge-tree --write-tree`, and compare the tree with the
   commit's. They must be equal. METHOD.md §7, "The integration verifier makes
   each merge again", says how.
2. **Each of the lead's restates**, against the finding it answers and the
   source it cites. A restate may narrow a sentence to its source; it may not
   change a rule, add a claim the source does not hold, or drop a correct one.
   The findings are in the verifiers' files, the rulings in `lead.md`.
3. **The lead's gate commits.** Each limit now stated is true of the code, and
   stated by its behaviour. The new check is a real check: its control fails
   the gate without the change and passes with it. Re-run the gate and
   `--control` yourself.
4. **The integration.** Wave 1's parcels wrote in four places with one
   METHOD.md in mind. Each points at text the others wrote:
   - "(§5 says how a limit is stated, §6 how it is tested)" and "(§7)", P1's;
   - "(§3)", "(§7 has its merges and records)" and "(§7)", P3's.

   Each must now be true. A rule written twice must say the same thing both
   times; the lead dedupes S5. No rule may contradict another.
5. **The lead's end-of-round commit**, when your dispatch names it:
   - ADOPTION.md's statuses and sections against METHOD.md as merged;
   - every other change, against its stated reason.
6. **CASE-STUDY-6.md**, when your dispatch names it. Every time, count and
   quotation it gives, against the ledger. Every observation must follow
   from what the ledger records. Every proposal must name the observation
   it comes from.
7. **Privacy:** every commit's message and diff, and the ledger as it will
   be archived.

## What will be measured

- Each finding with its class, its evidence as file:line at the tip you
  checked, and the state that shows it;
- what you ran;
- anything else.
