# Round 6: what every parcel's brief shares

Read this first, then your own brief (`P1.md` … `P4.md` beside it). Where your
brief and this file disagree, say so in the ledger at once; don't pick one.

## The project, and the invariant

You are a parcel in ParcelRound's round 6, a round run on ParcelRound itself.

**The repository.** ParcelRound (github.com/loganw234/ParcelRound, MIT) is a
method for running parallel coding agents. It holds:
- METHOD.md, its §§1-8;
- five case studies of the rounds it was learned from;
- templates;
- since this round's P0, ADOPTION.md and the gate `tools/check_method.py`.

**This round's job** is to bring METHOD.md to the method as practised. It adopts
the case-study proposals that later rounds practised, the owner's own rules, and
a few practices, restorations and allowed adaptations. Each is a row in
ADOPTION.md with its status, evidence, section and parcel.

**METHOD.md's invariant**: every rule is there because something broke without
it, and each cites its incident. A rule with no incident, an incident that
doesn't say what the rule claims, or an invented illustration breaks it.
HonestFramework's METHOD.md makes the same point: "a method document full of
invented illustrations would be the thing it warns against".

**What must not break:**
- **Sections.** §§1-8 keep their numbers and titles: other repositories cite
  them. New rules enter as subsections or within sections. The gate's check 8
  holds this.
- **Quoted passages.** loganw.dev reads several passages by regular expression,
  and HonestFramework presents others as verbatim. Each must stay word for word
  and appear exactly once, with its line wrapping as it is; loganw.dev's
  patterns use literal spaces. The gate's check 9 holds this. The list is
  `LOGANW_PATTERNS` and `HF_PASSAGES` in `tools/check_method.py`. If your job
  seems to need one of them changed, stop and escalate: they belong to other
  repositories, so the decision is the owner's.
- **Scope.** Adopt only what your rows say. A row marked **pending** is not
  yours to write. A row **in part** names its part: write that part, and
  nothing more. Writing a pending item, or more than the part, is a wrong
  answer under the round's send-back rule.

## Line numbers in these briefs

`M:n` is line n of METHOD.md at `49a9266`, the commit round6 was cut from
(METHOD.md is the same at `8767e23`). P0's preamble added 14 lines above §1, so
at round6's tip the line is n + 14, and each merge in wave 1 moves lines
again. Find each by its text, which is what counts. `CSn:m` is line m of case
study n, which this round does not change; case study 5 gains only a
postscript at its end.

## Places, and no absolute paths

Your dispatch message defines two roots:
- `<repos>`: the directory that holds ParcelRound's worktrees, this ledger,
  and the plan;
- `<scratch>`: the directory that holds your scratch directory.

This brief names places relative to them. **Never write an absolute path in
the ledger, a commit message or a committed file.** The ledger will be
published, a path names the owner's machine, and the gate's check 10 fails on
one, in history too. Write `<repos>/...` or `<scratch>/...` instead.

## Start here

1. The plan of record (draft 3), at the path your dispatch message gives.
   Read all of it, then your parcel's section under "Wave 1".
2. ADOPTION.md in your worktree: every row whose `parcel` column names you.
3. METHOD.md, all of it. You own only your sections, but rules refer across
   sections.
4. For each of your rows:
   - the proposal in its case study (the id's line, e.g. `CS4#16` is case study
     4's 16th proposal);
   - its evidence of practice, in `archive/round6-practice-survey.md`.
5. The gate's docstring (`tools/check_method.py`): its citation forms, and its
   stated limits.

## The ledger

`<repos>/parcelround-r6-ledger/`. Read its README now: it is the round's
rules. In short:
- one file per author, yours named in your brief, append only;
- stamps from `date`, never typed;
- read the whole directory before you start, before you design anything that
  touches a shared section, and before your report;
- mark what you measured and what you believe;
- nothing secret or personal in any file, because the ledger will be
  published.

**Escalation**: write it in your file first, then message the lead
(`SendMessage` to `main`) and wait. If `SendMessage` isn't loaded, load it with
the ToolSearch tool, query `select:SendMessage`.

## Your two phases (design first)

**Phase 1: read, echo, design, test the channel, then stop.**
1. **Your intent echo**, as your first ledger entry. In your own words:
   - what your brief asks;
   - which sections you own, and what you must not touch;
   - your negative control;
   - what would count as failing.
2. **A test escalation.** Send the lead one message, `"<you>: channel test"`,
   and record in your file that you sent it. This is how the round shows its
   escalation channel works (S3). The lead records its receipt.
3. **Your design.** For each of your rows, write in your ledger file:
   - where in your sections the rule goes;
   - the exact text you propose, or a close draft;
   - the incident and the citation you will give it.

   Also list anything your brief got wrong.
4. **Stop.** Your final message for phase 1 is the design. Do not edit METHOD.md
   yet. The lead compares your echo and design with the brief, and resumes you
   with "go", or with corrections.

**Phase 2, on the lead's "go": build, check, commit, report.**
1. **Make the edits**, in your sections only.
2. **Run the gate** in your worktree: `python tools/check_method.py`, which
   takes seconds. It must hold 10 of 10.
3. **Run your negative control in a copy, never in your worktree.**
   - Copy the tree to your scratch directory.
   - Plant one citation in the copy's METHOD.md that does not resolve: for
     example a time that appears nowhere in a case study or its archived ledger.
   - Run the copy's gate and show it names the plant.
   - Run `python tools/check_method.py --control` too.
   - Report both outputs.
4. **Commit on your own branch**, with a message that says what you did and ends
   with a `Co-Authored-By:` trailer naming the model you actually run as, with
   `<noreply@anthropic.com>`. Round 5 found dispatches and transcripts naming
   different models, so take the name from your own system prompt, not from
   this brief. Check `git show --stat HEAD` against your message before you
   believe it.
5. **Stop every background process of your own**, then report.

## How a rule is written here

- **Its incident and citation.** Each rule says what broke, and cites it in the
  forms METHOD.md's preamble gives:
  - `[CASE-STUDY-n, HH:MM]`, a time in the case study or its round's archived
    ledger;
  - `[CASE-STUDY-n, obs k]` in case studies 4 and 5, where the observations are
    numbered;
  - `[CASE-STUDY-n, §k]`, a section mark;
  - a bare time, which is round 2's.
- **Evidence outside the case studies** (cft-fp256's later rounds) is cited as a
  Markdown link: `[round 6's survey, B3](archive/round6-practice-survey.md)`,
  or a link to cft-fp256's public docs/VALIDATION.md at commit `4190a47`. Never
  a local path.
- **In METHOD.md, square brackets hold citations only.** The gate reads every
  bracketed text that is not a link as a citation, so anything else in
  brackets fails check 2.
- **A bare `§n` or "section n" names METHOD.md's own section**, and check 5
  fails one that METHOD.md does not have. Cite another document's section in
  brackets, as `[CASE-STUDY-n, §k]`.
- **A `file:line` in prose needs a commit beside it**, in backticks (check 4,
  because lines move). Anything shaped like word:number counts, so a host and
  port such as `localhost:8080` goes in backticks.
- **Keep the section's voice**: dense, a rule in bold, then why, then the
  citation. No invented examples.
- **Don't delete correct text.** Where an adopted rule qualifies an existing one,
  keep the existing sentence and add the qualification beside it, unless your
  row says the old sentence was wrong (for example, a claim round 3
  contradicted).

## READY

READY means every property of your work is either:
- **held by the gate**; or
- **stated as a limit**, by the behaviour it concedes, where a fault built to
  evade the gate lands inside that limit.

Your verifier works to that standard. "Found nothing" is an acceptable answer
for you too: if a row cannot be written truthfully, say so rather than forcing
it.

## Do not

- push, merge, rebase, or commit to `main` or `round6`. Commit only on your
  own branch; the lead merges;
- touch another parcel's sections, README.md, ADOPTION.md, tools/, .gitignore,
  any template (they are wave 2's), or any case study (they are records);
- weaken, delete, or rewrap a quoted passage;
- send a heredoc with backslashes through Bash: they get mangled here. Write
  scripts with your file-writing tool.

## Report (phase 2)

- Each row you applied, with the METHOD.md heading it now sits under.
- Each row you could not apply, and why.
- The gate's output and the control's output, the actual lines.
- **Anything you found that this brief got wrong.**
- Any boundary you crossed, and why. A crossing you disclose and reason is
  fine; a silent one is not.
- Confirmation that your background processes are stopped.
