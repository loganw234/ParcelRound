# Round 6: what every wave-1 verifier's brief shares

You are a **verifier**, not an author. Your job is to try to *disconfirm* one
parcel's work, and to report. **You must not fix anything.** A verifier that
edits is a second author with none of the first one's context. **"Found
nothing" is an acceptable, unpenalised answer.** A verifier under pressure to
produce findings invents them, which is worse than none.

Your dispatch message names your parcel, its commit, and the two roots this
brief uses, `<repos>` and `<scratch>`. Never write an absolute path in the
ledger or anywhere you report. Write `<repos>/...` and `<scratch>/...`.

## The project, and what must not quietly weaken

ParcelRound's METHOD.md is a method for running parallel coding agents. Its
invariant: **every rule is there because something broke without it, and
each cites its incident.** Round 6 brings METHOD.md to the method as
practised, by adopting what ADOPTION.md assigns each parcel. These all break
the invariant:
- a rule with no incident;
- an incident that doesn't say what the rule claims;
- an invented illustration;
- a pending item written as adopted.

**That is what this is about: whether this parcel's change weakened it.**

The shapes to hunt have happened before, in this method's own rounds:
- **words wider than the measurement under them**: "D2 quantified over every
  law on the evidence of one" (CS4 obs 23, behind CS4#17);
- **a limit stated by the faults that found it**, which a fault of another
  kind then walked past (CS4 obs 21, behind CS4#14).

## What you verify

- **A copy of the parcel's work**, at the path and commit your dispatch
  message names. The copy is the work under verification. Until you have
  reported, do not read the parcel's branch in ParcelRound or its worktree.
- **The copy may hold one or two faults the lead planted** to measure this
  check. Their key was committed to the ledger as a hash before your
  dispatch, under the three-commit protocol (HonestFramework METHOD.md,
  "Make the blinding a property of the record"). Treat everything you find
  as real, and report it. The lead separates planted from real after your
  report.
- **The parcel's brief**: `briefs/_common.md` and its own file in this
  directory. Its "What will be measured at verification" is part of your
  list.

## Order of reading (R2)

1. Read the ledger's README, `lead.md`, this brief, and the parcel's brief.
2. Read the copy: `git show --stat`, the diff against round6's base, the
   whole of METHOD.md, ADOPTION.md, and each row's proposal and evidence.
3. Only once you have formed your own view, read the parcel's own ledger
   file, to check its claims.

## Ground rules

- **Re-run things; never trust pasted output.** Run
  `python tools/check_method.py` and `--control` in the copy yourself.
- **Report only.** Edit no file in the copy, ParcelRound, any worktree or
  any other agent's directory. Build every fault in a further copy under
  your own scratch directory.
- **Read no other agent's scratch directory, the lead's included.** The
  planted faults' key is kept there, and a verdict that has seen it measures
  nothing.
- **Stamps come from `date`**, in your ledger file, `verifier-<P>.md`. It is
  append only.
- **Use `GIT_OPTIONAL_LOCKS=0`** with git in any repository that isn't your
  own copy.
- **Escalate** by writing it in your file, then messaging `main` (SendMessage;
  load it with ToolSearch, `select:SendMessage`), and waiting.
- **Stop every background process of your own** before you report.

## What the gate leaves to you

The gate's docstring states its threat model (the owner's decision,
2026-10-02). The gate guards against drift by honest authors and against
accidental publication. It leaves two things to you:
- **content**: whether a rule says what its incident supports. That is your
  main job, items 1, 2, 4 and 5 below, and the gate cannot do it;
- **deliberate evasion**: text built to pass the gate.

Spend your effort in that order. A fault you build against the gate counts
only when it lies inside the threat model and is neither caught nor stated.

## Your list

1. Each adopted rule against its proposal (the case study's list), its
   incident, and its evidence of practice (archive/round6-practice-survey.md).
2. A rule that claims more than its source: a domain, quantifier or count
   wider than the record's.
3. Scope, by `git diff --stat` and the diff's hunks, against the sections
   the parcel owns.
4. A pending item, or more than a row's named part, written as adopted.
5. An invented illustration, or an example the record doesn't hold.
6. The gate's stated limits, by name. Its docstring's "What it cannot see"
   lists them. In particular:
   - a citation of the right minute and the wrong event;
   - a named phrase that opens many items;
   - a wrong status;
   - a heading that exists while the rule is elsewhere;
   - the brief-errors clause kept but not asked.

   For each limit your parcel's work leans on, build a fault that passes
   every check, and say whether it lands inside the limit as stated.
7. Privacy, by name: an address, a personal path or a secret in the diff, the
   commit message, or the parcel's ledger file.
8. The quoted passages: `LOGANW_PATTERNS` and `HF_PASSAGES` in the gate, word
   for word and once each.
9. Anything else.

## READY

READY means every property of the parcel's work is either:
- held by the gate;
- held by a check you ran yourself; or
- stated as a limit by the behaviour it concedes, where a fault you built to
  evade the gate lands inside that limit.

## Classing what you find (the owner's send-back rule, 2026-09-27)

- **Sent back**: only a regression or a wrong answer.
  - A *wrong answer* is a rule that misstates its source, or an item
    adopted that the scope excludes.
  - A *regression* is a correct rule removed, or a quoted passage broken.
- **Merged as a known limit**: anything else, stated by the behaviour it
  concedes.
- **Restated at the merge**: a sentence that claims more than is true. It is
  not left standing.

You class each finding, not the parcel.

## Report

- **READY or NOT READY.**
- Each finding, with:
  - its class;
  - its evidence, as file:line at the copy's commit;
  - the input or state that shows it wrong.
- What you ran, command by command, with the outputs that matter.
- The faults you built, and what each did.
- Anything else.
- Confirmation that your background processes are stopped.
