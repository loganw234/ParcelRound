# Round 6 - verifier-P1's ledger

Append only. Each heading's time is taken from `date`.

## 2026-10-02 22:29:59 -0700 - verifier-P1 starts on the copy at f6ab37e

Measured:
- I run as Claude Opus 5.5, from my own system prompt.
- The copy at <scratch>/r6-vcopy-P1/ is detached at f6ab37e, parent 1dc5ed4 (round6's tip). It has no remote and no branch, and its working tree is clean.
- `git show --stat HEAD`: METHOD.md only, 151 insertions and 1 deletion. Its trailer names Claude Sonnet 5.5.
- Read so far, in R2's order: the ledger README, lead.md, briefs/_verifier.md, briefs/_common.md, briefs/P1.md, and the plan of record. I have not read P1.md, and will not until I have formed my own view.

Believed: nothing yet about the work.

For: the lead

## 2026-10-02 22:47:18 -0700 - verifier-P1's own view of f6ab37e: two wrong answers, two restates, two cross-section pointers that hold only after the merge

Formed before reading P1.md (R2). Line numbers are at f6ab37e.

Measured:
- **The gate, re-run in the copy:** `python tools/check_method.py` gives 10 of 10; `--control` catches 48 of 48. The copy's tree is clean after both, ignored files included.
- **Scope.** METHOD.md only. Its 13 zero-context hunks lie at lines 91-461, all inside sections 1-3 (section 4 opens at 465). Each of the 15 rows lands once, and nothing outside them:
  - CS4#4 carries only "a figure the documents quote has a script in the tree";
  - CS3#17 has no CI clause;
  - CS5#10 is the agent's half;
  - S4 is section 2's side, and S5 the brief's.
  - No pending item is written.
- **Every citation read at its source**, and each names the right event:
  - case study 4's obs 1, 4, 5, 8, 9, 15, 16, 24, 25, 27, 28 and its 13:06, 13:49, 13:51, 13:53, 16:13, 16:17, 22:39, 05:01, 06:23, 06:28;
  - case study 3's "The shared checkout" and its section 7, and case study 5's obs 12;
  - the survey's B13, B17 and departures rows, and cft-fp256's VALIDATION.md 16682, 16764 and 16851 at `4190a47`.
  - The archived ledgers hold three details the case studies don't: round 4's parcel wrote a script at the scratchpad's root; rounds 4 and 5 kept the brief-errors line; round 5's brief said to stop if the fast-forward fails.
- **Quoted passages.** I read each of the gate's 29 loganw.dev patterns at its source in loganw.dev at 43c36a2: each is verbatim. I ran each as loganw.dev runs it (`re.finditer(p, text, re.M)`): each matches once on the copy. The 6 HonestFramework passages appear once each. Section 1's three passages are unchanged.
- **Privacy.** In the diff and the commit message, the only address is the co-author trailer's. There is no path, no token and no invisible character.

Findings:
1. **Wrong answer.** METHOD.md:369-370: "all five parcels corrected their briefs, fifteen corrections in all".
   - The record says twelve: CASE-STUDY.md:38 ("Twelve brief errors, from all five parcels") and :266, and README.md:86 ("twelve corrections from five parcels", a passage loganw.dev quotes).
   - lead.md 22:09:39 kept "round 1's twelve corrections from five parcels".
2. **Wrong answer.** METHOD.md:156-157: "a parcel that reads none of P0's seams need not wait for the verifier".
   - Obs 5 (CASE-STUDY-4.md:139) says "need not wait for the lead's fixes". At 13:53 (:68), P2 went four minutes after the verifier's report of 13:49 (:66), "ahead of the fixes".
   - The paragraph's next clause, 158-159, says the same: "dispatched after that report and ahead of the fixes".
   - lead.md 22:09:39 chose P1's narrower wording, and f6ab37e's message says "need not wait for its fixes".
   - As written, the rule lets a lead dispatch before P0's verifier reports, which no round did. Its words are wider than the measurement (CS4 obs 23's shape).
3. **Restate.** METHOD.md:247-250 (B13): "In each of the rev7, audit, fixes, steps-5-and-6, language and step-6 rounds ... at least one parcel's brief had it propose before it built, and the lead decided".
   - The survey's B13 row (archive/round6-practice-survey.md:124) cites brief lines in all six rounds, but approvals in three: AUD, S56 and LANG.
4. **Restate.** METHOD.md:296-297 (CS4#7): the lead "judged READY by the standard the verifiers had offered themselves".
   - The verifiers judged READY. At 22:39 (CASE-STUDY-4.md:106): "The verifiers judge READY by the standard verifier-P1 had offered". Round 4's lead.md at 05:39Z: "verifier-P1's next pass judges READY".
   - The READYs were the verifiers' (:115, :124).
5. **Known limit, for the integration.** METHOD.md:292: "(§5 says how a limit is stated, §6 how it is tested)".
   - At f6ab37e, sections 5 and 6 (669-839) hold neither "limit" nor "concede". The sentence holds only once P3's CS4#14 and CS4#16 land.
   - Check 5 holds only that both sections exist.
6. **Known limit, for the integration.** METHOD.md:142: "When the round runs on a round branch (§7)".
   - At f6ab37e, section 7 (842-926) has no round branch, only "a staging branch per merge" (858-860). The pointer holds only once P4's S4 lands.

Faults: 21 runs, each committed on f6ab37e in a scratch clone (<scratch>/r6-vP1/fault-repo; faults.py and faults.out beside it).
- **Caught, as controls:** an observation case study 4 lacks (obs 33); an adopted row under a heading METHOD.md lacks; an undeclared foreign pin (`4190a48`); a time round 4's record lacks (03:17, the parcel's own control); a section 9.
- **Pass, inside a stated limit:**
  - the right minute of the wrong event (13:51 to 16:03);
  - "The", and another item's phrase, for "The shared checkout";
  - CS4#8 adopted under "3. The brief" with its rule moved into section 4;
  - CS4#4's "in part" dropped from its status;
  - a wrong cft-fp256 line beside the right pin;
  - B12 for B13 in a link's text;
  - a citation in parentheses;
  - the template's clause negated.
- **Pass, outside every stated limit, and outside the threat model as content:**
  - an existing observation of another event (obs 9 to obs 10);
  - METHOD.md's own brief-errors clause negated, and R1's rule inverted.
  - The citation limits are stated for minutes and named phrases, not for observation numbers or section marks. METHOD.md's R1 is held by no check; check 7 reads only the template.
- **Pass, as correct text:** "twelve" for "fifteen", and "for its fixes" for "for the verifier". The gate reads neither finding 1 nor finding 2. Only this check holds them.

Believed: findings 1 and 2 are the only ones that send the work back.

For: the lead

## 2026-10-02 22:50:32 -0700 - verifier-P1 reports NOT READY on f6ab37e: two wrong answers (a count, a relaxation wider than its case), two restates, two pointers for the integration

**NOT READY**, on two wrong answers. Line numbers are at f6ab37e. My view at 22:47:18 stands; this entry adds what P1.md shows against it.

Measured:
- **P1.md, read after my view (R2).** Two of its claims about its own text disagree with the copy. Its other measured claims match mine: 13 hunks at the same old lines; 151 insertions and 1 deletion; links 47, citations 81, refs 14, anchors 73; 97 commit messages; 48 of 48.
  - R1: its draft (P1.md:361-362), its ruling 2 (:94) and its phase-2 entry (:432) give round 1's **twelve** corrections. f6ab37e's message says "twelve" too. METHOD.md:369 says "fifteen".
  - CS4#1: its draft (:199) says "need not wait for its fixes". Its ruling 3 (:95) refuses "need not wait for the verifier" as a reading "the record does not hold". Its phase-2 entry (:432) says the narrower wording was kept, and f6ab37e's message says "for its fixes". METHOD.md:157 says "for the verifier".
- **Privacy, by name.** I scanned the diff, the commit message, P1.md and this file with the gate's own address, path and secret functions, and with a wider pattern of my own for any absolute path. Both were watched failing on a planted file, since deleted. Nothing is found in any of them.
- **The third read moment.** lead.md to 22:35:59; P2.md, P3.md and P4.md; every verifier file. P3.md:190 and :365 hold the section 5 and 6 paragraphs that METHOD.md:292 points to, and P4.md:185-193 holds the round branch that :142 points to. So findings 5 and 6 hold at the merge, if both land as drafted.
- **Left behind.** The copy is still at f6ab37e and clean. The system temp holds no check_method directory. I started no background process.

Findings, classed:
1. **Wrong answer**: METHOD.md:369-370, "fifteen corrections".
   - The record says twelve: CASE-STUDY.md:38 and :266; README.md:86.
   - The count is now transcribed in three files and has drifted in one, which is section 1's own rule (METHOD.md:55-59).
2. **Wrong answer**: METHOD.md:156-157, "need not wait for the verifier".
   - The source says "for the lead's fixes": CASE-STUDY-4.md:139 (obs 5), with :66 (13:49) and :68 (13:53).
   - The paragraph's own 158-159 says the same as the source.
3. **Restate**: METHOD.md:247-250 (B13), "In each of" six rounds "... and the lead decided".
   - The survey's B13 row (archive/round6-practice-survey.md:124) cites approvals in three rounds: AUD, S56 and LANG.
   - P1.md:263 reads the other three as briefs that say the lead decides. Step 6's line is a sibling parcel's design step.
4. **Restate**: METHOD.md:296-297 (CS4#7), the lead "judged READY".
   - In the record the verifiers judged it: CASE-STUDY-4.md:106 (22:39), round 4's archived lead.md 05:39Z entry, and :115 and :124.
5. **Known limit, for the integration**: METHOD.md:292, "(§5 says how a limit is stated, §6 how it is tested)".
   - At f6ab37e, sections 5 and 6 say neither. It holds once P3's paragraphs land.
6. **Known limit, for the integration**: METHOD.md:142, "a round branch (§7)".
   - At f6ab37e, section 7 has only "a staging branch per merge" (858-860). It holds once P4's S4 lands.

Anything else (none of it sends the work back):
- **B17**, METHOD.md:98-100: "each began with read-only agents".
  - P1.md:168-169 says the cert round used a single agent, and that the reporting form, with "measured or read" and "gaps and disagreements", is one round's survey brief.
  - The survey row that METHOD.md cites says "surveyors" for all three rounds, and I cannot read the gitignored source. cft-fp256's ROADMAP.md:4506-4530 at `4190a47` supports the "gaps" and "stale sentences" part in public.
- **S5's "later rounds"** rests on one brief, S56 b/S1:46-56. The survey states it generally, and P1 kept the survey's domain (P1.md:282).
- **CS5#10's agent half** lands in section 3 as "What a parcel starts" (METHOD.md:431).
  - Its incident includes a verifier's watch, and the proposal says "an agent". ADOPTION.md gives its templates as brief and checklists, not verifier.
  - So a verifier brief compiled from METHOD.md would not carry it unless section 6 or P5 adds it. This is a note for P5.
- **The gate, out of scope by its threat model.** Its citation limits are stated for minutes and named phrases.
  - An existing observation of another event passes (fault F2), and no stated limit names it. P1 leans on observation citations more than on any other form: 11 of them.
  - METHOD.md's own brief-errors clause is held by no check (faults F5 and F5c). Check 7 reads only the template.
- **P1's reading.** P1 read cft-fp256's gitignored Data/runs and the local round-5 ledger by plain file reads, and disclosed both (P1.md:125, :453).

For: the lead
