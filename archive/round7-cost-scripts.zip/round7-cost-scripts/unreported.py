"""For each agent: its assistant messages (and tool_use blocks) that fall outside every run window its usage
notifications report, grouped into stretches (a gap of over 30 minutes starts a new one). Prints each
stretch's start, end, minutes and tool uses. The windows are as cost2.py's runs: a task's notifications with
one implied start (within 3 s), from that start to the last of them."""
import csv, json, os, sys
from datetime import datetime, timedelta, timezone

TSV, SD = sys.argv[1], sys.argv[2]
LOCAL = timezone(timedelta(hours=-7))
rows = []
with open(TSV, encoding="utf-8") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        ts = datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00"))
        rows.append((r["task"], ts, int(r["duration_ms"])))
rows.sort()
runs = {}
for task, ts, ms in rows:
    start = ts - timedelta(milliseconds=ms)
    lst = runs.setdefault(task, [])
    if lst and abs((lst[-1][0] - start).total_seconds()) <= 3:
        lst[-1][1] = ts
    else:
        lst.append([start, ts])
tot_min = tot_tools = 0
n = 0
for task in sorted(runs):
    msgs = []
    with open(os.path.join(SD, "subagents", f"agent-{task}.jsonl"), encoding="utf-8", errors="replace") as f:
        for line in f:
            try:
                r = json.loads(line)
            except ValueError:
                continue
            m = r.get("message")
            if r.get("type") != "assistant" or not isinstance(m, dict) or not r.get("timestamp"):
                continue
            t = datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00"))
            tools = sum(1 for c in (m.get("content") or []) if isinstance(c, dict) and c.get("type") == "tool_use")
            msgs.append((t, tools))
    outside = [(t, k) for t, k in msgs
               if not any(s - timedelta(seconds=2) <= t <= e + timedelta(seconds=2) for s, e in runs[task])]
    if not outside:
        continue
    outside.sort()
    groups = [[outside[0]]]
    for t, k in outside[1:]:
        if (t - groups[-1][-1][0]).total_seconds() > 1800:
            groups.append([])
        groups[-1].append((t, k))
    for g in groups:
        mins = (g[-1][0] - g[0][0]).total_seconds() / 60
        tl = sum(k for _, k in g)
        if tl == 0 and mins < 1:
            continue
        n += 1
        tot_min += mins
        tot_tools += tl
        print(f"{task} {g[0][0].astimezone(LOCAL):%m-%d %H:%M:%S} to {g[-1][0].astimezone(LOCAL):%m-%d %H:%M:%S} "
              f"{mins:7.1f} min {tl:4} tool uses ({len(g)} messages)")
print(f"stretches {n}, minutes {tot_min:.1f} ({tot_min/60:.2f} h), tool uses {tot_tools}")
