# Case study 7's cost scripts

The scripts behind CASE-STUDY-7.md's "Cost of the run (measured from the
transcripts)" and observation 9's table of first runs.

Seven of them are, byte for byte, the copies the lead ran on 2026-10-05. The
eighth, firstruns.py, is not. The lead ran its program inline at 14:50, with
the session's path written in, and wrote this file from it four minutes
later, taking the path as an argument. The lead never ran the file; the case
study's third and fourth verifiers did, and it gave the same figures.

They read Claude Code's transcripts of the session: the lead's, one JSONL
file, and each agent's, in the session directory's `subagents/` as
`agent-<id>.jsonl` with `agent-<id>.meta.json` beside it. The transcripts are
not published, so these scripts show how the figures were made. They cannot
remake them from this repository.

Fixed inside the scripts:
- local time is UTC-7;
- step 6 began at 2026-10-02 07:33:51 local (14:33:51Z);
- an agent is a parcel, a survey or a verifier by its description's first
  words, and its model is read from its meta.json.

The cutoff given to cost2.py and failed.py was 2026-10-05T17:40:00Z, 10:40
local, the time of the writing.

In the order of their first use, in local time on 2026-10-05:

| script | first used | arguments | what it prints or writes | where the case study uses it |
|---|---|---|---|---|
| agent_usage.py | 10:31 | the lead's transcript; an output TSV | one row for each task notification that carries a usage block | the input to every script below but ctxcheck.py and failed.py |
| ctxcheck.py | 12:24 | the session directory; agent ids | each agent's last context, fresh tokens, cache reads and tool uses | the check that a notification's "tokens" is the agent's context size at its run's end |
| cost2.py | 12:27 | the TSV; the session directory; the cutoff | runs, not notifications: a task's notifications with one implied start (within 3 s) are one run, with its last notification's figures. Tokens are summed from each agent's own transcript, once a message. By class, by model, and for step 6 | the cost table, and the repeated notifications |
| cost3.py | 12:44 | the TSV; the session directory | the verifiers' per-run medians on each model, over all their runs | none now. A draft's table of the two models used it; the third verifier found that table set the smaller model's first runs against the larger model's all runs, and cost3_first.py replaced it |
| failed.py | 14:47 | the lead's transcript; the cutoff | the agent notifications with no usage block, and how many carry the harness's "may be interim" note. It prints a repeated identical notification once, so it lists eleven where the case study counts twelve: parcel C's third has the same text as its first | the notifications without usage |
| unreported.py | 14:48 | the TSV; the session directory | each agent's work outside every run window its notifications report | the runs that ended with no usage notification, which the table adds |
| firstruns.py | 14:50, inline (above) | the TSV; the session directory | each verifier's first run only: the median tool uses and minutes, from the notifications alone | observation 9's table: tool uses and minutes |
| cost3_first.py | 15:44 | the TSV; the session directory | cost3.py over each verifier's first run only. It is cost3.py with `rr[:1]`; its docstring is cost3.py's, unchanged | observation 9's table: fresh tokens and cache reads |
