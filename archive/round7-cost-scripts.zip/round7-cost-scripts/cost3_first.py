"""Observation 9's comparison: per RUN medians of the verifiers on each model - minutes, tool uses (the
run's last notification), and fresh tokens and cache reads inside the run's window from the agent's own
transcript. Runs as in cost2.py (a task's notifications with one implied start, within 3 s)."""
import csv, json, os, sys, statistics
from datetime import datetime, timedelta

TSV, SD = sys.argv[1], sys.argv[2]
rows = []
with open(TSV, encoding="utf-8") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        ts = datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00"))
        rows.append((r["task"], ts, r["summary"], int(r["tool_uses"]), int(r["duration_ms"])))
rows.sort(key=lambda x: (x[0], x[1]))
runs, desc = {}, {}
for task, ts, summ, tools, ms in rows:
    start = ts - timedelta(milliseconds=ms)
    desc[task] = summ[len('Agent "'):] if summ.startswith('Agent "') else summ
    lst = runs.setdefault(task, [])
    if lst and abs((lst[-1][0] - start).total_seconds()) <= 3:
        lst[-1][1:] = [ts, tools, ms]
    else:
        lst.append([start, ts, tools, ms])

def model(task):
    meta = json.load(open(os.path.join(SD, "subagents", f"agent-{task}.meta.json"), encoding="utf-8"))
    return "sonnet" if "sonnet" in json.dumps(meta).lower() else "opus"

def messages(task):
    seen = {}
    with open(os.path.join(SD, "subagents", f"agent-{task}.jsonl"), encoding="utf-8", errors="replace") as f:
        for line in f:
            try:
                r = json.loads(line)
            except ValueError:
                continue
            m = r.get("message")
            if r.get("type") != "assistant" or not isinstance(m, dict) or not m.get("usage") or not r.get("timestamp"):
                continue
            seen[m.get("id")] = (datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00")), m["usage"])
    return list(seen.values())

out = {"sonnet": [], "opus": []}
for task, rr in runs.items():
    d = desc[task]
    if d.startswith(("Parcel", "Survey", "Step-6 survey", "Completeness sweep")):
        continue
    msgs = messages(task)
    k = model(task)
    for start, end, tools, ms in rr[:1]:
        lo, hi = start - timedelta(seconds=2), end + timedelta(seconds=2)
        fr = cr = 0
        for t, u in msgs:
            if lo <= t <= hi:
                fr += u.get("input_tokens", 0) + u.get("cache_creation_input_tokens", 0) + u.get("output_tokens", 0)
                cr += u.get("cache_read_input_tokens", 0)
        out[k].append((d, ms / 60000, tools, fr, cr))
for k, v in out.items():
    print(f"{k}: {len(v)} runs; medians: minutes {statistics.median(x[1] for x in v):.1f}, tool uses {statistics.median(x[2] for x in v):.0f}, "
          f"fresh tokens {statistics.median(x[3] for x in v):,.0f}, cache reads {statistics.median(x[4] for x in v)/1e6:.1f} M")
    if k == "sonnet":
        for x in v:
            print(f"   {x[0][:40]:40} {x[1]:6.1f} min {x[2]:4} tools {x[3]:>10,} fresh {x[4]/1e6:7.1f} M cache")
