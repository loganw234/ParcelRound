"""Observation 9's like-for-like comparison: each verifier's FIRST run only, by model - the median tool uses
and minutes, from the notifications (runs as cost2.py's: one implied start within 3 s, the last notification
of a run gives its figures). usage: firstruns.py <usage.tsv> <session dir>"""
import csv, json, os, sys, statistics
from datetime import datetime, timedelta

TSV, SD = sys.argv[1], sys.argv[2]
rows = []
for r in csv.DictReader(open(TSV, encoding="utf-8"), delimiter="\t"):
    ts = datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00"))
    rows.append((r["task"], ts, r["summary"], int(r["tool_uses"]), int(r["duration_ms"])))
rows.sort(key=lambda x: (x[0], x[1]))
runs, desc = {}, {}
for task, ts, summ, tools, ms in rows:
    start = ts - timedelta(milliseconds=ms)
    desc[task] = summ[len('Agent "'):] if summ.startswith('Agent "') else summ
    lst = runs.setdefault(task, [])
    if lst and abs((lst[-1][0] - start).total_seconds()) <= 3:
        lst[-1][1:] = [ts, tools, ms]
    else:
        lst.append([start, ts, tools, ms])
first = {"sonnet": [], "opus": []}
for task, rr in runs.items():
    if desc[task].startswith(("Parcel", "Survey", "Step-6 survey", "Completeness sweep")):
        continue
    meta = json.load(open(os.path.join(SD, "subagents", f"agent-{task}.meta.json"), encoding="utf-8"))
    k = "sonnet" if "sonnet" in json.dumps(meta).lower() else "opus"
    first[k].append((rr[0][2], rr[0][3] / 60000))
for k, v in first.items():
    print(f"{k}: first runs {len(v)}; median tool uses {statistics.median(x[0] for x in v):.0f}; "
          f"median minutes {statistics.median(x[1] for x in v):.1f}")
