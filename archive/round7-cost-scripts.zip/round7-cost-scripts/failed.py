"""Task notifications WITHOUT a usage block (status failed or other), from the lead's transcript, up to a
cutoff: their task id, status, summary and time. And the count of earlier notifications that carry the
harness's "may be interim" note. Streams the transcript."""
import json, re, sys
from datetime import datetime, timedelta, timezone

SRC, CUT = sys.argv[1], sys.argv[2]
cut = datetime.fromisoformat(CUT.replace("Z", "+00:00"))
LOCAL = timezone(timedelta(hours=-7))
pat_task = re.compile(r"<task-id>([^<]+)</task-id>")
pat_status = re.compile(r"<status>([^<]+)</status>")
pat_summary = re.compile(r"<summary>([^<]+)</summary>")
seen = set()
nousage = []
interim = set()

def texts(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for v in obj.values():
            yield from texts(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from texts(v)

with open(SRC, encoding="utf-8", errors="replace") as f:
    for line in f:
        if "<task-notification>" not in line:
            continue
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        ts = rec.get("timestamp")
        if not ts:
            continue
        t = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        if t > cut:
            continue
        for s in texts(rec):
            if "<task-notification>" not in s:
                continue
            for block in s.split("<task-notification>")[1:]:
                block = block.split("</task-notification>")[0]
                tid = pat_task.search(block)
                st = pat_status.search(block)
                sm = pat_summary.search(block)
                if not tid or not sm or not sm.group(1).startswith("Agent "):
                    continue
                key = (tid.group(1), st.group(1) if st else "", sm.group(1))
                has_usage = "<subagent_tokens>" in block
                if "may be interim" in block:
                    interim.add((tid.group(1), sm.group(1)))
                if has_usage or key in seen:
                    continue
                seen.add(key)
                nousage.append((t, tid.group(1), st.group(1) if st else "?", sm.group(1)))
nousage.sort()
print("agent notifications without usage, by first appearance:", len(nousage))
for t, tid, st, sm in nousage:
    print(f"  {t.astimezone(LOCAL):%m-%d %H:%M:%S} {tid} {st:9} {sm[:90]}")
print("distinct (task, summary) with the 'may be interim' note:", len(interim))
