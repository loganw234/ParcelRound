"""Check VCS7's claim that a task notification's <subagent_tokens> is the agent's context size at
the end of its run, not tokens used. For each agent id given: the last assistant message's usage
(input + cache creation + cache read + output), the run's sums of fresh tokens (input + cache
creation + output, once per message id) and cache reads, and its tool_use count."""
import json, sys, os

SD = sys.argv[1]
for aid in sys.argv[2:]:
    p = os.path.join(SD, "subagents", f"agent-{aid}.jsonl")
    meta = json.load(open(os.path.join(SD, "subagents", f"agent-{aid}.meta.json"), encoding="utf-8"))
    last = None
    seen = {}
    tools = 0
    with open(p, encoding="utf-8", errors="replace") as f:
        for line in f:
            try:
                r = json.loads(line)
            except ValueError:
                continue
            m = r.get("message") or {}
            if r.get("type") == "assistant" and isinstance(m, dict) and m.get("usage"):
                u = m["usage"]
                seen[m.get("id")] = u
                last = u
                for c in m.get("content") or []:
                    if isinstance(c, dict) and c.get("type") == "tool_use":
                        tools += 1
    fresh = sum(u.get("input_tokens", 0) + u.get("cache_creation_input_tokens", 0) + u.get("output_tokens", 0) for u in seen.values())
    cread = sum(u.get("cache_read_input_tokens", 0) for u in seen.values())
    ctx = (last.get("input_tokens", 0) + last.get("cache_creation_input_tokens", 0)
           + last.get("cache_read_input_tokens", 0) + last.get("output_tokens", 0)) if last else 0
    print(f"{aid} {meta.get('description','')[:50]!r}: last-context {ctx:,}  fresh {fresh:,}  cache-reads {cread:,}  tool_use blocks {tools}  messages {len(seen)}")
