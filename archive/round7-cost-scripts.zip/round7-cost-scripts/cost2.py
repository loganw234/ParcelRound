"""Case study 7's cost table, the second method (after verifier-VCS7's findings).

1. Runs, not notifications. A task notification whose agent stopped with background work of its
   own may be interim; the same task id then notifies again for the SAME run, with tool uses and
   duration cumulative from that run's start. A run is a task id's notifications with one implied
   start (the notification's time less its duration, within 3 s); its figures are its LAST
   notification's.
2. Tokens from each agent's own transcript (<session>/subagents/agent-<id>.jsonl), not from the
   notification's <subagent_tokens>, which is the agent's context size at the run's end. Fresh
   tokens are input + cache creation + output, and cache reads are counted apart; each is taken
   once per message id, from that message's last usage record, up to the cutoff.
3. Classes by the agent's description (parcels "Parcel ...", others "Survey ..."/"Step-6 survey
   ..."/"Completeness sweep ...", verifiers the rest) and its model (meta.json).
4. Step 6: agents whose first run started at or after the round's first heading, 10-02 07:33:51
   local (14:33:51Z).
"""
import csv, json, os, sys
from datetime import datetime, timedelta, timezone

TSV, SD, CUT = sys.argv[1], sys.argv[2], sys.argv[3]   # cutoff, ISO UTC
cut = datetime.fromisoformat(CUT.replace("Z", "+00:00"))
S6 = datetime(2026, 10, 2, 14, 33, 51, tzinfo=timezone.utc)
LOCAL = timezone(timedelta(hours=-7))

rows = []
with open(TSV, encoding="utf-8") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        ts = datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00"))
        rows.append((r["task"], ts, r["summary"], int(r["tokens"]), int(r["tool_uses"]), int(r["duration_ms"])))
rows.sort(key=lambda x: (x[0], x[1]))

runs = {}   # task -> list of [start, end, tools, ms, ctx]
desc = {}
for task, ts, summ, tok, tools, ms in rows:
    start = ts - timedelta(milliseconds=ms)
    desc[task] = summ
    lst = runs.setdefault(task, [])
    if lst and abs((lst[-1][0] - start).total_seconds()) <= 3:
        lst[-1][1:] = [ts, tools, ms, tok]          # a later notification of the same run
    else:
        lst.append([start, ts, tools, ms, tok])

def klass(task):
    d = desc[task]
    d = d[len('Agent "'):] if d.startswith('Agent "') else d
    meta = json.load(open(os.path.join(SD, "subagents", f"agent-{task}.meta.json"), encoding="utf-8"))
    model = "sonnet" if "sonnet" in json.dumps(meta).lower() else "opus"
    if d.startswith("Parcel"):
        return "parcels", model
    if d.startswith(("Survey", "Step-6 survey", "Completeness sweep")):
        return "surveys and others", model
    return ("verifiers, smaller model" if model == "sonnet" else "verifiers, larger model"), model

def tokens(task):
    fresh = cread = 0
    seen = {}
    with open(os.path.join(SD, "subagents", f"agent-{task}.jsonl"), encoding="utf-8", errors="replace") as f:
        for line in f:
            try:
                r = json.loads(line)
            except ValueError:
                continue
            m = r.get("message")
            if r.get("type") != "assistant" or not isinstance(m, dict) or not m.get("usage"):
                continue
            t = r.get("timestamp")
            if t and datetime.fromisoformat(t.replace("Z", "+00:00")) > cut:
                continue
            seen[m.get("id")] = m["usage"]
    for u in seen.values():
        fresh += u.get("input_tokens", 0) + u.get("cache_creation_input_tokens", 0) + u.get("output_tokens", 0)
        cread += u.get("cache_read_input_tokens", 0)
    return fresh, cread

agg = {}
def add(key, task, model):
    a = agg.setdefault(key, {"agents": set(), "runs": 0, "hours": 0.0, "tools": 0, "fresh": 0, "cread": 0, "ctx": 0})
    rr = runs[task]
    if task not in a["agents"]:
        a["agents"].add(task)
        fr, cr = tokens(task)
        a["fresh"] += fr; a["cread"] += cr
    a["runs"] += len(rr)
    a["hours"] += sum(x[3] for x in rr) / 3.6e6
    a["tools"] += sum(x[2] for x in rr)
    a["ctx"] += sum(x[4] for x in rr)

byday = {}
notifs_by_day = {}
for task, ts, *_ in rows:
    d = ts.astimezone(LOCAL).strftime("%m-%d")
    notifs_by_day[d] = notifs_by_day.get(d, 0) + 1
for task in runs:
    k, model = klass(task)
    add(k, task, model)
    add("all", task, model)
    if runs[task][0][0] >= S6:
        add("step 6", task, model)
        add("step 6: " + k, task, model)
    for x in runs[task]:
        d = x[1].astimezone(LOCAL).strftime("%m-%d")
        byday[d] = byday.get(d, 0) + 1

order = ["parcels", "verifiers, larger model", "verifiers, smaller model", "surveys and others", "all", "step 6"]
order += sorted(k for k in agg if k.startswith("step 6: "))
print(f"{'class':34} agents runs  hours   tools  fresh_M  cacheread_G  ctx_sum_M")
for k in order:
    if k not in agg:
        continue
    a = agg[k]
    print(f"{k:34} {len(a['agents']):6} {a['runs']:4} {a['hours']:7.2f} {a['tools']:7} {a['fresh']/1e6:8.2f} {a['cread']/1e9:11.3f} {a['ctx']/1e6:9.2f}")
print("notifications:", len(rows), " runs:", sum(len(v) for v in runs.values()))
print("runs by day (local, by run end):", " ".join(f"{d}:{n}" for d, n in sorted(byday.items())))
print("notifications by day:", " ".join(f"{d}:{n}" for d, n in sorted(notifs_by_day.items())))
rep = [(t, len(v)) for t, v in runs.items()]
print("repeat notifications:", len(rows) - sum(len(v) for v in runs.values()))
