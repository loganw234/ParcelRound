"""Every subagent's usage from this session's transcript, read-only: each task notification that
carries a <usage> block, with its summary line, the agent's id, status and the record's timestamp.
Writes one TSV row a notification; a later notification for the same agent (a resumed one) is kept as
its own row, and the summary marks it."""
import json, re, sys

src = sys.argv[1]
out = sys.argv[2]
pat_usage = re.compile(r"<subagent_tokens>(\d+)</subagent_tokens><tool_uses>(\d+)</tool_uses><duration_ms>(\d+)</duration_ms>")
pat_task = re.compile(r"<task-id>([^<]+)</task-id>")
pat_status = re.compile(r"<status>([^<]+)</status>")
pat_summary = re.compile(r"<summary>([^<]+)</summary>")
rows = []
seen = set()

def texts(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for v in obj.values():
            yield from texts(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from texts(v)

with open(src, encoding="utf-8", errors="replace") as f:
    for line in f:
        if "subagent_tokens" not in line:
            continue
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        ts = rec.get("timestamp", "")
        for t in texts(rec):
            if "subagent_tokens" not in t or "<task-notification>" not in t:
                continue
            for block in t.split("<task-notification>")[1:]:
                u = pat_usage.search(block)
                if not u:
                    continue
                tid = (pat_task.search(block) or [None, ""])[1] if pat_task.search(block) else ""
                st = pat_status.search(block)
                sm = pat_summary.search(block)
                key = (tid, u.group(1), u.group(3))
                if key in seen:
                    continue
                seen.add(key)
                rows.append((ts, tid, st.group(1) if st else "", sm.group(1) if sm else "",
                             int(u.group(1)), int(u.group(2)), int(u.group(3))))
rows.sort()
with open(out, "w", encoding="utf-8", newline="\n") as g:
    g.write("timestamp\ttask\tstatus\tsummary\ttokens\ttool_uses\tduration_ms\n")
    for r in rows:
        g.write("\t".join(str(x) for x in r) + "\n")
print(len(rows), "notifications with usage")
