# verifier-P4.md

V4's file. Append only, as every file here.

## 2026-09-15 (see the lead's note on entry times; `date` at writing is
## in the log) — EN_WIDE has NO command-line override: P4's "wide path
## off" control needs a source edit, and no gate ever builds it

Measured, at P4's tip 6b5582e:

- `EN_WIDE` is a parameter of `rtl/cft_engine_stream.sv` only.
  `rtl/cft_krnl.sv:754` instantiates `cft_engine_stream` without it, so
  the kernel does not expose it, and `tb/cocotb.mk:86` ERRORS OUT on any
  `KRNL_PARAMS` naming a module other than `TOPLEVEL` ("Verilator can
  only ..."). So `make cycles SIM=verilator KRNL_PARAMS=-Pcft_krnl.EN_WIDE=0`
  cannot work, and nothing else on the command line can either.
- The only way to build the control is to edit the default in
  `cft_engine_stream.sv`. V4 did that in a COPY of the tree (the
  worktree was never touched; `git status` clean afterwards) and
  reproduced P4's before-numbers exactly: fp32 CFT_SUM marginal
  **11.3147 cycles a beat, fixed 195.9** at EN_WIDE=0 against
  **1.4152 / 193.4** at EN_WIDE=1, and all seven `wide=0` rows of the
  REDCYC table **cycle-identical between the two builds** (fp32 seg=3
  27344, fp64 seg=3 13745, fp128 seg=3 6864, and all four fp256 rows
  3505 / 1787 / 1167 / 445).

Why it matters outside V4: the consequence is that **EN_WIDE=0 is an
untested build**. Nothing in `make sim` or `make simmc` ever elaborates
it, so the "same bits at the old cycle count" the parameter exists for
is true only of a build made by hand and cannot be re-checked by a
gate. If the lead wants that control reachable it is one parameter
passed through `cft_krnl` (after which `-Pcft_krnl.EN_WIDE=0` works,
because the cocotb.mk guard is then satisfied); if not, the honest
statement at the merge is that the parameter is a source-edit switch,
not a knob.

Believed: nothing.
For: lead, P3 (the same `KRNL_PARAMS` restriction binds any parameter
you add below `cft_krnl`), V1.

## 2026-09-15 — `make quarter` reduces at BEAT_BITS=64 and was not in
## P4's gate list; it passes, and the tree really does run there

Measured at 6b5582e: `tb/test_krnl_quarter.py:130-138` calls `run_sum`
at fp32 n = 1,2,3,4,5,33 and fp64 n = 1,7 on `tb_krnl_quarter`
(BEAT_BITS=64), where every constant of the beat-wide tree is a
different number (EPB32 = 2, K32 = 1, the heap root at bit 32, ONE
stage instead of three). P4's report lists reduceacc, reduce, krnl,
reducemc, krnlmc and cycles - not `quarter`.

- `make quarter SIM=verilator`: **1/1**, checker `quarter ok 1 case(s)`.
- A V4 probe on the same wrapper that also reads the engine's
  `wide_beats`: fp32 n = 1,2,3,4,5,9,32,33,64,127,128 gives
  `wide_beats == n//2` every time, fp64 gives 0 (one element a beat at
  that width, so there is no tree) - so the pass is a tree that RAN,
  not a silent fallback that would have given the same bits.

For: lead (one more target for the merge gate list), and anyone who
changes beat geometry.

## 2026-09-15 — V4 found no defect in P4's work; the model-level claims
## hold too

Measured: all of P4's quoted gates reproduced from a clean build in a
worktree at 6b5582e (reduce 9/9, reduceacc 7/7 Verilator and 7/7
Icarus, krnl 2/2, reducemc10 9/9, krnlmc10 2/2, cycles 2/2 at rd=wr=0
and at rd=wr=150, yosys-lint rc=0), plus quarter 1/1, and eleven V4
probe cases P4 did not build (segments not a multiple of epb, every
tail length 0..epb-1 at every format, flags whose only source is a tree
lane, a tree flag inside one segment of a 40-segment run, the partial
queue saturated and the read side stalled mid-run by busfx, back-to-back
runs, sub-beat runs, one-beat segments, maxall with an sNaN in a tree
lane) - all exact against `python/cft_golden`, at MUL_PASSES=1 and
MUL_PASSES=10. Both `$fatal`s and the `LVL_W` guard fire when violated.
A pairing break (P4's control (c)) fails five of the nine reduce cases
with the exact strings P4 quoted; a PAIR-PRESERVING permutation (the
two halves of the beat exchanged at the bottom level) passes 9/9, which
is the commutativity claim holding in the RTL as well as the model.

Believed: nothing.
For: lead.

## 2026-09-15 10:45 — CORRECTION to the entry above ("V4 found no defect"): V4 DID find one, and it is on urgent/

The entry above was written before V4 ran `make redprog`. It is wrong
in its conclusion and is left standing, as this ledger requires, with
the correction here.

Measured: P4's tip 6b5582e raises a SPURIOUS UNDERFLOW in a reduction's
FLAGS. `make redprog` (`tb/probe_reduce_then_prog.py`, unmodified)
PASSES on a clean copy of b0b9add and FAILS at 6b5582e with
`fp32 op 24 n=1000 seg=0: flags 0b11000 want 0b10000`; the bits are
right and only FLAGS is wrong. It reproduces with `EN_WIDE = 1'b0`
too, so it is the new sticky-flag arm and not the tree's arithmetic.
Minimal form, no sequencer: an elementwise fp32 FMA of 2**-100 by
2**-100 (n = 4096), then CFT_SUM over 1000 copies of 1.0 - a run that
is exact in the model - returns FLAGS `0b11000` at 6b5582e and
`0b00000` at b0b9add, with identical bits both times. An instrumented
copy puts the leak at accepted array edges **0..15** of the reduction,
`arr_lf = 0x0001800000` (lane 4 alone), `lane0_f` zero. Detail, the
table and the cycle trace: `urgent/V4-p4-flags-regression.md` and
`urgent/V4-p4-flags-minimal-repro.md`.

Everything ELSE in the entry above stands as measured: the pairing is
unchanged at every n, seg, attribute, format and on both simulators,
the two `$fatal`s and the LVL_W guard fire, the controls behave, and
the cycle numbers are P4's.

For: lead, P4, V1, P3.

## 2026-09-15 12:05 — the fix at 778dabf holds: V4 re-verified it and could not break it

Measured, from clean builds in a worktree moved to 778dabf (`git
checkout -B v4-review worktree-agent-a59a9f4605673750c`, head 778dabf,
`git status` clean), every target followed by the checker:

- The defect is gone. `make redprog` `redprog ok 1 case(s)` under
  **Verilator AND Icarus**; V4's own minimal reproduction (an
  elementwise fp32 FMA of 2**-100 by 2**-100, then a sum of 1000 ones
  the model calls exact) gives `d=0x447a0000 FLAGS=0b00000` both from
  reset and after the elementwise run, where 6b5582e gave `0b11000`.
- P4's two new bench cases are load-bearing: with ONLY the `wide_f`
  narrowing reverted in a copy, `make reduce` is **TESTS=11 PASS=9
  FAIL=2** and the two failures are exactly those cases -
  `a_reductions_flags_do_not_depend_on_the_run_before_it` ("FLAGS
  0b11000 want 0b00000 - an exact reduction inherited the previous
  run's flags from the shared array") and
  `a_reduction_straight_after_a_sequencer_program` ("fp32 op 24 n=1000
  seg=0: flags 0b10100 want 0b10000"). With the fix, 11/11.
- P4's claim about which edges contribute is right and is now measured.
  An instrumented copy (`$fatal` if any lane flag reaches `flags_acc`
  at accepted edge <= LATENCY) ran `reduce` 11/11 and `redprog` 1/1
  with **no fire**: 8,690 collections in `reduce`, earliest at edge
  **21**, none at or below 16. In the same runs the UNQUALIFIED OR was
  non-zero and blocked at edges 0..15 on **127 occasions**
  (raw = 10000 / 10100 / 11000), so the gate is doing real work rather
  than being vacuously true.
- The tap is pinned both ways. Moving `lvl_ret` one stage EARLY (the
  issue edge instead of the return edge) fails 9 of 11 `reduce` cases,
  and in both directions - a real flag LOST (`fp32 sum n=8 rne: flags
  0b00000 want 0b10000`) and a spurious one GAINED (`n=21: flags
  0b10001 want 0b10000`). A V4 probe that raises the run's only flag at
  one chosen heap level - bottom, level 1, and the ROOT, with inexact,
  overflow and invalid - passes on the fix and catches the early tap.
- Nothing else moved. `git diff 6b5582e..778dabf --stat` is two files,
  both P4's; section-by-section SHA-1 of the engine shows only the
  beat-wide tree (the new `lvl_ret`), the ALU array (the `wide_f`
  decode) and the sticky-flag comment changed - the readers, the
  writer, run control, beat geometry, the stream FIFOs, the result
  assembler, compute issue and collection, the bus-fault and abort
  blocks are byte-identical, and the module port list is identical.
  reduce 11/11 (Verilator and Icarus), reduceacc 7/7 (both), krnl 2/2,
  reducemc10 11/11, krnlmc10 2/2, quarter 1/1, yosys-lint rc=0.
  `make cycles` at rd=wr=0 and at rd=wr=150 is **identical in all 21
  rows** to the 6b5582e run - marginal 1.4152 / fixed 193.4 and 493.4 -
  and the EN_WIDE=0 build's whole table is identical across the fix
  too, its marginal 11.3147 / 195.9 being b0b9add's own measured number.

Believed: nothing.
For: lead, P4.
