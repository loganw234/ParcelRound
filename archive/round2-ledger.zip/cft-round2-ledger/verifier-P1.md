# verifier-P1.md

V1's file. Append only, as every file here. V1 watches `lead.md` and
`urgent/` and writes here.

## 2026-09-15 09:27 - three things at P1's tip that bind someone other than P1

Measured, all at `1252e62` in V1's worktree, from a clean host build
and the Docker sim image on this desktop.

**1. `rd_need` is set by an operand FIELD, not by a read - and R16
makes that cost fifty times what it did.** `rtl/cft_seq.sv:2255-2262`
(untouched by P1) sets `rd_need[pw[17:16]]` whenever an ALU
instruction's *rb field* is below three. `seq.alu(op, rd, ra=.., rc=..)`
leaves rb defaulted at 0, so **every such instruction marks stream a as
needed** even though nothing reads it. Dense that costs
`ceil(blk_n / lpb)` beat reads a block; through a table it costs the
table's beats plus one round trip per entry.

Measured on the tile (fp64, n=70, program `ADD r6, ra=3, rc=4;
DEPOSIT r6; HALT`, V1's own bench, deleted after): stream a was read
**2 bursts dense** and **9 table + 70 element bursts gathered** - the
whole table, for a stream the program never names.

Two consequences beyond P1: (a) `host/tools/gathertime.py`'s docstring
says the fold "names no stream at all, so R10 loads none of the three",
and that is false - its `seq.alu(sf.OP_ADD, rd=3, ra=3, rc=4)` names r0
through the defaulted rb field. (b) Anyone writing a gathered program
(P2's composed `cft_run_ex`, cft-rebound's fold) must give every
operand field a register at or above three, or the "unread stream is
skipped" saving silently inverts into the most expensive path the
module has. A stream `b` or `c` cannot be hit this way - a defaulted
field is 0, never 1 or 2 - so only stream **a** is exposed.

**2. On the XRT path an indexed stream's SOURCE is staged and bound at
`n * esz`, not at `idx_*_src * esz`.** `host/src/device.c` (the
`bind_role(..., CFT_ROLE_A, a, n * esz)` calls) and
`host/src/backend_xrt.cpp` (`real_bytes = n * esz`, then
`stage(tile.a, a, real_bytes, opnd_bytes)`), both unchanged by P1 -
while `docs/HOSTAPI.md` at P1's tip now says the stream argument "may
hold any number" of elements and `idx_a_src` states how many. The
scratch pool does NOT have this problem: `seq_check_scratch` forces
`scratch_in_bytes == idx_scratch_src * esz` and `sin_bytes` comes from
that field, so the pool is staged whole. The three streams have no such
field. `idx_a_src > n` would let the tile gather past the staged bytes;
`idx_a_src < n` makes `stage()`'s `memcpy` read past the caller's
buffer, and `buf_find`'s "the whole window must fit" makes a resident
short source fall back to exactly that staging. Unreachable from any
gate in this tree (no CFT_ENABLE_XRT build here, no card) and NOT
reproduced on hardware - believed from the source, with the software
path measured correct beside it. It binds P2 (which composes over the
same staging) and the card day.

**3. `cft_program_run_ex` reads `n` elements from a dense `b`/`c`
whatever the program names, and P1's new device-test leg hands it a
short buffer.** `host/tests/device_test.c`'s `check_indexed` sets
`A.a = A.b = A.c = src` with `A.n = n` while `src` holds only
`n/3 + 1` elements (its own printed line is "16 lanes through a
6-element source"), and only `idx_a` is given - so `b` and `c` are read
densely for 16 lanes out of a 6-element `malloc`, at four formats,
on every `device-test` run. MEASURED: the same call shape with the
source placed against a `PAGE_NOACCESS` guard page faults; the guard
itself faults; the same run with 16-element `b`/`c` does not. It is in
a test, not in the library, and the deposits are unaffected because the
program is `DEPOSIT r0` - which is why every gate is green. Anyone
writing a gathered call must still size a DENSE operand at `n`.

Measured: 1 and 3, in the simulator and on this host. Believed: 2, read
from the source; no card.
For: P2, P3, the lead, whoever plans the card day, cft-rebound's agent

## 2026-09-15 09:28 - two gates that were green at b0b9add and are red at 1252e62

Measured: at `1252e62`, `python/check_docs_index.py` exits 1 -
`SEQUENCER.md says 1,717, file has 1769` and `HOSTAPI.md says 2,417,
file has 2445` - and `python bindings/arduino/sync.py --check` exits 1,
`src/cft/src/device.c` and `src/cft/src/program.c` having drifted from
`host/src/`. Both exit 0 at `b0b9add` in a scratch worktree at the same
paths with the same Miniconda python.

Both files are integrator-only by the plan and P1 was right not to
touch either. P1 disclosed the docs counts in `P1.md`; the Arduino
vendored copy is not mentioned anywhere, and `bindings/arduino/
verify.sh` leg 1 is `sync.py --check`. The lead's merge needs
`python bindings/arduino/sync.py` as well as the two doc counts.

Believed: nothing.
For: the lead, P2, P3 (both hit the same two the moment they edit a doc
or anything under `host/src/`)

## 2026-09-15 09:45 - correction to entry 2 above: the RESIDENT path sizes the copy the same way, so there is no configuration in which it works

Measured (by reading `host/src/backend_xrt.cpp:608-685`, which entry 2
did not): `buf_bind` does NOT hand the tile the caller's whole buffer.
For an INPUT role it creates a device BO of exactly `padded` bytes and
`memcpy`s exactly `real` bytes into it:

    c.bo = xrt::bo(B.D->dev, padded, ...);
    std::memcpy(p, B.host + off, real);

and `cftx_program_run` passes `real = real_bytes = n * esz`,
`padded = opnd_bytes` (n rounded up to a beat). So for an indexed
stream the device copy holds the first `n` elements of the source and
nothing else, **whether the caller registered the buffer with
`cft_alloc` or not**. Entry 2 said a resident source would work; it
would not.

Two shapes, both from the corpus `seq_check.py` already draws
(`alen` is one of `1, 3, n//2, n, n+37`):

* `idx_a_src > n` - every entry naming an element at or past `n` reads
  past the end of that BO on the card. Wrong elements, clean flags -
  which is the failure CAPS2[9] and the by-name refusal exist to
  prevent.
* `idx_a_src < n` - `memcpy(p, B.host + off, n * esz)` reads past the
  caller's shorter buffer; `bind_role`'s `buf_find` declines the window
  first ("the whole window must fit"), so the staged path does the same
  over-read instead.

The scratch pool is the control that shows it is an oversight rather
than a design: its device copy is sized `sin_bytes =
io->scratch_in_bytes`, which P1's own `seq_check_scratch` forces to
`idx_scratch_src * esz`. The three streams have no such field in
`cft_run_args`, and nothing was added.

Still BELIEVED, not measured: there is no CFT_ENABLE_XRT build and no
card in this worktree. The software backend is measured correct at
every one of those shapes (seq_check's fourth corpus, 326 indexed
programs over four formats, all agreeing with the model).
For: P2, the lead, whoever plans the card day

## 2026-09-15 10:30 - at b812a53 the three fixes hold, and R10's rule is now stated twice in two contradictory ways

Measured at P1's new tip `b812a53` in V1's worktree.

**The fixes.** (1) `op_reads` checked against the model by V1's own
reading, not by P1's parser: `sf.steer` gives ADD (a,c - b is
`one_bits`), SUB (a,c - c through `negate`), MUL (a,b - c is
`zero_bits(sign a^b)`), FMA (all three); `sf.SIMPLE_IMPL`'s signatures
give ABS/NEG/RECIP_SEED/RSQRT_SEED a alone, SELECT all three, the rest
a and b; and `rtl/cft_simpleops.sv` uses operand `c` in exactly one
place, `OP_SELECT`, which the table covers. The opcode numbers match
`python/cft_golden/softfloat.py` one for one. The control-code arm is
unchanged and is right: the model reads `ra` for DEPOSIT/SETACT/STL/STX
and `rb` for STX/LDX, and nothing reads `rc`. (2) Both XRT paths now
size an indexed stream from `idx_*_src * esz` - `device.c`'s
`buf_sync_in`/`bind_role` window, `buf_bind`'s `real`/`padded` and
`stage`'s - so the resident copy and the staged one are the same size,
which was V1's 09:45 correction. Dense, `beat_round(n * esz)` is
exactly the old `((n + epb - 1) / epb) * epb * esz` because `epb * esz`
is one beat, so the dense byte counts are unchanged. (3)
`check_indexed` gives b and c their own n-element buffer; V1's guard-
page probe does not fault on that shape and still faults on the old one.

**The new finding.** The rule changed for EVERY program and two places
still state the old one:

* `rtl/cft_seq.sv` lines 428-432, the comment on `rd_need`'s own
  declaration: *"Over-approximate by design - a unary opcode's unread
  field still counts - which only ever loads more."* The new rule is
  explained 550 lines lower, beside `op_reads`. A reader who goes to
  the declaration gets the wrong rule out of the same file.
* `docs/SEQUENCER.md` R10 (lines 1451-1453): *"It over-approximates on
  purpose: a unary opcode's unread field still counts, which only ever
  loads more."* No document changed at b812a53 - `git diff
  1252e62..b812a53 -- docs/` is empty - and R10 is the paragraph P3 and
  P2 will read to learn what the tile loads.

**The dense path really did change**, so the gates were all re-run at
b812a53 and all hold: the five-column cycle table of
`docs/SEQUENCER.md` "What it measures" is byte-for-byte what it was
(fp32 61/297/835/607/653 a block, fp64 45/217/563/527/573, fp128
37/177/427/487/533) and so are the gathered numbers (2.32->6.69,
3.39->7.63, 5.54->9.51, 9.83->13.27 cycles a lane; 6/578, 6/290,
6/146, 6/74 read bursts); seq_core 27/27, krnlseq 1/1, seqbanks 1/1,
faults 5/5, krnl 2/2, yosys-lint rc=0, each with the checker's PASS
line; test_seq.py 66, seq_check --trials 400 identical counts to
1252e62, device-test sw 1,802/0, api-test and remote_check green.

Believed: nothing about the card.
For: P2, P3, the lead

## 2026-09-15 12:09 USMST (`date`) - 991603f's three claims: all three hold; one half of the new term had no gate and now has one

Measured at `991603f` in V1's worktree (`git checkout -B v1-review
worktree-agent-af6c94c9c250dafd4`, one commit over `b812a53`), from a
clean host build, each bench target in the FOREGROUND one at a time per
P1's 11:44 environment entry.

**(1) The header-bit expression is the right bits.** `hdr_q[193]` is
`flags` bit 1 = SCRATCH_IO and `hdr_q[239:224]` is `scratch_io[15:0]` =
`n_scratch_in`, checked three ways: `docs/SEQUENCER.md`'s `struct
header` (word 6 `flags`, bit 0 BANK_EXT / bit 1 SCRATCH_IO; word 7
`scratch_io`, [15:0] in, [31:16] out), the model's own packing
(`Program.scratch_io_word` = `n_in | n_out << 16`, `from_bytes` reading
`word7 & 0xFFFF`) with `FLAG_SCRATCH_IO = 1 << 1` in `seqflags.py`, and
the RTL's own existing use of the same two slices four lines above.

**The term really is a cycle ahead of `h_nsin`.** Both are in `S_CHECK`
and `h_nsin <= hdr_q[193] ? ... : '0;` is a non-blocking assignment in
that same cycle, so `h_nsin` inside the `if` would still hold the
PREVIOUS run's count. `idx_en_q[3]` is fine to read: it is latched in
`S_IDLE`, two states earlier. P1's stated reason is exact.

**The refusal costs one read and touches nothing.** Measured in the
unit bench with the read log, at four formats: `refuse=1`, FLAGS 0,
no deposit-overflow bit, `assert_no_writes`, **not one read** in the
scratch table's region, the a table's, the pool's or any stream's, and
**exactly one read burst in the whole run** - the header beat itself.
`krnlseq` prints `MODE[22] with no scratch block to gather into:
refused, STATUS 0b01000` and its assertion is `== ST_REFUSED`, not a
mask.

**The gap I found, and closed for the round.** The new term is an OR:

    idx_en_q[3] && (!hdr_q[193] || hdr_q[239:224] == 16'b0)

and `tb/test_krnl_seq.py` exercises only the FIRST half (a program with
no SCRATCH_IO flag). The second - **SCRATCH_IO set, `n_scratch_in` 0,
`n_scratch_out` non-zero** - is a legal image, and the one an assembler
emits for a program that only WRITES the block. I built it (a
scratchpad bench, deleted): the tile refuses it identically at all four
formats, one read burst, nothing written. So the code is right and the
half was untested; worth a case in `tb/test_krnl_seq.py` beside the
existing one, since the two halves are different header states.

**No over-refusal**, measured rather than argued: MODE[22] on an image
that DOES declare a block still runs and still matches the model at
fp32 and fp256 (n a block and a bit, pool longer than n*k, one
sentinel); and MODE[19] on an image with no scratch block at all is
still ACCEPTED, as it must be - the term names bit 3 alone.

**(2) `compare_buffers_indexed`'s third assertion is genuinely gated,
and cannot pass vacuously.** It sits inside `if (resident_expected &&
get_info(rta.b) == OK && get_info(rsrc.b) == OK)`, and its own
`checks++` is inside that guard - so on a staging backend it is not
counted at all. Arithmetic: five counted checks a format x four
formats = 20, and `device-test sw -b -q -n 16` is **722, 0 failed**
against 702 before, so the sixth is provably not among them, and every
line prints `table binds 0`. CONTROL, built and run: with the call site
forced to `1` in a scratchpad copy, the assertion FIRES at all four
formats - `726 checks, 4 failed`, "this device reports resident
buffers, and the second run bound the table 0 time(s)". Restored and
rebuilt; `722/0` again.

The corollary is worth saying plainly: **on this desktop the saving is
not tested, only the contract.** The leg's first two assertions
(resident == staged; the deposits ARE `source[idx]` with `+0` at the
sentinel, over a 7-element source and an 11-element pool for n=16) do
run on `sw`; the `resident_binds` one is a card-day gate. That is what
P1 says, and the printed line is honest about it. One shape to note for
whoever reads it next: a `cft_buffer_get_info` that FAILED on a device
which does report resident buffers would remove the gate silently,
because the guard is one `&&` chain - the file's existing idiom, but
the shape that hides a gate.

**(3)** `tb/probe_seq_cycles.py` now names `host/tools/gathertime.py`;
`grep -rn probe_gather_card` over the tree finds only
`docs/ROUND2.md`'s "or" in P1's brief, which is the plan's own wording.

**No dense cycle number moved.** `make seqcycles` from a clean build:
fp32 60.8/297.2/835.2/607.2/653.2 a block, fp64
44.8/217.2/563.2/527.2/573.2, fp128 36.8/177.2/427.2/487.2/533.2 -
byte-for-byte `docs/SEQUENCER.md`'s fifth column, and the gathered row
unchanged too (2.32->6.69, 3.39->7.63, 5.54->9.51, 9.83->13.27 cycles a
lane; 6/578, 6/290, 6/146, 6/74 bursts).

**Gates re-run at 991603f, each with the checker's own line:**
`seqcycles` 2/2 ok, `seq_core` **27/27** ok, `krnlseq` 1/1 ok, V1's own
bench 3/3 ok; host build clean, `test_seq.py` 66 passed, `seq_check.py
--trials 400` identical counts to b812a53 (327 indexed programs, 909
tables, 10,041 sentinels, 73 bounds refusals, 47+41 controls, agreement
on every program), `device-test sw -q -n 16` 1,802/0, `sw -b -q -n 16`
722/0, `api-test` all contract checks passed. Not re-run (untouched by
this commit): the multi-pass census, `seqbanks`, `faults`, `krnl`,
lint, the remote suite.

Tree left clean on `v1-review` at `991603f`; the scratchpad copy, the
control and the bench are deleted. Believed: nothing about the card.
For: P3, P2, the lead
