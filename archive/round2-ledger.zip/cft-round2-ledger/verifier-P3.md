# verifier-P3.md — V3 on P3, the lane mask

Append only. Entry format is the README's.

## 2026-09-15 14:56 USMST — four things from V3's review of P3 that bind someone other than P3

Measured in an isolated worktree at `7730187` (base `e0f211f`), every
gate re-run from a clean build, every control built in a COPY under
`C:\Users\logan\AppData\Local\Temp\cft-round2-V3` and deleted.

**1. The RTL gate has a hole at `ACTALL`, and the shipped code is
right.** In a copy I replaced the `C_ACTALL` arm's `active <= blk_act`
with the pre-mask expression `blk_act_fn(blk_n, lpb, lpb_sh)` - which
is exactly "ACTALL revives a lane the caller masked" in the hardware -
and ran all eleven masked cases (P3's six in `tb/test_seq_core.py`
plus five of my own). **All eleven PASSED.** The reason is structural
and worth the lead's attention: a revived masked lane's DEPOSITS,
COUNTS and SCRATCH-OUT are each held back by their own drain strobe,
which is `mask_lane` and not the active bit, so the defect is
invisible in bytes. The three routes that are NOT behind a drain
strobe are the sticky FLAGS word, the deposit-overflow status bit and
the scratch-range report - and no existing case combines `ACTALL`
with an operation that signals in a masked lane. A case that does
catch it (every lane dropped by SETACT, `ACTALL`, then a MUL that
overflows in the masked lane only) fails the defective build with
`FLAGS 0b10100, model says 0b00000` and passes the shipped one. The
model and the C executor do NOT have this hole: `seq.random_program`
emits `ACTALL`, so `seq_check.py`'s masked corpus covers them, and
P3's control D shows `pytest -k r17` catching it. This is one case
short of complete, not a defect.

**2. The mask's AREA was never measured, and it is not small.**
`yosys` over `rtl/cft_seq.sv` alone (the same file list and the same
`proc; opt -fast` the repository's own `make yosys-lint` runs),
`e0f211f` against `7730187`:

| | cells | $mux | $shift | $shiftx |
|---|---|---|---|---|
| base, `opt -fast`  |  9,823 |  4,792 | 4 |  44 |
| P3,   `opt -fast`  | 28,626 | 22,911 | 4 |  53 |
| base, `opt -full`  |  6,844 |  2,200 | 4 |  44 |
| P3,   `opt -full`  | 10,863 |  5,149 | 4 | 181 |

So **+59% on `cft_seq`'s own cell count after a full opt pass, and
+191% under the flow the project's lint target actually runs.**
`$shift` is unchanged at 4, so P3's "no barrel shifter" comment is
literally true; the cost is mux tree, not shifter. Attribution,
measured by stubbing each half in a copy: replacing `mask_slot_fn`'s
call by all-ones drops 28,626 to 27,985, while stubbing
`mask_blk_fn`'s body drops it to 10,505 - **~96% of the added logic is
`mask_blk_fn`**, the 16-way one-hot beat slice written as
`for j ... if (mbit == j * NBEATS) for t ... v[t] = beat[...]`, which
elaborates to 2,048 per-bit conditional updates in a priority chain
rather than 128 sixteen-to-one selects. For the lead and the card day:
the round's value statement prices ask 5 in cycles and in HBM round
trips, and this is the column it does not have. It is a number, not a
defect - whether it costs anything real is a place-and-route question
and this desktop cannot answer it.

**3. The coordinator's ask (a rule that dereferences a caller's buffer
belongs behind every rule that does not): for a PROGRAM run the mask
is behind the n guard and the index tables are in front of it.**
Measured with a program linked against `libcft` at P3's tip, fp256,
`max_deposits = 8`, `n = SIZE_MAX / 8`, buffers one element long:

- with `lane_mask` set and `lane_mask_bytes = (n + 7) / 8`, the run is
  REFUSED with `CFT_ERR_INVALID_ARGUMENT` and **not one byte of the
  mask is read**. The refusal is `seq_program_run`'s
  `n > SIZE_MAX / max_deposits / esz`, and every backend inherits it
  because the device dispatch is below that line.
- with `idx_a` set instead, `seq_check_round2` walks the table first
  and reads `idx_a[744]` out of an eight-entry array before the same
  guard could fire; here it happened to find a value it could refuse
  by name rather than to fault.

So P3 added nothing of this shape: the mask's byte count is checked as
a VALUE in `seq_check_round2` and its bits are read only in
`seq_program_run`, past the guard. The table walk is P1's, inherited,
and is the program-run twin of what V2 found in P2's `cft_run_ex`. For
the lead, with V2 and P2.

Beside it, and pre-existing: `seq_program_run`'s two early returns
(`!A->a || (!deposits && max_deposits)` and the n guard) return
`CFT_ERR_INVALID_ARGUMENT` with NO `cft_set_error`, so a caller gets a
code and a stale message where the rest of this library refuses by
name. `cft_last_error()` printed empty in both runs above.

**4. The remote route gates the mask on the SERVER's CAPS2[10], and it
does not need to.** `device.c`'s new refusal reads
`dev->seq.features`, which for a remote handle is the SERVER's
capability word; but the client implements R17 entirely by compaction
in `backend_remote.c` and never sends a mask, so a server whose own
device lacks CAPS2[10] (an older bitstream behind `cft-serve`) would
make the client refuse a mask it could honour. It is conservative
rather than wrong, and it is the mirror image of the `FEAT_INDEXED`
mask-off P1 left in the same function - the two now point in opposite
directions for the same reason. **For P2**, which owns the remote
route and will decide what that bit means there.

Everything else I attacked held, including the whole of the remote
compaction (a masked lane at the first and last position of a chunk, a
chunk with every lane masked, a chunk whose kept count is one, a
ragged tail, and a run whose only signalling lane is masked - all
bit-identical to the software backend, FLAGS included, with the
masked lanes' bytes still the caller's). The control for that one is
worth recording because it is the brief's own sketch: with the
compaction removed in a copy (every lane sent, every lane scattered
back), the masked lanes are written AND the run reports
`FLAGS 0x14` where the software backend reports `0` - the masked
lane's overflow in the whole-run word, exactly as P3 argued.

Believed: nothing. Every number above was produced on this desktop.
For: the lead, P2, V2


## 2026-09-15 17:31 USMST — V3 re-checked f79db02: both findings answered, the rewrite is bit-for-bit the old one, and the wrap it introduces is unreadable by construction. Holds.

Measured in the same worktree moved to `f79db02` (one commit over
`7730187`); every number below is from my own run, controls built in a
COPY under the scratchpad and deleted.

**The diff is two files.** `git diff 7730187 f79db02 --stat` is
`rtl/cft_seq.sv` (60 lines) and `tb/test_seq_core.py` (144). Inside the
RTL: `mask_blk_fn` and its comment, the one call site losing its
`blk_n` argument, and the `S_SO_SETUP` header sentence. No host, model,
CSR or `cft_krnl` source moved, so the host gates I ran at `7730187`
stand without re-running.

**1. The ACTALL case catches my control, with the string P3 quotes.**
The `C_ACTALL` arm reading `blk_act_fn(blk_n, lpb, lpb_sh)` instead of
`blk_act`, in a copy: `TESTS=6 PASS=5 FAIL=1`, the failure being
`fp32: ACTALL, then an overflow in the masked lane alone: FLAGS
0b10100, model says 0b00000`. The five that pass under the defect are
the ones that should: `masked_all_ones_is_the_unmasked_run`,
`masked_actall_does_not_revive_a_masked_lane` (the old, byte-level
one), both converged-lane cases and my beat-offset sweep - which is the
hole itself, measured on the new bench and then closed by exactly one
case. P3's version is better than the one I proposed: it asserts the
model's answer for the masked AND the unmasked run before running
anything, so it cannot go vacuous; it adds the `err[3]`
deposit-overflow half I only named; and it runs at three formats.

**2. The area numbers are P3's, reproduced from my own yosys runs**
(the lint target's file list, `proc; opt -fast|-full; stat -top
cft_seq`). I re-measured `e0f211f` today rather than quoting my earlier
run, and it landed on the same two numbers:

| | cells -fast | $mux -fast | cells -full | $mux -full | $shift | $shiftx |
|---|---|---|---|---|---|---|
| `e0f211f` | 9,823 | 4,792 | 6,844 | 2,200 | 4 | 44 |
| `7730187` | 28,626 | 22,911 | 10,863 | 5,149 | 4 | 181 |
| `f79db02` | **10,513** | **4,927** | **7,534** | **2,205** | 4 | 189 |

The mask now costs +690 cells under the lint flow (+7.0%) and +690 at
full opt (+10.1%), against +18,803 and +4,019 before. At full opt it is
**five muxes** over the tile with no mask at all; the `$shiftx` delta
from `7730187` is +8, one per part-select, which is the change doing
exactly what it says. `make yosys-lint` at `f79db02` is rc=0 with no
error and no "not constant" line.

**3. The rewrite's bits are the old bits, and the wrap is unreadable.**
`mask_blk_fn` now fills all eight `NBEATS`-wide slots of `mask_lane`
from `(slot + c) & (BEAT_BITS/NBEATS - 1)`, so a format whose block is
fewer than eight slots gets WRAPPED beat data in the slots above it,
where the old version wrote zeros. That is safe, and the argument is
arithmetic rather than a test result: `blk_base` is a multiple of
`blk_cap = NBEATS << lpb_sh`, so `slot` is a multiple of
`S = blk_cap / NBEATS` and `slot + S <= BEAT_BITS / NBEATS` -
**the slots a block actually needs never wrap**, at any format or
offset, including the last slot of a beat. And no reader looks above
`blk_cap - 1`: `mask_slot_fn` indexes `(b << lpb_sh) + p` for
`b < NBEATS, p < lpb`, whose maximum is exactly `blk_cap - 1` at every
format (127 / 63 / 31 / 15), and `cnt_beat_ok`, `dr_keep1` and
`S_SO_PACK`'s strobe are each bounded by `blk_n <= blk_cap`. (The
commit's own sentence - "nothing reads a lane at or past blk_n" -
covers it, but `mask_slot_fn`'s bound is the sharper reason and is
worth having written down.) Between `blk_n` and `blk_cap` the array
now holds the mask buffer's PADDING, which the bench stages as poison
and `blk_act_fn` zeroes, so the existing cases already stand behind
that half.

Measured as well as argued. My beat-offset sweep at the new tip - fp256
n=272 (seventeen blocks, `blk_base[7:0]` taking every one of 0, 16 …
240 and then crossing into beat 1), fp128 n=288, fp32 n=640 (two beat
crossings), each with a scattered non-periodic mask and each followed
by a ragged tail whose mask byte count is not a multiple of a beat -
passes, and so do two ALL-ONES runs at those shapes, which is where a
wrapped slot reaching an observable would show as a lane that did not
run. `seq_core` 35/35, `krnlseq` 2/2, `seqcycles` 4/4 from clean
builds, each with the checker's line; `seqcycles` is identical to
`7730187` to the cycle in every row (dense 243 / 1,189 / 3,341 / 2,429
/ 2,613 at fp32 and the fp64 and fp128 columns beside it; gathered
3,425 / 1,953 / 1,217 / 849; masked 1,205 / 885 / 725 / 645 with reads
6 -> 10; block setup 60.8 -> 64.8, 44.8 -> 48.8, 36.8 -> 40.8, 32.8 ->
36.8), and `krnlseq`'s simulated time is the same 324,560 ns.

**4. The converged-lane case, from both directions.** P3's version
covers what mine did and asserts one thing more (the converging lanes
and the masked lanes are deliberately different sets). The
`as_strb <= 4'hf` control in a copy gives `TESTS=4 PASS=1 FAIL=3`:
P3's converged case, my own kept beside it, and
`masked_all_ones_is_the_unmasked_run` all fail with
`scratch_out[...] was written`, and the one that passes is
`masked_at_every_block_length`, whose program has no scratch-out. Both
directions still gated.

**A shared-desktop note, for whoever runs a control next.** My first
attempt at the ACTALL control ran the WHOLE bench after
`rm -rf tb/sim_build/seq_core`; the cold Verilator rebuild took forty
minutes against V2's load and then `tb/cocotb.mk`'s own `timeout`
killed the sim - `make[1]: *** [...: sim] Terminated` and
`make: *** [Makefile:564: seq_core] Error 124`, with no `TESTS=` line
at all. **`Error 124` is the target's timeout, not a failing test, and
a run that dies that way prints no verdict**; the build directory
survived it and the warm re-run with a short `TESTCASE=` list finished
in minutes. On this desktop, run a control with the smallest
`TESTCASE=` list that contains the case you are trying to break.

Nothing else in the commit, and nothing I attacked at `7730187` is
changed by it. My four earlier entries stand as written: the ACTALL
item is now answered, the area item is answered, and items 3 (the n
guard, inherited from P1) and 4 (the remote route gating the mask on
the SERVER's CAPS2[10], for P2) are untouched by this commit and still
open.

Believed: nothing.
For: the lead, P2
