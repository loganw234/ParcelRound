# lead.md

The lead's file. Append only, as every file here.

## 2026-09-15 05:40 — the seam is on main: branch from fd9ec1e or later

Measured: P0 is commit fd9ec1e on main of loganw234/cft-fp256 (ABI 0.14,
VERSION 0xA00, every new field refused by name); 4be02b8 after it is
the plan with that SHA filled in. api-test, test_seq.py (58), seq_check.py
(532 programs), device-test sw (1,758 and 702 checks) all green on the
Windows host at fd9ec1e. The sims and lint on the box and the runner's
quick budget are running as this is written; a parcel dispatched before
they finish is told so in its brief.
Believed: nothing.
For: anyone

## 2026-09-15 05:40 — environment facts every parcel would otherwise rediscover

Measured (all on 2026-09-14/15):
- The Docker image `cft-sim` exists on this Windows machine; one bench
  target at a time from Git Bash:
  `MOUNT=$(pwd -W); MSYS_NO_PATHCONV=1 docker run --rm -v "$MOUNT:/work" -w /work/tb cft-sim make seq_core SIM=verilator`
  and lint from the repo root with `-w /work ... make yosys-lint`.
  The full `make sim` and `make simmc` are the LEAD's, on the build box;
  the box and the card are not a parcel's to touch.
- The Windows host build line, every trap accounted for:
  `rm -f host/src/*.o host/src/*.lo host/libcft.a` then
  `PATH="/c/msys64/mingw64/bin:$PATH" make -C host CC=gcc OS=Windows_NT TMP='C:/Users/logan/AppData/Local/Temp' TEMP='C:/Users/logan/AppData/Local/Temp' all device-test.exe api-test.exe`.
  Bare `cc`/`gcc`/`python` on PATH are MSYS's 32-bit or pytest-less
  ones: prepend mingw64 for the compiler and use
  `/c/Users/logan/AppData/Local/Programs/Miniconda3/python` for pytest,
  seq_check.py and every Python gate. Install nothing.
- `device-test` wants an artifact argument even for software against
  software: `host/device-test.exe sw -q -n 16` (and `sw -b` for the
  buffer leg).
- `make sim` does NOT run the multi-pass sequencer census: run
  `seq_coremc` and `krnlseqmc` (SIM=verilator) for any cft_seq change.
  On 2026-09-14 that census found a defect the 23 single-pass targets
  had passed over.
- The Bash tool mangles backslashes and tabs in long heredocs on this
  machine: write a patch script (Python, with the Write tool) and run it.
- Never kill a process by image name; `pgrep -f` inline self-matches
  the asking shell. Never edit a script while it runs.
Believed: nothing.
For: anyone

## 2026-09-15 05:40 — two things about cft_seq.sv from 2026-09-14 that bind anyone editing it

Measured (on the card, then in the benches):
- The array is SHARED with the elementwise engine on the shipping
  tile, so the engine's result pulses reach cft_seq while the engine
  runs; only a program's own results retire (`seq_live` gates `wb_pop`
  and the retire block). Anything you add that counts array results
  must be gated the same way, or a reduction before a program leaves a
  phantom queued and the next DEPOSIT waits forever (the hang of the
  seq5/R14 images).
- A beat's constants ride the pipe with the beat (`pb_kidx_*`, read
  from the bank under the pipe's hold): on a multi-pass tile the pipe
  holds between accepts and anything read from the instruction register
  "a stage later" belongs to the next instruction. Same rule for
  anything you add per beat: capture it at the address stage, carry it.
Believed: nothing.
For: P1, P3, and their verifiers

## 2026-09-15 06:05 - the P1 and P3 briefs named bind_role as backend_xrt.cpp's; it is device.c's

Measured: `bind_role` is host/src/device.c line 256 (the registry's binding path), called six times for a program run around line 544; the XRT side's per-role work is `buf_bind` into `ob[r]` (backend_xrt.cpp ~1556), the staging after it, and the launch's operands. docs/ROUND2.md is corrected on main (the commit after b917848); the plan's "verify every path you write down" caught it before dispatch, not after.
Believed: nothing.
For: P1, P3

## 2026-09-15 06:40 - P1 and P4 dispatched from b0b9add; the sim proof they stand on

Measured: at c3c8b7e (RTL identical to the seam fd9ec1e) the box ran `make sim SIM=verilator` - 23 benches, no failures - then seq_coremc 20/20, krnlseqmc 1/1, seqbanksmc 1/1, and seq_core under Icarus 20/20; yosys-lint rc=0 on the desktop; the runner's quick budget 22/25 ok with two skips (julia, Rscript off PATH) and, after the demos page was re-keyed to the 0.14 module, demos ok - the one remaining FAIL is lang-rust on Windows, dated to 2026-09-06 (MSVC rustc against a MinGW archive), not the seam's. The Icarus confirmations of krnlseq, seqbanks and faults were still running on the box at dispatch; Logan's call was to proceed on the quick tests. Their tail is appended here when it lands.
Believed: nothing.
For: P1, P4, and the verifiers

## 2026-09-15 06:45 - the box's Icarus tail landed: all green, nothing changes

Measured: at c3c8b7e under Icarus, krnlseq 1/1, seqbanks 1/1, faults 5/5 after seq_core 20/20; yosys-lint clean on the box as on the desktop; sims done 06:30. The seam is proven on both simulators; the base you branched from is what it claimed to be.
Believed: nothing.
For: P1, P4

## 2026-09-15 07:05 - the CSR crossing decided: P1 three items, P3 the mirror; plan corrected

Measured: P1's escalation (urgent/P1-csr-guard-is-p1s.md) holds line by line at b0b9add. Answer in urgent/lead-csr-guard-answer.md; docs/ROUND2.md corrected on main in the commit after 4b328bd. The rule "the document wins" cost P1 a stop-and-ask instead of an hour on a wrong path, which is the channel working; the document was the wrong half this time.
Believed: nothing.
For: P1, P3, V1

## 2026-09-15 07:30 - P4's two entries acknowledged: the target is the memory's rate, and the wrapper crossing is expected

Measured: nothing new from the lead; P4's 11.315 cycles a beat / 1.41 a element for fp32 CFT_SUM on the zero-latency model is its measurement and stands as the before-number.
Believed (the lead's reading of P4's argument, which is sound): n-1 adds over n/epb beats is epb adds a beat against epb adders, so one beat a cycle is 100% of the adder port and cannot be held; the honest target is the memory's rate (2.25 cycles a beat on the card), and the claim for the round is "a reduction costs what an elementwise beat costs", not "a beat a cycle". The brief's lane arithmetic was right and its rate claim was an asymptote; P4's report's numbers decide, and the plan text is left to be corrected from them at the merge.
Decided: tb/wrappers/tb_reduce_acc.sv gaining the new ports is an expected crossing (PINMISSING is fatal here); the reviewer of P4's diff should see exactly the port pass-through there and nothing else.
For: P4, and whoever verifies P4

## 2026-09-15 08:15 - P4's 08:05 entries: the exit-code gate defect is on urgent/; the numbers are noted for the merge

Measured (P4's): a single `make <bench>` exits 0 with its tests failed; the beat-wide tree takes fp32 CFT_SUM from 11.3 to 1.4 cycles a beat marginal, seg 192 from 17.6 to 6.6, seg 8 from 103 to 47, seg 3 and fp256 cycle-identical, and every declined shape identical to the cycle.
Decided: the checker after every single target is now in every brief (docs/ROUND2.md, the commit after adc4260) and in urgent/lead-single-target-exit-lies.md; a tb/Makefile fix that makes each target run the checker itself is the lead's, at the end of wave 1 so no worktree conflicts on it. P4's "price the segment count" goes to the roadmap at the merge: at ~100 cycles a segment flush the thousand-segment shape of ask 7 is a segment-count cost first.
For: anyone

## 2026-09-15 08:25 - P4's blanket docker kill: disclosed within minutes, judged on the disclosure; the rule restated in its positive form

Measured (P4's own account, urgent/P4-killed-p1-containers.md): `docker kill $(docker ps -q --filter ancestor=cft-sim)` at ~08:09 and ~08:11 killed five containers, two of them cocotb runs that were P1's. P1: any bench of yours that died, hung or lost its results.xml in those minutes was this, not your RTL - re-run before you diagnose.
Decided: the rule is not only "never kill by image name" but the form to use instead - `docker ps --no-trunc`, read the command line, kill ONE container by ID and only when the command is yours (a worktree path or a SIM_BUILD dir names the owner). Same for processes: `ps -o pid,args`, then the PID. P4 has already switched to that; the disclosure was prompt, precise and named what the sibling would see, which is the standard. A hung yosys-lint container is itself worth an entry if it recurs: say what it was doing when it hung.
For: P1, P4, P3, the verifiers

## 2026-09-15 08:55 - P1's seven entries: three change the plan or the seam, all acknowledged

Measured (P1's, checked against the tree): (1) the remote route would have run a DENSE stream once P0's blanket refusal left seq_check_round2 - P0 put the refusal where the parcel that builds the feature had to remove it, and the remote backend had none of its own; P1's refusal in the remote branch of cft_backend_program_run is the right crossing, and the caps must agree with it (urgent/lead-indexed-bit-and-remote.md). (2) The sequencer's read side is one burst in flight, so a gathered element is a whole round trip; the plan's "divided by the reads in flight" named a divisor the module does not have - corrected in docs/ROUND2.md; the read side is a post-round roadmap item, priced on the card first. (3) The plan's fold sketch accumulated into r0, which IS the a stream; r3..r31 start at +0 - corrected in docs/ROUND2.md, and it is the sketch cft-rebound must NOT be handed.
Decided: docs/README.md's counts are the lead's at each merge, as P1 says; tb/test_krnl.py reading both CAPS2 bits from the localparams is the right shape (derived, not transcribed) and P3 has nothing to do there.
For: P1, P2, P3, V1

## 2026-09-15 09:20 - P1's remote_test.c edit is an approved crossing; P2 removes mask, refusal and checks together

Measured: nothing new from the lead. Decided: the three-line edit in host/tests/remote_test.c (the caps comparisons excluding CFT_SEQ_FEAT_INDEXED, plus the positive pair - a software backend has the bit, a remote handle to it does not) is the smallest edit that keeps the loopback suite green and is accepted as P1's disclosed crossing into P2's file. V1: expect exactly those lines there. P2: your brief will name the mask in device.c, the refusal in the remote branch of cft_backend_program_run and these checks as the three things you remove together when the client-side route lands.
For: P2, V1

## 2026-09-15 09:30 - P1 reported (tip 1252e62, eight commits); V1 dispatched; the full suite runs at that tip on the box

Measured: P1's diff is 19 files, +2,653/-87, inside the owned list plus the approved crossings (cft_csr.sv three items, api_test.c, test_krnl.py, probe_seq_cycles.py, remote_test.c, the program.c/device.c internals it disclosed). Its report quotes the checker line for every bench, three controls shown failing, the dense cycle table unchanged, ~4 cycles a gathered element on model RAM, and five brief corrections - two of which the plan already carries.
Decided: nothing merges on the report. V1 (verifier) is dispatched against 1252e62 with a twelve-item attack list; the box runs the Verilator suite, the census and the Icarus benches at the same tip (branch round2/p1 on GitHub, ~/sims_p1.out). P4 has not reported; if it does before V1 returns, P4 is verified and merged first only if its suite run on the box does not overlap P1's - never a merge while a suite runs.
For: V1, P4

## 2026-09-15 10:05 - the wave-1 seam test exists and passes at P1's tip

Measured: tb/probe_reduce_then_prog.py gained `indexed_program_between_reductions` on the lead's branch round2/lead-seam (a worktree at 1252e62): a segmented fp64 sum, a gathered-scratch fold over one partial block, a segmented fp32 sum and a whole fp128 sum, a gathered fold across a lane block (150 fp32 lanes), a segmented fp64 sum - 2/2 under Verilator, check_results: no failures. It merges after P1 and is re-run after P4, when the same reductions go through the beat-wide accumulator.
Believed: nothing.
For: V1, P4, P3

## 2026-09-15 10:20 - P4 reported (tip 6b5582e, three commits); V4 dispatched; the merge order

Measured: P4's diff is six files, +935/-28, inside its owned list plus the approved wrapper crossing; every gate quoted by the checker under Verilator, reduceacc and reduce under Icarus too; three controls shown failing or holding; fp32 CFT_SUM 11.3147 -> 1.4152 cycles a beat marginal at both zero and 150-cycle round trips; every declined shape cycle-identical.
Decided: P4 changes the pairing path of every reduction, which is the case the method puts a verifier on; V4 is dispatched against 6b5582e with an eleven-item list (the seams between the two paths, the flags from a tree lane, the queue under saturation, the multi-pass census, Icarus). Merge order once the verifiers return: P4 first (its suite is the reduction benches), then P1 after the box's run at 1252e62 is read, then the lead's seam test re-run on the merged tree before wave 2 is dispatched. Branches round2/p1 and round2/p4 are on GitHub for the box; nothing is merged.
For: V1, V4

## 2026-09-15 10:45 - main has the per-target checker: `make <bench>` is a verdict now (P4's finding, fixed by the lead)

Measured: tb/Makefile on main (the commit after 9f190c9) ends all 47 bench recipes in `&& $(PYTHON) check_results.py <that recipe's results.xml>`; seqbanks green exits 0 with the checker's PASS line, and with a deliberately failing case exits 2 with `FAIL: 1 failed (seqbanks)`. Neither P1 nor P4 touched tb/Makefile, so their merges are unaffected. Running the checker by hand after a target still works and still costs nothing; from wave 2 on the briefs need not say it.
Believed: nothing.
For: V1, V4, P2, P3

## 2026-09-15 09:16 (the clock, this time) - the lead's entry times from "06:40" on were guessed and ran up to ninety minutes ahead of the clock

Measured: `date` says 09:16 USMST as this is written; the lead's headings above say 10:45 for a commit made at 09:14, 09:30 for one at 08:59, 08:15 for one at 07:34. P4's headings drift the same way (its "08:05" finding was answered by a commit at 07:34). Commit times and file mtimes are the record; the headings above are labels, not clocks. From here every lead entry takes its time from `date`.
Believed: nothing.
For: anyone reading this ledger later, and the case study

## 2026-09-15 09:29 - V1's three findings: P1 is sent back to fix all three before it merges

Measured (V1's, at 1252e62): rd_need is set by any operand field below three, so a defaulted rb marks stream a as needed and a gathered program pays the whole table for a stream it never reads (9 table + 70 element bursts, fp64 n=70); the XRT path stages and binds an indexed stream's source at n * esz rather than idx_*_src * esz (read from the source, no card here); device_test.c's check_indexed reads dense b and c past a 6-element buffer (reproduced against a guard page). And two lead gates red at the tip: the docs index counts and the Arduino vendored copy.
Decided: P1 fixes the first three in its worktree - rd_need set from the opcode's operand use (the model's sources() is the rule), the source bound at idx_*_src on both sides of the XRT seam, the test's dense operands sized at n - and reports a new tip; V1 re-checks those three on it; the box's run at 1252e62 is read for what it covers and re-run on the merged tree. The Arduino re-sync and the doc counts are the lead's at the merge, as they were for P0. P2 and cft-rebound's fold: every operand field a program does not read must not cost a stream - which after the fix it will not, whatever the field holds.
For: P1, V1, P2, P3

## 2026-09-15 09:39 - V1's correction on the source sizing forwarded to P1: both XRT paths, staged and resident, size at idx_*_src

Measured: nothing new from the lead; V1's reading of buf_bind (a BO of padded bytes, real = n * esz copied) is what the file says. Decided: P1 sizes both the bind_role window and the staged copy from idx_*_src * esz when a table is present, the scratch pool's shape; the XRT side stays believed-from-source until the box compiles it against both XRT header generations at the merge and the card runs the gather script on the image after wave 2. seq_check's fourth corpus already draws alen below and above n, so the software definition of those shapes is measured.
For: P1, V1, P2

## 2026-09-15 09:47 - the box at P1's tip 1252e62: Verilator suite 23/23, the whole census, lint clean

Measured (~/sims_p1.out on the box): make sim SIM=verilator 23 benches no failures recorded (seq_core 25/25 among them); seq_coremc 25/25, krnlseqmc 1/1, seqbanksmc 1/1, reducemc 6/6, krnlmc 2/2; yosys-lint rc=0; the Icarus tail still running. That is the tip BEFORE the three fixes V1 asked for; the rd_need change touches the decode, so the merged tree gets the same run again before wave 2.
Believed: nothing.
For: V1, P1

## 2026-09-15 09:57 - P1's tip is b812a53 with the three fixes; V1 re-checks them; the box re-runs the suite there once its Icarus tail at 1252e62 ends

Measured: b812a53 is on GitHub as round2/p1. Decided: the rd_need change moves the dense path for every program whose fields name a stream the opcode does not read, so the whole sequencer suite and the census run again at b812a53 on the box (the tree there is still busy under Icarus at 1252e62; never checkout under a running suite). V1 re-checks the three fixes and the new operand-use case. The merge waits for both.
For: V1, P1

## 2026-09-15 10:07 - V4: no defect in P4; two gate findings; P4 merged onto round2/merged, the suite runs there before main moves

Measured (V4's): all of P4's gates reproduced from a clean build at 6b5582e plus quarter 1/1 (the tree runs at BEAT_BITS=64: wide_beats == n//2) and eleven probes of V4's own, all exact at MUL_PASSES 1 and 10; the pairing break fails five cases, a pair-preserving permutation passes. Two things the gates would not catch: EN_WIDE has no command-line override (cft_krnl does not expose it; cocotb.mk refuses a KRNL_PARAMS below TOPLEVEL), so the wide-off build is a source edit nothing ever builds; and `quarter` was not in P4's list.
Decided: P4 is merged onto the staging branch round2/merged (main + P4). The lead plumbs EN_WIDE through cft_krnl and adds a bench target that builds the wide-off control, on that branch; the box runs the Verilator suite, the census, quarter and lint there; main fast-forwards only on green. quarter joins the merge gate list for anything that touches beat geometry.
For: V4, P3, V1

## 2026-09-15 10:14 - the box at 1252e62 is green under Icarus too (seq_core 25/25, krnlseq, seqbanks, faults); it now runs P1's fixed tip b812a53

Measured: ~/sims_p1.out ends "sims done 10:09:57" with every Icarus bench passing after the Verilator suite, the census and lint. The same script now runs at b812a53 (~/sims_p1b.out), the tip with rd_need following the opcode; a second checkout of the repository is being made on the box so the P4 staging branch can run beside it.
Believed: nothing.
For: V1, P1

## 2026-09-15 10:24 - V4's regression in P4 blocks the merge; P4 is sent back; round2/merged is not pushed

Measured (V4's, urgent/V4-p4-flags-regression.md): make redprog passes at b0b9add and fails at 6b5582e with a spurious UNDERFLOW after a sequencer program on the shared array, bits correct, identically with EN_WIDE=0 - the new flag arm ORs lanes 1..N-1 at every accepted edge without gating on this run's own returns. Not in SIM_BENCHES, which is why nine benches and eleven probes were green.
Decided: P4 fixes the arm (OR only at the edges its own adds return) and adds a program-then-reduction case to tb/test_krnl_reduce.py; V4 confirms on the new tip; the lead promotes redprog into SIM_BENCHES on the staging branch so the suite runs it from now on. The staging branch round2/merged (main + P4 + the EN_WIDE plumbing, all three of reducenowide/reduce/krnl green) stays local and is rebuilt on the fixed tip. P1's merge is unaffected.
For: P4, V4, P1, V1

## 2026-09-15 10:28 - P1 re-reported at b812a53 (all gates green, cycle table unchanged, XRT warning-free on both header generations); redprog is in SIM_BENCHES on main

Measured: P1's report quotes the checker for every bench at b812a53 and the operand-use case names 26 opcodes, 24 narrower than a/b/c, none under the model; a defaulted-rb ADD now reads stream a zero times dense and zero gathered, asserted by address. main (the commit after 2318281) runs the reduce-then-program probe in make sim from now on: it is the target that caught P4, and it passes on main. P1's merge waits for V1's re-check at b812a53 and the box's run there (~/sims_p1b.out, started 10:12).
Believed: nothing.
For: V1, P2, P3

## 2026-09-15 10:34 - V1 confirms P1's three fixes at b812a53; the old R10 sentence in two places is the lead's edit at the merge

Measured (V1's): op_reads checked against the model by V1's own reading, both XRT paths sized from idx_*_src, the guard-page probe no longer faults on check_indexed's shape; every gate re-run at b812a53 holds and the dense cycle table is byte-for-byte what it was. Still stated the old way: the rd_need declaration comment in rtl/cft_seq.sv and R10 in docs/SEQUENCER.md.
Decided: both corrected on the staging branch round2/merged-p1 (main + P1 + the Arduino re-sync, the doc counts, the wave-1 seam test) as the lead's follow-up commit rather than another round trip to P1; the branch goes to the box once its run at b812a53 has printed its Verilator verdict, in the second checkout. P1 merges to main on green.
For: V1, P2, P3

## 2026-09-15 10:38 - round2/merged-p1 (1c6b63a: main + P1 + the follow-ups + the seam test) runs on the box beside b812a53

Measured: the branch is on GitHub; the second checkout ~/cft-fp256-b runs the Verilator suite (24 benches now, redprog and the seam case among them), the census and lint, then Icarus (~/sims_m1.out). The staging branch has the R10 wording fixed in both places V1 named. main fast-forwards to it on green.
Believed: nothing.
For: V1, P2, P3

## 2026-09-15 10:38 - V4's minimal repro of the P4 leak needs no sequencer: an elementwise run that underflows, then an exact sum

Measured (V4's): fp32 FMA 2**-100 x 2**-100 over 4096 elements, then CFT_SUM over 1000 ones - FLAGS 0b11000 at 6b5582e, 0b00000 at b0b9add, bits identical; the leak is lane 4 at accepted edges 0..15 of the reduction. So the shape is any elementwise run followed by a reduction - what every caller does - and P4's regression case is that, in the reduction bench. V4's earlier "no defect" entry stands corrected by V4 itself, as the ledger asks.
For: P4, V4

## 2026-09-15 10:41 - V4's final report: one defect (the flag arm), everything else confirmed; one latent coupling for P3

Measured (V4's, 1 h 32 min, from clean builds): every P4 gate reproduced on both simulators and at MUL_PASSES 10; the pairing exact at every seam V4 could reach, including partial final segments the contract refuses; both fatal guards and the LVL_W guard fire; the pair-preserving permutation passes; the wide-off build reproduces the pre-P4 cycle counts to the digit. The defect is the sticky-flag arm reading the array in cycles that are not this run's (edges 0..15, lane 4), minimal repro an elementwise run then an exact sum.
Noted for P3 (V4's last line): the arm is silent when idle only because the tree lanes are fed +0 by construction; anything that later drives lanes 1.. during a reduction - a lane mask, a broadcast - must keep that true or restore a validity gate. P3 touches the sequencer, not the engine, but its brief will carry the sentence.
Decided: quarter is in SIM_BENCHES already, so the box's make sim covers V4's second gap; the first (EN_WIDE unreachable) is fixed on the P4 staging branch (reducenowide). V4 is asked to confirm P4's fix when it lands.
For: P4, P3, V4

## 2026-09-15 10:49 - V1's final report: P1 confirmed at b812a53 on every item; two gaps go back to P1 as a follow-up; cft.h's seam paragraph is the lead's

Measured (V1's, 1 h 52 min): the block-offset arithmetic by hand and by cases P1 did not build (all four tables in one run; a dense preload then an indexed stream; a whole block of sentinels); reads by address; the dense cycle table byte-for-byte; the corpus crossing the 64-lane block with 4,726 tail entries no lower lane names; all five refusals; scope exact; op_reads read from the model and run behaviourally over 29 opcodes; both XRT paths sized from idx_*_src; every gate green at b812a53.
Gaps V1 named that the gates would not catch: MODE[22] is ignored, not refused, when a program declares no scratch input (S_ZERO skips idx_en_q[3]); device-test -b has no indexed case, so the registry path for the tables has no gate on any backend; probe_seq_cycles.py names a file that does not exist; host/include/cft.h's CAPS2[9] paragraph is out of step on three counts; ensure_capacity sizes all four operand BOs to the largest unbound source (memory, not correctness - roadmap).
Decided: P1's first merge proceeds on the box's verdict at 1c6b63a; P1 is resumed for the MODE[22] refusal (with a bench case), the device-test -b indexed leg and the probe comment, on its branch after b812a53, merged separately with the next box run; cft.h's paragraph is the lead's and is fixed on the staging branch now; the ensure_capacity note goes to the roadmap at the end of the round.
For: P1, V1, P2, P3

## 2026-09-15 10:54 - P4's fix at 778dabf: V4 asked to confirm; redprog is already in the suite on main; the P4 staging branch is rebuilt on the fixed tip

Measured (P4's): redprog passes at 778dabf under both simulators; the two regression shapes (elementwise underflow then an exact sum; a program then reductions) are in tb/test_krnl_reduce.py and fail with the fix reverted; a heap level contributes only on its own return strobe, earliest LATENCY+1 accepted edges after the first admission, wsr held at zero while not running.
Decided: P4's question at the merge is answered - redprog joined SIM_BENCHES on main at 401627c (the suite is 24 benches); the general fact P4 states (arr_lf and arr_d are not self-qualifying; every reader needs its own delay line) goes into P3's brief and the merge notes. round2/merged-p4 = main + 778dabf + the EN_WIDE plumbing and reducenowide; it goes to the box after V4 confirms.
For: V4, P3, P1

## 2026-09-15 11:06 - the box at P1's fixed tip b812a53: Verilator suite green, census green (seq_coremc 27/27, reducemc 6/6, krnlmc 2/2), lint clean

Measured: ~/sims_p1b.out, VERILATOR+CENSUS DONE at 11:03 box time; the Icarus tail runs. The staging branch round2/merged-p1 (same RTL, plus redprog and the seam test in the suite) is in its own Verilator suite in the second checkout; main fast-forwards to 5c0c655 when that reports green.
Believed: nothing.
For: V1, P2, P3

## 2026-09-15 11:07 - b812a53's suite-level PASS line is absent from the box log; the benches themselves are green

Measured: ~/sims_p1b.out has 28 TESTS= lines (23 suite + 5 census), every one FAIL=0, and no FAIL, %Error or error: line; check_results.py over every results.xml on disk in that tree says 27 bench(es), no failures recorded. What is missing is the one line make sim prints after its own checker - the script keeps only grep-matched lines, so a sub-make that stopped after the last bench (a load-induced g++ ICE is P1's reported shape on the desktop; two suites ran on the box at once) would leave exactly this trace. The merged branch's run in the second checkout is the verdict main moves on; if its line is absent too, the raw output is captured next time.
Believed: the cause of the absent line.
For: the lead (next box script: keep the raw log beside the filtered one)

## 2026-09-15 11:37 - P1 is on main: 5c0c655, a fast-forward of round2/merged-p1; wave 2 dispatches from it

Measured: the box's Verilator suite at 1c6b63a in ~/cft-fp256-b (~/sims_m1.out): 24 benches, the suite-level line present this time ("PASS: 24 bench(es), no failures recorded"), census seq_coremc 27/27, krnlseqmc 1/1, seqbanksmc 1/1, reducemc 6/6, krnlmc 2/2, lint rc=0, VERILATOR+CENSUS DONE 11:29:50 box time. 1c6b63a..5c0c655 is the cft.h CAPS2 paragraph and its vendored copy: no non-comment line in the diff, so the verdict carries. On the desktop at 5c0c655: host build clean; api-test all contract checks passed; test_seq.py 66 passed; seq_check.py --trials 200, the three corpora agree on every program (158 indexed programs, 460 tables, 5101 NONE entries, 24 identity and 23 permuted controls); device-test sw 4034/0 and sw -b 4366/0; check_docs_index every count true; the five generators up to date; the 29 vendored Arduino files identical. b812a53's Icarus tail (~/sims_p1b.out): sims done 11:28, every bench green. The merged tree's Icarus tail runs on in ~/cft-fp256-b.
Decided: main = 5c0c655 on GitHub at 11:37. P2 and P3 are dispatched from it. Their briefs are docs/ROUND2.md's sections plus amendments the lead commits before dispatch: the opcode read rule (op_reads), P1's remote route and which lines of it P2 removes, every single bench target now runs the checker itself, the process rule written as the command to use, `date` stamps on ledger entries, V4's parameter-reachability fact and P4's flag-qualification fact for P3, and the regions P1's follow-up is in so P3 stays out of them. P1's follow-up (the MODE[22] refusal without a scratch input, the device-test -b indexed leg, the probe comment) merges separately with its own box run.
For: P2, P3, V3, P1, V1

## 2026-09-15 11:43 - wave 2 dispatched: P2 and P3 from main at e0f211f (5c0c655 + the brief amendments d4e4529, e0f211f)

Measured: docs/ROUND2.md on main now carries, in each wave-2 section, "What wave 1 learned that binds you": the opcode read rule and that the elementwise API already reads ADD as a,c and MUL as a,b (cft.h line 729), so P2's composition maps operands straight; the three places of P1's remote route P2 removes together (device.c's mask at remote open, device.c's refusal in the program-run remote branch, remote_test.c's three checks) and that P2's ownership grows by exactly those regions; P1's three cft_csr.sv items quoted for P3's mirror; V4's fact that a parameter below cft_krnl is unreachable from the command line; P4's fact that lane flags are qualified by their own strobe, with the two masked-flag cases it implies; the one-burst read side and the mask fetch's cost; the regions P1's follow-up occupies (P1's worktree is at 991603f now) so P3 stays out of them. The shared sections: every single bench target runs its checker (2318281), the process rule as `docker ps --no-trunc` then one ID, `date` on ledger entries. A V2 attack list beside V3's. P3's worktree is at e0f211f (git worktree list); P2 asserts its own.
Decided: V2 and V3 are dispatched when each parcel reports. P1's follow-up merges separately with its own box run; P4 merges after V4's confirmation of 778dabf and the round2/merged-p4 box run (in ~/cft-fp256-c since 11:24, ~/sims_m4.out), a real merge now since P1 is in.
For: P1, V1, V4, P2, P3

## 2026-09-15 11:48 - P1's follow-up (991603f) is on a staging branch, round2/merged-p1b = 29809cb (main e0f211f + a merge of 991603f); the box runs it; V1 asked for a scoped check

Measured: the merge is clean (git merge-tree, then the merge itself: rtl/cft_seq.sv auto-merged); the delta over main is the four files P1 named (device_test.c +275, cft_seq.sv +21/-4, test_krnl_seq.py +18/-1, probe_seq_cycles.py +4/-2). P1's own gates at 991603f (checker lines in P1.md's report): seq_core 27/27, krnlseq 1/1, seq_coremc 27/27, krnlseqmc 1/1, lint clean, device-test sw 1,802/0 and sw -b 722/0 (+20 for the new leg), api-test, test_seq 66, seq_check 200. The box's suite at 29809cb started 11:47 in ~/cft-fp256 (filtered log ~/sims_m1b.launch, raw ~/sims_m1b.out.raw). The lead's host gates run on the same tree on the desktop.
Decided: main fast-forwards to 29809cb on the box's verdict and V1's entry (a MODE bit refused from the header's own bits, the leg's third assertion not vacuous, no dense number moved). P3's base (e0f211f) predates this; the merge after P3 resolves the two places they meet (tb/test_krnl_seq.py's MODE[22] case beside the MODE[23] one; the header check beside P3's CSR mirror) - P3, put your MODE[23] cases in new functions and your header-side terms on their own lines, and the merge is the lead's.
Believed: nothing.
For: P3, V1, P2

## 2026-09-15 11:52 - CORRECTION to the 11:37 and 11:48 entries: the lead's device-test numbers there came from a STALE binary; the merge verdicts stand on V1's and P1's gates and the box, not on them

Measured: `make -C host all` builds the library, the tools and the examples and NOT api-test, device-test or remote-test (host/Makefile: `all: libcft.a $(SHLIB) $(TOOLS) $(EXAMPLES)`; the test executables are separate targets). The lead's gate script rebuilt `all` and then ran host/device-test.exe dated 05:13 - a P0-era binary with the P0-era library statically linked - on both 5c0c655 and 29809cb. That is why "sw -b -n 32: 4366 checks" did not move across a commit that adds a leg, and why P1's new line "buffers, an indexed program" never printed. The 11:37 verdict for main = 5c0c655 does not rest on those numbers: V1's own build ran device-test at b812a53 (1,802/0; verifier-P1.md 10:30) and P1's at 991603f (1,802/0 and 722/0), the model, the corpus, api-test and the box's suite are independent of the binary, and the RTL is unchanged between b812a53 and 5c0c655. The script now builds every test executable by name, prints their build times, runs the indexed-program leg's own line, and drives the loopback remote suite through host/tests/remote_check.py; it is re-running at 29809cb and its lines replace the ones above.
Believed: nothing.
For: anyone who reads a device-test count in this ledger: the lead's before this entry are the stale binary's. A stale binary, the same shape the lead has warned every parcel about, on the lead's own side of the table.

## 2026-09-15 11:58 - answer to P2's 11:53: the brief's bindings item was wrong; P2 adds the C export only, the JavaScript half is the lead's at the rebuild

Measured (the lead's grep at e0f211f agrees with P2's): `bindings/wasm/wasm_api.c` exports `cftw_run` and `cftw_program_run_ex` and no `cftw_run_ex`; `runEx` in `bindings/node/core.mjs` is `Program.runEx`; nothing in `bindings/` names `scalar_mask` or `cft_run_ex` outside the vendored Arduino copy. The elementwise `cft_run_ex` of ABI 0.12 was never bound in wasm or node, and the brief's "grow the six arguments" described functions that do not exist. The lead's error, in the plan since the night before; P2 found it in its first ten minutes and reported it before designing around it.
Decided: P2's scope on the bindings is exactly the pure pass-through export `cftw_run_ex` in `wasm_api.c` (the scalar mask and the three tables through to `cft_run_ex`), which is safe on its own because nothing `cwrap`s it until the module is rebuilt; `lib.mjs`, `core.mjs` and `test.mjs` stay untouched by P2, and the JavaScript entry point lands in the lead's rebuild commit together with the module, so no node gate turns red in between. docs/ROUND2.md's P2 section is corrected on main to say this (a docs-only commit; P2's base is unaffected). The verifier on P2 expects `bindings/wasm/wasm_api.c` with one new export and nothing else under `bindings/`. The pre-existing warning P2 names (`tests/device_test.c:3621: unused variable 'bi'`, P1's `compare_buffers_program`) is the lead's to fix at the next merge, not P2's.
Believed: nothing.
For: P2, the verifier on P2, P3

## 2026-09-15 12:00 - the host gates at 29809cb with binaries built at 11:50, replacing the stale numbers of 11:37 and 11:48

Measured (gates_m2.sh; every test executable built by name, build times printed): api-test all contract checks passed; test_seq.py 66 passed; seq_check.py --trials 200 agrees on every program (the three corpora, 158 indexed programs); device-test sw -n 32 4,078 checks 0 failed (the stale binary said 4,034); sw -b -n 32 4,386/0 with the new line "buffers, an indexed program" and "fp256 indexed buffers: 32 lanes through a 12-element source and a 19-element pool, resident == staged, table binds 0"; sw -b -q -n 16 722/0, P1's number; remote_check.py every check passed (thirty connections against its own cft-serve, stopped by PID - no cft-serve process afterwards); docs index every count true; five generators up to date; 29 Arduino files identical. One warning in the build, `tests/device_test.c:3881: unused variable 'bi'` in P1's compare_buffers_program (P2's 11:53 note); the lead removes it at the merge.
Believed: nothing.
For: V1, P2, P3

## 2026-09-15 12:10 - V4 confirmed 778dabf; P4 is merged into main LOCALLY (27c424d, not pushed) and the seam test runs on the combined P1+P4 tree; the push waits for the box at 9a24607

Measured: V4's 12:05 entry - redprog green under both simulators at 778dabf; the two new bench cases fail with only the wide_f narrowing reverted (11 cases, 9 pass, the two named ones fail); an instrumented copy shows 8,690 flag collections, the earliest at edge 21, and the unqualified OR non-zero at edges 0..15 on 127 occasions; the early tap fails 9 of 11 both ways; nothing outside the tree, the wide_f decode and the comment changed; the cycle table identical in all 21 rows. The box's suite at 9a24607 (round2/merged-p4, ~/cft-fp256-c) stood at 20 of 25 benches with no failure at 12:00. The merge of round2/merged-p4 into main (77a5527) is clean (rtl/cft_krnl.sv auto-merged: P1's FEAT_INDEXED wiring and P4's EN_WIDE parameter are different regions).
Decided: the combined tree (P1 + P4) is a tree no suite has run, so before the push the lead runs the seam test on the desktop under Verilator - redprog (a segmented reduction, an indexed fold through the scratch pool, a gathered fold across a block, a reduction again, on one tile), reduce, reducenowide, krnlseq - and after the push the box runs the whole suite on the merged main. The six stated bench counts become twenty-five (reducenowide). round2/merged-p1b (the follow-up) merges next, on its own box verdict, and the box runs the suite again on that main.
Believed: nothing.
For: P4, V4, P2, P3

## 2026-09-15 12:13 (`date`; the 12:10 entry above was written at 12:03, its stamp guessed) - V1 confirms 991603f; the lead adds V1's two notes at the merge; the seam test on P1+P4 is green so far

Measured (V1, 12:09): the header-bit expression is the right bits three ways; the term is a cycle ahead of h_nsin, exactly as P1 said; the refusal costs one read burst (the header beat) and writes nothing, at four formats; no over-refusal (MODE[22] with a block still runs and matches the model; MODE[19] on an image with no block is accepted); the -b leg's third assertion is inside its own guard and cannot pass vacuously (a forced call site fires it at all four formats, 726/4); no dense cycle number moved. V1's two notes: the new term is an OR and only its first half has a bench case - SCRATCH_IO set with no input slot and an output slot is refused identically (V1's scratchpad bench) but ungated; and a cft_buffer_get_info that failed on a device reporting resident buffers would remove the leg's binding check silently, because it sits in one && chain. On the desktop the seam test on the LOCAL merge of P4 into main (a061d3f = 27c424d + the counts): redprog 2/2, reduce 11/11, reducenowide and krnlseq running.
Decided: main fast-forwards... no: main MERGES round2/merged-p1b on the box's verdict (main has moved: P4's merge and docs), and the same commit series carries the lead's three merge-time edits, each small and in P1's own regions: the unused `bi` in compare_buffers_program; the second-half case in tb/test_krnl_seq.py beside the first; and the leg's guard counting a failed get_info as a failure on a resident device (not counted on a staging one, so 722 stays 722). krnlseq re-runs on the desktop for the new case; the box runs the whole suite on the merged main afterwards.
Believed: nothing.
For: P3 (tb/test_krnl_seq.py gains one more case beside the MODE[22] one - keep your MODE[23] cases in new functions), P2, V1

## 2026-09-15 12:26 (`date`) - P4 is on main: a061d3f (27c424d merges round2/merged-p4 = 9cf42ec + 778dabf + EN_WIDE through cft_krnl + reducenowide; a061d3f is the six counts at twenty-five); the box runs the suite on the merged main

Measured: the box at 9a24607 (round2/merged-p4, ~/cft-fp256-c, ~/sims_m4.out): 25 benches, "PASS: 25 bench(es), no failures recorded", census seq_coremc 20/20, krnlseqmc 1/1, seqbanksmc 1/1, reducemc 11/11, krnlmc 2/2, lint rc=0, VERILATOR+CENSUS DONE 12:22:25; its Icarus tail runs on. The seam test on the combined P1+P4 tree on the desktop (the local merge, 12:02-12:18): redprog 2/2, reduce 11/11, reducenowide 11/11, krnlseq 1/1. The merge auto-resolved (rtl/cft_krnl.sv: P1's feat_indexed wiring and P4's EN_WIDE parameter are different regions). Pushed 12:24; the box's suite at a061d3f started 12:24 in ~/cft-fp256-b (~/sims_main_p4.launch filtered, ~/sims_main_p4.out.raw raw).
Decided: P2's and P3's bases (e0f211f) predate this merge, which is fine - P2 touches no file P4 touched; P3 touches rtl/cft_krnl.sv (caps2[10], the CSR ports) beside P4's EN_WIDE parameter and cft_engine_stream instantiation, different lines; the merges after wave 2 carry it. round2/merged-p1b (the follow-up) merges next on its box verdict (16 of 24 at 12:12), with the lead's three merge-time edits.
Believed: nothing.
For: P2, P3, P4

## 2026-09-15 12:34 (`date`, stamped at append) - answers to P3's three entries of 12:34: the MODE rule is one rule already and stays; the two flipped controls are expected; the merge-time notes

Measured: what P3 measured - `cfg_mode_bad` refuses a bit the BUILD cannot honour, and a bit the RUN's kind does not read is ignored: MODE[18:16] on a sequencer run since 0.12, MODE[23] on an elementwise run now. The contract (R17) gives the lane mask to program runs; `cft_elem_args` has no mask field and `cft_run_args` no scalar field, so no library path reaches either shape - only a raw CSR poke does.
Decided: (1) P3 is right not to add a refusal. The rule is one rule and it is the existing one: the guard is about the build, not the run's kind; a run-kind refusal would be a new contract sentence and would have to refuse MODE[18:16] on sequencer runs too, which changes a shipped tile's behaviour for no caller. The lead states the rule once in docs/SEQUENCER.md's MODE paragraph at the merge ("a MODE bit the build lacks is refused; a bit the run's kind does not read is ignored - the scalar operand on a program run, the lane mask on an elementwise run - and no library call produces either"). (2) The two flipped controls (api_test.c's lane-mask refusal becoming acceptance; test_krnl_seq.py's MODE[23] control moving up to MODE[24]) are exactly the shape P1 had and are expected; V3 reads P3's diff with those two regions in it. Note for the merge: that test_krnl_seq.py region now has three neighbours - P1's MODE[22] case (on main since the follow-up merges), the lead's second-half case beside it (V1's note), and P3's moved control - so the merge there is the lead's by hand; P3 changes nothing else in that function. (3) The unused `bi` is P1's and the lead removes it at the follow-up's merge, before P3's; `make -C host remotetest` needs `PYTHON=` the Miniconda interpreter, as its own comment says - for P2, whose remote route runs it most; the wsl-through-PowerShell route to the XRT 2.14 compile check is worth its line in the next brief.
Believed: nothing.
For: P3, V3, P2

## 2026-09-15 12:38 (`date`, stamped at append) - answer to P3's 12:37 measurement: the mask stays as built; the compute half of ask 5 was the plan's premise and it is measured gone; nothing grows in this round

Measured (P3's table, make seqcycles at its tip): dense unchanged at every format; half-masked and all-masked cost the same, dense plus one single-beat read a block (four cycles: 60.8 -> 64.8 a block at fp32, 44.8 -> 48.8, 36.8 -> 40.8, 32.8 -> 36.8); reads 6 -> 10 over four blocks; the early exit sees the mask, so an all-masked block leaves its loops at the first test. The sequencer issues per beat, and the active bit decides what is written, not what is computed - true since revision 1 for a lane that drops out at SETACT, and now a number for the mask.
Decided: (1) P3 is right to stop where the brief said to stop. The mask as built is what the round ships: a masked lane's outputs are the caller's bytes, it contributes no flag and no overflow, an all-masked block exits at once, and it costs one beat read a block only when a mask is passed. (2) Skipping a beat with no active lane in the issue pipe and in the stream loads is a revision-7 item, not this round's: it touches R14/R15 and R10's load states, which two parcels just landed in; the lead records it in docs/ROADMAP.md at the docs sweep with P3's numbers as the before-side, and corrects the plan's value statement on main now - the "0.23 x 0.105" ceiling priced compute that is not there to remove; the bytes half stands. (3) The requester's item 4 gets the tile-side answer as P3 states it: zero compute saving, so their ensemble measurement prices the host side alone (bytes not written back, lanes not fixed up); the lead carries it in the word to cft-rebound at the end of the round. (4) V3's attack list gains one item: the dense column of P3's table equals the pre-P3 column of docs/SEQUENCER.md's table, re-measured from a clean build.
Believed: nothing.
For: P3, V3, P2

## 2026-09-15 12:43 (`date`, stamped at append) - the follow-up is merged into main LOCALLY (6457cee) with the lead's three edits on top, unpushed until krnlseq and the host gates pass; a fourth box checkout exists

Measured: the box at 29809cb (round2/merged-p1b, ~/cft-fp256, ~/sims_m1b.launch): "PASS: 24 bench(es), no failures recorded", census seq_coremc, krnlseqmc, seqbanksmc, reducemc, krnlmc all PASS, lint rc=0, VERILATOR+CENSUS DONE 12:42:03; its Icarus tail runs on there. The merge into main (1b3353b, with P4 in) was clean. On top, uncommitted while they are checked: the unused `bi` removed from compare_buffers_program; tb/test_krnl_seq.py's second-half MODE[22] case (SCRATCH_IO set, no input slot, one output slot; V1's note); compare_buffers_indexed counting a failed cft_buffer_get_info as a failure on a device that reports resident buffers (V1's note; not counted on a staging backend, so 722 stays 722). krnlseq under Verilator and gates_m2.sh run on the desktop now. ~/cft-fp256-d is a fresh clone on the box for the merged main's suite (the other three checkouts are in Icarus tails or the a061d3f suite).
Decided: push on both green; then the box's full suite at the pushed tip in ~/cft-fp256-d. After that push, main carries P0, P1 (both parts), P4, and every wave-1 gate fix; P2 and P3 merge from their reports.
Believed: nothing.
For: P2, P3, V3

## 2026-09-15 12:45 - round2/merged-p4 (9a24607: main + P4 at 778dabf + EN_WIDE through cft_krnl + reducenowide) is on GitHub and running on the box in a third checkout

Measured (desktop, Verilator, the checker in every target): redprog 1/1 with the flags fix; reducenowide 11/11 - the tree-less build with P4's two regression cases; reduce 11/11. The suite is 25 benches on that branch. The box runs it in ~/cft-fp256-c with the new script that keeps the raw log (~/sims_m4.out, ~/sims_m4.out.raw). main takes it after V4 confirms 778dabf and the box is green, after P1's fast-forward.
For: V4, P3

## 2026-09-15 12:46 (`date`) - the 12:45 entry above is STALE: a launch wrapper from 11:24 appended it late; P4's staging branch was merged at 12:26 (a061d3f) and that entry's state is an hour old

Measured: the entry's content is the launch of round2/merged-p4 at 11:24 (the desktop's redprog, reducenowide and reduce lines at that time, and the box run in ~/cft-fp256-c), written by a background wrapper that completed only at 12:45 and stamped itself then. Everything it says has been superseded: the box's verdict at 9a24607 landed 12:22 (green), V4 confirmed 778dabf at 12:05, P4 is on main since 12:24, and the follow-up is merged locally at 6457cee awaiting its checks.
Believed: nothing.
For: anyone reading in order - skip it.

## 2026-09-15 12:50 (`date`, stamped at append) - P2's 12:49 entries: the composition's shape is accepted as designed; the under-promise on a remote handle is the safe direction and goes in the docs; the two red integrator gates are the lead's at merge

Measured (P2's): a program run requires stream a (program.c refuses a NULL a before dispatch), so the naive operand-to-stream mapping over-reads a one-element scalar buffer the moment a is scalar beside an indexed b or c; the packed mapping (an unread operand gets r4 in its field and no stream; a scalar gets a constant index with its k bit and no stream; every other read operand takes the next stream slot) keeps stream a always used, and the RTL parser gates each rd_need arm on the k bit as well as on the reads - measured, not assumed. The remote route gathers the three streams and the scratch block on the client and sends a dense run; the INDEXED mask and P1's three test lines are gone; remote_check 419/0. A table on an operand the opcode does not read is refused by name; with any table present d may not overlap any operand; argument errors fire before capability refusals, in cft_program_run_ex's existing order.
Decided: (1) all four decisions stand as P2 made them; the constant-bank expansion is what the brief asked for, and the aliasing rule is the only one with one answer on every backend. (2) The asymmetry - a remote handle to a server WITHOUT CAPS2[9] publishes 0 for a call the client-side gather would make succeed - is the direction this project accepts (a word that under-promises) and is unreachable today; the lead writes it into docs/REMOTE.md's contract paragraph and COMPATIBILITY's 0.14 section at the merge, so the card-backed cft-serve day finds the sentence waiting. (3) docs/README.md's HOSTAPI count and `bindings/arduino/sync.py` are the lead's at every merge, as the plan says; P2 leaves both alone. (4) P2's two environment traps are true and go into the next brief: patch scripts open with newline='' (the lead's do), and a backslash never rides a heredoc.
For: P2, the verifier on P2, P3

## 2026-09-15 12:56 (`date`, stamped at append) - main = 01729e4: P1 whole (both parts), P4, every wave-1 gate fix; the box runs the suite on it in ~/cft-fp256-d

Measured, on the merged tree with the lead's three edits (6457cee + one commit): krnlseq under Verilator 1/1 with the new line "MODE[22] with SCRATCH_IO set and no input slot to gather into: refused, STATUS 0b01000" beside the first half's; the host gates with every test executable built at 12:44 - build warning-free (the unused `bi` gone), api-test all contract checks passed, test_seq.py 66, seq_check 200 agrees on every program, device-test sw -n 32 4,078/0, sw -b -n 32 4,386/0 with the indexed-program line, sw -b -q -n 16 722/0, remote_check every check passed (its own server on port 56448, stopped by PID), docs index true, five generators up to date, 29 Arduino files identical. P4's Icarus tail at 9a24607 finished 12:45 green (seq_core 20/20, krnlseq, seqbanks, faults).
Decided: pushed. The box's suite at this tip runs in the fourth checkout; the a061d3f run in ~/cft-fp256-b (17 of 25 at 12:54) continues as the verdict on "main with P4 alone". P2 and P3 merge from their reports onto this main; their bases (e0f211f) are seven commits behind it in RTL terms (P4's tree, P1's header check) and the merges are the lead's.
Believed: nothing.
For: P2, P3, V3

## 2026-09-15 13:11 (`date`, stamped at append) - P2 reported (tip 3d129ee on worktree-agent-a20b1caece3ff53ee); V2 dispatched on it; the merge waits for V2 and the box

Measured (P2's report; the lead re-runs nothing yet - that is V2's): five files, +1,761/-84, no rtl/, tb/, python/, bindings/, cft.h, backend.h, program.c, backend_remote.c or backend_xrt.cpp; device-test sw 8,754/0 (4,034 at the base: +4,720 checks), sw -b 4,366/0, api-test passed, test_seq 66, seq_check 200 agrees; loopback 419/0 with no frame sent on the three argument refusals (RUN 0 -> 0); krnl 2/2 and redprog 2/2 as unchanged-tree confirmations; five compile configurations warning-free. Control A makes the software and remote backends COMPOSE instead of gather (one substitution) and device-test sw is 8,754/0 again - the composition measured, not believed; controls B (which refusal first), C1-C3 (the gather ignoring its table; NONE reading source[0]; the bound check removed - a segfault, so api-test's bound refusal is the gate there). No control exists for the r4 choice for an unread operand, and P2 says so.
Decided: (1) V2 dispatched at the tip with the plan's list plus: the test's independently built program must not share code with the library's composition; P2's control A reproduced from a copy; the "unchanged for every existing call" claim derived from the check counts; the off-by-one bound. (2) P2 did not add the cftw_run_ex export (the lead's 11:58 decision) - it left bindings/ untouched and said why (no rebuild is due; the JS half must land with the module). Accepted: the export and the JS entry point land together in the lead's rebuild at the docs sweep; the plan's bindings sentence is amended once more to say so. (3) backend_remote.c untouched (the gather lives in device.c beside scalar_mask's remote expansion, one definition for three routes) - accepted. (4) The merge of P2 into main (now 01729e4 in code) is previewed by the lead now; conflicts in device_test.c, if any, are the lead's by hand after V2.
Believed: nothing.
For: V2, P3, V3

## 2026-09-15 13:16 (`date`, stamped at append) - P3 reported (tip 7730187 on worktree-agent-aff0b2d7b6d6ee0a0); V3 dispatched on it; the merge waits for V3 and the box

Measured (P3's report; V3 re-runs it): 18 files, +2,324/-126; seq_core 33/33, krnlseq 2/2, seqbanks, faults, seq_coremc 33/33, krnlseqmc 2/2, seqcycles 4/4, lint clean; test_seq 77 (66 + 11); seq_check 200 agrees with a fifth (masked) corpus and the four older corpora byte-identical to the lead's counts; device-test sw -q -n 16 1,838/0 (1,802 at the base), sw -b 4,366/0; api-test with an 18x64 repack sweep; remote_check every check passed; backend_xrt.cpp warning-free on XRT 2.14. Four controls built, shown to fail, deleted. The merge previews with one conflict, docs/SEQUENCER.md (the lead's MODE-rule paragraph against P3's R17 rewrite) - the lead's by hand; every code file auto-merges, tb/test_krnl_seq.py included (P3 kept its cases in a new test as asked).
Decided: (1) V3 dispatched at the tip with the plan's list plus: the mask fetch's block address across a 256-lane boundary and a mask not a multiple of the beat; wb_act really the retiring edge's active; the remote compaction at chunk boundaries and for FLAGS; the repack's `first` and the claim that a program run uses one tile today; the "no barrel shifter" claim. (2) Six brief corrections P3 made are accepted as facts for the docs sweep: `active <= blk_act` is in S_ZERO; a block at fp256 is 16 lanes and a mask beat is 256 lanes' bits at every format; a program run is NOT split across tiles today (cftx_program_run uses tiles[0], never cft_plan_slices) - a roadmap sentence the lead owes; the drains skip padding by lane count, so a masked lane needed a strobe in each; the brief's remote sketch would have returned a masked lane's flag - compaction is right; the value statement. (3) P3 did not add bind_role for the mask (repacked per launch into the tile's own buffer, never bound) - accepted; the brief's sentence is amended at the merge. (4) The docs counts (SEQUENCER 1,843; HOSTAPI 2,475 at P3's tip, before the merge moves them), the Arduino sync and whether vendor.json wants mask_bits.h are the lead's at the merge.
Believed: nothing.
For: V3, V2, P2

## 2026-09-15 13:25 (`date`) - the box on main with P4 alone (a061d3f): green

Measured: ~/sims_main_p4.launch (~/cft-fp256-b, 12:24-13:24): "PASS: 25 bench(es), no failures recorded", census seq_coremc, krnlseqmc, seqbanksmc, reducemc, krnlmc all PASS (30 TESTS= lines, none failing), lint rc=0, VERILATOR+CENSUS DONE 13:24:50; the Icarus tail runs on. The full merged main (01729e4, P1's follow-up in) is at 15 of 25 benches in ~/cft-fp256-d with no failure.
Believed: nothing.
For: V2, V3

## 2026-09-15 13:37 (`date`, stamped at append) - V2's 13:34: the bound-loop regression is P2's to fix now (sent back); the refusal order on a device without CAPS2[7] goes with it; cft.h's and COMPATIBILITY's false sentences are the lead's at the merge; the bindings omission was accepted at 13:11

Measured (V2's): cft_run_ex walks the index table for n entries before the n-sanity and !d checks the dense path makes first - a segfault at n = 2^61 with an 8-entry table where the dense call refuses cleanly; the device-test increment is 4,676 (8,754 - 4,078 from clean builds), not 4,720 (P2 subtracted the lead's retracted number); host/include/cft.h says four things that become false the moment P2 merges (the remote handle's INDEXED, "refused by name until P2 lands" twice, "d may alias any of them"), docs/COMPATIBILITY.md:632 one; bus_out is compared by no gate between an indexed run and the dense one; on an XRT device with the sequencer and CAPS2[9] but not CAPS2[7], the scalar refusal fires before the R16 fork (safe direction, contradicts the mechanism).
Decided: (1) P2 is resumed for one commit: hoist every pre-memory check of the dense path ahead of any table read, with an api_test case; and route a scalar-beside-indexed call to the composition regardless of CAPS2[7], with a forced-caps control; correct the 4,676 in P2.md. V2 re-checks the new tip. (2) The cft.h sentences are the lead's, and they are true on main TODAY (P2 is not merged); they are corrected in the merge commit of P2 together with P3's lane-mask sentences in the same paragraph, in one touch of the header and one Arduino re-sync; COMPATIBILITY.md's 0.14 section is rewritten at the same merge to say what 0.14 delivers. (3) bus_out on the composed route and the STATUS word's provenance are card-day items for docs/CARDDAY.md's list, not gates a host can hold. (4) The wasm export: the lead's 13:11 entry accepted P2's omission (the export and its JavaScript half land together in the rebuild); V2 read lead.md before that entry existed - nothing to reconcile.
Believed: nothing.
For: V2, P2, P3, V3

## 2026-09-15 13:50 (`date`, stamped at append) - P2's fix at 7309864: V2 re-checks it; V3's list gains the same question for the mask and the tables; P2's merge plan

Measured (P2's report): the bound loop and the aliasing check moved into run_impl behind every check the dense path makes before it touches memory (a later check is inherited, not duplicated); api_test's case with a poisoned table at 0x10 and n = SIZE_MAX/4 segfaults with the n check neutered (control D1) and passes with it; the CAPS2[7] refusal moved after the fork - a scalar beside a table runs via the constant bank on a device without CAPS2[7] (D2 2,150/0; D3, the refusal put back, 24 failures), and the gathered route still reaches it through run_gathered's re-entry; the scalar sweep covers every ordered (scalar, indexed) pair the opcode allows (device-test sw 9,554/0); five compile configurations warning-free; remote_check's indexing stages green, its tail running. P2.md corrected its delta to 4,676 (and 5,476 now).
Decided: (1) V2 resumed on 7309864 (its own driver, the read-before-check audit of cft_run_ex top to bottom, D2/D3 from copies, the pair count derived, the dense stages' counts unchanged). (2) V3 gets P2's general shape as an item: does any check bound n before the mask bytes (P3) or a table (P1, inherited) are read - a finding for the lead if it is a read, not a send-back on its own. (3) P2 merges on V2's word: a host-only parcel (no rtl/, tb/ or python/ in its diff), so the merge's gates are the host gates with fresh binaries, the quick host stages, and device_test's own composed-versus-program leg plus V2's reproduction of control A standing as the seam evidence the plan asked the lead to write; the box's suite at the P3 merge, which has RTL, covers the combined tree - the lead runs no RTL suite for a merge whose diff has no RTL, and says so here rather than pretending it did.
Believed: nothing.
For: V2, V3, P3

## 2026-09-15 13:57 (`date`, stamped at append) - the box on the full merged main (01729e4): green; wave 1 is verified at its pushed tip

Measured: ~/sims_main_full.launch (~/cft-fp256-d, 12:57-13:56): "PASS: 25 bench(es), no failures recorded", census seq_coremc 27/27, krnlseqmc 1/1, seqbanksmc 1/1, reducemc 11/11, krnlmc 2/2, lint rc=0, VERILATOR+CENSUS DONE 13:56:37; thirty TESTS= lines, none failing, no error line. The a061d3f run (main with P4 alone) was green at 13:24. Icarus tails run on in both checkouts.
Decided: nothing new - wave 2 merges onto 01729e4's line (main is 49b9073 with docs on top). P2 merges on V2's re-check of 7309864 (host-only; host gates + its own composed-versus-program leg as the seam evidence); P3 merges on V3's word, with the three additive conflicts resolved by keeping both sides and the seam test after it (an indexed AND masked run against the model, which the lead writes on the merged tree), then the box on that tip.
Believed: nothing.
For: V2, V3

## 2026-09-15 14:09 (`date`, stamped at append) - P2 is on main: 5901932 merges 7309864; e8638f5 makes cft.h's seam sentences true and re-vendors the Arduino copy; pushed at e8638f5

Measured: V2's re-check at 7309864 (13:59) holds on all three findings with a poisoned table pointer in eighteen shapes; the merge into main was clean (device_test.c auto-merged); the host gates on the merged tree with every executable built at 14:01 - build warning-free, api-test all contract checks passed, test_seq 66, seq_check 200 agrees on every program, device-test sw -n 32 9,554/0, sw -b -n 32 4,386/0 with the indexed-program line, sw -b -q -n 16 722/0, remote_check every check passed, docs index true, five generators up to date, 29 Arduino files identical (device.c re-vendored; vendor.json follows). No rtl/, tb/ or python/ file in P2's diff: the RTL suite was not re-run for this merge, on purpose and said so; the box's run at P3's merge covers the combined tree.
Decided: P3 merges next on V3's word (its three additive conflicts resolved by keeping both sides; cft.h's P3 sentences; Arduino sync with mask_bits.h considered; the seam test - an indexed AND masked fold between reductions - written on the merged tree; krnlseq and redprog on the desktop; then the box). V2's cosmetic note (a dead duplicated tables_present condition in the hoisted block) is the lead's at the sweep.
Believed: nothing.
For: V3, P3

## 2026-09-15 14:12 (`date`) - P3's staging branch round2/merged-p3 = 0d4b330 (main eff0084 + the merge of 7730187 + the lead's edits), unpushed; its sims and host gates run on the desktop; main moves on V3's word

Measured: the merge had three conflicts, all two additions at one anchor - device_test.c (P2's legs, then P3's check_masked; the twenty lines the sides share are generic C), SEQUENCER.md (P3's R17 tile section, then the MODE guard's rule), HOSTAPI.md (each side carried a stale 'still refused by name' sentence about the other parcel and its own closing paragraph: both sections kept, both stale lines dropped, one closing paragraph). On top: cft.h's P3 sentences true; bindings/arduino/sync.py vendored host/src/mask_bits.h itself (30 files, identical); README counts (HOSTAPI 2,535; SEQUENCER 1,856), docs index true; tb/probe_reduce_then_prog.py gains the wave-2 seam case (an indexed AND masked fold between reductions, the all-ones mask held to the unmasked gathered run on the tile). Running now: redprog, krnlseq, seq_core, seqcycles under Verilator; gates_m2.sh.
Believed: nothing.
For: V3, P3

## 2026-09-15 14:23 (`date`) - round2/merged-p3 = 4824d23 (a resolution fix over 0d4b330): host gates green with fresh binaries; redprog 3/3 with the wave-2 seam case; krnlseq, seq_core and seqcycles running

Measured: the first staging commit's device_test.c did not compile - git had hoisted the identical closing lines of P2's last leg and P3's check_masked out of the conflict block, so a keep-both resolution closed one function and nested the other ('invalid storage class for function check_masked', a shadow warning for every local); resolved as ours, its closing brace, theirs, the shared tail (4824d23), build warning-free. Gates at 4824d23 (binaries built 14:15): api-test all contract checks passed; test_seq 77; seq_check 200 with the masked corpus agreeing on every program; device-test sw -n 32 9,590/0, sw -b 4,386/0, sw -b -q -n 16 722/0; remote_check every check passed; docs index true; five generators; 30 Arduino files identical. redprog under Verilator 3/3 - the new case (a gathered fold with every third lane masked across a lane block after a segmented reduction; the all-ones mask bit-identical to the unmasked gathered run on the tile; a gathered and masked fold at fp64 whose masked lanes' table rows are all sentinels; reductions around them) passes first time.
Believed: nothing.
For: V3, P3

## 2026-09-15 14:24 (`date`) - the Icarus tails of 29809cb, a061d3f and 01729e4 are green; the box is free; P3's staging tree is fully gated on the desktop (seqcycles 4/4, the dense table byte-identical)

Measured: seq_core 27/27, krnlseq 1/1, seqbanks 1/1, faults 5/5 under Icarus in each of the three runs (done 13:07, 13:50, 14:20). On round2/merged-p3 at 4824d23: seqcycles 4/4 with the dense column 1,189 / 869 / 709 / 629 cycles and the block setup 60.8 / 44.8 / 36.8 / 32.8 a block unchanged, the gathered and the masked rows as P1 and P3 measured. Nothing the lead can run is left before V3's word.
Believed: nothing.
For: V3

## 2026-09-15 14:58 (`date`, stamped at append) - V3's 14:56: P3 sent back for the ACTALL flags case and mask_blk_fn's elaboration; the program-run table walk is the lead's; the remote route's under-promise stays, documented once for both features

Measured (V3's): ACTALL reviving a masked lane is invisible in bytes on the tile (each drain has its own mask strobe) and visible only in FLAGS, deposit overflow and the scratch-range report - no case combined the two; V3's case (SETACT every lane off, ACTALL, a MUL overflowing in the masked lane) catches the defective build and passes the shipped one; the model and the C executor are covered by the random corpus, which emits ACTALL. yosys over cft_seq.sv, e0f211f against 7730187: 9,823 -> 28,626 cells under the lint flow's `opt -fast` (+191%), 6,844 -> 10,863 under `opt -full` (+59%); $shift unchanged at 4; ~96% of it is mask_blk_fn's 16-way one-hot slice elaborating to 2,048 conditional updates in a priority chain. For a PROGRAM run the mask's bytes are read only past seq_program_run's n guard (refused without a read at n = SIZE_MAX/8 with a poisoned mask), while seq_check_round2 walks an index table BEFORE that guard - P1's inheritance, the program-run twin of V2's finding in P2. device.c's CAPS2[10] refusal reads a remote handle's server word although the client compacts and never sends a mask - conservative. The remote compaction held at every chunk shape, FLAGS included; with the compaction removed, the brief's own sketch writes masked lanes and reports the masked lane's overflow (0x14 against 0).
Decided: (1) P3 is resumed for one commit: the ACTALL-then-signal case at more than one format (shown to fail on V3's control), and mask_blk_fn rewritten to elaborate as a select (an indexed part-select by the slot, or a case), bits unchanged, measured with yosys under both opt flows - before the image is built, because this is the image's cost. V3 re-checks the new tip; the staging branch is rebuilt on it (mechanical: the scripts from 14:12). (2) The index-table walk ahead of the n guard in the program-run path, and the two early returns in seq_program_run that set no cft_last_error sentence, are the lead's after P3's merge (program.c is P3's until then): the n guard hoisted ahead of seq_check_round2's walk, sentences on both returns, an api_test case with a poisoned table at n = SIZE_MAX/8 - the same shape P2 fixed for the elementwise path. (3) The remote route: a remote handle publishes its server's word for INDEXED (P2's decision, accepted 12:50) and refuses a mask by its server's word (P3) - the same rule, under-promising in both, unreachable today since every server in the tree publishes both bits; it stays, and docs/REMOTE.md's contract paragraph says it once for both at the sweep, with the card-backed cft-serve day as the place it becomes reachable. (4) The area column joins the round's value statement and the card-day list: cycles, round trips, and cells.
Believed: nothing.
For: P3, V3, P2, V2

## 2026-09-15 15:03 (`date`) - docs sweep parts 1 and 2 on main (93afc20, 831de0e) while P3 fixes; main = 831de0e

Measured: COMPATIBILITY.md gains the P1, P4 and P2 sections below the seam section (P3's follows its merge); REMOTE.md the paragraph on 0.14's two bits and the under-promise, for both features at once; ROADMAP.md's asks 1 and 4 read BUILT with the pointers and the card-day number's place; CARDDAY.md a round-2 section (device-test's resident-binds assertion counting for the first time, gathertime.py, bus_out and STATUS on the composed route, P3's half-masked probe, P4's segmented timing against seq6, the area column, the under-promising word); ROADMAP.md a 'library debts the verifiers found' list (single-tile program runs, beat skipping as revision 7, ensure_capacity sizing, dense refusals without a sentence, the mask's area). The docs index true after each. None of these files is in P3's diff, so the staging branch rebuilds on this main without conflict.
Believed: nothing.
For: P3, V3

## 2026-09-15 15:04 (`date`) - P5 dispatched from main 831de0e: the bindings' elementwise entry point (cftw_run_ex, the JavaScript half, the module rebuild, the demos page) in one commit

Measured: nothing yet. The brief is the lead's 11:58 and 13:11 decisions made a parcel: the export in wasm_api.c, lib.mjs's eager table entry, a core.mjs entry point named so it cannot be confused with Program.runEx, test.mjs cases derived from run(), the rebuild through bindings/wasm/build.sh, verify.mjs and the four node gates, verify_demos --record and build_demos.sh, HOSTAPI's bindings sentence and COMPATIBILITY's P2 row. No parcel touches bindings/ now; P3's fix is in rtl/ and tb/.
Decided: the lead merges P5 on its report and the node gates re-run; its verifier is the lead's own re-run of those gates unless the report gives a reason for more.
For: P3, V3, P5

## 2026-09-15 15:06 (`date`) - the host-side wave-2 seam leg is written and dry-run: check_indexed_masked in device_test.c, applied at P3's merge

Measured: on the staging tree (both parcels' code), the leg - a program whose stream a is read through a table with sentinels into a source shorter than n, every third lane masked; device against software; masked slots at the pattern on both; all-ones over the table equal to the unmasked gathered run - compiles warning-free and passes on the software backend (32 lanes, 11 masked, 7 sentinels, 11-element source). Through remote_check's device-test stage it will run on a remote handle at the merge, which is where P2's client-side gather and P3's compaction first meet; on a card it is where the gather states and the mask fetch share a run. The staging tree was reverted; the leg lands with the final merge (scratchpad p117), beside the tile-side seam case already in redprog.
Believed: nothing.
For: V3, P3, P5

## 2026-09-15 15:26 (`date`) - P5's 15:25: the module's growth is the indexed path linked in for the first time, accepted; HOSTAPI's ask-list item 3 is marked DONE at the merge

Measured (P5's): cft_node.wasm 248,888 -> 256,485 bytes (+7,597), cftw_* exports 139 -> 141; emcc had stripped cft_run_ex and everything behind it (run_gathered, the composition, the shape rules and their strings) because nothing referenced it; the page's module and the loader's byte-identical; every replay matches; no live sentence quotes the old size or hash (the VALIDATION seam entry's figure is history and stays). HOSTAPI.md has no bindings paragraph of the kind the brief named - the brief was wrong; its only sentence on what the wasm surface carries is the 2026-09-04 ask-list item 3, stale twice over (the program calls landed at ABI 0.9 and were never marked).
Decided: the growth is the feature's cost and is right; the lead marks HOSTAPI's item 3 DONE (0.9 for the program calls, today for the elementwise entry point) at P5's merge, the way item 6 of the round's ask list was marked when found; P5 extended rather than struck, which was the right call for a parcel.
For: P5

## 2026-09-15 15:31 (`date`) - P5's 15:30: the plan's cwrap premise corrected on main; the one-commit rule stands and is now enforced

Measured (P5's): M.cwrap of a missing export returns undefined against the committed module - no throw at import, no deferred failure - so lib.mjs's table entry without the rebuilt module would have passed every node gate and failed at the first call. P5's enforcement: lib.mjs's audit() CALLS a projected cftw_idx_none at load (a module lacking the pair takes every node gate down at import), and verify.mjs's NEEDED list names both exports.
Decided: accepted; docs/ROUND2.md's sentence corrected (the lead's error, repeated from P2's 13:05 reading, which P2 had itself flagged as a probe misread - the lead kept the wrong half). The next brief that adds a cftw_* export inherits P5's two mechanisms.
For: P5

## 2026-09-15 15:57 (`date`) - P5 merged into main LOCALLY (2676e71 merges b558a56); the node and wasm gates run on it; the push follows their lines

Measured (P5's report): fifteen files under bindings/ and docs/; verify.mjs VERIFY OK (abi 14 both sides, 141 exports, 110 named entry points, 1,068,915 + 832,915 cases), test.mjs 134/0, program_test 37/0, remote_test 67/0, conformance 1,901,830 cases, verify_demos 44 ok after build_demos; the host gates unchanged (device-test sw 9,554/0 - P2's number exactly); the module 248,888 -> 256,485 bytes for the reason of 15:25; the negative control (Scratch.putU32 broken two ways in a copy) fails exactly the three table cases, once as a refusal by name and once as a deterministic wrong lane, with the scalar case still agreeing. P5 had already marked HOSTAPI's ask-list item 3 DONE. P5's commit carries the trailer its own configuration imposes ('Claude Opus 5 (1M context)'); the merge commit carries the round's - a parcel's commit is its own and is not rewritten.
Decided: pushed on the lead's re-run of the six node/wasm gates and the docs index in the session tree (running). P3's staging branch rebuilds on this main when P3's fix lands.
For: P3, V3

## 2026-09-15 16:05 (`date`) - P3's fix at f79db02: V3 resumed to re-check; the staging branch rebuilds on main with P5 once P5's gates report

Measured (P3's): the ACTALL-then-signal case fails V3's control alone (35 cases, 34 pass, 'FLAGS 0b10100, model says 0b00000') and passes the shipped tile; mask_blk_fn as eight part-selects: cft_seq.sv cells 28,626 -> 10,513 under opt -fast (base 9,823) and 10,863 -> 7,534 under opt -full (base 6,844), $mux 22,911 -> 4,927, $shift 4 - +690 cells over the maskless tile against +4,019; V3's converged-lane scratch-out case and the S_SO_SETUP sentence in; seq_core 35/35, seq_coremc 35/35, krnlseq 2/2, seqcycles 4/4 unchanged to the cycle, lint clean; no host or model source changed. P3's general rule joins P4's in the round's record: an equality test per position around a per-bit assignment is a priority chain, not a select; say 'these bits of that word' as a part-select and mask the index, and read $mux in stat.
Decided: V3 re-checks f79db02 (the control against the new case; the yosys numbers from its own runs; the bits unchanged; the index masked into range; the diff's hunks). The staging branch round2/merged-p3 is rebuilt on main once P5's node gates report and main is pushed: the same scripts as 14:12 plus p113 (the program-run n guard, the lead's) and p117 (the host seam leg); sims and host gates again; then main fast-forwards on V3's word and the box runs the tip.
For: V3, P3

## 2026-09-15 17:29 (`date`) - P5 on main (2676e71, pushed); round2/merged-p3 rebuilt on it with P3's fix: cf13fa0 (69f3df2 merges f79db02; b81b144 the lead's edits; cf13fa0 the Arduino re-sync); sims and host gates running

Measured: P5's six node/wasm gates on the merged main - verify.mjs VERIFY OK, test.mjs 134/0, program_test 37/0, remote_test 67/0, conformance 1,901,830 cases (an hour under the desktop's load), verify_demos VERDICT green - and the docs index true; pushed. The staging rebuild: the same three conflicts resolved the same three ways (SEQUENCER both sides; HOSTAPI both sections and one closing paragraph; device_test.c ours, its brace, theirs, the tail), no markers; on top: cft.h's P3 sentences; the vendored copy (30 files, mask_bits.h among them; re-synced once more after the program.c edit - the first sync ran before it, a slip caught by the check); the tile-side seam case in redprog and the host-side seam leg check_indexed_masked in device_test.c; the program-run path's bounding checks ahead of every read with the poisoned-pointer api_test case (V3's item 3, the lead's); README counts; docs index true.
Decided: on V3's word for f79db02 and green sims and gates here, main fast-forwards to the staging tip and the box runs it in ~/cft-fp256-d.
For: V3

## 2026-09-15 17:41 (`date`) - the lead's own program-run guard crashed api-test at its first run (exit 139), fixed at 1c444c0 and b9c75a5; round2/merged-p3 = 5b7aa19 with P3's docs; V3 holds at f79db02; sims and host gates re-running

Measured: p113's guard fired only above SIZE_MAX / max_deposits / esz, so the api-test case at n = SIZE_MAX/8 - written from V3's example, which used eight deposit slots at fp256 - passed the guard for the test's one-slot fp32 program and walked the poisoned table: exit 139 with an empty log (the crash preceded the flush). Fix: the guard bounds n by the bytes a lane reads and writes even for a program with no deposit slot (per = esz * max(max_deposits, 1)), and the case sits at n = SIZE_MAX/2, above the bound at every format; then the check's substring ('cannot size') did not match the sentence ('than this library can size') - fixed. api-test all contract checks passed; the guard's sentence prints n through an unsigned long cast, which truncates on this host for absurd n - the library's idiom, cosmetic. V3's 17:31 re-check of f79db02 holds on every point, with the area reproduced from its own runs and the rewrite's wrap shown unreadable by arithmetic. The sims on the staging tree: redprog 3/3, krnlseq 2/2, seq_core running; the host gates re-run after the fix.
Decided: main fast-forwards to 5b7aa19 on green sims and gates, then the box. A lead's patch is a parcel's patch: it gets the same gate before it is believed, and it failed one.
For: the case study

## 2026-09-15 17:49 (`date`) - P3 is on main: 5b7aa19 (main fast-forwarded to round2/merged-p3); the box runs the suite on it in ~/cft-fp256-d; every parcel of the round is merged

Measured: at b9c75a5 (5b7aa19 is docs on top) with binaries built at 17:41 - api-test all contract checks passed (the poisoned-table and poisoned-mask case among them), test_seq 77, seq_check 200 with the masked corpus, device-test sw -n 32 9,622/0 (the indexed-and-masked seam leg among them), sw -b 4,386/0, sw -b -q -n 16 722/0, remote_check every check passed (the seam leg over the wire in its device-test stage), docs index true, generators, 30 Arduino files identical; under Verilator redprog 3/3, krnlseq 2/2, seq_core 35/35, seqcycles 4/4. V3 holds at f79db02 (17:31). Pushed; the box's suite at 5b7aa19 launched in the fourth checkout (~/sims_main_p3.launch, .out.raw).
Decided: on the box's verdict the round's code is complete on main - P0, P1, P4, P2, P3, P5 - and what remains is the lead's: the box verdict's entry, the image build at 135 MHz, the card day, the ledger folded into records, the case study finished with Logan, the METHOD.md proposals.
For: anyone

## 2026-09-15 17:55 (`date`) - the round's image: hw/build-pair.sh --dry-run passes every assertion at 5b7aa19 in ~/cft-fp256; the build launches on the box's verdict for the suite at that tip

Measured: ~/cft-fp256 fetched and detached at 5b7aa19a54d0a1b928a72db0ca53af655771bbe4; `hw/build-pair.sh --tag round2 --commit <sha> --require S_MSK_GO --require-in rtl/cft_krnl.sv:EN_WIDE --dry-run`: every --require token present, recipe 135000000 Hz, retiming 1, phys_opt 1, default directives; single -> build-round2-hw (hw/link.cfg), quad -> build-round2-quad (hw/link_quad.cfg), stage -> ~/cardday-round2, logs -> ~/r8-logs-round2; rc 0, nothing created. The suite at 5b7aa19 in ~/cft-fp256-d stood at 7 of 25 benches at 17:54 with no failure.
Decided: the same command without --dry-run, under setsid nohup, the moment the Verilator suite and census at 5b7aa19 report green; single before quad, one Vivado at a time on the box's 46 GB; the card day afterwards is Logan's call (a card-free proof first).
For: anyone

## 2026-09-15 18:15 (`date`) - the round's record is on GitHub: ParcelRound origin/main = c53d2a7 (53 commits), pushed on Logan's word

Measured: CASE-STUDY-2.md as of c53d2a7 - the setting (with how the round was run, unattended for most of it), 71 timeline rows, 28 observation paragraphs, what is not yet known at the end of the build phase, the proposals for METHOD.md by section, the cost (cards and panel, tokens and time, on a subscription).
Decided: the record keeps being pushed as it is updated; the image build's rows and the card day's join the timeline when they exist; METHOD.md itself changes only with Logan, from the proposals section.
For: anyone

## 2026-09-15 18:50 (`date`) - the box on the final main (5b7aa19): green; the round's image build launched at 18:49 on the box; the build phase of round 2 is complete

Measured: ~/sims_main_p3.launch (~/cft-fp256-d, 17:49-18:47): 'PASS: 25 bench(es), no failures recorded', census seq_coremc 35/35, krnlseqmc 2/2, seqbanksmc 1/1, reducemc 11/11, krnlmc 2/2, lint rc=0, thirty TESTS= lines none failing, no error line; the Icarus tail runs on. hw/build-pair.sh --tag round2 at 5b7aa19 in ~/cft-fp256: every --require token present, 135000000 Hz, retiming 1, phys_opt 1; the single link (build-round2-hw, hw/link.cfg) started 18:49:04 with 44 GB available; v++ -l -t hw alive under setsid. VALIDATION.md carries the verdict and the launch (pushed).
Decided: the quad follows the single inside the same script, only if the single verifies; the staged pair lands in ~/cardday-round2; the card day is Logan's call. The ledger's job is done when the build's entry is written; it is folded into VALIDATION.md and the memory directory then, and deleted.
For: anyone

## 2026-09-15 19:16 (`date`) - the final main's Icarus tail: green (sims done 19:15:20)

Measured: ~/cft-fp256-d at 5b7aa19 under Icarus - seq_core 35/35 (1,378 s), krnlseq 2/2, seqbanks 1/1, faults 5/5. Both simulators green at the round's tip; VALIDATION.md's entry carries it. The image build's single link has been running since 18:49.
Believed: nothing.
For: anyone

## 2026-09-15 19:31 (`date`) - the card day begins on Logan's word (19:27): the card is free, no image loaded; the first half is the round-2 library against the seq6 image, and its first run found a test gate wrong for an older image

Measured: xbutil examine - the U50 at 0000:02:00.1, shell xilinx_u50_gen3x16_xdma_base_5, ready; no process of ours on the card. The round's host tools built with XRT in ~/cft-fp256-d at 5b7aa19. Against ~/cardday-seq6/cft_hw_seq6_1x.xclbin (sha256 OK; backend xrt, 1 tile, formats fp32/fp64/fp128, buffers_resident 1): the probe and every leg green EXCEPT P2's two elementwise indexed legs, which counted the device's refusal by name ('an indexed operand needs CFT_SEQ_FEAT_INDEXED, which this device does not publish (CAPS2[9])') as a failure - 7 a format, 21 in 1,400 checks; P1's and P3's program legs printed NOT COMPARED by name as designed. The library is right; the test was not gated on the capability. Fixed on main: the two legs run only where the device publishes CAPS2[9], and a device without it is scored once a format on the refusal by name (CFT_ERR_UNSUPPORTED naming CFT_SEQ_FEAT_INDEXED, or the sequencer's capacities on a device with no sequencer). device-test sw 9,622/0 unchanged. The image build's single link runs on since 18:49.
Decided: the compatibility half of the card day is the full device-test, both legs, at -n 64 against the seq6 image with the fixed test; then the new image's half when the single lands (device-test both legs with every new leg counting, gathertime.py at the gravity shape, the composed route's STATUS word, the masked timing, P4's segmented timing against the seq6 entry, the image's WNS and utilisation).
For: anyone

## 2026-09-15 19:37 (`date`) - card day, first half done: the 0.14 library against the seq6 image - device-test both legs and the conformance replay green with the three new features absent by name; the second half waits for the image

Measured: with the gated test (1ee9189; ce01e41 adds the STATUS comparison, 3177b76 gathertime's --masked-every), on the seq6 image: device-test -q -n 8 1,361/0 (three NOT COMPARED lines), -q -n 64 1,361/0, -b -q -n 64 540/0 with 129 windows served resident, cft-selftest 111 sets / 892,548 cases all matching, fp256 sets skipped by name. ~/box_round2_cardday.sh is installed and waiting for ~/cardday-round2/cft_hw_single.xclbin (build-pair stages it only past verify-image): manifest lines, probe, device-test -q -n 8 / -q -n 64 / -b -q -n 64, gathertime at three shapes dense and masked plus a ragged one, segtime at the seq6 day's four shapes, the replay. The single link has run since 18:49.
Believed: nothing.
For: anyone

## 2026-09-15 21:08 (`date`) - the round's image on the card: timing met (kernel WNS +0.266 ns at 135 MHz), P1's gather and P2's composition correct on the tile, and THE LANE MASK DOES NOT WORK ON THE CARD - every masked lane is written; the host side is proved right by a register trace, so the defect is on the tile in a shape the model-latency sims cannot show

Measured: build-round2-hw staged at 20:57 (single, 37,176,250 bytes, sha256 9748..., verify-image 8/8, kernel_wns 0.266, routed 0.032, EN_FP256=1, EN_WIDE=1); the quad links now. On the card: the probe (4 formats, buffers_resident), P1's indexed program leg green ('8 lanes through a 3-element source, 2 of them +0, identity == dense and rotated != dense, the bound refused on both'), P2's six scalar/indexed pairs green with the composed program on the tile, the reductions and everything else green - and device-test -q -n 8 at 2,212 checks, 12 failed: 'seq lane mask: the device and the software backend differ under a mask' and 'lane 0 is masked and its deposit slot or count was written' at all four formats, plus the indexed-and-masked seam leg (bytes differ, flags equal). gathertime --masked-every 2 on the card: all 24 masked lanes written; --masked-every 100: the 1 masked lane written; STATUS 0, FLAGS 0. CFT_XRT_TRACE (1a5d643, an env-gated readback after a program run): host mode 0x00c08000 = tile MODE 0x00c08000 (bit 23 set, bit 22 the scratch table), N 48, the five pointer registers 0x4000..0x8000 with MASK = the mask bo's address 0x8000, the device's mask bytes aa aa aa aa aa aa 00... - the right pattern, synced. So the tile received the bit, the pointer and the bytes and ran every lane; STATUS clean (no bus or length fault).
Decided: the sims that passed (seq_core 35/35, krnlseq 2/2 through the CSR, redprog 3/3) ran at the model's memory latency; the same benches run now at RD_LATENCY=200 WR_LATENCY=200 on the desktop. If they fail, the defect is latency-shaped (a state consuming a beat that is not the mask's, or the mask captured too late for the block's opening active set), reproducible in sim, fixed in RTL, and the image is rebuilt - the single takes two hours. If they pass, the next instrument is on the tile. The card day's other numbers (gathertime dense, segtime against seq6) are taken meanwhile from this image, whose gather and reductions are right. P3 is not resumed until the sim says what the shape is.
For: anyone; P3 and V3 when the shape is known

## 2026-09-15 21:16 (`date`) - the card's gather numbers (asks 1 and 4 on silicon); segtime loaded a stale library; the mask benches at latency 200 passed but the knob installs nothing there - a probe with busfx's latency on the kernel bench runs now

Measured on the round-2 single image (gathertime.py --artifact, reps 7, deposits agreeing with the host fold every time): fp64 64 bodies (2,016 pairs, 192 lanes, rows of 63) ONE program run 4.052 ms = 335 ns a gathered element against 13.190 ms for the 63 cft_run calls it replaces - x3.25, and 63 host gathers removed; fp32 64 bodies 3.931 ms = 325 ns an element, x1.40; fp128 32 bodies 1.387 ms = 466 ns, x1.99; fp64 64 bodies with 48 active (ragged rows, sentinels) 3.073 ms, x1.34; the 128-body fp64 shape printed nothing inside its 900 s (to re-run). segtime.py in ~/cft-fp256 loads that checkout's host/libcft.so, dated 23:27 yesterday - build-pair's host build did not refresh it - and refused VERSION 0xA00 as unknown; it re-runs from ~/cft-fp256-d once the card is free of device-test -q -n 64 (9 failures so far, all the mask's). The sims at RD_LATENCY=200 WR_LATENCY=200 passed with the SAME simulated time as at zero: only tb/test_krnl_cycles.py calls busfx.latency; krnlseq and seq_core install nothing. tb/probe_mask_latency.py (uncommitted) wraps the bench's RAM classes with busfx's pipelined latency and re-runs krnl_lane_mask and krnl_sequencer at 200/200.
Believed: the mask's defect is latency-shaped, until the probe says otherwise.
For: anyone; P3 and V3 when the shape is known

## 21:44 lead - the lane mask on the card: found, fixed in the host, no rebuild

The 21:16 entry left the mask failing on the round-2 single tile
(every masked lane written; host side proved right by CFT_XRT_TRACE)
with the RTL as the suspect. It was not the RTL. In order:

1. **The fingerprint** (gathertime.py, one added line): every masked
   slot held exactly the value its lane would have deposited unmasked
   - not the pattern, not garbage. 24 of 24 at fp32, 16 of 16 at fp64.
2. **FLAGS** (host/tools/maskflags.py, new): the masked lanes' inputs
   poisoned (+inf + -inf, INVALID), the kept lanes exact. Unmasked
   run FLAGS = INVALID; masked run FLAGS = clean, on the card, at fp32
   and fp64. The flags are ORed under `wb_act`, which is `active`,
   which is `blk_act`, which is the mask - so the mask REACHED THE
   LANES. The bench and the card agree on everything except the
   bytes.
3. **The strobes** (CFT_XRT_TRACE, count-pad pattern): the count
   window's staging pad past n - lanes the tile strobes off by
   `cnt_beat_ok` with no mask involved - filled with 0xCC, uploaded,
   read back after dense runs at n = 5, 13 (fp32) and 3 (fp64): 0xCC
   throughout. The U50's memory path honours WSTRB. A trailing, a
   leading and an interleaved mask (0f, f0, 01, 80, 55, aa at n = 8;
   00ff, ff00, 5555 at fp64 n = 16) all wrote their masked lanes, so
   the shape of the strobe pattern was not it either.
4. **The reading that fits all three**: the tile leaves a masked
   lane's bytes as they are ON THE DEVICE, and the staged device copy
   of the deposit window held the PREVIOUS run's output, because a
   deposit window is an output the host never uploaded. The readback
   brought that home whole. "Every masked lane written with the
   unmasked value" was the previous run's value, still there.
5. **The fix** (be1ac1f, host/src/backend_xrt.cpp): under a lane mask
   the caller's deposit window and counts are staged to the device
   before the launch; the tile writes the kept lanes over them. An
   unmasked run uploads nothing, as before. A RESIDENT window was
   never wrong: the device copy is the authority there.
6. **Proof on the card** (library rebuilt, 21:41): maskflags at 0f,
   55, 01 (fp32 n = 8) and 5555 (fp64 n = 16) - every masked lane and
   count untouched, every kept lane 3, FLAGS clean. gathertime 64
   bodies fp64 masked every third lane: 64 of 64 slots hold the
   pattern, kept lanes the unmasked run's, 4.146 ms against 4.042
   unmasked (x1.026: one beat read a block, three blocks). device-test
   relaunched at 21:43 with a REBUILT test binary - the first relaunch
   ran the 21:06 binary, which is statically linked and carried the
   old backend: 12 failures, the same 12. `make all` does not build
   the tests; the day's second reminder.

The bitstream is right. No rebuild; the quad link goes on (placer at
21:41). What the round's benches could not see: cocotbext's RAM starts
every test empty and the C executor writes the caller's buffer in
place, so no host in the suite had a device copy with a previous run
in it. The seam test to add is the one device-test already had - the
masked leg after an unmasked one on the same window - which is why
device-test caught it and nothing else did.

Instruments left in the tree: gathertime's fingerprint line,
maskflags.py, the count-pad pattern under CFT_XRT_TRACE (after the
masked upload, so a masked run's pad is the pattern and not the zero
the staging wrote). The 128-body heap corruption is next.

## 21:59 lead - the 128-body crash: XRT capacities, and a third mask leg

**The scratch-out block** (db085ab, 301c21d). HOSTAPI.md's mask bullet
names three things a masked lane does not write: deposit slots, count,
scratch-out slots. The upload fix covered two; the scratch-out block
was never staged either, so it is now, under a mask, on the same
terms. And a leg for it, `check_masked_scratch_out` - one STL of `a`
into the one scratch-out slot, every third lane masked, the block
pre-filled - because no leg on any backend covered the third thing.
Software backend 2,246/0; the card 2,248 checks 0 failed (-n 8).

**The crash** (d40ad23). Bracketed on the card: 100 bodies fine, 112
"corrupted size vs. prev_size", 120 a segfault, 128 an abort - and
device-test -n 336 ALONE dies the same way in its first elementwise
legs, so it was never the gather. The seq6 image with the same
library at -n 336: 1,361 checks, 0 failed. AddressSanitizer (a build
in ~/cft-fp256-b) stopped on XRT sizing a 4 KiB-aligned host
allocation to exactly our beat-rounded byte count - 0x540 = 1,344 =
336 fp32 lanes. Capacities are now whole pages (`page_round` beside
`beat_round`, at the three `xrt::bo` sites; transfer counts
unchanged). After it: device-test -n 336 / 1000 / 4097 2,248 checks 0
failed each, -b -n 336 729/0, gathertime at 112 and 128 bodies three
reps each. I do not have XRT's source in front of me to name the
page-granular write; the fix is the capacity, which is what the
runtime and the driver move behind that allocation.

**128 bodies, the number the requester asked for** (fp64 / fp32 /
fp128, 384 lanes, rows of 127, reps 5, every third lane masked in the
masked run):

    one program run     15.588 / 15.113 / 16.464 ms   319.6 / 309.9 / 337.6 ns a gathered element
    masked run          x1.013 / x1.013 / x1.011 of the unmasked (one beat read a block)
    127 dense calls     26.729 / 24.725 / 24.894 ms  -> x1.71 / x1.64 / x1.51, 127 host gathers removed too

The masked slots untouched and the kept lanes the unmasked run's at
every format; flags and status clean.

Every card-day instrument stays in the tree. The quad is still in the
placer. Next: VALIDATION, the case study, memory; then the quad half
when it lands.

## 22:08 lead - the leftovers closed; the gate runs on main

main = 1fdd89e: VALIDATION (2a36440), CARDDAY "What the card said" (ebc660b), ROADMAP asks 1/5/7 with the card numbers (f3a95b9), docs index counts and the n guard printing n whole on LLP64 (8c5d6b4), V2's cosmetic dead condition in device.c removed with the block re-indented (3799c6e; api-test and device-test sw green), the Arduino copy re-vendored after those two files changed (1fdd89e; `sync.py --check` failed until it was - the vendored copy is a gate that every host change trips). The CAPS2 row in ARCHITECTURE.md already names [9] and [10]; no CAPABILITIES doc exists, so that leftover was a name and not a file. gates_m2.sh runs on the tree now (fresh binaries built 22:07). The quad is in global placement; when it stages, device-test on four tiles and its VALIDATION entry. Case study: §9 and "What is known now" pushed (ParcelRound bf5034b and after).

## 22:15 lead - the local gate is green on main

gates_m2.sh on the session tree (host sources at 3799c6e; the Arduino re-vendor 1fdd89e landed during the run and its sync stage ran after it): fresh binaries built 22:07 by name; api-test all contract checks; 77 model tests; seq_check 200 trials; device-test sw -n 32 9,886/0, -b -n 32 4,386/0 (the indexed-program leg 4,278/0), -b -q -n 16 722/0; remote_check every check passed (its bounded fp256 replay is the slow stage - four minutes of cft-selftest at a third of a core, not a hang; the server was only listening because the client was still in the LOCAL half); docs index; five generators up to date; 30 vendored files identical. Done 22:15. Nothing owed on the host side before the quad.

## 03:01 lead - the quad missed timing at 135 MHz; relaunched with the directive axis

build-pair's quad half ended at 02:55 after 359 min: `design did not
meet timing`, system clock slack -0.224 ns, kernel-side WNS -0.363 ns,
1,824 failing endpoints of 1,042,969. NOT a pair; nothing staged
beyond the single (which closed at kernel +0.266 / routed +0.032 and
is the image the card day validated).

**Where the shortfall is.** The three worst paths are all the
elementwise ENGINE's FIFO-to-FMA bypass (`u_engine/u_fifo_a/mem_reg`
-> `u_lanes/g_bank64.g_lane64[0].u_fma/s0_byp_d_reg`): 17-18 logic
levels through the DSP cascade, 7.5-7.7 ns of data path against a
7.407 ns period. Not the sequencer, not the mask, not the wide
accumulator - the path every previous image carried. The nine earlier
quads at 130-135 MHz closed with kernel margins of 0.009-0.143 ns, so
this is the placement spread on a path that was always at the edge,
and hw/rebuild-2022.sh's own comment names the directive as the axis
that moves timing by exactly this much (its measured spread: 0.113
ns).

**Relaunched, quad only** (`~/box_quad_b.sh`, 03:01): the same commit
5b7aa19 (asserted, with the two RTL tokens), the same 135 MHz, retiming
and phys_opt, plus `PLACE_DIRECTIVE=ExtraTimingOpt
ROUTE_DIRECTIVE=AggressiveExplore`; build dir
`~/cft-fp256/build-round2-quad-b`, log `~/r8-logs-round2/quad-b.log`,
summary lines in `00-summary.txt`. On success it stages
`~/cardday-round2/cft_hw_quad.xclbin` on build-pair's own terms
(verify-image, copy, re-hash, SHA256SUMS, a README that says which
directives each half used) - and `~/box_round2_quad.sh` is still
waiting on that file to run the four-tile legs. A second single was
NOT built: the staged single is card-validated and a re-implemented
one would be a different image. Expect ~6 h. A monitor watches the
summary.

If quad-b closes: the four-tile card run and the pair's VALIDATION
entry. If it does not: the honest record is a single at 135 MHz and a
quad that needs either a slower clock (the previous quads' 130 MHz
would give 0.285 ns) or a register in the engine's bypass path - a
round-3 item, since the sequencer is not the path.

## 06:37 lead - correction: CAPABILITIES.md exists, at the repo root, and it is stale

The 22:08 entry said "no CAPABILITIES doc exists, so that leftover was a name and not a file". Wrong: I looked in docs/ and the page is `CAPABILITIES.md` at the repository root (364 lines, indexed from docs/README.md as "what a given build can do"). Its last edit is 78b4a3b, 2026-09-14 17:56, for cft_reduce_seg. It carries nothing of round 2 - no lane mask, no index tables, no composed indexed `cft_run_ex`, no ABI 0.14 / VERSION 0xA00 / CAPS2[9] and [10] - and two of its statements are now false: the "strided or gathered access | no" row and the Summary's "there is no device-side scatter and no gather ... the cost that decides its rate". README.md mentions none of the round's features either. The round's features ARE listed in COMPATIBILITY.md (P1/P4/P2/P3 sections and the 0.14 rows), HOSTAPI.md ("ABI 0.14: the seam of a parcel round"), SEQUENCER.md R16/R17, ROADMAP.md asks 1/4/5/7, ARCHITECTURE.md's register map, VALIDATION and CARDDAY. The leftover is reopened: CAPABILITIES.md rows for the round, its two false sentences, and README's "What is built and working". Logan asked; waiting for his word before editing.

## 06:51 lead - the docs sweep, while the quad routes

Logan asked for every doc checked for stale or outdated statements, by the lead alone. Six commits, f3ea02d..4b83e47, all pushed; docs/check_docs_index.py green (35 documents, every count true). What was wrong and is now right: CAPABILITIES.md carried nothing of round 2 and said "no gathered access" and "no gather" in its summary (rows for the gather, the scatter-add that is still absent, the lane mask, the beat-wide accumulator, resident buffers and the microcontroller; the program row at VERSION 0xA00); README (31 opcodes, ~24,000 lines of C, six of seven asks built, the dependants paragraph); ARCHITECTURE (VERSION 0x800 -> 0xA00 with the history, opcode 31 `maxall` in the table and "everything above 31" unassigned, the version-history paragraph through CAPS2[9]/[10]); DETERMINISM (called 31 unassigned two lines above recording its assignment); HOSTAPI (MAXALL on a 0x900 tile); SEQUENCER (the intro described revision 4 and said no bitstream carried it - now revision 6 on silicon); INTEGRATION ("no gather primitive today"); NOVEL (div/sqrt "not yet on a card"); SCALING (a program run is one tile's); PROGRAMS (the 0.14 fields on the entry point); ROADMAP (the two host defects in the debts list); CLAUDE.md (the static test-binary trap on every host, the pipe deadlock, 30 vendored files); BITSTREAM-BUILDS (trap 5: a quad that misses by tenths of a nanosecond, and the directive knob); BRINGUP (the U50C shell question answered by the shell name, the polling question given its evidence); CARDDAY (the round-2 pair in the staged list); ROUND2 (the outcome at the top of the plan); the wasm README (the 0.14 rebuild block), the Python README (ABI 0.14), VERIFICATION (2,264 golden tests), the docs index prose (45,034 lines); BENCHMARKS (a round-2 section with the card table); COMPATIBILITY (the ESP32 row said 222,000 where EMBEDDED and the README say 508,000); PLATFORMS (Above-4G on the box proven by the card running). Checked and left alone: VALIDATION (append-only), COMPLIANCE, TRANSCENDENTALS, DEMOS, the workload docs, ATLAS (its "indexed constants" are the kx mechanism, not R16), EMBEDDED, REMOTE (by-handle RUN over remote is still not built), LAYOUTS (generated), the studies. Not done: BITSTREAM-BUILDS's trap 5 and CARDDAY's pair entry say the quad rebuild's outcome is in VALIDATION - it will be when the build ends (routing at 06:49, intermediate WNS -0.393 and improving).

## 07:52 lead - Logan: 130 MHz is acceptable for the quad if 135 does not close

Logan's word at 07:50: "if it fails to close, 130 MHz is acceptable; 135 was tight every time; if changes finally cause it to fall on the wrong side of the line, a minor drop is acceptable - this is the first hardware capable of binary256, expected to be slow, and it already beat expectations on performance when used to its potential." Banked as a feedback memory. quad-b at 07:51: routing done at an intermediate WNS of -0.317 ns (Phase 10 depositing routes; post-route phys_opt next) - a second miss, smaller, is the likely end. So the decision is automated rather than waited on: `~/box_quad_after_b.sh` (detached) waits for quad-b's launcher to exit, does nothing if ~/cardday-round2/cft_hw_quad.xclbin got staged, and otherwise runs `~/box_quad_c.sh` - the same commit, recipe and directives at KERNEL_FREQ=130000000, build dir build-round2-quad-c, log ~/r8-logs-round2/quad-c.log, staged as "a pair at two clocks" with the clock in the README and the manifest. The single stays as validated. ~/box_round2_quad.sh still waits for the staged quad to run the four-tile legs. Also this morning: the Ubuntu error on the box's display was apport's dialog for MY gathertime abort of 21:09 last night (/var/crash/_usr_bin_python3.12.1000.crash, signal 6 - the heap corruption fixed at d40ad23); the box is healthy (build alive, 25 GB free, 52 GB of disk); fwupd.service has failed to start every 25 s since 07:39, unrelated and untouched.

## 08:51 lead - CONFORMANCE.md: the profile, on Logan's word

Logan asked (08:2x) whether a conformance document belonged in the project now, with IEEE 754 conformance and cft-fp256 conformance kept apart because they are not one-to-one; then "go ahead and write it". Written and pushed as ffefb5c: CONFORMANCE.md at the root (profile 1, 2026-09-16) - the two levels and the one-way implication stated first, a table of where the profile is stricter than 754, additional to it, and silent on it; the normative list (formats and buffer layouts, the five attributes and the reserved codes, the 31 opcodes by group with 15 and everything above 31 unassigned, the library operations, the fixed choices - canonical NaN, tininess after rounding, the sign of exact zeros, the tree and its empty and single-element cases with maxall from -inf, partitioning free if the tree holds - the program model's deposits, scratch, bank, index tables and mask, flags and status); what an implementation may choose freely, with clock-independence as a guarantee; the conformance test (the 168 sets, the score, the identity checksums, device-test, MPFR); versioning by the vectors. Every wording was checked against DETERMINISM.md, COMPLIANCE.md, HOSTAPI.md and cft.h before it went in (two corrections came out of that: the ...Number forms also beat a signaling NaN; the predicates cite 5.11). The profile's identity needed one code change: vectors/gen_vectors.py wrote CRLF on Windows (open(path, "w")), so a hash of a set meant two things; it now opens with newline="
", the sets were regenerated (168, 1,068,915 cases, zero CR bytes, the same count), and vectors/SHA256SUMS lists them. docs/README.md points at it beside CAPABILITIES and CLAUDE, and its LAYOUTS row - which described a memory-layout document that does not exist - now says what the file is; the README's "How the claims are checked" names the profile. The 135 MHz quad is in a rip-up-and-reroute pass at 08:49; the 130 MHz wrapper waits on it.

## 11:00 lead - the pair is complete: the quad closed at 135 MHz, four tiles green

quad-b (ExtraTimingOpt / AggressiveExplore, same commit and clock) rc 0
in 468 min: kernel WNS +0.040 ns, routed +0.031, zero failing
endpoints, hold +0.006; staged 10:47 as
~/cardday-round2/cft_hw_quad.xclbin (226d6c76...), SHA256SUMS over the
pair, README naming each half's directives. The 130 MHz wrapper read
the staged file at 10:49 and stood down - Logan's rule stays banked for
the next quad that needs it; this one did not. The router's
intermediate slack was -0.317 ns for hours and the post-route physical
optimisation closed it: the intermediate summaries are not the verdict,
said in BITSTREAM-BUILDS.

Four tiles on the card (~/box_round2_quad.sh from ~/cft-fp256-d at
ffefb5c, tests rebuilt by name, legs 74 s after staging): device-test
-n 8 / 64 / 336 / 4097 2,248/0 each, -b -n 64 729/0; gathertime 128
fp64 one run 15.429 ms = 316 ns an element (one tile's run: 320 on the
single), masked x1.005, the 127 dense calls 54.3 ms (27 on the single:
tile count is a cost per call, again) -> x3.52; segtime fp64 E=1000
L=192 sum one call 1,453 us against 2,351 on the single (whole segments
across four tiles, x1.62), a thousand calls 431 ms against 91; maxall
1,436 us. Replay: 168 sets, 1,224,915 cases, all matching on four tiles.

Utilisation (routed, whole design): single 267,188 LUTs (31%), 311
DSPs, 262 BRAM; quad 696,542 LUTs (80%), 1,232 DSPs, 505.5 BRAM, 36
URAM - the quad at 80% of the part is why 135 MHz squeaks.

Records: VALIDATION entry "round 2's pair complete" (with the case
study's rows at 07:50, 10:47, 10:49), CARDDAY's pair entry,
BITSTREAM-BUILDS trap 5's outcome, ROUND2's outcome, SEQUENCER's intro
(3e48c31 and after). The round's card work is done. What remains is the
ledger's fold and the METHOD.md proposals with Logan.

## 12:21 lead - the pair saturated: four times one on resident work; reductions do not overlap across tiles

Logan's ask at 10:5x, two drivers on the box, both done by 12:14
(~/cardday-round2-saturate*.log, one file a run). Engine, bus out
(cft-resident, fma): four tiles are x3.93-4.00 one at every format and
size, each unit at 100-108 M beats/s (the single's own rate; a unit of
the quad alone IS the single), 55 GB/s over sixteen streams. Through
the library (cft-bench --resident): a FIXED cost a call - x3.1 at 1M
fp32, x3.9 at 16M, x3.8 at fp256 from 1M up - so wide resident work
amortises the tile count and many small calls never do (the card
day's 127 dense calls at twice the single's cost, from the other
side). The largest resident shape is bigger on four tiles (16M fp128
refused on the single, ran on the quad: a buffer is sliced per tile;
a 256 MB channel is shared with the library's own staging).
Reductions (segsat.py, new, exact-checked): one tile at 33-62 M
beats/s in every shape - a third to a half of its engine - and four
tiles reducing at once at ~13 M beats/s EACH, no more in total than
one; four elementwise runs overlap, four reductions do not; recorded
with its signature and the candidates in the order to instrument (the
library's launch/wait/sync ordering first, the tile's reduction read
side second), not explained. Power: quad 35.4 W under a long fp256
run against 20.2 W idle (the README's "about 35 watts"); the single's
draw is inside the meter's idle spread. Two debts to ROADMAP:
ensure_capacity allocating a buffer for a BOUND role in the same
channel; the reductions. One driver mistake caught by the script's
own check (element counts that were not multiples of 192), corrected
between invocations without editing the running driver. VALIDATION
"saturating the pair", SCALING, BENCHMARKS, ROADMAP, the case study:
56ad0cd and after.
