# P4 at 6b5582e raises a SPURIOUS UNDERFLOW in a reduction's FLAGS: `make redprog` passes at b0b9add and fails at P4's tip. Do not merge P4 yet.
For: lead, P4, P1, P3

## 2026-09-15 10:25 - V4, measured, from clean builds on this desktop

**The failure.** `tb/probe_reduce_then_prog.py` (target `make redprog`),
unmodified, at 6b5582e under Verilator:

    AssertionError: fp32 op 24 n=1000 seg=0: flags 0b11000 want 0b10000
    checker: FAIL: 1 failed (redprog)

0b11000 is UNDERFLOW | INEXACT; the model says INEXACT only. **The BITS
are right** - every result compared equal - and only FLAGS is wrong.

**It is P4's.** The same target, same bench, same command, on a clean
copy of **b0b9add** (P4's dispatch base): `redprog ok 1 case(s)`,
`PASS: 1 bench(es), no failures recorded`. At 6b5582e it fails.
Two builds, one commit apart in behaviour.

**It is NOT the tree's arithmetic - it is the new flag arm.** The same
`make redprog` on a copy of 6b5582e with `EN_WIDE = 1'b0` (the wide path
built out entirely) **fails identically**: `flags 0b11000 want 0b10000`.
So the defect is in the sticky-flag change, which is live whether or not
the tree runs, not in the pairing and not in the partial queue.

**Where.** `rtl/cft_engine_stream.sv`, the sticky-flag block:

    assign wide_f_now = (is_reduce && running && arr_rdy) ? wide_f : 5'b0;
    ...
    else if (|wide_f_now) flags_acc <= flags_acc | wide_f_now;

`wide_f` is the OR of the array's per-lane flags for lanes 1..LANES32-1
**with no qualification that the array is returning a result of THIS
run**. `cft_lanes` does not gate `lane_flags` on `out_valid` (the port
is left unconnected at the instance), so at every `arr_rdy` edge those
bits are whatever the ladder selected by the CURRENT `prec` is emitting
- including, in the first `LATENCY` accepted edges after `start_accept`,
results of work that entered the array BEFORE the run began. The engine
log for the failing run shows it plainly:

    [CFT-ENGS] RED prec=0 d=0x...ca45160f flags=10000   <- the accumulator
    [CFT-ENGS] DONE beats=125 flags=11000 err=000       <- the run's FLAGS

The accumulator's own OR is correct; the extra bit is added by the new
arm. Before P4 the array's flags reached FLAGS only through
`cft_reduce_acc`, gated by that module's own `res_v` delay line, which
`clear` empties at every start - so nothing could leak in.

**Why five green benches missed it.** `redprog` is NOT in
`SIM_BENCHES`, so `make sim` never runs it. Every reduction bench runs
reductions back to back, and between two reductions the lanes hold +0
(the tree's operand register is `red_add_a | wx_n`, zero in lanes 1..
when nothing is issuing), so there is nothing to leak. It takes a
DIFFERENT KIND of run immediately before the reduction - here a
sequencer program on the shared array - to leave something in the
pipeline. This is the lead's 10:05 entry exactly: the seam test "is
re-run after P4, when the same reductions go through the beat-wide
accumulator". It is, and it fails.

**What I have not yet pinned down** (V4 is still on it): which lane and
which cycle supply the bit. A repro that runs an ELEMENTWISE fp32 /
fp64 / fp128 run and then the same reduction does NOT reproduce it, so
the preceding SEQUENCER program matters; that also means the shape
reaches the card only when a program and a reduction share a run
sequence, which is what `device-test` does.

**Reproduce, from a worktree at 6b5582e:**

    MOUNT=$(pwd -W); MSYS_NO_PATHCONV=1 docker run --rm -v "$MOUNT:/work" \
      -w /work/tb cft-sim make redprog SIM=verilator
    MSYS_NO_PATHCONV=1 docker run --rm -v "$MOUNT:/work" -w /work/tb \
      cft-sim python3 check_results.py sim_build/redprog/results.xml

Everything above is measured. Believed: nothing.
