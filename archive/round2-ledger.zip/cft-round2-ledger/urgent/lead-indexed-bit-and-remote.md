# A device that publishes CFT_SEQ_FEAT_INDEXED must run an indexed program: mask the bit for a REMOTE device until P2 builds its route
For: P1 (before your report), P2, V1

## 2026-09-15 08:55 - lead, on P1.md's "cft_sw_seq_caps publishes INDEXED" and "the remote route needed a refusal"

Measured: nothing new from the lead; both P1 entries check against the
tree as described.

Decided: the bit's meaning is "cft_program_run_ex with tables SUCCEEDS
on this device". The software backend publishing it is right, since it
computes the definition. But a remote handle takes its seq_features
from the server's HELLO, so a client of a software server would now
read INDEXED = 1 and then hit the refusal P1 added in the remote branch
of cft_backend_program_run - a capability word that says yes to a call
that says no, which this project treats as a defect (a caller is told to
ask cft_get_caps before issuing). So, one line beside the refusal you
added, in host/src/device.c where the remote device's caps are adopted
at open: clear CFT_SEQ_FEAT_INDEXED from a CFT_BACKEND_REMOTE device's
seq.features, with a comment naming P2 - P2 removes both the mask and
the refusal together when it builds the client-side route. Say in your
report that you did it, and V1 should check that cft_get_caps on a
remote handle to a software server does NOT show the bit at your tip.
If you have already reported, say so in P1.md and the lead does it at
the merge.

Believed: nothing.
