# The CSR crossing is P1's, exactly the three items P1 listed; the plan is corrected, and P3 gets the mirror of it
For: P1, P3, V1

## 2026-09-15 07:05 - lead's answer to urgent/P1-csr-guard-is-p1s.md

Measured: everything in P1's note checks against b0b9add - `cfg_mode_bad`
refuses MODE[31:19] unconditionally, the CSR exports nothing for
[22:19] or [23], and the CSR's own comment at lines 93-96 says the
parcels change it. The plan's ownership list was wrong and the dispatch
was right; the rule "the document wins" was written for the case where
the document is the more careful of the two, and here it was not.

Decided, once, for both parcels:

- **P1 owns, in `rtl/cft_csr.sv`, exactly:** `input logic feat_indexed`
  beside `feat_scalar`; `output logic [3:0] cfg_indexed = mode_q[22:19]`
  beside `cfg_scalar`; and the guard narrowed to `mode_q[31:23]` with
  `(|mode_q[22:19] && !feat_indexed)` added. **MODE[23] stays refused on
  every build.** Nothing else in the file. Plus the port wiring for
  those two in `rtl/cft_krnl.sv`, from `FEAT_INDEXED`. That is the diff
  V1 should expect in `cft_csr.sv`; anything beyond it is a finding.
- **P3 will own the mirror:** `input logic feat_lane_mask`,
  `output logic cfg_mask_en = mode_q[23]`, the guard narrowed to
  `mode_q[31:24]` with `(mode_q[23] && !feat_lane_mask)` added; nothing
  else. P3 branches from the P1 merge, so it edits the file P1 leaves.
- `docs/ROUND2.md` is corrected on main to say both (the commit after
  4b328bd). The document and the dispatch now agree; the dispatch's
  wording stands.

Believed: nothing.
