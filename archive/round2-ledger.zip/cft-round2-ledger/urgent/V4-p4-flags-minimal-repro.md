# The P4 FLAGS leak in two runs and no sequencer: an elementwise run that underflows, then an EXACT reduction, and the reduction reports UNDERFLOW
For: P4, lead

## 2026-09-15 10:45 - V4, follow-up to urgent/V4-p4-flags-regression.md

**The reproduction, as small as it goes.** Two runs through one
`cft_krnl`, nothing else:

1. elementwise fp32 `CFT_FMA`, n = 4096, `a[i] = b[i] = 2**-100`,
   `c[i] = +0`. Every lane's product underflows. FLAGS = `0b11000`
   (UNDERFLOW|INEXACT) - correct for that run.
2. `CFT_SUM` over **1000 copies of 1.0** at fp32. Every partial of the
   counter's tree is a whole number below 2**24, so the whole run is
   EXACT: `fsum` gives `0x447a0000` and flags **0**.

| | d | FLAGS |
|---|---|---|
| run 2 from reset, b0b9add | 0x447a0000 | 0b00000 |
| run 2 after run 1, b0b9add | 0x447a0000 | **0b00000** |
| run 2 from reset, 6b5582e | 0x447a0000 | 0b00000 |
| run 2 after run 1, 6b5582e | 0x447a0000 | **0b11000** |

Same reduction, same operands, same bits out - and FLAGS depends on
what ran before it. That is the determinism property, not a cosmetic
one.

**The cycles, from an instrumented copy** (a `$display` on the new arm,
counting accepted array edges since `start_accept`; `make redprog` at
6b5582e):

    [V4LEAK] edge=0  wide_f=11000 arr_lf=0001800000 lane0=00000 prec=0 lv=0 wqv=0 rq=0
    [V4LEAK] edge=1  wide_f=11000 arr_lf=0001800000 lane0=00000 prec=0 lv=0 ...
    ... through ...
    [V4LEAK] edge=15 wide_f=11000 arr_lf=0001800000 lane0=00000 prec=0 lv=1 ...

Edges **0 to 15** - exactly `LATENCY` accepted edges, i.e. the whole
window in which the array is still returning work that entered it
BEFORE this run - and at edges 0..4 `lane_valid` is LOW, so the array
is not even accepting. `arr_lf = 0x0001800000` is lane **4** alone
holding UNDERFLOW|INEXACT; `lane0_f` is zero throughout, which is why
the accumulator's own OR (`RED ... flags=10000`) is right and only
`flags_acc` (`DONE ... flags=11000`) is wrong.

**The shape of a fix is yours, not mine** - but note that the array
already produces the qualification this needs: `cft_lanes.out_valid`
is a one-cycle pulse in the cycle `d` and `lane_flags` hold a result,
and `cft_engine_stream` leaves that port unconnected (`.out_valid()`)
at both instantiation sites. The elementwise path does not need it
because `collect` is its own `LATENCY`-deep delay line, and the
accumulator does not need it because `res_v` is; the new arm is the
only reader of `arr_lf` with no delay line of its own.

Measured, all of it, from clean builds. Believed: nothing.
