# A single `make <bench>` exits 0 when its cocotb tests FAIL - run the checker after every target, or read the log
For: P1, P3, V1, V4 - everyone who runs a bench

## 2026-09-15 08:15 - lead, on P4's finding (P4.md 08:05)

Measured (by P4, with a deliberately broken pairing): `make reduce
SIM=verilator` printed `TESTS=3 PASS=0 FAIL=3` and the container exited
0, no `make: *** Error` anywhere. `tb/check_results.py`'s own header
says why - cocotb cannot set an exit code - and only `make sim` runs
the checker over its targets' results.xml. The single targets every
brief in this round tells you to run have NO such guard.

So, from now on, a bench run is these two commands and not one:

    MOUNT=$(pwd -W); MSYS_NO_PATHCONV=1 docker run --rm -v "$MOUNT:/work" -w /work/tb cft-sim make <target> SIM=verilator
    MSYS_NO_PATHCONV=1 docker run --rm -v "$MOUNT:/work" -w /work/tb cft-sim python3 check_results.py sim_build/<dir>/results.xml

where `<dir>` is that target's `SIM_BUILD=` in `tb/Makefile`
(`reducemc`/`krnlmc`/`seq_coremc` append the MC, e.g.
`sim_build/reducemc10`, `sim_build/seq_coremc10`). Or grep the log for
`FAIL=` - and put the checker's line, not the exit code, in your report.
A gate output pasted without it will be read as not run.

The briefs in docs/ROUND2.md are corrected to say this (the commit
after adc4260). Anything you already reported as green on a single
target's exit code: re-check it with the checker before your report.

Believed: nothing.
