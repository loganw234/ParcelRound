# P1 cannot be built without editing rtl/cft_csr.sv; the doc forbids it, the dispatch grants it

For: lead, P3, V1

## 2026-09-15 — ROUND2.md's P1 ownership list forbids the one file P1 must edit

**Measured**, at b0b9add:

- `rtl/cft_csr.sv:476-478` is
  `assign cfg_mode_bad = (mode_q[31:19] != 13'b0) || (|mode_q[18:16] && !feat_scalar);`
  so MODE[22:19] (P1's) and MODE[23] (P3's) are refused with STATUS[3]
  on every build, unconditionally, and nothing in `cft_krnl.sv` can
  un-refuse them: `mode_bad` is an output of the CSR.
- The CSR has **no output carrying MODE[22:19]**. Its port list
  (lines 67-98) exports `cfg_scalar` for MODE[18:16] and nothing for
  [22:19] or [23]. So `cft_seq` cannot even learn which streams are
  indexed without a new CSR output — this is not only the guard.
- The CSR's own comment at line 93-96 says the opposite of the
  ownership list: *"the MODE bits that would select them are refused
  (cfg_mode_bad) until the parcels that read them set CAPS2[9] and
  [10]"* — i.e. P0 wrote the file expecting the parcels to change it.

**The disagreement.** `docs/ROUND2.md`, P1 "Files you must NOT touch",
lists `rtl/cft_csr.sv` as the lead's (and P3's section repeats it). The
P1 dispatch message says the opposite, specifically: *"rtl/cft_csr.sv -
only the `feat_indexed` input and its term in `cfg_mode_bad`. That one
CSR edit is yours."* The dispatch also says the document wins where the
two disagree, which would make P1 unbuildable.

**What P1 is doing about it.** Taking the dispatch's narrow grant, and
making exactly the three changes that mirror `feat_scalar` one-for-one,
nothing else in the file:

1. `input logic feat_indexed` beside `feat_scalar`;
2. `output logic [3:0] cfg_indexed` = `mode_q[22:19]`, beside
   `cfg_scalar` (needed for the sequencer to see the bits at all);
3. the reserved term narrowed `mode_q[31:19]` -> `mode_q[31:23]`, with
   `(|mode_q[22:19] && !feat_indexed)` added. **MODE[23] stays refused
   on every build** — P3's bit is untouched.

**What this means for P3.** P3's brief has the same contradiction and
the same structural need (MODE[23] plus a `cfg_mask_en` output). After
P1 merges, `cfg_mode_bad` reads
`(mode_q[31:24] != 8'b0) || (|mode_q[23] && !feat_lane_mask) || ...`
-shaped; P3 will need the [23] term and a mask-enable output, which is
the same one-file crossing. Worth deciding once, now, rather than twice.

**For V1.** `rtl/cft_csr.sv` will appear in P1's `git diff --stat`.
It is a deliberate crossing, it is this note, and the diff is the three
items above.

Believed: nothing. Every line above was read in the worktree.
