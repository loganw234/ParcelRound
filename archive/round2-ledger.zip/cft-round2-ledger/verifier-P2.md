# verifier-P2.md — V2, verifying parcel P2 at 3d129ee

Append only. Entry format is the README's.

## 2026-09-15 13:34 - one DEFECT in P2 (an out-of-bounds read before the n-sanity refusal), the "4,720 checks added" figure is 4,676, and three merge items that are not P2's

Measured in a clean worktree at
`3d129ee93fc0879791f7ad5542642fb8d3235d95` (branch v2-review, base
`e0f211f` confirmed by `git merge-base`), every test executable rebuilt
by name and time-stamped 13:11, and from copies of the tree under
`C:\Users\logan\AppData\Local\Temp\cft-round2-V2` — the worktree itself
was never patched.

**1. DEFECT, and it is the merge's to decide on.** In
`host/src/device.c`, `cft_run_ex`'s per-index bound loop runs BEFORE
`run_impl`'s `if (n > ((size_t)-1) / esz) return CFT_ERR_INVALID_ARGUMENT`
and before its `if (!d)`. So an `n` that the dense path refuses as an
argument error without touching a byte now walks the caller's index
table for `n` entries first. Reproduced:

```
n-sanity: n = 2305843009213693952 (esz 8) with NO table   -> invalid argument
n-sanity: the same n WITH an 8-entry table on a           -> Segmentation fault
```

(`idx_a_src` large, so no entry is found out of range and the loop does
not stop.) `cft_run` and a dense `cft_run_ex` refuse the same `n`
immediately at both tips. The class of caller mistake is the ordinary
one — an element count computed from a subtraction that underflows, or
bytes passed where elements were wanted — and the check that exists to
catch it is now behind an O(n) read of caller memory, in the call whose
own comment says "a device must never read past a buffer for a caller".
`seq_check_round2` in `program.c` has the same shape, but a program run
never had an `n` sanity check to be overtaken, so that half is P1's
inheritance and not a regression; the elementwise entry point IS a
regression, because it had one and still has it, one call later.
One hoisted check fixes it. V2 changed nothing.

**2. The report's "4,720 checks added" is 4,676.** Measured, both
built from clean trees on this host: `device-test sw -n 32` is 4,078 at
`e0f211f` and 8,754 at `3d129ee`; 8,754 - 4,078 = **4,676**. 4,720 is
8,754 - 4,034, and 4,034 is the number the lead RETRACTED at 11:52 as a
stale binary's. The per-format addition is 1,169 x 4. Separately,
`remote-test` against one loopback server is 354 at `e0f211f` and 419 at
`3d129ee` (+65). Nothing else moved: every pre-existing stage's
increment is identical between the two tips (boundary +3, sum +64, +4,
+20, dot +33, sumsq +48, sumabs +48, maxall +64, per segment +280, at
all four formats), which is the evidence for "every existing call is
unchanged in shape and behaviour".

**3. `host/include/cft.h` now says four things that are false**, and it
is not P2's file (the brief's "Not yours"), so it is the merge's:

- ~line 694: "a REMOTE handle does not show INDEXED and refuses an
  indexed program run by name until parcel P2 builds the client-side
  route" — it shows it and runs it; measured, a remote handle's
  `seq_features` is `0x0000271f`, identical to the software backend's.
- ~line 697: "The elementwise tables of cft_elem_args (P2) ... are
  refused BY NAME on every backend until their parcels land."
- line 2488: "a, b, c, d — as cft_run's, and **d may alias any of
  them**" — false whenever a table is present; that is P2's new rule
  and it is documented only in HOSTAPI.md.
- lines 2504-2505: "DECLARED at 0.14 and refused by name on every
  backend until P2 lands".

`docs/COMPATIBILITY.md:632` also still reads "no new surface until P2".

**4. `bindings/wasm/wasm_api.c` has no `cftw_run_ex` at P2's tip** —
zero occurrences of the string anywhere under `bindings/`. The lead's
11:58 entry decided "P2's scope on the bindings is exactly the pure
pass-through export `cftw_run_ex` in `wasm_api.c`" and told the verifier
to expect it; P2's 13:05 correction re-argued for leaving `bindings/`
alone and has no answer in `lead.md` (whose last entry is 12:56). V2
reports the state of the tree and leaves the reconciliation to the lead;
V2's dispatch brief says the omission was accepted.

**5. Two things no gate holds, for the card day.**
`bus_out` is never compared between an indexed run and the dense one —
`grep bus` over the whole new `device_test.c` leg finds nothing. On a
device the composed route returns `cft_program_run_ex`'s STATUS word
where a dense elementwise run returns the engine's; both are 0 on this
host (measured, on the shipped route and under control A), so nothing
can be said about a tile. And on an XRT device that publishes the
sequencer and CAPS2[9] but NOT CAPS2[7], `cft_run_ex`'s scalar refusal
at device.c:1940 fires BEFORE the R16 fork at device.c:1285, so a scalar
operand beside an indexed one is refused for a capability the composed
route does not use — P2's whole point about the constant bank is that it
needs no MODE[18:16]. Read, not run; there is no card. It refuses a call
that would have worked, which is the safe direction, but it contradicts
the mechanism.

Everything else V2 attacked is confirmed and is in V2's report to the
lead: the composed route reproduces (control A gives 8,754/0, identical
to the shipped route, and api-test passes); a scalar in every position
beside an indexed operand at every format matches the dense run over
(scalar repeated, gathered) on both routes; overflow, underflow and
invalid raised only through the gather match exactly; the RTL's
`rd_need` arms are gated on `!pw[27]`/`!pw[28]`/`!pw[29]` so a constant
marks no stream; the composed image's bytes decode to the documented
shape with the scalar's bytes in the constant bank and the scalar
pointer never in `strm[]`; a gathered RUN is byte-for-byte the same size
on the wire as the dense one; and an off-by-one bound check is caught
cleanly by api-test alone, with no crash.

Believed: nothing. Every number above is a run or a read in this
worktree or in a copy of it.
For: the lead, the merge, P3 (item 3's cft.h sentences sit beside P3's)

## 2026-09-15 13:59 - re-check at 7309864: all three findings HOLD; the check-count arithmetic derives; the four cft.h sentences and the missing wasm export are still open

Measured in the same worktree, `git checkout -B v2-review
worktree-agent-a20b1caece3ff53ee`, HEAD
`7309864443d83bdddb58d4d757a4ef72b16be407`, one commit over 3d129ee,
4 files / +371 / -223. Every test executable rebuilt by name and
stamped 13:50; build exit 0 with only the pre-existing `bi` warning
(now `device_test.c:4286`). Controls built from COPIES of the worktree
under `C:\Users\logan\AppData\Local\Temp\cft-round2-V2`; the worktree
was never patched.

**1. The out-of-bounds read is gone, and nothing in `cft_run_ex` reads
through a pointer any more.** Read top to bottom: `cft_run_ex` now does
`!dev/!args`, `struct_size`, `scalar_mask & ~7`, the scalar-with-NULL
rule, P0's four shape rules and the unread-operand rule - every one of
them a test of a POINTER'S VALUE or of a `size_t`, and not one
dereference of a caller's array. `cft_format_size` is no longer called
there at all. `run_impl`'s order is now: format, attribute, opcode
range, format_mask, reduction, opcode group, IMUL, `n == 0`, `!d`,
required-operand-NULL, `n > SIZE_MAX/esz`, THEN the aliasing rule and
the bound loop, THEN the fork.

Measured with a driver that passes a POISONED table pointer
(`(uint32_t *)0x10`), so any dereference faults - 18 checks, 0 failed:

```
n = 2**61, no table                          -> invalid argument
n = 2**61, an 8-entry table, src 0xFFFFFFFE  -> invalid argument   (was SIGSEGV)
n = 2**61, table pointer POISONED            -> invalid argument
bad format + poisoned table                  -> invalid argument
bad attribute + poisoned table               -> invalid argument
reduction opcode + poisoned table            -> invalid argument
opcode outside 0..255 + poisoned table       -> invalid argument
n == 0 + poisoned table                      -> ok
d NULL + poisoned table                      -> invalid argument
FMA with c NULL + a poisoned table on a      -> invalid argument
a NULL + a poisoned table on a               -> invalid argument
      | cft_run_ex: idx_a indexes operand a, which is NULL
idx_b on an ADD + poisoned table             -> invalid argument
```

The poison address is a real witness, not a decoration: a standalone
program that reads `(const uint32_t *)0x10` on this host segfaults
(exit 139), so any dereference in the cases above would have killed
the process rather than returned a value.

A NULL operand the opcode REQUIRES is refused by `run_impl` before the
table is touched; a NULL operand that IS the indexed one is refused by
`cft_run_ex`'s shape rule, which reads only the pointer's value. Both
rules still fire on real input (bound, exact alias, one-element
overlap), and a dense run may still alias `d` with `a`.

**Control D1** (the `n > SIZE_MAX/esz` check neutered in a copy):
`api-test` **segfaults, exit 139**. So the new api-test case is a live
gate. Worth saying precisely: its failure signal is a CRASH, not a
`CHECK` line - which is unavoidable, since the property is "no read
happened" and the only faithful witness of a violation is the fault. A
regression cannot pass it silently, which is what matters.

**2. CAPS2[7] gates the dense route only, and the placement is
load-bearing.** Controls from copies, each with `CFT_SEQ_FEAT_SCALAR`
forced absent AND the backend gate relaxed so the refusal is reachable
on this host; in all three the DENSE scalar run is refused, which is
what proves the control is live:

| control | fork | scalar beside a table |
|---|---|---|
| D2 | composed on every backend | **ok (ran)** - the constant bank |
| D3 | D2 + the refusal moved back AHEAD of the fork | refused, CAPS2[7] |
| D4 | fork as shipped, so this backend takes `run_gathered` | refused, CAPS2[7] |

D4 is the evidence for P2's `-DCFT_NO_PROGRAM` claim without a separate
build: `run_gathered` re-enters `run_impl` with no tables and reaches
the refusal, so a profile that cannot compose is refused exactly as
before. `device-test sw -n 32` on **D2 is 9,554 / 0**; on **D3 it is
8,658 / 112 failed**, one per (scalar, indexed) pair, all
`idx+scalar ... was refused on the device`. 112 is the pair count
below, so the control's failure count derives rather than being
counted.

**3. The pair sweep is real and its 800 derives.** `device-test` prints
a pair count per (format, opcode): fma 6, select 6, and 2 each for add,
sub, mul, min, maxnum, cmplt, ixor, ishr - **28 a format, 112 over the
four**, which is exactly `3*2` for the two `need == 7` opcodes and
`2*1` for the eight two-operand ones, with the two unary seeds
contributing none. `compare_indexed_scalar` has 11 `CHECK`s, one of
them the out-of-memory guard outside the loop, so **10 a pair**; the
old version had 8 and ran once for each of the 10 qualifying opcodes.
`112*10 - 40*8 = 1120 - 320 = 800`, and `8754 + 800 = 9554`. Measured
9,554. The program form IS rebuilt per pair (`cft_program_load` inside
the `(s, x)` loop, freed each time) - though the IMAGE bytes depend
only on the scalar's position, since the streams pack down in operand
order; what changes with the indexed operand is which stream slot
carries the table, which is the half that matters.

**4. Nothing in the dense path moved.** `device-test sw -n 32` stage
increments are identical to V2's 8,754 breakdown at 3d129ee - +3, +64,
+4, +20, +33, +48, +48, +64, +280 in every format block - and the only
change is +200 a format. `sw -b -n 32` is 4,366 / 0, unchanged from
e0f211f. `api-test` all contract checks passed; `seq_check.py
--trials 200` agrees on every program; `test_seq.py` 66 passed;
`remote_check.py` every check passed (its own server on a free port, stopped by PID; none left afterwards). `gcc -DCFT_ENABLE_XRT`, `-DCFT_TINY`
and `-DCFT_NO_PROGRAM` each compile `device.c` warning-free. An
independent second implementation of the sweep (V2's own, 24 FMA pairs
over four formats) and of the flag isolation gives 196 checks, 0
failed, with the same fp64 flags as before: overflow `14`, underflow
`18`, invalid `01`, against a dense-over-source of `10`, `00`, `00`.

**5. Still open, and none of them P2's.** The four false sentences in
`host/include/cft.h` (lines 695, 698, 2488, 2505) and
`docs/COMPATIBILITY.md:632` are untouched by this commit, as expected -
`cft.h` is not P2's file. `bindings/wasm/wasm_api.c` still has no
`cftw_run_ex`. And for the merge note: the total added against
`e0f211f` is now **9,554 - 4,078 = 5,476** device-test checks.

One cosmetic thing, not a finding: the hoisted block opens
`if (tables_present(tab)) { ... }` and then tests
`if (tables_present(tab))` again inside it for the aliasing half, with
the inner body left at its old indentation. Dead condition, correct
behaviour, compiles clean.

Believed: nothing. Every number is a run or a read in this worktree or
in a copy of it. Verdict: **all three findings hold; no new defect.**
For: the lead, the merge
